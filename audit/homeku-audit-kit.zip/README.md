# HOMEKU — kit audit 2.3

Input: MP4 asli terpisah + ZIP ini. Hasil audit kelak satu ZIP tanpa video.

1. Ekstrak empat file ini. Jalankan python homeku_runtime.py --output . untuk memulihkan runtime dan panduan lokal berhash, tanpa jaringan. Python3.11+, Pillow, jsonschema, FFmpeg/ffprobe diperlukan.
2. Jalankan python tools/audit.py inspect /path/<id>.mp4. Baca audit/visual-audit.md; kerjakan pengamatan shot/kamera/desain terlebih dahulu. Baseline6FPS/native, pendalaman10FPS/native sesuai pertanyaan. Jangan menganggap ekstraksi sebagai viewed.
3. Setelah simpulan visual diperiksa silang, baca audit/json-guide.md, audit/protocol.md, audit/rubric.md dan docs/contracts/package-v2-3.md. Isi template-audit.json dan template-audit-info.json di work/. Placeholder bukan hasil audit.
4. Baca audit/README.md untuk perintah draft-v2/review. Sumber2.3 → report2.2.2/media2.2.0. MD enam bagian dihasilkan renderer; media/font diterima tetap. Tampilkan seluruh kandidat untuk koreksi pengguna.
5. Setelah persetujuan keseluruhan terbaru, baca audit/prompts/03-export.md. export-v2 --source /path/<id>.mp4 --receipt work/review.md.json membungkus byte snapshot yang sama. Contoh teks persetujuan di dokumen bukan persetujuan nyata.

Panduan lingkungan: audit/providers.md; koreksi: audit/prompts/02-correct.md. Tidak ada konfirmasi tambahan antarputaran internal. Semua shot moderate boleh. ZIP final tanpa MP4, frame kerja atau receipt. Kontrak lama tetap menurut versi masing-masing.


## Inventaris resource lokal

| File | SHA-256 |
| --- | --- |
| tools/audit.py | 79dfa886d986fd4d4bf9d3ed4ddc7dfc3ccfa82e2a980c09c0c09727b41022a4 |
| tools/homeku/__init__.py | 2b5f65b3abc6dc24856fb05e4b5758738e67aae209f4352a5929bc9ea4260d66 |
| tools/homeku/common.py | e9fce85aa4cd50f6f8e73d68cd7aeb90d9e82dffdf4a6b67f66f37dde59d95b4 |
| tools/homeku/markdown.py | 98c8fce8d82e826c7bb1e674bdfe2c7f235c3cdf0a7ecdd2fae75d0763e2baeb |
| tools/homeku/validation.py | 1a642ea79ef339bdc67c7af03f75f8b9865cd5d7dddb1170b01150cd76352d52 |
| tools/homeku/exporter.py | 91209e7280c38848678e7c587552243c8d0a9590d27da5207ee3d9bda533969f |
| docs/contracts/manifest-v1.schema.json | 2646fc5eabc6c99044ee9ee27b2fc6af2a5cfc63279769908b04a46903be8852 |
| audit/template-analysis.md | aa5aa2dd50acdb034d63b2f93e9c1664ffaea554907f3dd2b6d5d57338aa7ded |
| tools/homeku/video.py | 76494ee7ad884634ac175df743c21e3e0e7abb3eacd6cc8e1195fff2fb0fc13a |
| tools/homeku/models.py | c9d5e6e137d51cdb299e9b170f0e686a98dd2d8d917368f48cc50dcfc5470997 |
| tools/homeku/media.py | a5cda699414a2d7db18d76f4d741e5fba77c66c0b2bc9bfb451a61562271de50 |
| tools/homeku/reporting.py | 5c72bc65b2c79906731de98125c4b76e96aa3bc2b1e98800a8c383972fdea696 |
| docs/contracts/audit-v2.schema.json | a383005f6724ed1d0e254073ff39c0919bf95c4b838b82f46e5bfe5ffc83470f |
| docs/contracts/manifest-v2.schema.json | e1dd593c3f835090c60e351a3c30e582b2625e1f1bb04e1a43438dcf2ceba904 |
| tools/homeku/media_v2_0.py | f2c7232a9c09ab55a4190b2e0905e9c8b502b68decf23d5bf16ce379c6d204ab |
| tools/homeku/media_v2_1.py | ba0df816b72c760a90c5ebf9d41804e84613d7bff293de8aa84d314df0f5699c |
| tools/homeku/media_v2_1_1.py | 9875b1a4eabd71388db59e8c21f39f18e41440becd8f1cf5a387b9d8b05f936c |
| tools/assets/templates/analysis-2.1.2.md | 4d3eed42a800cc8f4806013dbdf7c7801eac457f77cc163066814a626aa9a0be |
| tools/assets/templates/analysis-2.1.1.md | 6793a4be71cf4ad1d1222aba3d5354e397ee6b9c4f21213de33f4911d4c15d82 |
| tools/assets/fonts/DejaVuSans-Bold.ttf | 5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895 |
| tools/assets/templates/analysis-2.1.0.md | c34e4df89b949b437c9f7010c778f0165a12f9b28fe8597faf6e6d2e3a52be85 |
| tools/assets/fonts/DejaVuSans.ttf | ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280 |
| tools/assets/fonts/LICENSE.txt | e180b3d65bf650dffffd71dd21b6180767b469a18dd87e1d8552be69bb9ecdf0 |
| tools/assets/templates/analysis-2.0.0.md | 25ebc37f6bfe06d3b5bc7d51ef81c6fb02b25a97b5b9cb569ebaafc0466f5c7a |
| tools/homeku/reporting_v2_legacy.py | a11e22c7cfce39da7f4c61dd3dd33814c8b1f267a35f1c89a33b026707df0c5e |
| tools/homeku/media_v2_1_2.py | d824aca4cc5e9ef89ac3ff08f284961058e0d0c5f00e889295667289e9d98c6d |
| tools/homeku/camera_pattern.py | e0cb8ff09300145cfd86cf7b5920034f8b814c02e64a43c97fbabbef70ac3d33 |
| tools/homeku/media_v2_2.py | ca1189a4f7d20c43cdf52c6d2db58e3a1ecee606934010500c633246dcdb15c4 |
| tools/homeku/reporting_v2_2.py | e5371d8105704e22d7833be9e52ad1a5f9ad316d5cc83a131296ad68466dc4cc |
| docs/contracts/audit-v2-1.schema.json | 8018c2210ff0c21cd82ba75c08becd4cff9e75dca1e6ad1719e933528006ec5a |
| docs/contracts/manifest-v2-1.schema.json | e3fdea353dc5725f1ff7452a258b3349957f019db667c93e68b8a4fbeec551f1 |
| tools/assets/templates/analysis-2.2.0.md | 1e909dc3e97016221ca1331e0243497557921d89694b3d425ec98f0d98a481e0 |
| tools/assets/layouts/media-2.2.0.json | 174b4bd2e59497d43449375f77ecf4ff91bc2fb7cb79ee7f9d65cf56f70b590b |
| tools/homeku/versions.py | 74b760a9dd6a766cdd245d6340c98c29d74d993fdc5228a1d56ad8d549f152e8 |
| tools/homeku/audit_quality.py | efd13f3177944387ac1b30fc40a9806278682df6214aee0ce64e85d704211fe7 |
| tools/homeku/report_validation.py | 48a1a2da1d3b14183e9a5fe7e032ae7930eac30cde4dd18c4788f0b3a771cd56 |
| tools/homeku/reporting_v2_2_1.py | 39f916996e135da297d78050bd7ce03eb3c574a082174cd5848e7e51bb91d293 |
| docs/contracts/audit-v2-2.schema.json | 501bdec8f7e2f8ad128958786ff2369634edd90fd7f03089d7726571e91df3d7 |
| docs/contracts/manifest-v2-2.schema.json | 2e5b11e1bdd0c11bcdda9b13171a44bc60302293fcdeb30637dcb800ebf7591b |
| tools/assets/templates/analysis-2.2.1.md | 79f5550cc081d9c0708e75de20f3aca82baa94aa29e9bd1b4d63d795d2e0e0ad |
| tools/homeku/reporting_v2_2_2.py | b81a06a1f037ecb33aeb7eeadcc160c836be63e25c30e477bb9cc7b624492a51 |
| docs/contracts/audit-v2-3.schema.json | 11b1d53842f926780502869f35d7e775fe2405bf6ad28809e9207a2fdf656faf |
| docs/contracts/manifest-v2-3.schema.json | 169612a7b551be024600b647510bbdb1045e4133a4071c6f87f4551119ad4dba |
| tools/assets/templates/analysis-2.2.2.md | 79f5550cc081d9c0708e75de20f3aca82baa94aa29e9bd1b4d63d795d2e0e0ad |
| audit/README.md | 78b710e6138e889fbd40c010ab0e829bd3e01513dbfdf93e73fff0e387947f73 |
| audit/visual-audit.md | b5d434b499cc6ec23d0732761abc5c0f981c8722556f1338fc2ac1c785bc7d22 |
| audit/protocol.md | aca53c7720be6b3f9bce553063e65479f9a8f7195c836784ed5e662868c30150 |
| audit/rubric.md | 7c42e3d353cb261c696ef5b70d92c06a7de6ff6dcc925399ab444117e3580dc5 |
| audit/json-guide.md | 270a15b83af51de81d5d7a5c7eaffc472d8bd12d237af827cb47438a931766cb |
| audit/vocabulary.md | 4d5f68146ad962a274f0aeadf05886d58fd7ad2cd4003369e7898d77f52a4b81 |
| audit/providers.md | 8628d6b31181ae024d80eafa324482a40ba37c99466cae3675bcc5b8614d6e81 |
| audit/calibration.md | cd82efb308773a43042a1185b8d3dd5f0835589a6fa0537474bcc457765c7a84 |
| audit/prompts/01-audit.md | 1d6f0a04563ea21388893152b21873be06298090353da9ccfbc7b1c456e38671 |
| audit/prompts/02-correct.md | d19cd50fb2f536621211e85eb9e8a880e6ed571b5505dcb4425ae3ab682b3fb7 |
| audit/prompts/03-export.md | d549a2f7facdc7ddee7385496830b6bdbd4828a8bdcb5beb9da4ba9cbde4063d |
| docs/contracts/package-v2-3.md | 3cfac1a516c9c047bc3d1f0f8cc4ba402dd22a3d24c5fe898bc92d99da3ecd12 |
| docs/contracts/analysis-v2-2-2.md | 6dbd90032efaf3da99fe4f902fbfc22541e65d73631b657cb7c550f4fed114ea |
| docs/contracts/package-v2-2.md | 680b330d6748626703b745b3c2ab2adb90590d91b30c2a3e93ef6568c80e9969 |
| docs/contracts/package-v2-1.md | 05d5545ad2fa0be9c6fcfd834beed11d09e9fe0787aeb86f5c476adced81cd6f |
| docs/contracts/package-v2.md | 25b3cfdf5604fbf758b333a6f9515804c8564350d593a9ef1b7127c43c31e920 |
| docs/contracts/analysis-v2-2-1.md | 00a9c738f7274eb618a080915b9d40408ab9a9674855f9ea138879ffa75e0ca0 |
