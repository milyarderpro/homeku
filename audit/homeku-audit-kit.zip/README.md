# Kit audit HOMEKU 3.1

Siapkan satu MP4 sumber terpisah dan ekstrak keempat file kit ke workspace chat. Jalankan `python homeku_runtime.py --output .` untuk memulihkan resource lokal. Audit memakai Python 3.11+, FFmpeg/ffprobe, serta dependensi di requirements.txt termasuk OpenCV dan NumPy.

Untuk Google Drive, simpan kit di root HOMEKU dan MP4 asli di HOMEKU/Video. Hasil disimpan di HOMEKU/Audit/<nama-video-tanpa-ekstensi>/.

Baca `audit/authoring.md` dan jalankan lima fase dalam satu chat memakai `audit/prompts/01-audit.md`.

1. Petakan cut dan siapkan frame baseline dengan `prepare`.
2. Audit kamera dengan `audit/visual-audit.md` dan `audit/camera-cases.md`, lalu jalankan `check-camera`.
3. Lengkapi desain, framing, panel dan Overview dengan `audit/design-audit.md`.
4. Jalankan `complete → check-input → draft → review → export` untuk menghasilkan ZIP final tanpa MP4.
5. Simpan `analysis.md`, `media/`, dan ZIP itu ke Drive, lalu verifikasi hasilnya. Tampilkan laporan, media, unduhan ZIP, dan status penyimpanan di chat.

Gunakan `audit/prompts/02-correct.md` atau `03-export.md` untuk melanjutkan sesi yang sama. Contoh JSON berisi data sintetis.


## Inventaris resource lokal

| File | SHA-256 |
| --- | --- |
| tools/audit.py | bbcab1b454d93aaf6678571a169e4944b066f5c0e678184e861ddbf412055ad6 |
| tools/homeku/__init__.py | 229779955f355dd66c0719feb9aa98ecd0217239d2a989b61c737856495d5803 |
| tools/homeku/audit_performance.py | f7f2dbb9103ff2b8a02b8efd8852a699442be404360d656b4d3adcd565295fba |
| tools/homeku/audit_quality.py | ffaab2f464becd0cb2404d5c3a9b6ed3b0b423c54d3110778562e942b5616217 |
| tools/homeku/audit_review.py | 5c81c21798dadbbc6f1d2b7ca2d46299bb90a421f1fc253caf9dfab4f4ff0f7c |
| tools/homeku/audit_session.py | ebe1e5abf06da54bc5931d893f2b353847d01e2d55d6cddb85b5dabee87df3c4 |
| tools/homeku/audit_workflow.py | f2058e2d9d95a2a98ad6c01e4c28f5508463dea6a2de2cc21c253bf08b5337fd |
| tools/homeku/authoring.py | 50d5bdfb6cae54f9f7bfb0df0ba9a39601e5e81d2b625b37d7e42346ec136b19 |
| tools/homeku/camera_anchor.py | 8b9c25dbc6ff2097abcd43325ead2793a7580dbcd2c74059e2c254a10f663047 |
| tools/homeku/camera_notation.py | 2e3329def5b19e0d247029149683fbc81b01a891e6c1f173cadbaf8d509412d8 |
| tools/homeku/camera_pattern.py | c5708318a94415f68629d9703b7562f59e70b04d0f6ae28ede5ad627d52ea314 |
| tools/homeku/common.py | 84b7ef91c87be39753a8bca752557f8b9c16214bdfd6ac961326a924a47d8079 |
| tools/homeku/delivery.py | 8e52a35771e4a147cad20bd0d51b3376d21d9a313dad0521c2a0caea6ee61ed9 |
| tools/homeku/derivations.py | 726dfdb7986696293a437a5506a3bdcbf8ca500a2413efe326e7827da089c29f |
| tools/homeku/exporter.py | d6854a5e5157c0e0f130bf10b43c65260ebe5f0736cb9bb850dabb35e6757c5d |
| tools/homeku/media.py | 5e0c80a374cfd2190b8c98a34b0c34e82846cb6584a375a9299364009c6ca81a |
| tools/homeku/media_incremental.py | fa0316c02f5b7fe3e4df1a1e12ba21a64d5abe122b7135d216c5792cc4b1b919 |
| tools/homeku/models.py | d37412b8282c995cb8496f9f6f4e2817ce1654241c941e0c7b8c4006b59f397f |
| tools/homeku/motion_analysis.py | fe3f6f467fd9813b6a7951658f88042e9c95caf5cce05db0bcddfb78315618c2 |
| tools/homeku/package_manifest.py | fd6ac353a0c42439b7f1d82ac6816df1e69cb1c06fdd5e05b9a01d33e7da4cda |
| tools/homeku/preflight.py | be408b8c453ebea1c7e36e3e7793db3b00ae50805a8dbfc9f31ce48b8e7fc9af |
| tools/homeku/render_assets.py | c49719ad4f7e5dfba89dac89d876f1072c20518a36b0dd96a1f30774a81aa0dc |
| tools/homeku/report_validation.py | 6b152b9af0e07b32e1811453bc52ea83118491a569409fc05f754376c23ee228 |
| tools/homeku/reporting.py | 8547fcc78e7cb7008731271083522390eab16ce61a144543e870243dec27b002 |
| tools/homeku/storage.py | bbe7daf97d12e29adcc606bb136c37f134effde42a77d1d3fffb1fcdecad29c9 |
| tools/homeku/validation.py | ad40f2cb8283b7e617bb0ff38ea64bc3c77c5d6d9348e833fe05a1f6077dcf0b |
| tools/homeku/video.py | 6258f3b76234885cdbc9cc96a2a398526ae7b433efd76d7308564ae455c37e88 |
| tools/homeku/video_cache.py | cb5a63ac34e16d291704bf29e6cfc8e44f104e2ebed48e33696e41e361fca8aa |
| schemas/audit.schema.json | 855206a3e5e7c4bcca7361249a9550ab544cd895bb6fabb3e0548d930494ff76 |
| schemas/audit-info.schema.json | ea05be764a74394b1a85056837385d8c7446f1f9bf310855beb13b3d58b68c78 |
| schemas/manifest.schema.json | 09704e75d4ae0f4c4bc5aec932f0f47328c5ad2e165bba9b18a8b04f52d1b705 |
| schemas/reference-reader.schema.json | 9794da0f3293deadbd35616e9b9840b6de4c1e2605e3f5a8d14be811c282ead4 |
| schemas/search-index.schema.json | f65f47ce3fdbac9e128417793ad2e958a30a1011045142c1db272188a03dbd21 |
| tools/assets/fonts/DejaVuSans.ttf | ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280 |
| tools/assets/fonts/DejaVuSans-Bold.ttf | 5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895 |
| tools/assets/fonts/LICENSE.txt | e180b3d65bf650dffffd71dd21b6180767b469a18dd87e1d8552be69bb9ecdf0 |
| tools/assets/templates/analysis.md | 66a15912eb9782b1823ba9aa4dc00e190c2a67787c716979bc1614503266e1b5 |
| tools/assets/layouts/media.json | 8d7f59138e617569a2986a8f2bf35ef3609344efa088366ec77b171e25b10a3f |
| audit/README.md | f57c2f68d7c6d605947949048424799d6d5c1e11b8d65f9b9a4e04af2e3a1cda |
| audit/visual-audit.md | c26a13c57c2331960ca0aa06fbd5d6f1864f9d7bdec750e8e029e172d2971345 |
| audit/design-audit.md | 9f0ef143ae537adb63ec317425c203b02402bbf2f73f81e3802a0dd91ad2da96 |
| audit/authoring.md | 90e20e39aaa1de5983766c21b863494a54d5ae1cdae5927212c21bf59e777864 |
| audit/json-guide.md | 55daeaba5a92545907757715a2294efc13ae4c8aef9b6f1cf0c08cb68c1b9bf0 |
| audit/vocabulary.md | 4583f04cf171aaeb72f3332486e7b28cd17289e3a3685f64e8ae4d649e9629cb |
| audit/camera-cases.md | 938b46747e980becaea3d6d5356a97bbe1ccf176590c9339ba6a52fe50fd38b4 |
| audit/contracts/package.md | 19cb989c6c9e8349871d06763cf7721ac8b324d0c245d54ce5a4773d5f3adf60 |
| audit/contracts/report.md | 98957c6a60fd713c9bf590ac6a7db132a31f1f4908156bdd493d254d4818752a |
| audit/contracts/reader.md | 1c2b718b176958e224943c2ca450803959d256c56bf89dcf50864a1e45dc413a |
| audit/prompts/01-audit.md | b490b6c1b2df3e482350915af4f15cd9fd476ab14bae88c6944ea8c775ed3b16 |
| audit/prompts/02-correct.md | 1c792b44d6bc42c56002ace482e9d3cbe2dbbcd261728c0c6c9d4566e6dbc876 |
| audit/prompts/03-export.md | 6875a850199295aa92a482cd5926028f2a5120dcce36f0edab7bb9c6c03f7f7a |
| audit/template-audit.json | 2f4896281ac3b7efd284de57e473dd7de5816f976d1981c9afc126ee8647f7da |
| audit/template-audit-info.json | c41cd39166ec3172f3de82661be303239f22010c0868800cf34a6e46cddf6825 |
| audit/examples/normal/audit.json | 138f98aa0227fc9ff69001b3ed9ed61cca3ed25612b1ab4d43ee31e52b77ff82 |
| audit/examples/multi/audit.json | a2e854e548c9ed1e807cd14ae13ff85985ee2d350930eebfb1de4cfa3a81f4cb |
| requirements.txt | 63ac40ba5398341f4083ffdba8407f2a51f893d048b36536bda9776d4be7b34d |
