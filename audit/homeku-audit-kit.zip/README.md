# HOMEKU — kit audit V2

Input: satu ZIP ini dan satu MP4 terpisah.

Ekstrak empat file input, lalu jalankan `python homeku_runtime.py --output .`. Bootstrap memulihkan seluruh runtime/schema/font/lisensi dari payload lokal yang diinventarisasi; tidak mengunduh kode. Dependensi runtime: Python 3.11+, Pillow, jsonschema, FFmpeg/ffprobe. Baca seluruh panduan berikut. Placeholder template wajib diganti dengan hasil audit nyata. Versi sumber/paket 2.1; renderer/media/template 2.2.0. Jangan mengubah renderer versi lama.


---

<!-- Source: audit/README.md -->

# Audit HOMEKU 2.1 di ChatGPT/Gemini

Satu video per chat. Lampirkan **MP4 asli + homeku-audit-kit.zip**, lalu kirim prompt audit. AI menjalankan seluruh helper di workspace chat. Anda cukup meninjau laporan dan gambar, memberi koreksi, lalu mengunduh satu ZIP final. Sesudah menaruh ZIP di incoming/ lokal, jalankan `python tools/library.py ingest`.

## Alur singkat

1. AI membuka kit, membaca README, menjalankan `python homeku_runtime.py --output .`, lalu inspect video. Runtime/schema/template/font/lisensi tersedia tanpa repo penuh atau API AI.
2. AI menentukan cut nyata, memeriksa baseline 10 FPS seluruh shot + frame native awal/akhir, lalu memperdalam native bila arah/fase/tempo/detail belum jelas. Satu take melewati banyak area tetap satu shot.
3. AI mengisi `work/audit.json` dari template serta `work/audit-info.json` dari log nyata. Panduan JSON menjelaskan bidang dan bukti. JSON adalah satu sumber isi; MD tidak ditulis terpisah.
4. AI menjalankan draft-v2 dan review. Anda melihat Overview, Storyboard, kolase semua shot dan analysis.md manusia enam bagian dengan desain lengkap, posisi awal, kamera sederhana/teknis dan ritme. Nama gaya memakai bahasa Inggris; prosa Indonesia.
5. Bila perlu gunakan prompt koreksi. AI memperbarui JSON/log, merender ulang dan menampilkan hasil terbaru. Persetujuan satu aspek bukan persetujuan keseluruhan audit.
6. Setelah seluruh kandidat sesuai, kirim prompt ekspor. Export mengemas kandidat yang sama tanpa membuat ulang JPEG/MD/created_at. Anda mengunduh satu ZIP `<id>-r0001.zip` atau revisi yang benar.

Tidak ada review isi kedua setelah ingest. Kesalahan teknis harus diselesaikan sebelum penyerahan ZIP; helper tidak membuat atau menebak fakta agar lolos validasi.

## Perintah yang dijalankan AI

```sh
python homeku_runtime.py --output .
python tools/audit.py inspect /path/<id>.mp4
python tools/audit.py sample /path/<id>.mp4 --output work/baseline-shot-01 --start 0 --end <SHOT_END> --shot-id shot-01
python tools/audit.py sample /path/<id>.mp4 --output work/native-shot-01 --native --start <START> --end <END> --shot-id shot-01 --reason "Pan/orbit belum jelas"
python tools/audit.py draft-v2 /path/<id>.mp4 work/audit.json --audit-info work/audit-info.json --output work/candidate
python tools/audit.py review work/candidate/<id> --source /path/<id>.mp4 --output work/review.md
python tools/audit.py export-v2 work/candidate/<id> --source /path/<id>.mp4 --output work/final --receipt work/review.md.json
```

Opsi draft --overview-scale dan --storyboard-scale mengatur media gabungan; --scale mengatur foto kolase, --quality dan --columns tersedia. Default skala1/quality91/kolom multi4. Perubahan harus eksplisit, lalu kandidat lengkap dirender/ditinjau ulang.

Receipt dihitung helper dan tetap di luar kandidat; pengguna tidak diminta membaca JSON/hash. Receipt bukan persetujuan otomatis: export tetap menunggu pernyataan pengguna bahwa keseluruhan hasil terbaru sesuai. `--reviewed-sha256` tetap tersedia untuk pemanggilan teknis eksplisit.

Untuk revisi yang sudah aktif, `--supersedes work/supersedes.json` berisi revision/content_sha256 aktif yang benar; jangan mengarangnya. `--include-source` pada draft menyertakan MP4 jika sumber kanonis belum terverifikasi tersedia dengan hash sama. Input JSON/video disimpan di luar folder kandidat. Draft bisa dibuat ulang setelah koreksi; export tidak melakukan draft ulang.

## Isi paket dan media

Paket final berisi audit.json, analysis.md, manifest.json dan N+2 JPEG: satu kolase per shot, media/overview.jpg serta media/storyboard.jpg; source.mp4 opsional. Normal memakai tiga panel Start/Middle/End; multi area memakai panel dinamis yang cukup menjelaskan perjalanan. Overview seluruh area satu baris; Storyboard seluruh blok kolase vertikal. Setiap overview wajib composition_summary untuk komposisi wide, terpisah dari Camera Start sumber. Arah IN/OUT/netral/ambigu disimpan per fase; pola dihitung helper. Semua gambar berasal dari frame asli; tidak ada JPEG frame terpisah, motion/ atau seluruh rangkaian frame dalam ZIP final.

Kit input dan ZIP hasil berbeda. Kit input dikemas ringkas untuk batas lampiran provider, tetapi bootstrap memulihkan seluruh inventaris teknis yang sama dengan repo. Gunakan hanya alat yang benar-benar tersedia dan laporkan kegagalan spesifik; panduan lingkungan tidak menganggap nama model sebagai bukti kemampuan eksekusi.

Format sumber/paket **2.1**, renderer/media **2.2.0**. Paket2.0 tetap memakai versi renderer asal; tidak dikonversi diam-diam. Legacy 1.0/1.1 tetap dapat dibaca, tetapi prompt audit baru mengisi JSON V2. Pilot mencatat run nyata; kit siap tidak berarti tujuh pilot selesai.


---

<!-- Source: audit/json-guide.md -->

# Panduan pengisian audit.json 2.1

Gunakan template-audit.json untuk isi dan template-audit-info.json untuk metadata proses. Semua placeholder waktu/indeks/luas dan {{penanda}} harus diisi sebelum draft. Null yang sah (depth_direction ambigu, model_build tidak diketahui, atau metadata komponen yang tidak berlaku) dipertahankan sesuai bukti; jangan mengarang nilai untuk menghapus null. Setelah kit diekstrak, `template-audit.json` dan `template-audit-info.json` berada di root workspace; salin sebagai work/audit.json dan work/audit-info.json, lalu isi. Template bukan audit valid; jangan mengisinya dengan fakta contoh Willow Cottage atau nilai default ruangan.

## Siapa menulis apa

AI auditor menulis identitas/gaya, estimasi ukuran, narasi, klaim/status/bukti, interval shot/area/fase/tempo, komposisi, kamera sederhana/teknis dan pilihan panel. Helper menghitung metadata/hash/PTS, durasi tampilan, MD, layout/font, inventaris gambar dan snapshot. Ingest hanya memvalidasi serta membangun turunan.

| Bidang sumber | Cara mengisi |
| --- | --- |
| schema_version/id/revision | 2.1; ID mengikuti stem MP4; r1 untuk sumber baru, +1 dengan supersedes yang benar untuk revisi aktif |
| identity | Nama rumah deskriptif; primary_style, nama influences dan interior_style bahasa Inggris. style_names_language=en; penjelasan boleh Indonesia. Ciri, palet, suasana/lingkungan konkret. style_relations hanya family/blend/influence yang dinyatakan, bukan alias rekaan |
| size | scale/massing/vertical/footprint/proportions dan floor_area_m2 min/max positif berurutan. Estimasi luas lantai total rumah wajib diisi; basis/uncertainty hanya JSON, tampilan cukup 60–90 m² sebagai contoh format |
| profile | Seluruh aspek DNA kontrak ditulis eksplisit dengan id/aspect/value/state/confidence/evidence/area_ids/basis/uncertainty. Tambahkan interior-style dan nilai pengaruh diskret agar mudah dicari. Unknown bila belum diketahui; jangan menebak material fisik |
| areas | ID area fisik, label, functions dan visible_intervals waktu video. Bathroom + laundry dapat satu area/two functions; dua bathroom fisik mempunyai ID berbeda. Interval boleh overlap antararea dan berulang untuk area yang muncul kembali |
| shots | Satu take sampai cut nyata. start_s/end_s menutup durasi stream video tanpa gap/overlap. transition/continuity berdasarkan sumber; jangan membuat cut dari pergantian area |
| shots.route/area_relations | Rute kamera yang benar-benar dimasuki, penghubung/fokus dan interval. Area terlihat tidak sama dengan dilalui; route boleh kosong untuk pandangan beberapa area dari satu posisi. Hubungan memakai status/bukti |
| shots.design | architecture/furnishings/environment berupa paragraf konkret; area_ids mengikat tiap uraian. Semua area penting harus tercakup. Jangan mengisi inventaris generik atau memastikan yang tertutup |
| shots.facts | Klaim atomik id/domain/subject/attribute/value dengan area_ids, state/confidence/evidence/basis/uncertainty. Konfigurasi, orientasi, bukaan dan penyimpanan lebih berguna daripada warna saja. Label baru dan negasi tetap disimpan |
| composition | camera_position/direction/view_angle/height/tilt, foreground/depth/reveal, start/end_composition, motion_compatibility, focus/lighting. Posisi awal bukan otomatis frame overview akhir OUT |
| camera_summary/phases | Summary sama dengan urutan components fase. + simultan, → berurutan; phase-01 dst. mencakup shot tanpa gap/overlap. Komponen raw/parsed harus sama; gunakan helper component bila perlu. Simpan anchor, focus/area_ids, tempo, speed_change, basis/evidence/confidence/uncertainty |
| camera_simple/rhythm | Narasi Indonesia lengkap tetapi singkat untuk semua arah, kebersamaan/urutan, target dan ritme. Ditulis auditor; renderer tidak menerjemahkan notasi |
| tempo_profile | Interval tempo aktual sepanjang shot, misalnya moderate lalu fast. Perubahan tempo tidak otomatis fase kamera baru; ~2× adalah perubahan skala, bukan kecepatan |
| journey_dna | Wajib untuk multi area: lintasan, penghubung, peralihan fokus/reveal dan ritme. Normal boleh kosong bila tidak menambah penjelasan |
| panels/overviews | ID unik global, shot/area_ids, frame_index/PTS tepat dari inspect, role/label/reason. Normal tiga panel start/middle/end; tengah native terdekat titik tengah. Multi dinamis, awal/akhir dan momen penting. Overview tiap area biasanya awal IN/akhir OUT, boleh bukan panel kolase, tersusun dalam media/overview.jpg, satu baris. Isi composition_summary wajib pada setiap pilihan overview |
| uncertainty/review_summary/composition_notes/camera_notes | Pertahankan batas pengamatan serta penjelasan terkait, jangan menyelipkan status draf/final ke narasi manusia |
| relations/limitations | Hubungan antarshot dan batas keseluruhan yang benar-benar didukung; urutan edit bukan bukti denah atau satu rumah fisik |

## Overview dan arah fase

`shots[].overviews[].composition_summary` adalah satu paragraf biasa tanpa `>` atau Enter. Setelah melihat frame terpilih, jelaskan posisi kamera, arah pandang, sudut, ketinggian/kemiringan, cakupan wide, penempatan elemen, kedalaman dan pencahayaan. Ringkas dan konkret, bukan inventaris furnitur berulang. Judul Shot/Area/waktu dan blockquote ditambahkan renderer. Ini menjelaskan frame overview terpilih; `shots[].composition` selalu menjelaskan **awal shot sumber**, sehingga overview akhir OUT dapat berbeda.

`shots[].phases[].depth_direction` wajib: IN (maju), OUT (mundur), NO IN/OUT (tidak ada maju/mundur), atau null bila belum jelas. Gunakan bukti temporal dan komponen translasi yang eksplisit. Pan/orbit/zoom atau skala saja tidak menentukan klasifikasi. Fase Dolly-In eksplisit tidak boleh diberi OUT/NO IN/OUT; fase berlawanan arah harus dipisah. Bila ambigu, perdalam native dan catat batasnya; null bukan NO IN/OUT.

Helper menurunkan Camera Pattern dari fase: arah sama berurutan digabung, arah berubah dipertahankan, fase netral tidak menambah arah bila sudah ada IN/OUT. Orbit netral lalu Dolly-In menghasilkan IN. Fase ambigu membuat pola shot null (tampilan —). Antarshot memakai ` – `; pola campuran diberi kurung, misalnya IN – (OUT → IN) – NO IN/OUT. Jangan menambahkan camera_pattern manual ke audit.json.

Camera summary, components fase dan notasi raw ditulis satu paragraf; tidak ada Enter setelah → atau +. ~× adalah perubahan skala, bukan kecepatan. Native PTS tetap presisi penuh; tampilan memakai dua desimal.

## Status dan bukti

State: observed, uncertain, not-visible, not-present, unknown. Confidence: high, medium, low, unknown. Not-visible berarti tidak terlihat dalam bukti, bukan tidak ada. Selain unknown, klaim memerlukan bukti; uncertainty dan negasi tidak dihilangkan demi katalog.

Evidence menunjuk ID pilihan panel/overview, atau `frame:shot-01:42` untuk frame native yang tidak masuk kolase. ID bukti harus benar dan dalam shot/scope yang sesuai. Satu fase lintas area boleh memakai gabungan beberapa panel; tidak harus semua area terlihat dalam satu foto. Simpan bukti temporal sumber, bukan hanya tiga gambar final. Jangan memakai path frame kerja sementara.

## Metadata proses

Audit-info berisi method, limitations cakupan, ai provider/model/model_build yang diketahui, reviewed_ranges dan frame_reviews. created_at opsional dihitung helper saat draft. Model/build tidak diketahui tidak dikarang; model_build null. Gunakan sampling.json sebagai template record; isi viewed_frame_indices hanya setelah frame benar-benar dilihat. Baseline 10 FPS seluruh shot wajib selesai; pendalaman native ditambah sebagai record baru. Ekstraksi otomatis tidak boleh dianggap pemeriksaan otomatis.

Simpan sumber audit JSON, MP4 dan metadata kerja di luar kandidat. Koreksi JSON/log lalu draft dan review ulang. MD/media/manifest adalah hasil; jangan merawat fakta manual kedua atau memodifikasi hasil sesudah persetujuan. Receipt review mengikat seluruh kandidat, bukan hanya MD.

## Render dan pemeriksaan final

Sumber/paket2.1 → report/media2.2.0. Helper menghasilkan laporan enam bagian: Profil desain, Ukuran & proporsi, Shot Timeline, Overview, Storyboard, Shot Details. Timeline lima kolom memakai Camera Movement teknis; Tempo tetap di detail. A/B/C dan subjudul multi area bold; Overview dan kategori desain A memakai blockquote. Kamera regular satu paragraf. Nama gaya utama dan luas bold, tanpa catatan dasar/kepastian pada MD.

Inventaris tepat N+2 JPEG: media/shot-NN.jpg per take kontinu, media/overview.jpg satu baris, media/storyboard.jpg seluruh kolase vertikal. Kolase normal tiga panel, multi area dinamis dan kronologis. Semua foto native mempertahankan konteks/rasio; hanya camera: bold pada baris kamera, caption regular. Tidak ada JPEG overview lepas per shot atau motion/.

Default quality91, scale1, columns4. Bila batas media dilampaui, pilih --quality (60–98), --scale, --overview-scale, --storyboard-scale (0,1], --columns (1–6) secara eksplisit, lalu draft/review ulang lengkap. Jangan mengecilkan font/membuang panel/membagi file diam-diam. Tampilkan Overview, Storyboard, seluruh kolase dan MD sebelum pengguna menyetujui snapshot terakhir. Export memakai receipt di luar kandidat dan tidak merender ulang.


---

<!-- Source: audit/protocol.md -->

# Protokol audit HOMEKU V2

Workflow sumber/paket2.1 dan renderer/media2.2.0. Kontrak tetap provisional sampai pilot nyata selesai. Prinsip berlaku untuk ratusan sumber, bukan hanya tujuh pilot.

## Urutan audit

1. Buka kit dan jalankan bootstrap, baca template/panduan. Inspect MP4: ID, SHA-256, durasi stream video, dimensi, FPS rasional dan PTS native. Operasi alat dijalankan nyata; tidak diisi dari dugaan model.
2. Tentukan cut/take dari seluruh video dan perubahan di batasnya. Satu take exterior → living → kitchen tanpa cut tetap satu shot. Area fisik, fungsi, area terlihat, rute dilalui serta fase kamera dicatat terpisah.
3. Periksa baseline **10 FPS sepanjang setiap shot**, termasuk frame asli pertama/terakhir. Sumber di bawah 10 FPS memakai seluruh frame tersedia. Lihat setiap gambar terpilih; frame yang diekstrak belum otomatis viewed.
4. Perdalam **semua frame native** pada rentang arah/fase/laju, oklusi, blur atau detail yang meragukan. Awali 0.5–1s bila cocok, perluas sampai seluruh shot bila perlu. Native dapat 24/30/60 FPS atau lainnya tanpa interpolasi. Pendalaman yang diperlukan harus selesai sebelum review final.
5. Audit desain/komposisi: nama gaya English, ukuran/proporsi dan luas wajib, tiga kategori narasi area, konfigurasi/orientasi/penyimpanan/bukaan, cahaya/lingkungan, posisi dan framing awal. Status/basis/bukti disimpan eksplisit dalam JSON.
6. Audit kamera dengan tiga tes di bawah. Catat semua komponen simultan, urutan fase, depth_direction, estimasi skala/sudut, jangkar, tempo dan perubahan penting. Sumber diikuti apa adanya; tidak ada reverse, durasi 4/6s, default slow atau frontal produksi.
7. Pilih panel setelah memahami perjalanan. Normal Start/Middle/End; multi dinamis paling sedikit yang cukup menjelaskan area/penghubung/reveal/perubahan penting. Overview seluruh area biasanya awal IN/akhir OUT; alasan dan satu composition_summary per frame dicatat. Posisi awal sumber tetap tersimpan terpisah. Satu frame dapat mencakup beberapa area tanpa duplikasi.
8. Isi audit.json dan metadata/log nyata, kemudian draft-v2. Periksa silang narasi/fakta, kamera sederhana/teknis, timeline/fase/tempo dan semua pilihan media. Jalankan review dan tampilkan MD manusia enam bagian, Overview, Storyboard serta kolase seluruh shot.
9. Koreksi di chat memperbarui JSON dan pemeriksaan yang benar-benar diulang; draft/review ulang kandidat lengkap. Persetujuan satu shot/aspek bukan seluruh kandidat.
10. Setelah pengguna menyatakan keseluruhan kandidat terbaru sesuai, export-v2 memakai receipt/digest terakhir. Tidak merender ulang. Validasi folder dan ZIP dibuka ulang; pengguna mengunduh satu ZIP lalu ingest lokal tanpa review isi kedua.

## Aturan Penentuan Arah & Fase

| Aspek | Keputusan berdasarkan bukti |
| --- | --- |
| Pan murni | Rotasi pandangan; pada scene statis gambar menyapu kiri mendukung Pan Right dan sebaliknya. Foreground/background relatif serempak. Jangan menentukan arah hanya dari gerak satu objek |
| Oklusi foreground | Pergeseran kusen/meja/tiang yang menutupi atau membuka elemen belakang mendukung translasi. Periksa bersama perspektif dan jangkar |
| Paralaks | Foreground lebih ke kanan relatif background mendukung translasi kamera ke kiri; kebalikannya mendukung kanan. Delta bukan tes tunggal, terutama bila dolly/pan/generatif bercampur |
| Orbit / truck | Orbit mengubah sudut/sisi mengelilingi jangkar yang tetap terbingkai. Truck menilai geser lateral serta orientasi pandangan; perpindahan layar saja tidak membuktikan orbit |
| Dolly / zoom | Skala bersama perubahan kedalaman/oklusi mendukung dolly. Skala saja tidak membuktikan gerak fisik atau focal length |
| IN / OUT | depth_direction setiap fase: IN/OUT/NO IN/OUT/null ambigu. Pan/orbit/zoom/static tidak otomatis maju/mundur; jangan menyamakan belum diketahui dengan netral |
| Fase | + hanya komponen simultan pada interval yang sama. → saat komponen mulai/berhenti/berubah. Area atau tempo berubah saja tidak memaksa fase baru |
| Tilt | Drift/jitter vertikal kecil tidak disebut subtle tilt. Tilt nyata memerlukan rotasi vertikal jelas dan berkelanjutan, berbeda dari pedestal/perubahan tinggi; penggunaan gimbal tidak disimpulkan dari gambar |

Pola per shot/video dihitung helper dari klasifikasi fase; bukan ringkasan manual kedua. Fase netral awal + IN tetap IN, perubahan IN/OUT nyata tetap berurutan. Jika arah berubah, pisahkan fase pada bukti perubahan tersebut. Notasi summary/fase satu paragraf tanpa Enter setelah → atau +.

Usahakan ~× dan ~° dari jangkar yang dilihat. ~× adalah rasio skala, bukan kelipatan kecepatan. Bila sudut tertentu tidak dapat dipisahkan dari gerak gabungan, simpan keterbatasan pada basis/uncertainty; jangan mengarang presisi. Bahasa sederhana harus membedakan badan kamera melingkar ke kiri dari pandangan memutar ke kanan.

## Tempo, cakupan dan pemulihan

Smooth tidak berarti slow. Bandingkan perubahan per interval waktu sama: skala jangkar, bukaan sisi, lintasan dan reveal. Simpan tempo_profile moderate/fast/dll beserta perubahan yang benar-benar diamati; variable tidak menggantikan label kecepatannya. Bedakan tempo kamera dari ritme cut.

Frame review mencatat selected indices dan viewed indices nyata; record sampling/native harus sesuai PTS. Jika dibagi beberapa rentang, baseline tetap mencakup shot tanpa gap. Native overlap baseline sah; jangan menjumlahkan duplikat sebagai frame unik. Audio hanya diklaim bila benar-benar diperiksa. Durasi video dapat berbeda dari container/audio.

Semua frame audit/contact sheet sementara berada di workspace kerja. Paket final hanya kolase per shot, Overview satu baris dan Storyboard vertikal seluruh blok, tanpa motion/, klip shot atau frame terpisah. Jika workspace/sumber hilang, pulihkan dari sumber dan JSON terbaru; jangan membuat bukti/hash palsu. Masalah teknis diselesaikan di chat sebelum ZIP final.

Sebelum ingest, koreksi chat tetap dapat memakai revisi yang sama. Setelah revisi aktif, gunakan +1 dan supersedes benar. Dokumen bekerja/masterprompt hanya acuan tes pembeda/notasi; ketentuan produksi tidak menjadi aturan audit pustaka.


---

<!-- Source: audit/rubric.md -->

# Rubrik audit dan kalibrasi HOMEKU

Gunakan penilaian berbukti, bukan skor total yang dapat menutupi salah arah kamera. Ketepatan satu angka tidak dapat menggantikan kelengkapan ruang atau salah identifikasi cut.

## Desain dan konfigurasi

| Aspek | Bukti yang dicatat | Kesalahan yang harus diperbaiki di chat |
| --- | --- | --- |
| Bentuk | Dinding/volume, bidang melengkung, proporsi tampak, level lantai/plafon | Hanya menyebut nama gaya dan warna |
| Isi | Elemen yang terlihat beserta bentuk, orientasi dan posisi relatif | Mengisi ruangan dari furnitur generik yang tidak terlihat |
| Hubungan | Susunan terhadap bukaan, sudut ruang, kabinet dan jalur yang tampak | Mengarang denah atau koneksi dari urutan edit |
| Pembeda | Kombinasi fungsi, solusi penyimpanan, bukaan, platform, ceruk | Menyamakan semua bathroom sebagai tub/vanity yang sama |
| Material/cahaya | Tampilan tekstur, warna, arah dan lapisan cahaya | Memastikan spesies kayu, batu asli, negara atau lux tanpa bukti |
| Ketidakpastian | Bagian tertutup/crop, fungsi parsial, tafsir alternatif | Mengubah not-visible menjadi not-present |

## Membedakan gerakan kamera

| Tafsir | Petunjuk pendukung | Batas tafsir |
| --- | --- | --- |
| Dolly-In/Out | Perubahan skala subjek beserta perubahan kedalaman/oklusi antar lapisan | Skala saja juga dapat berasal dari zoom/crop digital |
| Pan Left/Right | Reorientasi pandangan ke kiri/kanan dan pergeseran susunan elemen | Arah benda di layar berlawanan dengan rotasi kamera; bukan label gerak kamera otomatis |
| Truck/Tracking | Pergeseran lateral dengan parallax foreground/background | Translasi lateral tidak otomatis orbit |
| Orbit Left/Right | Perubahan sisi/sudut pandang mengelilingi jangkar dan hubungan perspektif | Jangan menyebut orbit hanya karena gambar bergeser mendatar |
| Tilt/Pedestal | Rotasi vertikal versus perpindahan ketinggian dengan parallax | Perubahan crop/kemiringan generatif dapat meniru keduanya |
| Zoom | Skala relatif cenderung berubah tanpa parallax yang mendukung translasi | Tidak cukup untuk mengklaim kamera fisik atau focal length |
| Uncertain/other | Bukti tidak membedakan beberapa tafsir atau label baru | Pertahankan teks/bukti dan alternatif; jangan paksa ke gerakan yang populer |

Perubahan perspektif pada video generatif juga dapat mengandung deformasi. Pisahkan petunjuk yang diamati dari interpretasi gerak. Estimasi derajat bukan hasil rekonstruksi pose 3D; ~2× harus menyebut jangkar dan dimensi/skalanya, bukan faktor percepatan.

## Tempo dan percepatan

Bandingkan perubahan pada interval waktu sama dalam shot yang sama: perpindahan jangkar relatif lebar gambar aktif, perubahan skala, perubahan sisi yang terlihat dan laju pengungkapan area. Jika ada black bar, bedakan bidang gambar aktif dari resolusi file. Tidak ada ambang fisik universal dari video monokuler.

| Label | Pedoman operasional |
| --- | --- |
| slow | Perubahan kecil per detik; reveal berlangsung bertahap dalam rentang yang diperiksa |
| moderate | Perubahan framing/kedalaman jelas dalam beberapa detik tanpa lompatan besar setiap interval |
| fast | Perubahan framing/skala/reveal besar dalam rentang pendek dibanding fase lain yang dikalibrasi |
| variable | Laju berubah bermakna; jelaskan urutan, misalnya awal slow lalu ekor moderate/fast |
| unknown | Bukti waktu/gerak tidak cukup; wajib jelaskan batasnya |

Kelancaran adalah karakter berbeda dari tempo. Gerakan smooth dapat fast; durasi shot pendek tidak otomatis gerak fast. Pisahkan ritme edit antarshot dari kecepatan kamera di dalam shot. Jangan memaksa distribusi label agar mengikuti dugaan bahwa sebagian besar koleksi sedang/cepat.

Accelerating memerlukan perubahan yang lebih besar pada interval akhir daripada awal, dengan jangkar/observasi yang dijelaskan. Pelebaran proyeksi saat mendekati objek tidak sendirian membuktikan percepatan fisik: gunakan istilah percepatan visual pada tafsir sumber dan beri batasnya. Jika kecepatan fisik tidak teridentifikasi, simpan batas tersebut dalam uncertainty.

## Konsistensi lintas model

1. Pakai MP4 dengan hash yang sama, template, kontrak dan pembagian fase yang eksplisit.
2. Periksa arah, IN/OUT, cut, fase, tempo dan posisi overview terlebih dahulu; label gaya diperiksa setelahnya.
3. Jika Gemini/GPT berbeda, bandingkan timestamp, jangkar dan bukti. Jangan memilih jawaban karena model lebih terkenal atau tulisan lebih panjang.
4. Koreksi di chat dan tampilkan kartu dari snapshot terbaru; MD lengkap tersedia. Tidak perlu mengaudit setiap pilot dua kali; kedua lingkungan diuji di antara enam pilot yang tersisa.
5. Catat lingkungan/model yang diketahui dan perbedaan yang diselesaikan. Kontrak tetap provisional sampai pengalaman nyata selesai.

## Siap ditinjau pengguna

- Seluruh durasi tercakup; cut dibedakan dari segmen fungsi.
- Seluruh area dan pembeda yang terlihat tercatat pada audit.json dan laporan MD hasil render, dengan bukti yang tepat.
- Kamera mempunyai arah, fase, estimasi besaran yang diusahakan, tempo, dasar dan batas; tidak ada default slow/frontal atau tilt tipis dari jitter.
- Gambaran area sesuai IN/OUT atau pengecualian dijelaskan; Overview memakai frame wide setiap area penting; paragraf composition_summary menjelaskan posisi/arah/sudut/tinggi/kemiringan/cakupan/elemen/kedalaman/cahaya pada foto itu.
- Gambar awal produksi dapat ditentukan dari posisi/peran frame dan target lintasan, tanpa mengubah kronologi sumber.
- Kandidat lolos validasi teknis di chat. Pengguna kemudian menilai isi; kelulusan kode tidak menjadi pengganti penilaian visual.


## Kriteria V2

- Seluruh aspek profil DNA dicatat beserta nilai/status/confidence/bukti, bukan hanya nama gaya. Unknown eksplisit untuk yang belum diketahui.
- Baseline 10 FPS mencakup setiap shot dan frame asli pertama/terakhir; pendalaman native dilaksanakan bila arah/fase/laju meragukan. Jumlah serta rentang dilaporkan dari indeks yang benar-benar dilihat.
- Gunakan aturan arah/fase pada protokol: pan murni menyapu berlawanan arah kamera; delta paralaks mendukung translasi tetapi perlu oklusi dan perspektif. Orbit mengubah sudut mengelilingi jangkar, truck menilai arah translasi dan orientasi pandangan.
- Drift/jitter kecil bukan tilt utama. Rotasi vertikal yang jelas dan berkelanjutan dibedakan dari perubahan tinggi. Penyebab goyangan atau penggunaan gimbal tidak dipastikan.
- Ringkasan literal, tabel fase dan kartu identik pada notasi. + untuk simultan, → untuk berurutan; timeline menampilkan waktu sumber; ringkasan, fase dan label gambar mengikuti notasi sumber satu paragraf.
- Usahakan ~×/~° dengan jangkar/basis. Rasio skala bukan faktor percepatan; angka tidak diketahui dijelaskan tanpa rekaan.
- audit.json menjadi satu sumber audit; MD enam bagian mengikuti template baku, dengan kategori Arsitektur, Furnitur & dekorasi, Lingkungan serta kamera sederhana dan teknis. Snapshot review mengikat JSON, MD, manifest dan seluruh media; ekspor tidak merender ulang.
- Nama gaya teknis berbahasa Inggris; identitas dan detail tidak hanya menyebut warna. Luas lantai wajib rentang positif, tampil sebagai angka m² tanpa catatan tambahan. Basis dan ketidakpastian tetap dalam JSON.
- Satu continuous take tetap satu shot; fungsi, area terlihat, rute yang dilalui dan fase gerak dibedakan. Multi area memakai panel dinamis yang cukup menjelaskan perjalanan, tanpa menambah cut rekaan.
- Media N+2: kolase per shot, Overview satu baris, Storyboard seluruh blok vertikal; normal caption shot-NN start/middle/end dan waktu di bawah foto, multi nama momen yang sesuai. Tidak ada frame terpisah dalam paket.

## Pemeriksaan format2.1 / report2.2.0

- Camera Pattern diturunkan dari depth_direction fase; source asli tidak berubah karena workflow produksi reverse. Netral bukan ambigu. Pola campuran tetap satu shot; penulisan IN – (OUT → IN) – NO IN/OUT mempunyai tiga slot.
- Camera Start menjelaskan start sumber, paragraf Overview menjelaskan pilihan wide. End OUT tidak disebut start sumber. Overview tengah tidak otomatis dapat menjalankan seluruh lintasan dari awal.
- Shot Timeline tepat lima kolom dengan notasi teknis; Tempo tetap pada detail. Tiga kategori desain A berupa uraian regular blockquote, label di luar; multi area dikelompokkan per area dengan A/B/C bold. B poin dan C paragraf biasa.
- Periksa seluruh Overview, Storyboard, kolase dan MD. Hanya camera: bold pada gambar; ukuran caption sama dengan notasi, waktu kanan atas tetap terbaca, padding bawah mengikuti teks terakhir. Teks panjang tidak menimpa foto.
- Batas60M piksel/gambar, sisi65000px,95MiB/file,256MiB ZIP/ekstraksi. Kegagalan ukuran diperbaiki lewat konfigurasi eksplisit sebelum review terakhir; tidak menghilangkan detail diam-diam.


---

<!-- Source: audit/vocabulary.md -->

# Kosakata pencatatan

Gunakan label domain/subject/attribute yang konsisten untuk konsep yang sama. Nama gaya utama, pengaruh dan interior memakai bahasa Inggris; nilai penjelasan tetap bahasa Indonesia. Daftar berikut pedoman awal, bukan whitelist; label baru tetap boleh dicatat bila maknanya berbeda.

| Domain | Subject contoh | Attribute yang dianjurkan |
| --- | --- | --- |
| space | bathroom, kitchen, bedroom, living, exterior | layout, room-shape, combined-functions, circulation, floor-level |
| architecture | house, roof, canopy, window, doorway, ceiling | massing, shape, opening, position, structure-appearance |
| furnishing | shower, vanity, toilet, sofa, bed, coffee-table, refrigerator, range | type, shape, configuration, orientation |
| storage | cabinet, wardrobe, niche, shelf, laundry-tower | type, configuration, capacity-appearance |
| relation | subjek yang sama dengan benda terkait | position, alignment, adjacency-visible |
| material | wall, floor, countertop, facade, frame | appearance, physical-material |
| lighting | ceiling-light, task-light, niche-light, wall-light | type, placement, light-character |
| environment | site, landscape, exterior-view | visible-setting, vegetation, surface-condition |
| decoration | textile, artwork, plant, seasonal-decoration | type, pattern, placement |

Untuk hubungan, tulis jangkar dan perspektifnya, misalnya 'tower laundry di kanan shower menurut layar awal'. Jangan menulis 'di kanan' tanpa referensi yang jelas. Subject yang berulang tidak berarti objek identik lintas shot; ID fisik/adjacency hanya ditetapkan jika terlihat.

Pisahkan material appearance yang terlihat dari physical-material yang belum diketahui. Contoh 'tampak kayu cokelat' observed tidak membuktikan teak; physical-material dapat unknown. Jangan menerjemahkan state not-visible menjadi daftar barang yang tidak ada.

Label areas memakai fungsi eksplisit, misalnya bathroom; laundry bila keduanya tampak. Kabinet dalam bedroom bukan otomatis ruang walk-in closet. Jika variasi penting tidak cocok daftar ini, beri label baru yang spesifik dan pertahankan bukti/statusnya.


## DNA, alias dan notasi

Profil V2 mempertahankan seluruh aspek DNA kontrak 1.1: gaya/pengaruh, skala tampak, tingkat, massa/atap/entrance/porch/bukaan, material/palet/cahaya/lingkungan, konfigurasi/pembeda/kontinuitas. Nilai diskret ditulis per klaim dengan state/confidence/bukti. Gaya adalah interpretasi beralasan; tidak memastikan asal budaya/lokasi.

Alias eksplisit Indonesia/Inggris berada di data/taxonomy.json: area, gaya, skala, sudut, massa dan gerak. Nilai asli tidak diganti. Contoh american cattage → american cottage hanya normalisasi ejaan label eksplisit, bukan deteksi gaya dari benda. Label baru dan klaim nonpositif tetap tersedia.

Notasi kamera: Dolly-In/Out, Orbit Left/Right, Pan Left/Right, Truck Left/Right, Tilt-Up/Down, Pedestal Up/Down, Zoom-In/Out, Static atau Uncertain. Parser mengenali Tilt-Up dan Tilt Up tanpa mengubah teks literal. Label lain disimpan sebagai other beserta literalnya. Gentle/strong menjelaskan komponen, bukan otomatis tempo. Jangan memakai subtle tilt untuk drift/jitter kecil.

## Area dan kontinuitas V2

`area_ids` menunjuk area fisik; `functions` boleh lebih dari satu (bathroom + laundry tetap satu area bila satu ruang). `visible_intervals` dapat tumpang tindih; `route` hanya perjalanan yang benar-benar dilalui. Fase gerak bukan batas area, dan cut memulai shot baru. Tidak menyimpulkan koneksi denah dari urutan shot. Gunakan `style_names_language: "en"`, primary-style/interior-style serta klaim influence terpisah agar label dapat ditemukan tanpa sintesis AI.

## Camera Pattern dan tampilan2.2.0

Depth_direction fase: IN, OUT, NO IN/OUT atau null ambigu. Pola per shot/video hasil helper, bukan field manual audit. Arah berubah dalam satu shot memakai →; antarshot memakai – dan pola campuran dikurung. Misalnya IN – (OUT → IN) – NO IN/OUT. Pan/orbit/zoom sendiri tidak menentukan kedalaman; ~× bukan tempo.

Overview adalah gabungan frame wide terpilih satu baris; Storyboard adalah seluruh kolase shot vertikal. Camera Start adalah awal sumber, composition_summary adalah paragraf pada frame Overview. Gunakan istilah Profil desain, Ukuran & proporsi, Shot Timeline, Overview, Storyboard, Shot Details, Framing & Lighting, Camera Movement, Tempo, Alur visual, Movement Timeline. Notasi English satu paragraf; nama area/gaya teknis English, uraian Indonesia.


---

<!-- Source: audit/providers.md -->

# Audit di ChatGPT/Gemini

Satu MP4 dan homeku-audit-kit.zip per chat. Kit aktif memakai sumber/paket2.1, report/media2.2.0 dan empat file input: README.md, homeku_runtime.py, template-audit.json, template-audit-info.json. Video tetap lampiran terpisah. Jalankan bootstrap untuk memulihkan seluruh runtime/schema/template/font/lisensi dari payload lokal yang berinventaris/hash; tidak mengunduh kode.

AI menjalankan inspect/sample, melihat gambar yang benar-benar dipilih, mengisi JSON/log aktual, kemudian draft/review. Baseline10FPS+awal/akhir native dan pendalaman native mengikuti protokol yang sama pada kedua lingkungan. Nama provider/model yang diketahui dicatat; build tidak diketahui null. Jangan menyatakan tool tersedia atau frame telah dilihat hanya karena nama model atau proses ekstraksi berhasil.

Jika operasi gagal, laporkan operasi/error nyata dan pulihkan di workspace beralat sebelum mengekspor; jangan mengarang file/hash/hasil helper. Jangan meminta pengguna menata fakta atau membuat laporan teknis secara manual. Tampilkan kandidat lengkap di chat: Overview, Storyboard, kolase semua shot dan MD enam bagian. Setelah koreksi dan persetujuan keseluruhan, unduh satu ZIP final dengan byte snapshot yang sama. Tidak ada review isi kedua setelah ingest.

Uji portable kit dengan fixture membuktikan dependensi teknis, bukan run nyata pada akun ChatGPT/Gemini. Enam pilot pengguna menjadi pengujian lingkungan yang sesungguhnya, tanpa kewajiban mengaudit setiap video dua kali. Status hanya dicatat dari pelaksanaan nyata.


---

<!-- Source: audit/calibration.md -->

# Contoh notasi dan bahan kalibrasi

Contoh berikut menunjukkan sintaks, bukan label yang harus disalin ke setiap video:

```text
Orbit Right (~15°–20°) → Accelerating Dolly-In (~2×) toward teak entrance door.
```

```text
Dolly-In (~1.3×) + Orbit Left + strong Pan Right (~35°).
```

```text
Dolly-In (~2×) + gentle Pan Right (~15°).
```

Pan/orbit tunggal, gerakan lain, fase Static dan Uncertain tetap sah. Angka/material pada contoh tidak menjadi default. Interpretasi hanya ditulis bila didukung sumber; batasnya dicatat terpisah agar ringkasan tetap ringkas.

## Kasus pembeda

| Kasus | Cara membaca |
| --- | --- |
| Dua shot dengan framing sama, satu menempuh perubahan dalam 2 s dan satu dalam 6 s | Perubahan per waktu berbeda; keduanya dapat smooth tetapi temponya berbeda |
| Ukuran objek membesar tanpa parallax yang jelas | Cukup untuk menyatakan perubahan skala; dolly fisik versus zoom belum tentu terpisah |
| Kamera mundur dan membuka seluruh area | Gambaran area biasanya di akhir; gambar awal sumber tetap lebih dekat |
| Objek bergeser ke kanan layar | Belum membuktikan Pan Right; periksa rotasi pandangan dan translasi/parallax |
| Satu lintasan melewati exterior, entry, living dan kitchen tanpa cut | Fungsi bertambah tetapi tidak otomatis menjadi empat shot |
| Enclosure shower, laundry tower dan dua bukaan berbeda | Catat hubungan serta konfigurasi ini; jangan mengganti dengan bathroom generik |

## Pilot edh001: audit diterima; kalibrasi lintas pilot masih terbuka

Laporan edh001 berasal dari video asli, bukan anotasi arsip. Durasi stream 18.4 s dengan cut pada 4.733333333, 8.3, 11.566666667 dan 15 s. Snapshot audit ulang memisahkan orbit kanan awal eksterior dari pendekatan yang meningkat, membedakan arc OUT pada living/bedroom, pan kiri kitchen dan pan kanan bathroom.

Laporan itu belum menjadi ground truth seluruh video. Pengguna telah menerima koreksi gerakan shot 02 berikut, setelah pemeriksaan ulang seluruh 107 frame asli pada indeks 142–248 (4.733333333–8.266666667 s; akhir interval shot 8.3 s):

```text
Dolly-Out (~2×) + Orbit Left + Pan Right.
```

Penerimaan awal ini khusus gerakan shot 02. Pada 22 November 2026, koreksi tersebut sudah diterapkan ke draf audit ulang format 1.1. Seluruh durasi diaudit ulang dengan 10 FPS dan pendalaman native; 461 frame unik diperiksa, termasuk seluruh shot 02/04. Setelah meninjau hasil audit ulang, pengguna menyetujui keseluruhan snapshot dan meminta ekspor final. Ekspor telah dilakukan dengan MD SHA-256 2d04d6bbd7fd35ee813ea7298322d593f195322f864dc2ca23142af57c4a260f; riwayat dan hash paket ada pada docs/edh001-re-audit.md. Persetujuan isi tidak menjadikan estimasi visual sebagai pengukuran pose fisik. Jangan menyalin gerak/angka ini ke sumber lain. Setelah koreksi pengguna dan enam pilot lintas chat selesai, bekukan contoh dengan versi/hash yang sesuai.

## Kalibrasi V2 — belum dibekukan

Riwayat penerimaan pada bagian r0001 di atas berlaku untuk format1.1. Pada implementasi V2 sebelumnya, audit baru menghasilkan audit.json2.0 dan MD/kolase2.1.2 yang kemudian diterima sebagai r0002 (catatan di bawah). Log r0001 tidak dihitung sebagai pemeriksaan V2 baru. Enam pilot pengguna belum dijalankan; kesamaan struktur fixture tidak membuktikan ketepatan visual atau ketersediaan tool pada akun ChatGPT/Gemini tertentu.

Kalibrasi memisahkan kesalahan tafsir kamera/desain, instruksi, render/media dan ingest. Catat koreksi nyata beserta versi/ID/rujukannya; jangan menyalin angka kalibrasi sebagai default sumber lain. Label gaya teknis Inggris, estimasi luas wajib, area/rute/fase dan kelengkapan detail merupakan bagian review isi V2.

### Pemeriksaan V2 edh001 pada 22 November 2026

Audit baru telah memeriksa 455 frame unik dari 552: baseline 10 FPS seluruh shot; native seluruh shot 01 (142 frame), 02 (107), 04 (103), serta ekor shot 03 (53 frame). Log dipisahkan dari r0001 dan tersimpan pada manifest snapshot r0002 yang diterima. Kelima cut dan rumusan kamera r0001 tetap didukung setelah pemeriksaan baru. Shift gaya utama ke Contemporary Modern merupakan penamaan teknis Inggris; tambahan Warm Contemporary dan pengaruh Scandinavian Contemporary tetap interpretasi dengan status/confidence/bukti pada JSON.

Laporan review telah disetujui pengguna sebagai keseluruhan snapshot V2. Kandidat dipertahankan di audit/pilots/v2-candidates/edh001; ZIP r0002 diekspor tanpa render ulang lalu di-ingest. R0002/2.0 aktif pada saat penerimaan tersebut; versi aktif berikutnya dicatat pada bagian Overview/Storyboard di bawah. Ini bukti audit lokal di Codex, bukan run pada antarmuka ChatGPT atau Gemini. Tidak ada continuous take lintas beberapa area fisik dalam edh001; dukungan multi area baru terbukti secara teknis pada fixture sampai pilot nyata tersedia.

Penerimaan V2 pada chat 22 November 2026: pengguna menyatakan “ya saya setuju” setelah laporan lengkap, storyboard dan kelima kolase ditampilkan. Snapshot `71e949c51a3ca82f0a8d22c26ad98c82c6283d8c40413b8b0a24ef99e178ca45`; ZIP `c290e7f81642498330cdb4b0b4b2ecaf2238c5074b83761bf31b08040e74c26f`. Byte sumber JSON/MD/manifest/media tidak berubah pada ekspor/ingest. Ini penerimaan edh001 saja; enam pilot pengguna tetap belum dijalankan dan kalibrasi lintas provider belum dibekukan.

### Workflow Overview / Storyboard2.1

Kit berikutnya menggunakan audit2.1 dan report/media2.2.0: paragraf Overview per frame, depth_direction per fase, pola turunan, Overview satu baris dan Storyboard kolase vertikal. Notasi seluruhnya satu paragraf. Penambahan data ke edh001 dilakukan sebagai kandidat revisi eksplisit yang mempertahankan fakta/gerak/tempo diterima, bukan konversi referensi aktif diam-diam. Pemeriksaan Overview tambahan dicatat terpisah dari log audit r0002; tidak mengklaim audit penuh ulang. Penerimaan r0002 tidak dianggap persetujuan r0003.

Pada 23 November 2026, kandidat edh001 r0003/2.1 dirender dengan report/media2.2.0 dan7JPEG. Lima frame Overview native (0,248,249,449,450) benar-benar dibuka kembali untuk paragraf komposisi. Rekaman r0002 dipertahankan; gabungan tetap455frame unik, bukan460. Fakta/gerak/tempo/pilihan frame diterima tetap sama; Enter pada summary shot01 diratakan menjadi satu paragraf. Pengguna kemudian menyetujui keseluruhan r0003 dengan “ya saya setuju”. Snapshot `e1572245a3cc3e88cac25409816694de5f021d2da83fbb248d5331baaee5501f` diekspor tanpa render ulang lalu di-ingest sebagai referensi aktif. ZIP r0003 berukuran 8,635,907 byte dengan SHA-256 `87fa54a8db2169e757ef5d1325fa52bb819cc71ff90d77090774a31320775db1`; replay unchanged dan check berhasil. Tidak ada audit penuh video atau run enam pilot baru pada pekerjaan ini.


---

<!-- Source: audit/prompts/01-audit.md -->

# Prompt mulai audit HOMEKU 2.1

Audit MP4 terlampir untuk pustaka HOMEKU. Buka homeku-audit-kit.zip, baca README, jalankan bootstrap runtime, lalu baca template JSON dan panduan pengisian. Kerjakan inspeksi video dan semua helper di workspace chat; saya cukup meninjau hasil dan mengunduh satu ZIP final.

Gunakan ID dari stem MP4. Jalankan inspect untuk hash/metadata/PTS aktual. Tentukan cut nyata, lalu periksa baseline 10 FPS sepanjang setiap shot termasuk frame native awal/akhir. Lihat gambar yang dipilih. Perdalam semua frame native pada rentang arah/fase/tempo/oklusi/detail yang belum jelas, termasuk seluruh shot bila perlu. Frame yang hanya diekstrak tidak ditandai viewed; model_build tidak diketahui null.

Tulis audit.json schema_version 2.1 sebagai satu sumber: gaya utama/pengaruh/interior dengan istilah English dan style_names_language=en; estimasi luas lantai total berupa rentang angka wajib; detail Arsitektur, Furnitur & dekorasi, Lingkungan yang konkret; fakta konfigurasi/bukaan/penyimpanan/orientasi/status/bukti; posisi dan arah kamera awal, framing serta cahaya. Jangan mengisi ruangan generik atau memastikan material fisik yang tidak terlihat. Prosa penjelasan Indonesia; basis/uncertainty tetap JSON. MD luas cukup angka m² tanpa catatan tambahan.

Satu take tanpa cut tetap satu shot walau melewati beberapa area. Bedakan area fisik dari fungsi, visibility dari route, dan route dari fase kamera. Catat interval/rute/penghubung/reveal serta journey DNA multi area. Jangan mengarang denah atau kontinuitas dari urutan edit.

Terapkan aturan arah/fase: oklusi + paralaks + perspektif, pan berbeda dari orbit/truck; gerak benda di layar bukan arah kamera. Bedakan dolly/zoom dan smooth/tempo. Jitter vertikal kecil bukan tilt. Gunakan notasi English, + simultan, → berurutan, estimasi ~×/~° berdasar jangkar. Isi depth_direction tiap fase dengan IN/OUT/NO IN/OUT atau null ambigu berdasarkan bukti, bukan skala/orbit/pan saja. Helper menghitung Camera Pattern; jangan menulis salinan manualnya. Fase netral lalu IN tetap IN. Summary harus sejalan dengan fase; notasi satu paragraf tanpa Enter setelah → atau +; tempo_profile menyimpan perkembangan sedang/cepat/dll, bukan default slow. Pertahankan kronologi/durasi sumber tanpa reverse/default produksi.

Pilih frame asli untuk kolase: normal tepat Start/Middle/End; multi dinamis sesuai momen penting, bukan wajib lima. Pilih overview seluruh area penting, biasanya awal IN/akhir OUT. Pada setiap overview, tulis composition_summary satu paragraf tanpa markup: posisi kamera, arah pandang, sudut, ketinggian/kemiringan, cakupan wide, penempatan elemen, kedalaman dan pencahayaan. Camera Start tetap posisi awal sumber; overview akhir OUT tidak menggantikannya. Overview tengah tidak otomatis mewakili awal seluruh lintasan. Simpan pilihan indeks/PTS/bukti stabil; tidak ada JPEG frame kerja dalam ZIP final.

Jalankan draft-v2, periksa silang JSON/narasi/kamera/media, lalu review. Tampilkan Overview satu baris, Storyboard seluruh kolase vertikal, gambar kolase semua shot dan analysis.md manusia enam bagian yang dirender helper2.2.0. Timeline memakai notasi teknis, A/B/C bold, uraian desain dan Overview blockquote, detail multi area dikelompokkan per area. Media N+2; hanya camera: bold pada baris kamera gambar, notasi/caption regular. Jika batas ukuran gagal, pilih skala/quality/kolom secara eksplisit lalu render ulang sebelum ditinjau. Kamera sederhana dan teknis harus sejalan; semua bagian penting tetap tersedia tanpa tabel proses teknis dalam MD. Jangan mengarang fakta untuk lolos validator.

Tunggu koreksi atau pernyataan saya bahwa keseluruhan kandidat sesuai. Jangan membuat ZIP final dulu. Persetujuan satu gerakan atau tampilan bukan persetujuan seluruh audit. Tugas ini hanya audit/pengetahuan referensi, tanpa membuat konsep/gambar baru atau plugin produksi.


---

<!-- Source: audit/prompts/02-correct.md -->

# Prompt koreksi HOMEKU 2.1

Perbaiki audit terbaru berdasarkan catatan saya:

[TULIS SHOT/TIMESTAMP DAN KOREKSI]

Baca ulang sumber terkait; periksa native jika arah/fase/tempo atau detail belum jelas. Isi frame_reviews hanya untuk gambar yang benar-benar dilihat. Terapkan oklusi/paralaks/perspektif serta bedakan jitter dari tilt nyata.

Perbarui audit.json dan metadata/log aktual di workspace, bukan MD hasil render. Bawa seluruh desain/fakta/status/bukti dan bagian yang tidak berubah ke kandidat baru. Periksa dampak pada identitas/luas, area/fungsi/rute, komposisi awal sumber, composition_summary/frame Overview, depth_direction/pola turunan, kamera sederhana/summary/fase/tempo dan pilihan panel. Notasi tetap satu paragraf tanpa Enter setelah → atau +. Usahakan besaran kamera berbukti tanpa mengarang presisi.

Jalankan draft-v2 lalu review ulang. Tampilkan seluruh kandidat terbaru: Overview, Storyboard, semua kolase shot dan MD enam bagian, dengan ringkasan perubahan yang singkat. Jika pilihan frame/batas shot berubah, periksa ulang paragraph Overview, Camera Start, waktu, scope bukti dan seluruh transform media. Perubahan config skala/quality/kolom juga memerlukan render/review ulang. Receipt/digest sebelumnya batal jika isi kandidat berubah. Jangan mengekspor sampai saya menyatakan keseluruhan versi terbaru sesuai; persetujuan satu aspek bukan persetujuan seluruh kandidat. Koreksi sebelum ingest boleh tetap revisi yang sama; referensi yang sudah aktif memakai revisi berikutnya dengan supersedes yang benar.


---

<!-- Source: audit/prompts/03-export.md -->

# Prompt ekspor final HOMEKU 2.1

Keseluruhan kandidat audit terbaru yang saya tinjau sudah sesuai. Ekspor satu ZIP final HOMEKU dari snapshot tersebut.

Gunakan export-v2 atas folder kandidat dan receipt review terakhir, bukan menjalankan draft ulang. JSON, MD, manifest, JPEG dan created_at harus tetap sama dengan kandidat yang saya periksa. Jangan mengubah isi atau memperbarui media/metadata saat ekspor. Jika kandidat berubah atau receipt tidak cocok, tampilkan ulang perubahan sebelum meminta persetujuan versi baru.

Pastikan sumber/paket2.1, report/media2.2.0, dan inventaris N+2 JPEG lengkap: Overview satu baris, Storyboard seluruh kolase vertikal, kolase setiap take. Tidak mengubah versi paket lama diam-diam. Pastikan log mencatat pemeriksaan nyata dan sumber terikat hash yang sama. source.mp4 hanya disertakan jika sumber kanonis belum terverifikasi tersedia; jika diperlukan tetapi belum ada dalam kandidat yang disetujui, buat kandidat lengkap baru dan tampilkan kembali sebelum ekspor. Jangan menambahkan script, receipt, audit-info, frame sementara, motion/ atau klip shot ke ZIP referensi.

Jalankan validasi folder dan ZIP yang dibuka ulang serta kesamaan digest seluruh payload. Jika gagal, jelaskan error nyata; jangan menulis hash/bukti rekaan. Berikan satu tautan download <id>-rNNNN.zip, jumlah shot/gambar dan ringkasan pemeriksaan teknis singkat. Saya menaruh ZIP di incoming/ lokal lalu menjalankan ingest; tidak ada review isi kedua di repo.


---

<!-- Source: docs/contracts/package-v2-1.md -->

# Kontrak paket 2.1

`audit.json` schema_version 2.1 adalah satu sumber audit; analysis.md hasil renderer 2.2.0; manifest.json contract_version 2.1 menyimpan provenance teknis. Schema audit, manifest, laporan, reader.

Isi: audit.json, analysis.md, manifest.json, N media/shot-NN.jpg, media/overview.jpg, media/storyboard.jpg; source.mp4 opsional. Receipt di luar ZIP. Tidak ada JPEG frame lepas atau motion/. N adalah jumlah take kontinu, bukan jumlah area.

shots[].overviews[].composition_summary wajib satu paragraf biasa; Camera Start tetap shots[].composition. shots[].phases[].depth_direction wajib IN, OUT, NO IN/OUT atau null ambigu. Validator menolak arah berlawanan dengan Dolly eksplisit; tidak menentukan orbit/pan/zoom hanya dari nama. Pola turunan menggabungkan arah berturut sama, mempertahankan perubahan dan slot ambigu; bukan field manual audit.

Manifest panel menunjuk selection_id/frame/PTS/area dan bbox foto [x,y,w,h]. Media memiliki blocks (kosong kecuali Storyboard); setiap blok mencatat shot_id, bbox seluruh kolase, derived_from, scale. Metadata harus tepat sama dengan layout deterministik; caption bukan bbox foto. Selection boleh muncul di beberapa media tanpa membuat identitas bukti baru.

Render/media pasangan 2.2.0; hash template/font regular/bold/layout tercatat. Quality default91 (60–98), panel_scale/overview_scale/storyboard_scale default1 (0,1], columns multi default4 (1–6). Skala Storyboard berlaku pada seluruh blok, bbox mengikuti ukuran integer aktual. Tidak memperbesar sumber/crop konteks. Batas 60 juta piksel/gambar, sisi65000px, 95MiB/file, 256MiB ZIP/ekstraksi, 2000file, teks2MiB. Preflight sebelum alokasi, ukur byte sesudah encoding. Tidak mengurangi panel/font atau membagi file diam-diam.

Aturan sumber/10FPS/native, coverage, keamanan ZIP, supersedes/revisi +1, snapshot review/export byte identik dan ingest tanpa review isi ulang mengikuti kontrak 2.0. Paket 2.0 tetap renderer lamanya. Default draft: 2.0→2.1.2; 2.1→2.2.0. Semua schema mandiri tanpa resolusi jaringan.


---

<!-- Source: docs/contracts/analysis-v2-2.md -->

# Laporan manusia 2.2.0

Sumber audit 2.1, renderer/media 2.2.0. Acuan template, PRD.

Enam bagian: Profil desain; Ukuran & proporsi; Shot Timeline; Overview; Storyboard; Shot Details. Timeline tepat lima kolom Shot, Time (s), Duration, Area/Scene, Camera Movement; Camera Pattern di atas. Waktu dua desimal; gaya utama/rentang luas bold, tanpa catatan estimasi tambahan.

Overview satu baris frame wide; judul bold Shot NN · Area · x.xxs di luar blockquote, composition_summary verbatim dalam blockquote. Storyboard seluruh kolase vertikal; kolase tiap shot juga tampil pada detail. A/B/C heading tingkat4 bold; multi area heading tingkat5 bold dikelompokkan per area. A kategori Arsitektur/Furnitur & dekorasi/Lingkungan bold, uraian regular blockquote. B poin berlabel. C gerak sederhana, Tempo, Alur visual bila ada, Movement Timeline bila beberapa fase/multi, Camera satu paragraf regular. Tanpa label proses/placeholder pada laporan final.

Kolase: judul bold kiri, interval/durasi kanan; caption regular shot-NN start/middle/end x.xxs (momen dinamis multi). Hanya camera: bold, notasi regular berukuran caption. Padding mengikuti teks terakhir. Identitas ID — Primary style — durasi — jumlah shot. Algoritme/font/template/layout diterima tidak ditimpa. Tidak menyimpulkan atau menerjemahkan nilai sumber. Anchor profil-dna/shot-NN stabil.


---

<!-- Source: tools/assets/templates/analysis-2.2.0.md -->

# {{ID}} — {{NAMA_DESAIN}}

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** {{NAMA_DESAIN_DESKRIPTIF}}.
- **Gaya utama:** **{{NAMA_GAYA_UTAMA_ENGLISH}}**.
- **Pengaruh gaya:** {{GAYA_PENDUKUNG_ENGLISH_DAN_ALASAN_SINGKAT}}.
- **Gaya interior:** {{NAMA_GAYA_INTERIOR_ENGLISH_DAN_KARAKTER}}.
- **Ciri khas:** {{CIRI_PEMBEDA}}.
- **Warna & material:** {{WARNA_DAN_MATERIAL_TAMPAK}}.
- **Suasana dan lingkungan:** {{SUASANA_CAHAYA_DAN_LINGKUNGAN}}.

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | {{TINY_SMALL_MEDIUM_ATAU_LARGE}} |
| **Bentuk bangunan** | {{BENTUK_DAN_SUSUNAN_MASSA}} |
| **Lantai & bentuk atap** | {{TINGKAT_TERLIHAT_DAN_BAGIAN_ATAS}} |
| **Tapak bangunan** | {{KESAN_BENTUK_DAN_CAKUPAN_TAPAK}} |
| **Proporsi utama** | {{HUBUNGAN_LEBAR_TINGGI_PANJANG}} |
| **Perkiraan luas lantai** | **{{LUAS_MIN}}–{{LUAS_MAX}} m²** |

## 3. Shot Timeline

{{DURASI_TOTAL_JUMLAH_SHOT_DAN_CUT_ATAU_KONTINUITAS}}

**Camera Pattern:** {{POLA_ARAH_SUMBER_SESUAI_URUTAN_SHOT}}.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| {{NN}} | {{AWAL}}–{{AKHIR}} | {{DURASI}}s | {{AREA_ATAU_URUTAN_AREA}} | {{NOTASI_TEKNIS_LENGKAP_SATU_PARAGRAF}} |

## 4. Overview

!Overview wide seluruh area

<!-- Ulangi judul dan paragraf berikut untuk setiap frame overview yang dipilih. -->

**Shot {{NN}} · {{AREA}} · {{WAKTU_OVERVIEW}}s**

> {{SATU_PARAGRAF_POSISI_ARAH_SUDUT_KETINGGIAN_KEMIRINGAN_CAKUPAN_WIDE_PENEMPATAN_ELEMEN_KEDALAMAN_DAN_CAHAYA_PADA_FRAME_OVERVIEW}}.

## 5. Storyboard

!Storyboard seluruh shot dengan panel dan camera

## 6. Shot Details

<!-- Ulangi satu blok Shot Details per take kontinu, bukan per area. -->

<a id="shot-{{NN}}"></a>

### Shot {{NN}} · {{AREA_ATAU_URUTAN_AREA}}

**Time:** {{AWAL}}–{{AKHIR}}s · **Duration:** {{DURASI}}s

<!-- Tampilkan Shot Type hanya untuk shot multi area. -->

**Shot Type:** Continuous shot · Multi area · No cut.

!Kolase Shot {{NN}}

#### **A. Desain area**

<!-- Untuk shot satu area, langsung mulai dari Arsitektur tanpa subjudul area. Untuk multi area, ulangi subjudul area beserta ketiga kelompok paragraf berikut sesuai urutan kemunculan. -->

##### **{{AREA}}**

**Arsitektur**

> {{PARAGRAF_GEOMETRI_DINDING_PLAFON_LANTAI_BUKAAN_KABINET_MATERIAL_DAN_LAMPU}}

**Furnitur & dekorasi**

> {{PARAGRAF_BENTUK_POSISI_HUBUNGAN_FURNITUR_PERALATAN_PENYIMPANAN_DAN_DEKORASI}}

**Lingkungan**

> {{PARAGRAF_PEMANDANGAN_TAMAN_VEGETASI_BANGUNAN_SEKITAR_CUACA_DAN_HUBUNGAN_LUAR}}

#### **B. Framing & Lighting**

- **Fokus:** {{SUBJEK_DAN_PERALIHAN_FOKUS}}.
- **Camera Start:** {{LOKASI_ARAH_PANDANG_DAN_SUDUT_PADA_PANEL_START_SUMBER}}.
- **Framing:** {{CAKUPAN_AWAL_PERUBAHAN_PENTING_DAN_AKHIR}}.
- **Lighting:** {{SUMBER_ARAH_KARAKTER_DAN_PERUBAHAN_CAHAYA}}.

<!-- Camera Start menjelaskan awal shot asli; paragraf Overview menjelaskan frame overview terpilih. Untuk shot OUT, keduanya dapat berbeda. -->

<!-- Tambahkan rincian berikut hanya untuk multi area. -->

- **Area:** {{AREA_DAN_YANG_TERLIHAT_BERSAMAAN}}.
- **Rute kamera:** {{LOKASI_AWAL_JALUR_DAN_AKHIR}}.

**Hubungan antararea**

- **Penghubung area:** {{PINTU_KORIDOR_BUKAAN_ATAU_OPEN_PLAN}}.
- **Peralihan:** {{WAKTU_AREA_TERLIHAT_DAN_KAMERA_MEMASUKINYA}}.
- **Orientasi ruang:** {{ELEMEN_PENJAGA_ORIENTASI_SEPANJANG_PERJALANAN}}.

#### **C. Camera Movement**

{{PARAGRAF_LINTASAN_ARAH_PANDANG_TARGET_URUTAN_KEBERSAMAAN_DAN_PERUBAHAN_PENTING_TANPA_MENGULANG_TEMPO}}

**Tempo:** {{TEMPO_AWAL_PERUBAHAN_DAN_AKHIR}}.

<!-- Tambahkan Alur visual bila ada perjalanan multi area; Movement Timeline bila ada beberapa fase atau perpindahan area. -->

**Alur visual:** {{LINTASAN_PENGHUBUNG_PERALIHAN_FOKUS_REVEAL_DAN_HUBUNGANNYA_DENGAN_TEMPO}}.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| {{AWAL_FASE}}–{{AKHIR_FASE}} | {{AREA_PERALIHAN_DAN_TARGET}} | {{KOMPONEN_SIMULTAN_NOTASI_TEKNIS}} | {{TEMPO_DAN_PERUBAHAN}} |

**Camera:** {{NOTASI_TEKNIS_LENGKAP_SESUAI_URUTAN_FASE_SATU_PARAGRAF}}


## Inventaris runtime terpulihkan

| File | SHA-256 |
| --- | --- |
| tools/audit.py | 21cc0c63add2e19aadf8afa8727620190338b1abb36349e34cdd7d253a296d67 |
| tools/homeku/__init__.py | 06e0bec209b5ee5869262c7ce7493485bf40753d58bb5d3c6bf8dc445d305171 |
| tools/homeku/common.py | e9fce85aa4cd50f6f8e73d68cd7aeb90d9e82dffdf4a6b67f66f37dde59d95b4 |
| tools/homeku/markdown.py | 98c8fce8d82e826c7bb1e674bdfe2c7f235c3cdf0a7ecdd2fae75d0763e2baeb |
| tools/homeku/validation.py | 19a42dbed7b0783f401541b937cef7073dac309f803f4088cdbfbf936e1ebfe5 |
| tools/homeku/exporter.py | 89d411b36b1f7c7e75e7e7d6a30c575e64a33f1d833e658175acee48b66fce38 |
| docs/contracts/manifest-v1.schema.json | 2646fc5eabc6c99044ee9ee27b2fc6af2a5cfc63279769908b04a46903be8852 |
| audit/template-analysis.md | aa5aa2dd50acdb034d63b2f93e9c1664ffaea554907f3dd2b6d5d57338aa7ded |
| tools/homeku/video.py | 76494ee7ad884634ac175df743c21e3e0e7abb3eacd6cc8e1195fff2fb0fc13a |
| tools/homeku/models.py | f3d740618abbe976fb9927d967762851f5ec67cd887127fa3f7cc3b11cbe0bf7 |
| tools/homeku/media.py | a5cda699414a2d7db18d76f4d741e5fba77c66c0b2bc9bfb451a61562271de50 |
| tools/homeku/reporting.py | e445158f486adf43ac8a36789ab346679ea18b8faeb136fa8879ac7ae28d9437 |
| docs/contracts/audit-v2.schema.json | a383005f6724ed1d0e254073ff39c0919bf95c4b838b82f46e5bfe5ffc83470f |
| docs/contracts/manifest-v2.schema.json | e1dd593c3f835090c60e351a3c30e582b2625e1f1bb04e1a43438dcf2ceba904 |
| tools/homeku/media_v2_0.py | f2c7232a9c09ab55a4190b2e0905e9c8b502b68decf23d5bf16ce379c6d204ab |
| tools/homeku/media_v2_1.py | ba0df816b72c760a90c5ebf9d41804e84613d7bff293de8aa84d314df0f5699c |
| tools/homeku/media_v2_1_1.py | 9875b1a4eabd71388db59e8c21f39f18e41440becd8f1cf5a387b9d8b05f936c |
| tools/assets/templates/analysis-2.1.2.md | 4d3eed42a800cc8f4806013dbdf7c7801eac457f77cc163066814a626aa9a0be |
| tools/assets/templates/analysis-2.1.1.md | 6793a4be71cf4ad1d1222aba3d5354e397ee6b9c4f21213de33f4911d4c15d82 |
| tools/assets/fonts/DejaVuSans-Bold.ttf | 5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895 |
| tools/assets/templates/analysis-2.1.0.md | c34e4df89b949b437c9f7010c778f0165a12f9b28fe8597faf6e6d2e3a52be85 |
| tools/assets/fonts/DejaVuSans.ttf | ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280 |
| tools/assets/fonts/LICENSE.txt | e180b3d65bf650dffffd71dd21b6180767b469a18dd87e1d8552be69bb9ecdf0 |
| tools/assets/templates/analysis-2.0.0.md | 25ebc37f6bfe06d3b5bc7d51ef81c6fb02b25a97b5b9cb569ebaafc0466f5c7a |
| tools/homeku/reporting_v2_legacy.py | a11e22c7cfce39da7f4c61dd3dd33814c8b1f267a35f1c89a33b026707df0c5e |
| tools/homeku/media_v2_1_2.py | d824aca4cc5e9ef89ac3ff08f284961058e0d0c5f00e889295667289e9d98c6d |
| tools/homeku/camera_pattern.py | e0cb8ff09300145cfd86cf7b5920034f8b814c02e64a43c97fbabbef70ac3d33 |
| tools/homeku/media_v2_2.py | ca1189a4f7d20c43cdf52c6d2db58e3a1ecee606934010500c633246dcdb15c4 |
| tools/homeku/reporting_v2_2.py | e5371d8105704e22d7833be9e52ad1a5f9ad316d5cc83a131296ad68466dc4cc |
| docs/contracts/audit-v2-1.schema.json | 8018c2210ff0c21cd82ba75c08becd4cff9e75dca1e6ad1719e933528006ec5a |
| docs/contracts/manifest-v2-1.schema.json | e3fdea353dc5725f1ff7452a258b3349957f019db667c93e68b8a4fbeec551f1 |
| tools/assets/templates/analysis-2.2.0.md | 1e909dc3e97016221ca1331e0243497557921d89694b3d425ec98f0d98a481e0 |
| tools/assets/layouts/media-2.2.0.json | 174b4bd2e59497d43449375f77ecf4ff91bc2fb7cb79ee7f9d65cf56f70b590b |
