# Kit audit HOMEKU 3.0

Siapkan satu MP4 sumber terpisah dan ZIP kit ini. Ekstrak empat file input ke workspace chat.

1. Jalankan `python homeku_runtime.py --output .` untuk memulihkan resource lokal berhash. Audit memakai Python 3.11+, Pillow, jsonschema, dan FFmpeg/ffprobe.
2. Baca `audit/visual-audit.md` dan `audit/authoring.md`. Pastikan cut dan periksa baseline 6 FPS dengan batas native. Sumber ≤6 FPS dan shot <1 detik memakai seluruh native.
3. Isi Profil Desain baku dan audit dari gambar yang diperiksa. Catat tipe rumah, atmosfer, dan palet HEX. Nilai besaran tiap komponen gerak dan cantumkan estimasi yang wajar dari frame. Gunakan `mark-viewed` sesudah pemeriksaan, lalu `complete`, `check-input` dan `draft`.
4. Ikuti checklist isi di `audit/authoring.md`. Setelah kandidat lulus validasi, jalankan `review` dan langsung `export --receipt`. Tampilkan laporan enam bagian, Overview, Storyboard, semua kolase, dan tautan unduhan ZIP tanpa MP4 dalam balasan yang sama.
5. Jika ada koreksi, ulangi draft, review, dan ekspor. Berikan tautan ZIP yang terbaru. Simpan MP4 untuk ingest lokal.

Gunakan `audit/prompts/01-audit.md` untuk memulai, `02-correct.md` untuk koreksi, dan `03-export.md` sebagai panduan ekspor. Contoh normal dan multi area adalah fixture sintetis.


## Inventaris resource lokal

| File | SHA-256 |
| --- | --- |
| tools/audit.py | 163bc2ad884ea51ea5a82b64e7160af156866ea2e16380ae47f7880fa346801c |
| tools/homeku/__init__.py | df43fdd84c5a9d4d314eb47c88a02ff81e4cf95808205152bb37e0aec3d6c17f |
| tools/homeku/audit_performance.py | 99be30b6c19b04f64f16e6cf6e5abc56aa289b518e35e375bc524799bd8369c8 |
| tools/homeku/audit_quality.py | 4130110495baad61c1343c557f4dfc112ffcc9214fe4e140d47dabf6df973ea5 |
| tools/homeku/audit_session.py | 5f3d0144ad7736f73cc5fd1123eb9e1c87162a3698e79b14819a995bb70d53f6 |
| tools/homeku/authoring.py | 98e831e01a18fbe390828ba9a90eb122f7d4b4c600475f49548852390aa77e69 |
| tools/homeku/camera_notation.py | 2e3329def5b19e0d247029149683fbc81b01a891e6c1f173cadbaf8d509412d8 |
| tools/homeku/camera_pattern.py | c5708318a94415f68629d9703b7562f59e70b04d0f6ae28ede5ad627d52ea314 |
| tools/homeku/common.py | 84b7ef91c87be39753a8bca752557f8b9c16214bdfd6ac961326a924a47d8079 |
| tools/homeku/derivations.py | 3b2a3d063f7aa94c9aa90375bcc0ce2d210d6a1b233b8cc302b1995521a5119f |
| tools/homeku/exporter.py | 386be33cd30e5ddd03afe3d2a8ea9c7c01a3246922273d5c48c28581d3367727 |
| tools/homeku/media.py | 0a685560e4091e0f2e412fccd42abbad63d06dea9d8054ba4e4dbe6f1c9252a9 |
| tools/homeku/media_incremental.py | fa0316c02f5b7fe3e4df1a1e12ba21a64d5abe122b7135d216c5792cc4b1b919 |
| tools/homeku/models.py | 966340ea994d1f8094d727e0adb7750bfcce493f8f6e63bf85e06448e5467ebb |
| tools/homeku/motion_analysis.py | 6a485f1a0b5799a635887f8057c46aae8c1e7ae1c35c46555e284f6d9dd7c538 |
| tools/homeku/package_manifest.py | 2d26f9c1f4dec8ee2c949ad83b7c78945b465b54a2216d20777ac6c096c07862 |
| tools/homeku/preflight.py | 52450cc9be70941f2145f0337d67023a42e66f16e3aea25174b595e8982268be |
| tools/homeku/render_assets.py | 97c7d508a258eb14a32d4fd788fc2081d64432c4c381e6c652439821b87b1105 |
| tools/homeku/report_validation.py | 063d3e2c8d4272e6b46e0b9e791a2f71510feaa23a8f6974c02e835c456a98a8 |
| tools/homeku/reporting.py | b20ce018df12a4bf8161151e25ba087deb1275413e611b0bf02d835b20ae298a |
| tools/homeku/storage.py | aa8310489011e0e5293a9766662a1040527f2085ce080fa40620c56c90ab1d5b |
| tools/homeku/validation.py | 189615642c835740ae401ea6112da139d481200b86aa9d52e2c5663638dbb0f6 |
| tools/homeku/video.py | 6258f3b76234885cdbc9cc96a2a398526ae7b433efd76d7308564ae455c37e88 |
| tools/homeku/video_cache.py | cb5a63ac34e16d291704bf29e6cfc8e44f104e2ebed48e33696e41e361fca8aa |
| schemas/audit.schema.json | 2a83809e805771ccef252bc7b15767622d922f53bb014e00c6fcc431fbf72ff8 |
| schemas/audit-info.schema.json | ea05be764a74394b1a85056837385d8c7446f1f9bf310855beb13b3d58b68c78 |
| schemas/manifest.schema.json | bce67071a6a2a1360b2004ee2f54f7cb84aded417d74bb17b72df4c67f1c1a9d |
| schemas/reference-reader.schema.json | e842f3937c33ebfa7f3f3bf4ce27aeb925bac631725db6bf66271ea2003fef2f |
| schemas/search-index.schema.json | b89e1d407dfbddb782e2adae88e391d8dd88714616cfba3cf49ec4499be7fdf8 |
| tools/assets/fonts/DejaVuSans.ttf | ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280 |
| tools/assets/fonts/DejaVuSans-Bold.ttf | 5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895 |
| tools/assets/fonts/LICENSE.txt | e180b3d65bf650dffffd71dd21b6180767b469a18dd87e1d8552be69bb9ecdf0 |
| tools/assets/templates/analysis.md | 922902a9b3431f1316ec563de8963371574d6332e9aee7a60b14f9b8038e831c |
| tools/assets/templates/analysis-profile.md | d86f9bcc4f4fc8af70f58df7c7b7ae1ca11acab1aa2a626d05c8baffa89643ac |
| tools/assets/layouts/media.json | d68b9b5a84d6f1c336a5edf4cfa8a1848aa2c77840d503d488e2fcf3fc3ece37 |
| tools/assets/layouts/media-aligned.json | 4e9787151c825046ea2c3b6e231c4cda84c6e4cf06c5c1b95965fe529d72a825 |
| audit/README.md | 61578db27350a4df96458d843afb6012e7b3cdb059af4ba3d982f43091a73170 |
| audit/visual-audit.md | 0fece8161b17e116a84317dec3ff3efe804b77e23f4db1bf7d77d759ed8c10fe |
| audit/authoring.md | d1e76b8b64ff0d332b34dc6a4a4fd218b31a1e4f98269470167884928e195867 |
| audit/json-guide.md | 4ec2f8d757ef059f45228594f3df1f324fb995b1e662eb0abe02b61185b4b5fd |
| audit/vocabulary.md | 906b93fa09c6a47eeaf9ae9fed8fbc2d4bd26d1c41f0753b635fcf6b69b0fca2 |
| audit/camera-cases.md | e35d1903f19877d812fb21c80d97a4688dea06f36c7c5b0edff0920fad44bc0f |
| audit/contracts/package.md | 2a41b967baa09041a35b68f71de724e43a63227ecfc56588b0906288d999f985 |
| audit/contracts/report.md | bfff66f9ca3245c5657fb90df3fa42a392cf1eda4f0cb0aab9f47195894459a4 |
| audit/contracts/reader.md | a37dd8157e922c3e83aa1f404fc05ce076d609e5f1b3a2a3b4cd49b644dcfabc |
| audit/prompts/01-audit.md | f862a4228f9b802f58888f7629a03c625d4654b40c26e6e29a33239dccfcfec8 |
| audit/prompts/02-correct.md | a97bb5aaba563fc8022c6f39b7c63da5a7dfdb9a8645df5fa3c2649f408e5567 |
| audit/prompts/03-export.md | 34f49753e1089f459deac1fb4f7f8d2ce7b3381a110b670a22b7d186a2841e5c |
| audit/template-audit.json | 350461aa848a6301d0a0f7e2104478c51efca800d084c65c37c12b8c9992807f |
| audit/template-audit-info.json | c41cd39166ec3172f3de82661be303239f22010c0868800cf34a6e46cddf6825 |
| audit/examples/normal/audit.json | bbf3ec7f6ab6954f8645f819b8462441f85032e767b79e929869afe217d9758c |
| audit/examples/multi/audit.json | 4f7027da7952ce3b839b12e7a02f7bcdb2e20fbddb393a4489f0cce83e92554f |
| requirements.txt | 03edefdafb04435826494a85df70d8d442f7fb970e72d8e17bd56e0b94690c91 |
| requirements-audit-motion.txt | 3f8acbea4b15265731ade002c15440013043de43db747099a073ababc317a0eb |
