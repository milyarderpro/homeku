# HOMEKU — kit audit V2

Input: satu ZIP ini dan satu MP4 terpisah.

Ekstrak empat file input, lalu jalankan `python homeku_runtime.py --output .`. Bootstrap memulihkan seluruh runtime/schema/font/lisensi dari payload lokal yang diinventarisasi; tidak mengunduh kode. Dependensi runtime: Python 3.11+, Pillow, jsonschema, FFmpeg/ffprobe. Baca seluruh panduan berikut. Placeholder template wajib diganti dengan hasil audit nyata. Versi sumber 2.0; renderer/template 2.1.2. Jangan mengubah renderer versi lama.


---

<!-- Source: audit/README.md -->

# Audit HOMEKU V2 di ChatGPT/Gemini

Satu video per chat. Lampirkan **MP4 asli + homeku-audit-kit.zip**, lalu kirim prompt audit. AI menjalankan seluruh helper di workspace chat. Anda cukup meninjau laporan dan gambar, memberi koreksi, lalu mengunduh satu ZIP final. Sesudah menaruh ZIP di incoming/ lokal, jalankan `python tools/library.py ingest`.

## Alur singkat

1. AI membuka kit, membaca README, menjalankan `python homeku_runtime.py --output .`, lalu inspect video. Runtime/schema/template/font/lisensi tersedia tanpa repo penuh atau API AI.
2. AI menentukan cut nyata, memeriksa baseline 10 FPS seluruh shot + frame native awal/akhir, lalu memperdalam native bila arah/fase/tempo/detail belum jelas. Satu take melewati banyak area tetap satu shot.
3. AI mengisi `work/audit.json` dari template serta `work/audit-info.json` dari log nyata. Panduan JSON menjelaskan bidang dan bukti. JSON adalah satu sumber isi; MD tidak ditulis terpisah.
4. AI menjalankan draft-v2 dan review. Anda melihat storyboard, kolase semua shot dan analysis.md manusia dengan desain lengkap, posisi awal, kamera sederhana/teknis dan ritme. Nama gaya memakai bahasa Inggris; prosa Indonesia.
5. Bila perlu gunakan prompt koreksi. AI memperbarui JSON/log, merender ulang dan menampilkan hasil terbaru. Persetujuan satu aspek bukan persetujuan keseluruhan audit.
6. Setelah seluruh kandidat sesuai, kirim prompt ekspor. Export mengemas kandidat yang sama tanpa membuat ulang JPEG/MD/created_at. Anda mengunduh satu ZIP `<id>-r0001.zip` atau revisi yang benar.

Tidak ada review isi kedua setelah ingest. Kesalahan teknis harus diselesaikan sebelum penyerahan ZIP; helper tidak membuat atau menebak fakta agar lolos validasi.

## Perintah yang dijalankan AI

```sh
python homeku_runtime.py --output .
python tools/audit.py inspect /path/<id>.mp4
python tools/audit.py sample /path/<id>.mp4 --output work/baseline-shot-01 --start 0 --end <SHOT_END> --shot-id shot-01
python tools/audit.py sample /path/<id>.mp4 --output work/native-shot-01 --native --start <START> --end <END> --shot-id shot-01 --reason "Pan/orbit belum jelas"
python tools/audit.py draft-v2 /path/<id>.mp4 work/audit.json --audit-info work/audit-info.json --output work/candidate
python tools/audit.py review work/candidate/<id> --source /path/<id>.mp4 --output work/review.md
python tools/audit.py export-v2 work/candidate/<id> --source /path/<id>.mp4 --output work/final --receipt work/review.md.json
```

Receipt dihitung helper dan tetap di luar kandidat; pengguna tidak diminta membaca JSON/hash. Receipt bukan persetujuan otomatis: export tetap menunggu pernyataan pengguna bahwa keseluruhan hasil terbaru sesuai. `--reviewed-sha256` tetap tersedia untuk pemanggilan teknis eksplisit.

Untuk revisi yang sudah aktif, `--supersedes work/supersedes.json` berisi revision/content_sha256 aktif yang benar; jangan mengarangnya. `--include-source` pada draft menyertakan MP4 jika sumber kanonis belum terverifikasi tersedia dengan hash sama. Input JSON/video disimpan di luar folder kandidat. Draft bisa dibuat ulang setelah koreksi; export tidak melakukan draft ulang.

## Isi paket dan media

Paket final berisi audit.json, analysis.md, manifest.json, satu kolase per shot dan satu storyboard; source.mp4 opsional. Normal memakai tiga panel Start/Middle/End; multi area memakai panel dinamis yang cukup menjelaskan perjalanan. Storyboard overview seluruh area satu baris. Semua gambar berasal dari frame asli; tidak ada JPEG frame terpisah, motion/ atau seluruh rangkaian frame dalam ZIP final.

Kit input dan ZIP hasil berbeda. Kit input dikemas ringkas untuk batas lampiran provider, tetapi bootstrap memulihkan seluruh inventaris teknis yang sama dengan repo. Gunakan hanya alat yang benar-benar tersedia dan laporkan kegagalan spesifik; panduan lingkungan tidak menganggap nama model sebagai bukti kemampuan eksekusi.

Format sumber/paket 2.0, renderer terbaru 2.1.2. Legacy 1.0/1.1 tetap dapat dibaca, tetapi prompt audit baru mengisi JSON V2. Pilot mencatat run nyata; kit siap tidak berarti tujuh pilot selesai.


---

<!-- Source: audit/json-guide.md -->

# Panduan pengisian audit.json V2

Gunakan template-audit.json untuk isi dan template-audit-info.json untuk metadata proses. Semua null numerik dan {{penanda}} pada template harus diganti sebelum draft final. Setelah kit diekstrak, `template-audit.json` dan `template-audit-info.json` berada di root workspace; salin sebagai work/audit.json dan work/audit-info.json, lalu isi. Template bukan audit valid; jangan mengisinya dengan fakta contoh Willow Cottage atau nilai default ruangan.

## Siapa menulis apa

AI auditor menulis identitas/gaya, estimasi ukuran, narasi, klaim/status/bukti, interval shot/area/fase/tempo, komposisi, kamera sederhana/teknis dan pilihan panel. Helper menghitung metadata/hash/PTS, durasi tampilan, MD, layout/font, inventaris gambar dan snapshot. Ingest hanya memvalidasi serta membangun turunan.

| Bidang sumber | Cara mengisi |
| --- | --- |
| schema_version/id/revision | 2.0; ID mengikuti stem MP4; r1 untuk sumber baru, +1 dengan supersedes yang benar untuk revisi aktif |
| identity | Nama rumah deskriptif; primary_style, nama influences dan interior_style bahasa Inggris. style_names_language=en; penjelasan boleh Indonesia. Ciri, palet, suasana/lingkungan konkret. style_relations hanya family/blend/influence yang dinyatakan, bukan alias rekaan |
| size | scale/massing/vertical/footprint/proportions dan floor_area_m2 min/max positif berurutan. Estimasi luas lantai total rumah wajib diisi; basis/uncertainty hanya JSON, tampilan cukup 60–90 m² sebagai contoh format |
| profile | Seluruh aspek DNA kontrak ditulis eksplisit dengan id/aspect/value/state/confidence/evidence/area_ids/basis/uncertainty. Tambahkan interior-style dan nilai pengaruh diskret agar mudah dicari. Unknown bila belum diketahui; jangan menebak material fisik |
| areas | ID area fisik, label, functions dan visible_intervals waktu video. Bathroom + laundry dapat satu area/two functions; dua bathroom fisik mempunyai ID berbeda. Interval boleh overlap antararea dan berulang untuk area yang muncul kembali |
| shots | Satu take sampai cut nyata. start_s/end_s menutup durasi stream video tanpa gap/overlap. transition/continuity berdasarkan sumber; jangan membuat cut dari pergantian area |
| shots.route/area_relations | Rute kamera yang benar-benar dimasuki, penghubung/fokus dan interval. Area terlihat tidak sama dengan dilalui; route boleh kosong untuk pandangan beberapa area dari satu posisi. Hubungan memakai status/bukti |
| shots.design | architecture/furnishings/environment berupa paragraf konkret; area_ids mengikat tiap uraian. Semua area penting harus tercakup. Jangan mengisi inventaris generik atau memastikan yang tertutup |
| shots.facts | Klaim atomik id/domain/subject/attribute/value dengan area_ids, state/confidence/evidence/basis/uncertainty. Konfigurasi, orientasi, bukaan dan penyimpanan lebih berguna daripada warna saja. Label baru dan negasi tetap disimpan |
| composition | camera_position/direction/view_angle/height/tilt, foreground/depth/reveal, start/end_composition, motion_compatibility, focus/lighting. Posisi awal bukan otomatis frame overview akhir OUT |
| camera_summary/phases | Summary sama dengan urutan components fase. + simultan, → berurutan; phase-01 dst. mencakup shot tanpa gap/overlap. Komponen raw/parsed harus sama; gunakan helper component bila perlu. Simpan anchor, focus/area_ids, tempo, speed_change, basis/evidence/confidence/uncertainty |
| camera_simple/rhythm | Narasi Indonesia lengkap tetapi singkat untuk semua arah, kebersamaan/urutan, target dan ritme. Ditulis auditor; renderer tidak menerjemahkan notasi |
| tempo_profile | Interval tempo aktual sepanjang shot, misalnya moderate lalu fast. Perubahan tempo tidak otomatis fase kamera baru; ~2× adalah perubahan skala, bukan kecepatan |
| journey_dna | Wajib untuk multi area: lintasan, penghubung, peralihan fokus/reveal dan ritme. Normal boleh kosong bila tidak menambah penjelasan |
| panels/overviews | ID unik global, shot/area_ids, frame_index/PTS tepat dari inspect, role/label/reason. Normal tiga panel start/middle/end; tengah native terdekat titik tengah. Multi dinamis, awal/akhir dan momen penting. Overview tiap area biasanya awal IN/akhir OUT, boleh bukan panel kolase, tidak menjadi file terpisah |
| uncertainty/review_summary/composition_notes/camera_notes | Pertahankan batas pengamatan serta penjelasan terkait, jangan menyelipkan status draf/final ke narasi manusia |
| relations/limitations | Hubungan antarshot dan batas keseluruhan yang benar-benar didukung; urutan edit bukan bukti denah atau satu rumah fisik |

## Status dan bukti

State: observed, uncertain, not-visible, not-present, unknown. Confidence: high, medium, low, unknown. Not-visible berarti tidak terlihat dalam bukti, bukan tidak ada. Selain unknown, klaim memerlukan bukti; uncertainty dan negasi tidak dihilangkan demi katalog.

Evidence menunjuk ID pilihan panel/overview, atau `frame:shot-01:42` untuk frame native yang tidak masuk kolase. ID bukti harus benar dan dalam shot/scope yang sesuai. Satu fase lintas area boleh memakai gabungan beberapa panel; tidak harus semua area terlihat dalam satu foto. Simpan bukti temporal sumber, bukan hanya tiga gambar final. Jangan memakai path frame kerja sementara.

## Metadata proses

Audit-info berisi method, limitations cakupan, ai provider/model/model_build yang diketahui, reviewed_ranges dan frame_reviews. created_at opsional dihitung helper saat draft. Model/build tidak diketahui tidak dikarang; model_build null. Gunakan sampling.json sebagai template record; isi viewed_frame_indices hanya setelah frame benar-benar dilihat. Baseline 10 FPS seluruh shot wajib selesai; pendalaman native ditambah sebagai record baru. Ekstraksi otomatis tidak boleh dianggap pemeriksaan otomatis.

Simpan sumber audit JSON, MP4 dan metadata kerja di luar kandidat. Koreksi JSON/log lalu draft dan review ulang. MD/media/manifest adalah hasil; jangan merawat fakta manual kedua atau memodifikasi hasil sesudah persetujuan. Receipt review mengikat seluruh kandidat, bukan hanya MD.


---

<!-- Source: audit/protocol.md -->

# Protokol audit HOMEKU V2

Workflow 2.0; sumber/paket 2.0 dan renderer 2.1.2. Kontrak tetap provisional sampai pilot nyata selesai. Prinsip berlaku untuk ratusan sumber, bukan hanya tujuh pilot.

## Urutan audit

1. Buka kit dan jalankan bootstrap, baca template/panduan. Inspect MP4: ID, SHA-256, durasi stream video, dimensi, FPS rasional dan PTS native. Operasi alat dijalankan nyata; tidak diisi dari dugaan model.
2. Tentukan cut/take dari seluruh video dan perubahan di batasnya. Satu take exterior → living → kitchen tanpa cut tetap satu shot. Area fisik, fungsi, area terlihat, rute dilalui serta fase kamera dicatat terpisah.
3. Periksa baseline **10 FPS sepanjang setiap shot**, termasuk frame asli pertama/terakhir. Sumber di bawah 10 FPS memakai seluruh frame tersedia. Lihat setiap gambar terpilih; frame yang diekstrak belum otomatis viewed.
4. Perdalam **semua frame native** pada rentang arah/fase/laju, oklusi, blur atau detail yang meragukan. Awali 0.5–1s bila cocok, perluas sampai seluruh shot bila perlu. Native dapat 24/30/60 FPS atau lainnya tanpa interpolasi. Pendalaman yang diperlukan harus selesai sebelum review final.
5. Audit desain/komposisi: nama gaya English, ukuran/proporsi dan luas wajib, tiga kategori narasi area, konfigurasi/orientasi/penyimpanan/bukaan, cahaya/lingkungan, posisi dan framing awal. Status/basis/bukti disimpan eksplisit dalam JSON.
6. Audit kamera dengan tiga tes di bawah. Catat semua komponen simultan, urutan fase, estimasi skala/sudut, jangkar, tempo dan perubahan penting. Sumber diikuti apa adanya; tidak ada reverse, durasi 4/6s, default slow atau frontal produksi.
7. Pilih panel setelah memahami perjalanan. Normal Start/Middle/End; multi dinamis paling sedikit yang cukup menjelaskan area/penghubung/reveal/perubahan penting. Overview seluruh area biasanya awal IN/akhir OUT; alasannya dicatat. Satu frame dapat mencakup beberapa area tanpa duplikasi.
8. Isi audit.json dan metadata/log nyata, kemudian draft-v2. Periksa silang narasi/fakta, kamera sederhana/teknis, timeline/fase/tempo dan semua pilihan media. Jalankan review dan tampilkan MD manusia, storyboard serta kolase seluruh shot.
9. Koreksi di chat memperbarui JSON dan pemeriksaan yang benar-benar diulang; draft/review ulang kandidat lengkap. Persetujuan satu shot/aspek bukan seluruh kandidat.
10. Setelah pengguna menyatakan keseluruhan kandidat terbaru sesuai, export-v2 memakai receipt/digest terakhir. Tidak merender ulang. Validasi folder dan ZIP dibuka ulang; pengguna mengunduh satu ZIP lalu ingest lokal tanpa review isi kedua.

## Aturan Penentuan Arah & Fase

| Aspek | Keputusan berdasarkan bukti |
| --- | --- |
| Pan murni | Rotasi pandangan; pada scene statis gambar menyapu kiri mendukung Pan Right dan sebaliknya. Foreground/background relatif serempak. Jangan menentukan arah hanya dari gerak satu objek |
| Oklusi foreground | Pergeseran kusen/meja/tiang yang menutupi atau membuka elemen belakang mendukung translasi. Periksa bersama perspektif dan jangkar |
| Paralaks | Foreground lebih ke kanan relatif background mendukung translasi kamera ke kiri; kebalikannya mendukung kanan. Delta bukan tes tunggal, terutama bila dolly/pan/generatif bercampur |
| Orbit / truck | Orbit mengubah sudut/sisi mengelilingi jangkar yang tetap terbingkai. Truck menilai geser lateral serta orientasi pandangan; perpindahan layar saja tidak membuktikan orbit |
| Dolly / zoom | Skala bersama perubahan kedalaman/oklusi mendukung dolly. Skala saja tidak membuktikan gerak fisik atau focal length |
| IN / OUT | Dicatat bila didukung; pan/orbit/static tidak dipaksa mempunyai gerak maju/mundur |
| Fase | + hanya komponen simultan pada interval yang sama. → saat komponen mulai/berhenti/berubah. Area atau tempo berubah saja tidak memaksa fase baru |
| Tilt | Drift/jitter vertikal kecil tidak disebut subtle tilt. Tilt nyata memerlukan rotasi vertikal jelas dan berkelanjutan, berbeda dari pedestal/perubahan tinggi; penggunaan gimbal tidak disimpulkan dari gambar |

Usahakan ~× dan ~° dari jangkar yang dilihat. ~× adalah rasio skala, bukan kelipatan kecepatan. Bila sudut tertentu tidak dapat dipisahkan dari gerak gabungan, simpan keterbatasan pada basis/uncertainty; jangan mengarang presisi. Bahasa sederhana harus membedakan badan kamera melingkar ke kiri dari pandangan memutar ke kanan.

## Tempo, cakupan dan pemulihan

Smooth tidak berarti slow. Bandingkan perubahan per interval waktu sama: skala jangkar, bukaan sisi, lintasan dan reveal. Simpan tempo_profile moderate/fast/dll beserta perubahan yang benar-benar diamati; variable tidak menggantikan label kecepatannya. Bedakan tempo kamera dari ritme cut.

Frame review mencatat selected indices dan viewed indices nyata; record sampling/native harus sesuai PTS. Jika dibagi beberapa rentang, baseline tetap mencakup shot tanpa gap. Native overlap baseline sah; jangan menjumlahkan duplikat sebagai frame unik. Audio hanya diklaim bila benar-benar diperiksa. Durasi video dapat berbeda dari container/audio.

Semua frame audit/contact sheet sementara berada di workspace kerja. Paket final hanya kolase per shot dan storyboard satu baris, tanpa motion/, klip shot atau frame terpisah. Jika workspace/sumber hilang, pulihkan dari sumber dan JSON terbaru; jangan membuat bukti/hash palsu. Masalah teknis diselesaikan di chat sebelum ZIP final.

Sebelum ingest, koreksi chat tetap dapat memakai revisi yang sama. Setelah revisi aktif, gunakan +1 dan supersedes benar. Dokumen bekerja/masterprompt hanya acuan tes pembeda/notasi; ketentuan produksi tidak menjadi aturan audit pustaka.


---

<!-- Source: audit/rubric.md -->

# Rubrik audit dan kalibrasi HOMEKU

Gunakan penilaian berbukti, bukan skor total yang dapat menutupi salah arah kamera. Ketepatan satu angka tidak dapat menggantikan kelengkapan ruang atau salah identifikasi cut.

## Desain dan konfigurasi

| Aspek | Bukti yang dicatat | Kesalahan yang harus diperbaiki di chat |
| --- | --- | --- |
| Bentuk | Dinding/volume, bidang melengkung, proporsi tampak, level lantai/plafon | Hanya menyebut nama gaya dan warna |
| Isi | Elemen yang terlihat beserta bentuk, orientasi dan posisi relatif | Mengisi ruangan dari furnitur generik yang tidak terlihat |
| Hubungan | Susunan terhadap bukaan, sudut ruang, kabinet dan jalur yang tampak | Mengarang denah atau koneksi dari urutan edit |
| Pembeda | Kombinasi fungsi, solusi penyimpanan, bukaan, platform, ceruk | Menyamakan semua bathroom sebagai tub/vanity yang sama |
| Material/cahaya | Tampilan tekstur, warna, arah dan lapisan cahaya | Memastikan spesies kayu, batu asli, negara atau lux tanpa bukti |
| Ketidakpastian | Bagian tertutup/crop, fungsi parsial, tafsir alternatif | Mengubah not-visible menjadi not-present |

## Membedakan gerakan kamera

| Tafsir | Petunjuk pendukung | Batas tafsir |
| --- | --- | --- |
| Dolly-In/Out | Perubahan skala subjek beserta perubahan kedalaman/oklusi antar lapisan | Skala saja juga dapat berasal dari zoom/crop digital |
| Pan Left/Right | Reorientasi pandangan ke kiri/kanan dan pergeseran susunan elemen | Arah benda di layar berlawanan dengan rotasi kamera; bukan label gerak kamera otomatis |
| Truck/Tracking | Pergeseran lateral dengan parallax foreground/background | Translasi lateral tidak otomatis orbit |
| Orbit Left/Right | Perubahan sisi/sudut pandang mengelilingi jangkar dan hubungan perspektif | Jangan menyebut orbit hanya karena gambar bergeser mendatar |
| Tilt/Pedestal | Rotasi vertikal versus perpindahan ketinggian dengan parallax | Perubahan crop/kemiringan generatif dapat meniru keduanya |
| Zoom | Skala relatif cenderung berubah tanpa parallax yang mendukung translasi | Tidak cukup untuk mengklaim kamera fisik atau focal length |
| Uncertain/other | Bukti tidak membedakan beberapa tafsir atau label baru | Pertahankan teks/bukti dan alternatif; jangan paksa ke gerakan yang populer |

Perubahan perspektif pada video generatif juga dapat mengandung deformasi. Pisahkan petunjuk yang diamati dari interpretasi gerak. Estimasi derajat bukan hasil rekonstruksi pose 3D; ~2× harus menyebut jangkar dan dimensi/skalanya, bukan faktor percepatan.

## Tempo dan percepatan

Bandingkan perubahan pada interval waktu sama dalam shot yang sama: perpindahan jangkar relatif lebar gambar aktif, perubahan skala, perubahan sisi yang terlihat dan laju pengungkapan area. Jika ada black bar, bedakan bidang gambar aktif dari resolusi file. Tidak ada ambang fisik universal dari video monokuler.

| Label | Pedoman operasional |
| --- | --- |
| slow | Perubahan kecil per detik; reveal berlangsung bertahap dalam rentang yang diperiksa |
| moderate | Perubahan framing/kedalaman jelas dalam beberapa detik tanpa lompatan besar setiap interval |
| fast | Perubahan framing/skala/reveal besar dalam rentang pendek dibanding fase lain yang dikalibrasi |
| variable | Laju berubah bermakna; jelaskan urutan, misalnya awal slow lalu ekor moderate/fast |
| unknown | Bukti waktu/gerak tidak cukup; wajib jelaskan batasnya |

Kelancaran adalah karakter berbeda dari tempo. Gerakan smooth dapat fast; durasi shot pendek tidak otomatis gerak fast. Pisahkan ritme edit antarshot dari kecepatan kamera di dalam shot. Jangan memaksa distribusi label agar mengikuti dugaan bahwa sebagian besar koleksi sedang/cepat.

Accelerating memerlukan perubahan yang lebih besar pada interval akhir daripada awal, dengan jangkar/observasi yang dijelaskan. Pelebaran proyeksi saat mendekati objek tidak sendirian membuktikan percepatan fisik: gunakan istilah percepatan visual pada tafsir sumber dan beri batasnya. Jika kecepatan fisik tidak teridentifikasi, simpan batas tersebut dalam uncertainty.

## Konsistensi lintas model

1. Pakai MP4 dengan hash yang sama, template, kontrak dan pembagian fase yang eksplisit.
2. Periksa arah, IN/OUT, cut, fase, tempo dan posisi overview terlebih dahulu; label gaya diperiksa setelahnya.
3. Jika Gemini/GPT berbeda, bandingkan timestamp, jangkar dan bukti. Jangan memilih jawaban karena model lebih terkenal atau tulisan lebih panjang.
4. Koreksi di chat dan tampilkan kartu dari snapshot terbaru; MD lengkap tersedia. Tidak perlu mengaudit setiap pilot dua kali; kedua lingkungan diuji di antara enam pilot yang tersisa.
5. Catat lingkungan/model yang diketahui dan perbedaan yang diselesaikan. Kontrak tetap provisional sampai pengalaman nyata selesai.

## Siap ditinjau pengguna

- Seluruh durasi tercakup; cut dibedakan dari segmen fungsi.
- Seluruh area dan pembeda yang terlihat tercatat pada audit.json dan laporan MD hasil render, dengan bukti yang tepat.
- Kamera mempunyai arah, fase, estimasi besaran yang diusahakan, tempo, dasar dan batas; tidak ada default slow/frontal atau tilt tipis dari jitter.
- Gambaran area sesuai IN/OUT atau pengecualian dijelaskan; storyboard memakai gambaran area setiap shot.
- Gambar awal produksi dapat ditentukan dari posisi/peran frame dan target lintasan, tanpa mengubah kronologi sumber.
- Kandidat lolos validasi teknis di chat. Pengguna kemudian menilai isi; kelulusan kode tidak menjadi pengganti penilaian visual.


## Kriteria V2

- Seluruh aspek profil DNA dicatat beserta nilai/status/confidence/bukti, bukan hanya nama gaya. Unknown eksplisit untuk yang belum diketahui.
- Baseline 10 FPS mencakup setiap shot dan frame asli pertama/terakhir; pendalaman native dilaksanakan bila arah/fase/laju meragukan. Jumlah serta rentang dilaporkan dari indeks yang benar-benar dilihat.
- Gunakan aturan arah/fase pada protokol: pan murni menyapu berlawanan arah kamera; delta paralaks mendukung translasi tetapi perlu oklusi dan perspektif. Orbit mengubah sudut mengelilingi jangkar, truck menilai arah translasi dan orientasi pandangan.
- Drift/jitter kecil bukan tilt utama. Rotasi vertikal yang jelas dan berkelanjutan dibedakan dari perubahan tinggi. Penyebab goyangan atau penggunaan gimbal tidak dipastikan.
- Ringkasan literal, tabel fase dan kartu identik pada notasi. + untuk simultan, → untuk berurutan; timeline menampilkan waktu sumber dan relatif shot.
- Usahakan ~×/~° dengan jangkar/basis. Rasio skala bukan faktor percepatan; angka tidak diketahui dijelaskan tanpa rekaan.
- audit.json menjadi satu sumber audit; MD lima bagian mengikuti template baku, dengan kategori Arsitektur, Furnitur dan properti, Lingkungan serta kamera sederhana dan teknis. Snapshot review mengikat JSON, MD, manifest dan seluruh media; ekspor tidak merender ulang.
- Nama gaya teknis berbahasa Inggris; identitas dan detail tidak hanya menyebut warna. Luas lantai wajib rentang positif, tampil sebagai angka m² tanpa catatan tambahan. Basis dan ketidakpastian tetap dalam JSON.
- Satu continuous take tetap satu shot; fungsi, area terlihat, rute yang dilalui dan fase gerak dibedakan. Multi area memakai panel dinamis yang cukup menjelaskan perjalanan, tanpa menambah cut rekaan.
- Satu kolase per shot dan storyboard satu baris; normal Start · Middle · End, waktu kecil di bawah foto. Tidak ada frame terpisah dalam paket.


---

<!-- Source: audit/vocabulary.md -->

# Kosakata pencatatan

Gunakan label domain/subject/attribute yang konsisten untuk konsep yang sama. Nama gaya utama, pengaruh dan interior memakai bahasa Inggris; nilai penjelasan tetap bahasa Indonesia. Daftar berikut pedoman awal, bukan whitelist; label baru tetap boleh dicatat bila maknanya berbeda.

| Domain | Subject contoh | Attribute yang dianjurkan |
| --- | --- | --- |
| space | bathroom, kitchen, bedroom, living, exterior | layout, room-shape, combined-functions, circulation, floor-level |
| architecture | house, roof, canopy, window, doorway, ceiling | massing, shape, opening, position, structure-appearance |
| furnishing | shower, vanity, toilet, sofa, bed, coffee-table, refrigerator, range | type, shape, configuration, orientation |
| storage | cabinet, wardrobe, niche, shelf, laundry-tower | type, configuration, capacity-appearance |
| relation | subjek yang sama dengan benda terkait | position, alignment, adjacency-visible |
| material | wall, floor, countertop, facade, frame | appearance, physical-material |
| lighting | ceiling-light, task-light, niche-light, wall-light | type, placement, light-character |
| environment | site, landscape, exterior-view | visible-setting, vegetation, surface-condition |
| decoration | textile, artwork, plant, seasonal-decoration | type, pattern, placement |

Untuk hubungan, tulis jangkar dan perspektifnya, misalnya 'tower laundry di kanan shower menurut layar awal'. Jangan menulis 'di kanan' tanpa referensi yang jelas. Subject yang berulang tidak berarti objek identik lintas shot; ID fisik/adjacency hanya ditetapkan jika terlihat.

Pisahkan material appearance yang terlihat dari physical-material yang belum diketahui. Contoh 'tampak kayu cokelat' observed tidak membuktikan teak; physical-material dapat unknown. Jangan menerjemahkan state not-visible menjadi daftar barang yang tidak ada.

Label areas memakai fungsi eksplisit, misalnya bathroom; laundry bila keduanya tampak. Kabinet dalam bedroom bukan otomatis ruang walk-in closet. Jika variasi penting tidak cocok daftar ini, beri label baru yang spesifik dan pertahankan bukti/statusnya.


## DNA, alias dan notasi

Profil V2 mempertahankan seluruh aspek DNA kontrak 1.1: gaya/pengaruh, skala tampak, tingkat, massa/atap/entrance/porch/bukaan, material/palet/cahaya/lingkungan, konfigurasi/pembeda/kontinuitas. Nilai diskret ditulis per klaim dengan state/confidence/bukti. Gaya adalah interpretasi beralasan; tidak memastikan asal budaya/lokasi.

Alias eksplisit Indonesia/Inggris berada di data/taxonomy.json: area, gaya, skala, sudut, massa dan gerak. Nilai asli tidak diganti. Contoh american cattage → american cottage hanya normalisasi ejaan label eksplisit, bukan deteksi gaya dari benda. Label baru dan klaim nonpositif tetap tersedia.

Notasi kamera: Dolly-In/Out, Orbit Left/Right, Pan Left/Right, Truck Left/Right, Tilt-Up/Down, Pedestal Up/Down, Zoom-In/Out, Static atau Uncertain. Parser mengenali Tilt-Up dan Tilt Up tanpa mengubah teks literal. Label lain disimpan sebagai other beserta literalnya. Gentle/strong menjelaskan komponen, bukan otomatis tempo. Jangan memakai subtle tilt untuk drift/jitter kecil.

## Area dan kontinuitas V2

`area_ids` menunjuk area fisik; `functions` boleh lebih dari satu (bathroom + laundry tetap satu area bila satu ruang). `visible_intervals` dapat tumpang tindih; `route` hanya perjalanan yang benar-benar dilalui. Fase gerak bukan batas area, dan cut memulai shot baru. Tidak menyimpulkan koneksi denah dari urutan shot. Gunakan `style_names_language: "en"`, primary-style/interior-style serta klaim influence terpisah agar label dapat ditemukan tanpa sintesis AI.


---

<!-- Source: audit/providers.md -->

# Menggunakan ChatGPT dan Gemini

Gunakan chat baru per video agar sumber, revisi dan koreksi mudah diikuti. Lampirkan MP4 secara terpisah dan homeku-audit-kit.zip, lalu kirim prompt mulai audit. Kit tidak mengandung video atau audio dan berisi empat file input: README, bootstrap runtime, template audit dan template log. `python homeku_runtime.py --output .` memulihkan semua modul/schema/font/lisensi dari payload lokal; tidak ada dependensi runtime yang dibuang.

Pilih lingkungan chat yang dapat memeriksa video/frame, menjalankan helper dan menghasilkan file unduhan. Jalankan operasi yang diperlukan langsung; jangan menyimpulkan kemampuan hanya dari nama model. Jika suatu operasi benar-benar gagal, catat operasi/error tersebut dan pulihkan di chat tanpa membuat metadata palsu.

Pada ChatGPT, buktikan kemampuan menerima sumber dan menjalankan inspect/sample di workspace yang dipakai; dokumentasi file tidak menjamin FFmpeg/code execution tersedia di semua permukaan. Tampilkan hasil dan minta koreksi terarah sebelum file final diunduh. Panduan resmi menjelaskan alur sumber/format/kriteria review dan revisi file: [Work with files](https://learn.chatgpt.com/docs/artifacts-viewer?surface=app).

Pada Gemini, jangan menyamakan kemampuan menonton video dengan ketersediaan Python/FFmpeg untuk ekspor. Jika workspace terpilih tidak dapat menjalankan bootstrap/helper, laporkan operasi yang gagal dan gunakan workspace beralat yang sesuai sebelum membuat ZIP; jangan mengarang hasil helper. Video diunggah sendiri, di luar ZIP kit. Panduan resminya menyatakan ZIP input tidak memuat video/audio dan dibatasi sampai 10 file di dalam ZIP, ukuran ZIP 100 MB. MP4 tidak dikemas di kit input; ketersediaan akun dapat berbeda. [Attach and analyze files](https://support.google.com/gemini/answer/14903178?hl=en).

Dokumentasi tersebut mendukung cara memasukkan/meninjau file; bukan bukti bahwa pilot HOMEKU telah dijalankan pada akun/model tertentu. Model/build yang tidak diketahui tetap unknown/null. Tidak ada asumsi frame rate internal model atau jaminan bahwa Gemini dan ChatGPT memberi jawaban identik.

Sisa enam pilot dibagi di antara kedua lingkungan agar keduanya diuji. Tidak wajib mengaudit setiap video dua kali. Pengguna menilai isi di chat dan mengunduh ZIP final setelah koreksi; importer repo tidak menambahkan review isi kedua.


---

<!-- Source: audit/calibration.md -->

# Contoh notasi dan bahan kalibrasi

Contoh berikut menunjukkan sintaks, bukan label yang harus disalin ke setiap video:

```text
Orbit Right (~15°–20°) →
Accelerating Dolly-In (~2×) toward teak entrance door.
```

```text
Dolly-In (~1.3×) +
Orbit Left + strong Pan Right (~35°).
```

```text
Dolly-In (~2×) +
gentle Pan Right (~15°).
```

Pan/orbit tunggal, gerakan lain, fase Static dan Uncertain tetap sah. Angka/material pada contoh tidak menjadi default. Interpretasi hanya ditulis bila didukung sumber; batasnya dicatat terpisah agar ringkasan tetap ringkas.

## Kasus pembeda

| Kasus | Cara membaca |
| --- | --- |
| Dua shot dengan framing sama, satu menempuh perubahan dalam 2 s dan satu dalam 6 s | Perubahan per waktu berbeda; keduanya dapat smooth tetapi temponya berbeda |
| Ukuran objek membesar tanpa parallax yang jelas | Cukup untuk menyatakan perubahan skala; dolly fisik versus zoom belum tentu terpisah |
| Kamera mundur dan membuka seluruh area | Gambaran area biasanya di akhir; gambar awal sumber tetap lebih dekat |
| Objek bergeser ke kanan layar | Belum membuktikan Pan Right; periksa rotasi pandangan dan translasi/parallax |
| Satu lintasan melewati exterior, entry, living dan kitchen tanpa cut | Fungsi bertambah tetapi tidak otomatis menjadi empat shot |
| Enclosure shower, laundry tower dan dua bukaan berbeda | Catat hubungan serta konfigurasi ini; jangan mengganti dengan bathroom generik |

## Pilot edh001: audit diterima; kalibrasi lintas pilot masih terbuka

Laporan edh001 berasal dari video asli, bukan anotasi arsip. Durasi stream 18.4 s dengan cut pada 4.733333333, 8.3, 11.566666667 dan 15 s. Snapshot audit ulang memisahkan orbit kanan awal eksterior dari pendekatan yang meningkat, membedakan arc OUT pada living/bedroom, pan kiri kitchen dan pan kanan bathroom.

Laporan itu belum menjadi ground truth seluruh video. Pengguna telah menerima koreksi gerakan shot 02 berikut, setelah pemeriksaan ulang seluruh 107 frame asli pada indeks 142–248 (4.733333333–8.266666667 s; akhir interval shot 8.3 s):

```text
Dolly-Out (~2×) + Orbit Left + Pan Right.
```

Penerimaan awal ini khusus gerakan shot 02. Pada 22 November 2026, koreksi tersebut sudah diterapkan ke draf audit ulang format 1.1. Seluruh durasi diaudit ulang dengan 10 FPS dan pendalaman native; 461 frame unik diperiksa, termasuk seluruh shot 02/04. Setelah meninjau hasil audit ulang, pengguna menyetujui keseluruhan snapshot dan meminta ekspor final. Ekspor telah dilakukan dengan MD SHA-256 2d04d6bbd7fd35ee813ea7298322d593f195322f864dc2ca23142af57c4a260f; riwayat dan hash paket ada pada docs/edh001-re-audit.md. Persetujuan isi tidak menjadikan estimasi visual sebagai pengukuran pose fisik. Jangan menyalin gerak/angka ini ke sumber lain. Setelah koreksi pengguna dan enam pilot lintas chat selesai, bekukan contoh dengan versi/hash yang sesuai.

## Kalibrasi V2 — belum dibekukan

Riwayat penerimaan di atas hanya berlaku untuk edh001 r0001/format 1.1. Tahap 2 mengaudit ulang sumber secara nyata, mengisi audit.json 2.0, merender MD/kolase 2.1.2 dan meminta persetujuan snapshot lengkap yang baru sebelum r0002. Log lama tidak dihitung sebagai pemeriksaan V2 baru. Enam pilot pengguna belum dijalankan; kesamaan struktur fixture tidak membuktikan ketepatan visual atau ketersediaan tool pada akun ChatGPT/Gemini tertentu.

Kalibrasi memisahkan kesalahan tafsir kamera/desain, instruksi, render/media dan ingest. Catat koreksi nyata beserta versi/ID/rujukannya; jangan menyalin angka kalibrasi sebagai default sumber lain. Label gaya teknis Inggris, estimasi luas wajib, area/rute/fase dan kelengkapan detail merupakan bagian review isi V2.

### Pemeriksaan V2 edh001 pada 22 November 2026

Audit baru telah memeriksa 455 frame unik dari 552: baseline 10 FPS seluruh shot; native seluruh shot 01 (142 frame), 02 (107), 04 (103), serta ekor shot 03 (53 frame). Log dipisahkan dari r0001 dan tersimpan pada manifest snapshot r0002 yang diterima. Kelima cut dan rumusan kamera r0001 tetap didukung setelah pemeriksaan baru. Shift gaya utama ke Contemporary Modern merupakan penamaan teknis Inggris; tambahan Warm Contemporary dan pengaruh Scandinavian Contemporary tetap interpretasi dengan status/confidence/bukti pada JSON.

Laporan review telah disetujui pengguna sebagai keseluruhan snapshot V2. Kandidat dipertahankan di audit/pilots/v2-candidates/edh001; ZIP r0002 diekspor tanpa render ulang lalu di-ingest. Referensi aktif kini r0002/2.0. Ini bukti audit lokal di Codex, bukan run pada antarmuka ChatGPT atau Gemini. Tidak ada continuous take lintas beberapa area fisik dalam edh001; dukungan multi area baru terbukti secara teknis pada fixture sampai pilot nyata tersedia.

Penerimaan V2 pada chat 22 November 2026: pengguna menyatakan “ya saya setuju” setelah laporan lengkap, storyboard dan kelima kolase ditampilkan. Snapshot `71e949c51a3ca82f0a8d22c26ad98c82c6283d8c40413b8b0a24ef99e178ca45`; ZIP `c290e7f81642498330cdb4b0b4b2ecaf2238c5074b83761bf31b08040e74c26f`. Byte sumber JSON/MD/manifest/media tidak berubah pada ekspor/ingest. Ini penerimaan edh001 saja; enam pilot pengguna tetap belum dijalankan dan kalibrasi lintas provider belum dibekukan.


---

<!-- Source: audit/prompts/01-audit.md -->

# Prompt mulai audit V2

Audit MP4 terlampir untuk pustaka HOMEKU. Buka homeku-audit-kit.zip, baca README, jalankan bootstrap runtime, lalu baca template JSON dan panduan pengisian. Kerjakan inspeksi video dan semua helper di workspace chat; saya cukup meninjau hasil dan mengunduh satu ZIP final.

Gunakan ID dari stem MP4. Jalankan inspect untuk hash/metadata/PTS aktual. Tentukan cut nyata, lalu periksa baseline 10 FPS sepanjang setiap shot termasuk frame native awal/akhir. Lihat gambar yang dipilih. Perdalam semua frame native pada rentang arah/fase/tempo/oklusi/detail yang belum jelas, termasuk seluruh shot bila perlu. Frame yang hanya diekstrak tidak ditandai viewed; model_build tidak diketahui null.

Tulis audit.json sebagai satu sumber: gaya utama/pengaruh/interior dengan istilah English dan style_names_language=en; estimasi luas lantai total berupa rentang angka wajib; detail Arsitektur, Furnitur dan properti, Lingkungan yang konkret; fakta konfigurasi/bukaan/penyimpanan/orientasi/status/bukti; posisi dan arah kamera awal, framing serta cahaya. Jangan mengisi ruangan generik atau memastikan material fisik yang tidak terlihat. Prosa penjelasan Indonesia; basis/uncertainty tetap JSON. MD luas cukup angka m² tanpa catatan tambahan.

Satu take tanpa cut tetap satu shot walau melewati beberapa area. Bedakan area fisik dari fungsi, visibility dari route, dan route dari fase kamera. Catat interval/rute/penghubung/reveal serta journey DNA multi area. Jangan mengarang denah atau kontinuitas dari urutan edit.

Terapkan aturan arah/fase: oklusi + paralaks + perspektif, pan berbeda dari orbit/truck; gerak benda di layar bukan arah kamera. Bedakan dolly/zoom dan smooth/tempo. Jitter vertikal kecil bukan tilt. Gunakan notasi English, + simultan, → berurutan, estimasi ~×/~° berdasar jangkar. Summary harus sejalan dengan fase; tempo_profile menyimpan perkembangan sedang/cepat/dll, bukan default slow. Pertahankan kronologi/durasi sumber tanpa reverse/default produksi.

Pilih frame asli untuk kolase: normal tepat Start/Middle/End; multi dinamis sesuai momen penting, bukan wajib lima. Pilih overview seluruh area penting, biasanya awal IN/akhir OUT. Overview bukan otomatis posisi awal produksi. Simpan pilihan indeks/PTS/bukti stabil; tidak ada JPEG frame kerja dalam ZIP final.

Jalankan draft-v2, periksa silang JSON/narasi/kamera/media, lalu review. Tampilkan storyboard, kolase semua shot dan analysis.md manusia lengkap yang dirender helper. Kamera sederhana dan teknis harus sejalan; semua bagian penting tetap tersedia tanpa tabel proses teknis dalam MD. Jangan mengarang fakta untuk lolos validator.

Tunggu koreksi atau pernyataan saya bahwa keseluruhan kandidat sesuai. Jangan membuat ZIP final dulu. Persetujuan satu gerakan atau tampilan bukan persetujuan seluruh audit. Tugas ini hanya audit/pengetahuan referensi, tanpa membuat konsep/gambar baru atau plugin produksi.


---

<!-- Source: audit/prompts/02-correct.md -->

# Prompt koreksi V2

Perbaiki audit terbaru berdasarkan catatan saya:

[TULIS SHOT/TIMESTAMP DAN KOREKSI]

Baca ulang sumber terkait; periksa native jika arah/fase/tempo atau detail belum jelas. Isi frame_reviews hanya untuk gambar yang benar-benar dilihat. Terapkan oklusi/paralaks/perspektif serta bedakan jitter dari tilt nyata.

Perbarui audit.json dan metadata/log aktual di workspace, bukan MD hasil render. Bawa seluruh desain/fakta/status/bukti dan bagian yang tidak berubah ke kandidat baru. Periksa dampak pada identitas/luas, area/fungsi/rute, komposisi, kamera sederhana/summary/fase/tempo dan pilihan panel. Usahakan besaran kamera berbukti tanpa mengarang presisi.

Jalankan draft-v2 lalu review ulang. Tampilkan kolase/bagian yang berubah beserta konteks, storyboard dan MD lengkap terbaru. Receipt/digest sebelumnya batal jika isi kandidat berubah. Jangan mengekspor sampai saya menyatakan keseluruhan versi terbaru sesuai; persetujuan satu aspek bukan persetujuan seluruh kandidat. Koreksi sebelum ingest boleh tetap revisi yang sama; referensi yang sudah aktif memakai revisi berikutnya dengan supersedes yang benar.


---

<!-- Source: audit/prompts/03-export.md -->

# Prompt ekspor final V2

Keseluruhan kandidat audit terbaru yang saya tinjau sudah sesuai. Ekspor satu ZIP final HOMEKU dari snapshot tersebut.

Gunakan export-v2 atas folder kandidat dan receipt review terakhir, bukan menjalankan draft ulang. JSON, MD, manifest, JPEG dan created_at harus tetap sama dengan kandidat yang saya periksa. Jangan mengubah isi atau memperbarui media/metadata saat ekspor. Jika kandidat berubah atau receipt tidak cocok, tampilkan ulang perubahan sebelum meminta persetujuan versi baru.

Pastikan log mencatat pemeriksaan nyata dan sumber terikat hash yang sama. source.mp4 hanya disertakan jika sumber kanonis belum terverifikasi tersedia; jika diperlukan tetapi belum ada dalam kandidat yang disetujui, buat kandidat lengkap baru dan tampilkan kembali sebelum ekspor. Jangan menambahkan script, receipt, audit-info, frame sementara, motion/ atau klip shot ke ZIP referensi.

Jalankan validasi folder dan ZIP yang dibuka ulang serta kesamaan digest seluruh payload. Jika gagal, jelaskan error nyata; jangan menulis hash/bukti rekaan. Berikan satu tautan download <id>-rNNNN.zip, jumlah shot/gambar dan ringkasan pemeriksaan teknis singkat. Saya menaruh ZIP di incoming/ lokal lalu menjalankan ingest; tidak ada review isi kedua di repo.


---

<!-- Source: docs/contracts/package-v2.md -->

# Kontrak paket 2.0 — fondasi V2

Format eksplisit `manifest.contract_version = "2.0"`; 1.0/1.1 tetap memakai kontrak legacy. Implementasi fondasi tersedia; workflow chat dan pilot V2 diselesaikan pada Tahap 2.

## Isi dan otoritas

```text
<id>-r0001.zip
  <id>/
    audit.json
    analysis.md
    manifest.json
    media/storyboard.jpg
    media/shot-01.jpg
    media/shot-02.jpg
    ...
    source.mp4             # Opsional sesuai ketersediaan sumber kanonis
```

`audit.json` satu sumber isi yang ditulis AI. `analysis.md` hasil renderer untuk manusia. Manifest menyimpan metadata teknis/provenance, bukan salinan fakta desain. Tidak ada analysis.json, receipt, log kerja terpisah, motion/, JPEG frame lepas atau seluruh rangkaian frame. Setiap shot tepat satu kolase; satu storyboard per referensi.

ID mengikuti stem MP4 dan kapitalisasi aslinya. Revisi 1 memakai supersedes null; revisi berikutnya tepat +1 dan menunjuk revision/content_sha256 aktif. Paket r0001 yang telah diterima tidak diedit atau ditimpa; ZIP penyerahan lama tetap disimpan. Registry versi 1 tetap dipakai, entri V2 menambahkan contract_version dan audit_sha256; entri legacy tidak dilengkapi secara rekaan.

Sumber kanonis `video/<id>.mp4` disimpan sekali. Sertakan source.mp4 hanya jika sumber kanonis belum terbukti tersedia dengan SHA-256 yang sama. Importer tidak menyimpan salinan MP4 dalam references/. Sumber disamakan dengan ffprobe: durasi stream video, dimensi tampilan, FPS rasional dan indeks stream.

## Sumber JSON dan pemeriksaan video

audit-v2.schema.json mengatur isi sumber; manifest-v2.schema.json mengatur metadata. Luas lantai wajib rentang positif min < max, diisi AI dengan estimasi visual. Basis/uncertainty tetap JSON. Semua aspek DNA legacy dipertahankan; domain, atribut, label baru, negasi, hubungan dan ketidakpastian tidak dibuang.

Shot adalah satu take kontinu sampai cut sumber; area/fungsi bukan cut. `areas` adalah identitas area fisik dengan functions dan visible_intervals global. Interval area berbeda boleh bertumpang tindih; area yang sama boleh muncul kembali pada interval terpisah. `shots[].route` hanya lintasan kamera yang benar-benar dinyatakan, boleh kosong jika kamera tetap di satu posisi. Terlihat dari kamera tidak sama dengan dimasuki kamera.

Fase kamera dan profil tempo masing-masing menutup interval shot tanpa gap/overlap. Satu fase boleh melalui banyak area, satu area boleh memuat banyak fase. Komponen simultan memakai +, fase berurutan memakai →; summary dan komponen fase harus sama. `components_parsed` diperiksa terhadap raw, tidak ditafsirkan menjadi gerak produksi. Rasio ~× bukan kecepatan; tempo eksplisit tersimpan terpisah.

Baseline tetap 10 FPS sepanjang tiap shot dengan frame native awal/akhir. Pendalaman memakai semua frame native pada rentang yang perlu, tanpa memaksa 30 FPS/interpolasi. Manifest frame_reviews memakai kontrak record 1.1: pilihan dan daftar yang benar-benar dilihat, mode/rentang/reason. Validator memeriksa PTS, batas dan kelengkapan deklarasi; tidak dapat membuktikan kebenaran penglihatan auditor. Sampling yang baru diekstrak tidak otomatis dianggap sudah dilihat.

## Pilihan media dan bukti

Auditor menentukan `panels` dan `overviews` dalam audit.json. Setiap pilihan mempunyai ID unik, shot_id, area_ids, indeks native, PTS, role, label dan reason. Awal/akhir harus frame asli tepat di batas shot. Normal: tepat tiga pilihan start/middle/end, tengah memakai PTS terdekat titik tengah, tiga kolom. Multi area: jumlah dinamis minimal cukup, kronologis, tanpa frame berulang; dapat beberapa baris. Storyboard memakai seluruh overview menurut urutan sumber, tepat satu baris. Overview biasanya awal IN/akhir OUT; alasan pilihan tersimpan tanpa JPEG overview mandiri.

Manifest media berisi path/hash/dimensi dan panels sekali. Panel teknis menunjuk selection_id, shot/area, frame index/PTS, scale dan bbox `[x,y,width,height]` untuk **foto saja**, bukan caption. Tidak ada crop konteks atau pembesaran generatif; default panel mempertahankan dimensi asli. Skala turun hanya lewat konfigurasi eksplisit. Header dan caption terang/kontras berada di luar foto. JPEG quality 60–98, scale (0,1], kolom multi 1–6; default quality 91, scale 1, kolom 4. Normal tetap tiga kolom, storyboard tetap satu baris. Batas 60 juta piksel dan dimensi JPEG 65.000 diperiksa sebelum alokasi.

Fakta/fase/profil/hubungan merujuk ID pilihan, bukan path frame sementara. Bukti tambahan yang tidak masuk kolase memakai `frame:shot-01:42`, menunjuk indeks native dalam shot; timestamp dilampirkan validator ke proyeksi. Inventaris bukti proyeksi menyimpan metadata bersama; pembaca bisa mengambil panel tanpa caption atau frame native ke folder sementara. Gambar terpilih bukan pengganti audit 10 FPS/native.

## Penyajian 2.1.2 dan istilah

Nama gaya utama, pengaruh gaya dan gaya interior ditulis menggunakan istilah bahasa Inggris; penjelasan tetap bahasa Indonesia. Auditor menyatakan identity.style_names_language = "en". Field ini wajib pada renderer 2.1.x; paket lama yang telah diterima tidak diubah. Schema memeriksa deklarasi, sedangkan nama/tafsir gaya ditulis dan diperiksa auditor. Generator tidak menerjemahkan, menebak atau mengganti nama gaya dari deskripsi bentuk rumah.

- Header kolase cukup **SHOT 03 · Kitchen** diikuti `8.30–11.57s · 3.27s` pada baris yang sama bila muat. Tidak ada daftar waktu Start/Middle/End dalam header.
- Di bawah tiap foto normal: **Start** · 8.30s, **Middle** · 9.93s, **End** · 11.53s. Label bold; timestamp regular sekitar 75% ukuran label, pada baseline yang sama. Nama area cukup pada judul.
- Multi area memakai nomor/label momen dengan timestamp kecil di bawah foto, misalnya **02 · Entrance reveal** · 6.80s. Caption panjang boleh membungkus tanpa menimpa foto. Satu shot tetap satu pengambilan.
- Header storyboard: **ID — Primary style — 18.40s — 5 shot**. Gunakan identity.primary_style, bukan nama kreatif rumah atau tafsir baru generator.
- Caption storyboard: **03 · Kitchen**, diikuti `Overview · 8.30s` dengan font waktu lebih kecil daripada nama area. Beberapa area dalam satu shot mempertahankan nomor shot sama.
- Font bold asli digunakan untuk judul/nama area/label; seluruh judul serta label area diperkecil sekitar 15% dari 2.1.0, termasuk storyboard. Ukuran tetap mempertimbangkan lebar kanvas. Caption rata kiri, ruang caption sejajar dan teks panjang membungkus di luar foto. Storyboard tetap satu baris.
- Dua desimal hanya tampilan: audit JSON, manifest PTS/frame index, bukti serta pointer tidak dibulatkan atau dimutasi. Versi terdahulu mempertahankan format lamanya.

## Snapshot dan versi renderer

Draft membuat kandidat lengkap; review menampilkan MD/media dan menghasilkan receipt di **luar** kandidat. Receipt bukan persetujuan otomatis. Setelah pengguna menyetujui keseluruhan kandidat di chat, export menerima digest snapshot dan membungkus byte yang sama. Tidak membuat ulang JPEG, MD, created_at atau manifest. Setiap perubahan file, termasuk salinan MP4 opsional, membatalkan digest. Hash sumber kanonis selalu terikat manifest. Hash isi revisi mengecualikan salinan source.mp4 opsional supaya identitas revisi tidak bergantung penempatan sumber.

Renderer/report dan media profile terbaru `2.1.2`; pasangan `2.0.0`, `2.1.0`, dan `2.1.1` tetap didukung. Hash template beku serta font regular tercatat pada manifest, ditambah bold_font_sha256 untuk 2.1.x. Report dan media harus memakai pasangan versi yang sama. Aset versi diterima tidak boleh ditimpa; renderer/template/font baru memakai registrasi versi/aset baru. Pemeriksaan MD memakai renderer versi paket. Berkas template penulisan berikutnya tidak mengubah salinan template beku yang sudah dipakai paket.

ZIP dibuka ulang, divalidasi lalu dibandingkan digest. Ekstraksi mempertahankan aturan anti traversal, symlink, duplikat, executable dan batas ZIP legacy: 2.000 file, 95 MiB/file, 256 MiB total, teks 2 MiB/file. File/media yang diizinkan diputuskan kembali oleh kontrak versi; keberadaan audit.json saja bukan deteksi V2.

Pengguna mengoreksi sebelum download ZIP. Ingest lokal `python tools/library.py ingest` melakukan validasi teknis dan memperbarui turunan; tidak ada review isi kedua atau watcher otomatis.


---

<!-- Source: docs/contracts/analysis-v2.md -->

# Laporan manusia V2

Laporan `analysis.md` dihasilkan dari audit.json, bukan sumber ekstraksi fakta. Gunakan template baku dan renderer terbaru 2.1.2 dengan dukungan versi terdahulu. Salinan template sesuai versi berada pada tools/assets/templates/analysis-<versi>.md; perubahan versi selanjutnya tidak menimpa aset tersebut.

Urutan tetap:

1. Identitas desain: nama rumah, gaya utama, pengaruh, interior, ciri, palet dan suasana/lingkungan.
2. Ukuran dan proporsi: ukuran, massa, vertikal, tapak, proporsi, perkiraan luas lantai wajib.
3. Struktur dan timeline: satu baris per take kontinu; gerak bahasa manusia dan ritme.
4. Storyboard: satu baris overview seluruh area penting.
5. Detail shot: satu kolase, urutan panel dan tiga kelompok A/B/C.

A: paragraf Arsitektur, Furnitur dan properti, Lingkungan yang ditulis AI secara konkret. Multi area memakai penanda nama area dalam satu kartu. B: fokus, posisi/arah/sudut awal, framing awal → akhir dan pencahayaan; multi menambahkan rute, area terlihat serta hubungan/peralihan. C: bahasa kamera sederhana lengkap, ritme, DNA perjalanan bila berlaku, timeline fase bila multi/beberapa fase, lalu notasi teknis lengkap.

Rentang luas ditampilkan hanya `**60–90 m²**` (contoh format), tanpa dasar perkiraan atau catatan kepastian. Hash, log frame, ID fakta dan status proses tetap pada JSON/manifest/workspace. Renderer hanya menata nilai/narasi sumber; tidak menjalankan AI, menerjemahkan notasi atau menyimpulkan fakta.

Anchor eksplisit `profil-dna` dan `shot-NN` stabil. Metadata teknis dan pointer klaim berada pada proyeksi, sehingga perubahan judul manusia tidak memutus sumber. Ingest menolak laporan yang berbeda dari hasil renderer JSON sesuai versi; tidak memperbaikinya diam-diam.

Contoh normal dan contoh multi area adalah ilustrasi fiktif, bukan audit/paket aktif. Kelengkapan narasi dan kesesuaian semantiknya terhadap fakta diperiksa AI sebelum review; validator hanya memeriksa kesesuaian teknis eksplisit.

Nama gaya utama/pengaruh/interior memakai bahasa Inggris, penjelasan bahasa Indonesia. identity.style_names_language=en wajib pada renderer 2.1.x. Nilai nama berasal dari audit, bukan terjemahan renderer. Urutan panel pada laporan 2.1.x memakai Start/Middle/End atau nama momen dengan waktu ringkas, sementara timeline dan JSON mempertahankan data waktu sumber. Tampilan media mengikuti kontrak 2.1.2: judul/nama area tebal dengan ukuran 15% lebih kecil dari 2.1.0; header kolase cukup judul/rentang/durasi dan caption foto kembali memakai label serta timestamp kecil pada baris yang sama, dan header storyboard ID — Primary style — durasi — jumlah shot. Urutan panel pada MD tetap mencantumkan waktu sumber.


---

<!-- Source: docs/template-analysis-v2.md -->

# Template baku analysis.md — V2

Acuan: contoh normal, contoh multi area, dan plan V2.

Status: fondasi renderer V2 tersedia dan menghasilkan MD dari audit.json. Renderer 2.1.2 memakai salinan template beku yang berisi struktur ini; workflow chat serta audit ulang pilot tetap Tahap 2.

**Petunjuk pengisian**

- Laporan dimulai pada judul ID di bawah. Pengantar ini dan komentar petunjuk tidak masuk laporan final; ganti semua penanda {{...}}.
- Pertahankan lima bagian utama serta kelompok A/B/C. Ulangi kartu sesuai jumlah shot, bernomor 01 dan seterusnya, dipisahkan garis horizontal.
- Satu pengambilan berkelanjutan tetap satu shot meskipun melewati banyak area. Area terlihat dan rute kamera dicatat berbeda; jangan membuat cut yang tidak ada.
- Desain berupa paragraf konkret tentang bentuk, susunan, posisi dan hubungan objek. Panjang mengikuti detail yang terlihat, tanpa kuota objek atau batas kata yang menghilangkan informasi penting. Jangan mengarang detail.
- Untuk multi area, setiap kategori desain memuat paragraf berpenanda **Nama area.** mengikuti urutan kemunculan, tetap dalam satu kartu shot.
- Nama gaya utama, pengaruh gaya dan gaya interior memakai istilah bahasa Inggris; penjelasan tetap bahasa Indonesia. identity.style_names_language wajib en pada renderer 2.1.2. Generator tidak menerjemahkan atau menebak nama gaya.
- Gaya utama wajib bernama jelas; pengaruh gaya mengikuti bukti. Luas lantai wajib rentang estimasi total lantai rumah, ditampilkan hanya sebagai **angka–angka m²** tanpa catatan kepastian atau dasar perkiraan. Rincian estimasi tetap dalam JSON.
- Bahasa sederhana menjelaskan semua arah, urutan/kebersamaan gerak, target dan perubahan penting secara singkat. Bedakan perpindahan kamera dari perubahan arah pandang.
- Notasi teknis berbahasa Inggris: + untuk bersamaan, → untuk urutan, ~× untuk perubahan skala terhadap jangkar, bukan kelipatan kecepatan. Tempo terpisah; arah, waktu dan ritme mengikuti sumber.
- Timeline gerakan wajib untuk multi area atau beberapa fase. Fase mengikuti perubahan komponen kamera; pergantian area atau tempo saja tidak memaksa fase baru. Waktu mengacu ke awal video, berurutan sesuai shot. Semua tampilan kamera harus sejalan.
- Media final hanya satu kolase per shot dan satu storyboard. Shot satu area tepat 3 panel awal/tengah/akhir dalam 3 kolom. Multi area memakai panel dinamis: awal/akhir ditambah area, penghubung/reveal dan perubahan penting; pilih jumlah paling sedikit yang tetap lengkap, tanpa wajib 5 atau panel berulang. Panel kronologis; boleh beberapa baris jika terlalu panjang.
- Storyboard overview seluruh area penting dalam satu baris. Multi area boleh beberapa panel dengan nomor shot sama. Overview adalah pilihan frame asli, biasanya awal IN/akhir OUT, bukan JPEG terpisah. Frame kerja hanya sementara.
- Judul kolase/storyboard serta nama area tetap tebal tetapi 15% lebih kecil daripada 2.1.0. Header kolase cukup judul diikuti rentang/durasi pada satu baris, font regular sekitar 75% ukuran judul; dapat membungkus jika teks panjang. Timestamp Start/Middle/End atau momen multi area dikembalikan ke bawah masing-masing foto, memakai font regular sekitar 75% ukuran label bold. Timestamp tiap panel tidak dirangkum lagi dalam header. Caption rata kiri dan sejajar; waktu dua desimal seperti 2.37s. Header storyboard: ID — Primary style — 18.40s — 5 shot; setiap panel memakai nomor shot/nama area tebal lalu Overview · 2.37s.
- Kolase berlabel nomor shot/area/waktu/durasi; tiap panel berlabel peran atau kejadian serta timestamp. Tulisan di luar foto, rasio/detail sumber terjaga; metadata panel tetap dapat ditelusuri.
- Hapus bagian opsional yang tidak berlaku. Jangan menyisakan penanda kosong. Batas pengamatan penting dijelaskan singkat; hash, log frame dan tabel pembuktian teknis tidak tampil pada laporan manusia.

---

# {{ID}} — {{NAMA_DESAIN}}

## 1. Identitas desain

- **Nama desain rumah:** {{NAMA_DESAIN_DESKRIPTIF}}.
- **Gaya utama:** {{NAMA_GAYA_UTAMA}}.
- **Pengaruh gaya:** {{GAYA_PENDUKUNG_DAN_ALASAN_SINGKAT}}.
- **Gaya interior:** {{NAMA_DAN_KARAKTER_INTERIOR}}.
- **Ciri pengenal:** {{DUA_ATAU_TIGA_CIRI_PEMBEDA}}.
- **Palet utama:** {{WARNA_DAN_MATERIAL_TAMPAK}}.
- **Suasana dan lingkungan:** {{SUASANA_CAHAYA_DAN_LINGKUNGAN}}.

## 2. Ukuran dan proporsi bangunan

| Aspek | Estimasi visual |
| --- | --- |
| Ukuran rumah | {{TINY_SMALL_MEDIUM_ATAU_LARGE}} |
| Bentuk bangunan | {{BENTUK_DAN_SUSUNAN_MASSA}} |
| Skala vertikal | {{TINGKAT_TERLIHAT_DAN_BENTUK_BAGIAN_ATAS}} |
| Tapak bangunan | {{KESAN_BENTUK_DAN_CAKUPAN_TAPAK}} |
| Proporsi utama | {{HUBUNGAN_LEBAR_TINGGI_PANJANG}} |
| Perkiraan luas lantai | **{{LUAS_MIN}}–{{LUAS_MAX}} m²** |

## 3. Struktur dan timeline video

{{DURASI_TOTAL_JUMLAH_SHOT_DAN_CUT_ATAU_KONTINUITAS}}

| Shot | Waktu (detik) | Durasi | Area/Scene | Gerakan singkat | Ritme |
| --- | --- | --- | --- | --- | --- |
| {{NN}} | {{AWAL}}–{{AKHIR}} | {{DURASI}} detik | {{AREA_ATAU_URUTAN_AREA}} | {{GERAK_BAHASA_MANUSIA}} | {{TEMPO_DAN_PERUBAHAN}} |

<!-- Ulangi satu baris per shot, bukan per area. -->

## 4. Storyboard

!Storyboard overview seluruh area

<!-- Satu baris overview seluruh area penting; tiap panel berlabel shot, area dan waktu. Beberapa area satu shot tetap memakai nomor shot sama. -->

## 5. Detail shot

### Shot {{NN}} — {{AREA_ATAU_URUTAN_AREA}} · {{DURASI}} detik

<!-- Jenis shot berikut hanya untuk multi area. -->
**Jenis shot:** berkelanjutan, multi area, tanpa cut.

!Kolase perjalanan Shot {{NN}}

**Urutan panel:** {{PERAN_AREA_ATAU_KEJADIAN_DAN_WAKTU_SETIAP_PANEL}}.

<!-- Normal: awal → tengah → akhir. Multi area: panel dinamis sesuai momen penting dan kronologi, bukan interval waktu seragam. Rujuk panel awal bila overview storyboard berasal dari akhir OUT; tidak menautkan JPEG frame terpisah. -->

#### A. Desain area

**Arsitektur**

{{PARAGRAF_BENTUK_SUSUNAN_DINDING_PLAFON_LANTAI_BUKAAN_KABINET_MATERIAL_DAN_POSISI_LAMPU}}

**Furnitur dan properti**

{{PARAGRAF_BENTUK_POSISI_HUBUNGAN_FURNITUR_PERALATAN_PENYIMPANAN_DEKORASI_DAN_TANAMAN}}

**Lingkungan**

{{PARAGRAF_PEMANDANGAN_BUKAAN_TAMAN_VEGETASI_BANGUNAN_SEKITAR_CUACA_DAN_HUBUNGAN_LUAR_RUMAH}}

<!-- Multi area: gunakan beberapa paragraf berpenanda nama area dalam setiap kategori, tetap satu shot. -->

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Area yang terlihat | {{AREA_DAN_YANG_TERLIHAT_BERSAMAAN}} |
| Rute kamera | {{LOKASI_AWAL_JALUR_DAN_AKHIR}} |
| Fokus utama | {{SUBJEK_DAN_PERALIHAN_FOKUS}} |
| Posisi kamera awal | {{LOKASI_RELATIF_ARAH_PANDANG_DAN_SUDUT}} |
| Framing awal → akhir | {{CAKUPAN_AWAL_PERUBAHAN_PENTING_DAN_AKHIR}} |
| Pencahayaan | {{SUMBER_ARAH_KARAKTER_DAN_PERUBAHAN_CAHAYA}} |

<!-- Area yang terlihat dan Rute kamera wajib untuk multi area; pada normal boleh dihapus bila mengulang judul/posisi. -->

**Hubungan antararea**

| Aspek | Penjelasan |
| --- | --- |
| Penghubung area | {{PINTU_KORIDOR_BUKAAN_ATAU_OPEN_PLAN}} |
| Peralihan yang terlihat | {{WAKTU_AREA_MULAI_TERLIHAT_DAN_KAMERA_MEMASUKINYA}} |
| Kesinambungan ruang | {{ELEMEN_PENJAGA_ORIENTASI_SEPANJANG_PERJALANAN}} |

<!-- Hubungan antararea hanya untuk multi area. Waktu area terlihat berbeda dari waktu kamera masuk; jangan mengarang waktu yang tidak didukung. -->

#### C. Gerakan kamera

**Bahasa sederhana**

{{PARAGRAF_SINGKAT_LENGKAP_LINTASAN_ARAH_PANDANG_TARGET_URUTAN_GERAK_BERSAMAAN_DAN_PERUBAHAN_PENTING}}

**Ritme:** {{TEMPO_AWAL_PERUBAHAN_PENTING_DAN_AKHIR}}.

**DNA perjalanan:** {{POLA_PERJALANAN_PERALIHAN_FOKUS_REVEAL_DAN_RITME}}.

<!-- DNA perjalanan untuk multi area; pada normal hanya bila menambah penjelasan penting. -->

**Timeline gerakan**

Semua waktu berikut dihitung dari awal video. Pergantian baris mengikuti perubahan gerakan kamera; pergantian area tidak otomatis membuat fase atau shot baru.

| Waktu (detik) | Area dan fokus | Gerakan Kamera | Ritme |
| --- | --- | --- | --- |
| {{AWAL_FASE}}–{{AKHIR_FASE}} | {{AREA_PERALIHAN_DAN_TARGET}} | {{SEMUA_KOMPONEN_SIMULTAN_DALAM_NOTASI_TEKNIS}} | {{TEMPO_DAN_PERUBAHAN}} |

<!-- Ulangi baris sesuai fase aktual. Hapus bagian Timeline gerakan untuk shot normal satu fase. -->

**Notasi teknis**

```text
{{NOTASI_TEKNIS_LENGKAP_SESUAI_URUTAN_FASE}}
```

<!-- Untuk shot berikutnya, tambahkan garis horizontal lalu ulangi kartu mulai heading Shot. -->


## Inventaris runtime terpulihkan

| File | SHA-256 |
| --- | --- |
| tools/audit.py | 9aa294108e2787d51ee3563f43bb2c6828880344a75d1d018b2f3be6ee2be90d |
| tools/homeku/__init__.py | fb3d221dd6993826f18718471ceaa2e115d6209534b07bb2d203a05023c3e347 |
| tools/homeku/common.py | e9fce85aa4cd50f6f8e73d68cd7aeb90d9e82dffdf4a6b67f66f37dde59d95b4 |
| tools/homeku/markdown.py | 98c8fce8d82e826c7bb1e674bdfe2c7f235c3cdf0a7ecdd2fae75d0763e2baeb |
| tools/homeku/validation.py | a0f5bc638e01c543c86e82da2f375038011752ef6dd43d7095edb0b321d5a7ed |
| tools/homeku/exporter.py | a37df000a40347842571eae6a4353308687f048b429fb8b1b19d6eac9ae7ee35 |
| docs/contracts/manifest-v1.schema.json | 2646fc5eabc6c99044ee9ee27b2fc6af2a5cfc63279769908b04a46903be8852 |
| audit/template-analysis.md | aa5aa2dd50acdb034d63b2f93e9c1664ffaea554907f3dd2b6d5d57338aa7ded |
| tools/homeku/video.py | 76494ee7ad884634ac175df743c21e3e0e7abb3eacd6cc8e1195fff2fb0fc13a |
| tools/homeku/models.py | 56944cef4e9650d10bbaf730f9d0e00f1dee0ea5b8f355e700331fb892cd2158 |
| tools/homeku/media.py | d824aca4cc5e9ef89ac3ff08f284961058e0d0c5f00e889295667289e9d98c6d |
| tools/homeku/reporting.py | a11e22c7cfce39da7f4c61dd3dd33814c8b1f267a35f1c89a33b026707df0c5e |
| docs/contracts/audit-v2.schema.json | a383005f6724ed1d0e254073ff39c0919bf95c4b838b82f46e5bfe5ffc83470f |
| docs/contracts/manifest-v2.schema.json | e1dd593c3f835090c60e351a3c30e582b2625e1f1bb04e1a43438dcf2ceba904 |
| tools/homeku/media_v2_0.py | f2c7232a9c09ab55a4190b2e0905e9c8b502b68decf23d5bf16ce379c6d204ab |
| tools/homeku/media_v2_1.py | ba0df816b72c760a90c5ebf9d41804e84613d7bff293de8aa84d314df0f5699c |
| tools/homeku/media_v2_1_1.py | 9875b1a4eabd71388db59e8c21f39f18e41440becd8f1cf5a387b9d8b05f936c |
| tools/assets/templates/analysis-2.1.2.md | 4d3eed42a800cc8f4806013dbdf7c7801eac457f77cc163066814a626aa9a0be |
| tools/assets/templates/analysis-2.1.1.md | 6793a4be71cf4ad1d1222aba3d5354e397ee6b9c4f21213de33f4911d4c15d82 |
| tools/assets/fonts/DejaVuSans-Bold.ttf | 5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895 |
| tools/assets/templates/analysis-2.1.0.md | c34e4df89b949b437c9f7010c778f0165a12f9b28fe8597faf6e6d2e3a52be85 |
| tools/assets/fonts/DejaVuSans.ttf | ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280 |
| tools/assets/fonts/LICENSE.txt | e180b3d65bf650dffffd71dd21b6180767b469a18dd87e1d8552be69bb9ecdf0 |
| tools/assets/templates/analysis-2.0.0.md | 25ebc37f6bfe06d3b5bc7d51ef81c6fb02b25a97b5b9cb569ebaafc0466f5c7a |
