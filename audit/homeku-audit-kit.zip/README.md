# Kit audit HOMEKU 3.0

Siapkan satu MP4 sumber terpisah dan ZIP kit ini. Ekstrak empat file input ke workspace chat.

1. Jalankan `python homeku_runtime.py --output .` untuk memulihkan resource lokal berhash. Audit memakai Python 3.11+, Pillow, jsonschema, dan FFmpeg/ffprobe.
2. Baca `audit/visual-audit.md` dan `audit/authoring.md`. Pastikan cut dan periksa baseline 6 FPS dengan batas native. Sumber ≤6 FPS dan shot <1 detik memakai seluruh native.
3. Isi Profil Desain baku dan audit dari gambar yang diperiksa. Catat tipe rumah, atmosfer, dan palet HEX. Nilai besaran tiap komponen gerak dan cantumkan estimasi yang wajar dari frame. Gunakan `mark-viewed` sesudah pemeriksaan, lalu `complete`, `check-input` dan `draft`.
4. Ikuti checklist isi di `audit/authoring.md`. Setelah kandidat lulus validasi, jalankan `review` dan langsung `export --receipt`. Tampilkan laporan enam bagian, Overview, Storyboard, semua kolase, dan tautan unduhan ZIP tanpa MP4 dalam balasan yang sama.
5. Jika ada koreksi, ulangi draft, review, dan ekspor. Berikan tautan ZIP yang terbaru. Simpan MP4 untuk ingest lokal.

Gunakan `audit/prompts/01-audit.md` untuk memulai, `02-correct.md` untuk koreksi, dan `03-export.md` sebagai panduan ekspor. Contoh normal dan multi area adalah fixture sintetis.


## Inventaris resource lokal

| File | SHA-256 |
| --- | --- |
| tools/audit.py | c7077638096e705dfa7e0eda27c5764dfbe9db54b7b93ca22ad2056882c38a4b |
| tools/homeku/__init__.py | df43fdd84c5a9d4d314eb47c88a02ff81e4cf95808205152bb37e0aec3d6c17f |
| tools/homeku/audit_performance.py | 99be30b6c19b04f64f16e6cf6e5abc56aa289b518e35e375bc524799bd8369c8 |
| tools/homeku/audit_quality.py | 4130110495baad61c1343c557f4dfc112ffcc9214fe4e140d47dabf6df973ea5 |
| tools/homeku/audit_session.py | 5f3d0144ad7736f73cc5fd1123eb9e1c87162a3698e79b14819a995bb70d53f6 |
| tools/homeku/authoring.py | 98e831e01a18fbe390828ba9a90eb122f7d4b4c600475f49548852390aa77e69 |
| tools/homeku/camera_notation.py | 2e3329def5b19e0d247029149683fbc81b01a891e6c1f173cadbaf8d509412d8 |
| tools/homeku/camera_pattern.py | c5708318a94415f68629d9703b7562f59e70b04d0f6ae28ede5ad627d52ea314 |
| tools/homeku/common.py | 84b7ef91c87be39753a8bca752557f8b9c16214bdfd6ac961326a924a47d8079 |
| tools/homeku/derivations.py | 3b2a3d063f7aa94c9aa90375bcc0ce2d210d6a1b233b8cc302b1995521a5119f |
| tools/homeku/exporter.py | 7183a8fcd37966872c0fc9707bc5bc155f19db14249f1238961e773ac9624c9b |
| tools/homeku/media.py | 207c1245f77d66bf594f4f0db6d4437ad56296485c8d47844ae0948da2d95a95 |
| tools/homeku/media_incremental.py | fa0316c02f5b7fe3e4df1a1e12ba21a64d5abe122b7135d216c5792cc4b1b919 |
| tools/homeku/models.py | 966340ea994d1f8094d727e0adb7750bfcce493f8f6e63bf85e06448e5467ebb |
| tools/homeku/motion_analysis.py | b7906be8b6b943446258d25941dc4d5cb905602cd67ae5e5e40ee56794c6fe69 |
| tools/homeku/package_manifest.py | 2d26f9c1f4dec8ee2c949ad83b7c78945b465b54a2216d20777ac6c096c07862 |
| tools/homeku/preflight.py | 52450cc9be70941f2145f0337d67023a42e66f16e3aea25174b595e8982268be |
| tools/homeku/render_assets.py | 96aebdd80efa63251a600d4891164a1052a9e3c32958a350efdfaab24d2c2cc8 |
| tools/homeku/report_validation.py | 063d3e2c8d4272e6b46e0b9e791a2f71510feaa23a8f6974c02e835c456a98a8 |
| tools/homeku/reporting.py | 570c03d5f97d5919581c151d6b2318f7a5d2b434dd8b13ac44b7311b6e397ee5 |
| tools/homeku/storage.py | aa8310489011e0e5293a9766662a1040527f2085ce080fa40620c56c90ab1d5b |
| tools/homeku/validation.py | 189615642c835740ae401ea6112da139d481200b86aa9d52e2c5663638dbb0f6 |
| tools/homeku/video.py | 6258f3b76234885cdbc9cc96a2a398526ae7b433efd76d7308564ae455c37e88 |
| tools/homeku/video_cache.py | cb5a63ac34e16d291704bf29e6cfc8e44f104e2ebed48e33696e41e361fca8aa |
| schemas/audit.schema.json | 2a83809e805771ccef252bc7b15767622d922f53bb014e00c6fcc431fbf72ff8 |
| schemas/audit-info.schema.json | ea05be764a74394b1a85056837385d8c7446f1f9bf310855beb13b3d58b68c78 |
| schemas/manifest.schema.json | bce67071a6a2a1360b2004ee2f54f7cb84aded417d74bb17b72df4c67f1c1a9d |
| schemas/reference-reader.schema.json | e842f3937c33ebfa7f3f3bf4ce27aeb925bac631725db6bf66271ea2003fef2f |
| schemas/search-index.schema.json | b89e1d407dfbddb782e2adae88e391d8dd88714616cfba3cf49ec4499be7fdf8 |
| tools/assets/fonts/DejaVuSans.ttf | ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280 |
| tools/assets/fonts/DejaVuSans-Bold.ttf | 5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895 |
| tools/assets/fonts/LICENSE.txt | e180b3d65bf650dffffd71dd21b6180767b469a18dd87e1d8552be69bb9ecdf0 |
| tools/assets/templates/analysis.md | 922902a9b3431f1316ec563de8963371574d6332e9aee7a60b14f9b8038e831c |
| tools/assets/templates/analysis-profile.md | d86f9bcc4f4fc8af70f58df7c7b7ae1ca11acab1aa2a626d05c8baffa89643ac |
| tools/assets/layouts/media.json | d68b9b5a84d6f1c336a5edf4cfa8a1848aa2c77840d503d488e2fcf3fc3ece37 |
| audit/README.md | 9ef917ad13a6511ff0d5720f6be79cdc264c0ddfb1c83be7b92668d942f40874 |
| audit/visual-audit.md | da96a718c7ad16d79d1e9899f9325313916081fbf51150907571d26a0dff25a8 |
| audit/authoring.md | 35c819f25e17fa186ead59406b1f9eec8aa78cafcfa2d3cba706a8ae1633e853 |
| audit/json-guide.md | eb28f2f5573b3ef15b4b191b201ef0491588517aa9164ac1992020d905bc5217 |
| audit/vocabulary.md | c783dbb05182c53e4c6bd4e488a2be7d5f3cff1695567e46247d4765af3ce129 |
| audit/camera-cases.md | 427026f5ee41a376b5a24f6090aab132dc117b035f3dce3a95694ff76634036e |
| audit/contracts/package.md | f3a3f76ffa610a4ca67c0adaa5d5046dd269500d4f1a4843765d925215a65757 |
| audit/contracts/report.md | 63b6e3b8d552957c171533e607e13b42fae1a9f0f00d85b757dcf7f45456f458 |
| audit/contracts/reader.md | a37dd8157e922c3e83aa1f404fc05ce076d609e5f1b3a2a3b4cd49b644dcfabc |
| audit/prompts/01-audit.md | d4811bb7edb922af64c934bb638a866d7dc6b31adb909d9caf18badb040dd0c3 |
| audit/prompts/02-correct.md | 949fa9f3c79fa3fc4eedc91f3550ae325f04404878f25db9704bb2c428ede429 |
| audit/prompts/03-export.md | 34f49753e1089f459deac1fb4f7f8d2ce7b3381a110b670a22b7d186a2841e5c |
| audit/template-audit.json | 350461aa848a6301d0a0f7e2104478c51efca800d084c65c37c12b8c9992807f |
| audit/template-audit-info.json | c41cd39166ec3172f3de82661be303239f22010c0868800cf34a6e46cddf6825 |
| audit/examples/normal/audit.json | f707a828b83d375c7fd071bd259c2c1b8d05effaf90c764ff80d78f78857dafa |
| audit/examples/multi/audit.json | b81129c8573adc180f5d1e513537d73eeaae871276239ed7326b6e8f70bb64fd |
| requirements.txt | 03edefdafb04435826494a85df70d8d442f7fb970e72d8e17bd56e0b94690c91 |
| requirements-audit-motion.txt | 3f8acbea4b15265731ade002c15440013043de43db747099a073ababc317a0eb |
