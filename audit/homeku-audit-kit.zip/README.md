# Kit audit HOMEKU 3.0

Siapkan satu MP4 sumber terpisah dan ZIP kit ini. Ekstrak empat file input ke workspace chat.

1. Jalankan `python homeku_runtime.py --output .` untuk memulihkan resource lokal berhash. Audit memakai Python 3.11+, Pillow, jsonschema, dan FFmpeg/ffprobe.
2. Baca `audit/visual-audit.md` dan `audit/authoring.md`. Pastikan cut dan periksa baseline 6 FPS dengan batas native. Sumber ≤6 FPS dan shot <1 detik memakai seluruh native.
3. Isi Profil Desain baku dan audit dari gambar yang diperiksa. Catat tipe rumah, atmosfer, dan palet HEX. Nilai besaran tiap komponen gerak dan cantumkan estimasi yang wajar dari frame. Gunakan `mark-viewed` sesudah pemeriksaan, lalu `complete`, `check-input` dan `draft`.
4. Ikuti checklist isi di `audit/authoring.md`. Setelah kandidat lulus validasi, jalankan `review` dan langsung `export --receipt`. Tampilkan laporan enam bagian, Overview, Storyboard, semua kolase, dan tautan unduhan ZIP tanpa MP4 dalam balasan yang sama.
5. Jika ada koreksi, ulangi draft, review, dan ekspor. Berikan tautan ZIP yang terbaru. Simpan MP4 untuk ingest lokal.

Gunakan `audit/prompts/01-audit.md` untuk memulai, `02-correct.md` untuk koreksi, dan `03-export.md` sebagai panduan ekspor. Contoh normal dan multi area adalah fixture sintetis.


## Inventaris resource lokal

| File | SHA-256 |
| --- | --- |
| tools/audit.py | 163bc2ad884ea51ea5a82b64e7160af156866ea2e16380ae47f7880fa346801c |
| tools/homeku/__init__.py | df43fdd84c5a9d4d314eb47c88a02ff81e4cf95808205152bb37e0aec3d6c17f |
| tools/homeku/audit_performance.py | 99be30b6c19b04f64f16e6cf6e5abc56aa289b518e35e375bc524799bd8369c8 |
| tools/homeku/audit_quality.py | 66504e6563c9b35f91381b003579c16c43519274ffd5a03e3f73e8884d85911b |
| tools/homeku/audit_session.py | 5f3d0144ad7736f73cc5fd1123eb9e1c87162a3698e79b14819a995bb70d53f6 |
| tools/homeku/authoring.py | 98e831e01a18fbe390828ba9a90eb122f7d4b4c600475f49548852390aa77e69 |
| tools/homeku/camera_notation.py | 2e3329def5b19e0d247029149683fbc81b01a891e6c1f173cadbaf8d509412d8 |
| tools/homeku/camera_pattern.py | c5708318a94415f68629d9703b7562f59e70b04d0f6ae28ede5ad627d52ea314 |
| tools/homeku/common.py | 84b7ef91c87be39753a8bca752557f8b9c16214bdfd6ac961326a924a47d8079 |
| tools/homeku/derivations.py | e717e8dfb20e244bfe26fd621b7b511c322e6cc9f3382cee5b803b58626b7b87 |
| tools/homeku/exporter.py | 386be33cd30e5ddd03afe3d2a8ea9c7c01a3246922273d5c48c28581d3367727 |
| tools/homeku/media.py | 0a685560e4091e0f2e412fccd42abbad63d06dea9d8054ba4e4dbe6f1c9252a9 |
| tools/homeku/media_incremental.py | fa0316c02f5b7fe3e4df1a1e12ba21a64d5abe122b7135d216c5792cc4b1b919 |
| tools/homeku/models.py | 65359610ada598ea4d9f7a7129d6a0ae9e570ac9da09b20bf22cda28920c047e |
| tools/homeku/motion_analysis.py | 6a485f1a0b5799a635887f8057c46aae8c1e7ae1c35c46555e284f6d9dd7c538 |
| tools/homeku/package_manifest.py | 0e7dc644ef9fbf1ad5111a6be6e562d8ec058fcb03d1788ca014d58d26651dad |
| tools/homeku/preflight.py | 52450cc9be70941f2145f0337d67023a42e66f16e3aea25174b595e8982268be |
| tools/homeku/render_assets.py | 97c7d508a258eb14a32d4fd788fc2081d64432c4c381e6c652439821b87b1105 |
| tools/homeku/report_validation.py | 063d3e2c8d4272e6b46e0b9e791a2f71510feaa23a8f6974c02e835c456a98a8 |
| tools/homeku/reporting.py | 2cd570918241c51c15fdfb064f3552707b9120706afe10f61e642d9464931927 |
| tools/homeku/storage.py | aa8310489011e0e5293a9766662a1040527f2085ce080fa40620c56c90ab1d5b |
| tools/homeku/validation.py | 189615642c835740ae401ea6112da139d481200b86aa9d52e2c5663638dbb0f6 |
| tools/homeku/video.py | 6258f3b76234885cdbc9cc96a2a398526ae7b433efd76d7308564ae455c37e88 |
| tools/homeku/video_cache.py | cb5a63ac34e16d291704bf29e6cfc8e44f104e2ebed48e33696e41e361fca8aa |
| schemas/audit.schema.json | 366312940e30e2c3f479da8806484785185494732303822b9429bfcc31f5e6a2 |
| schemas/audit-info.schema.json | ea05be764a74394b1a85056837385d8c7446f1f9bf310855beb13b3d58b68c78 |
| schemas/manifest.schema.json | bce67071a6a2a1360b2004ee2f54f7cb84aded417d74bb17b72df4c67f1c1a9d |
| schemas/reference-reader.schema.json | ad74575695e1dbc4432bd57ad1906d6f1d7c33c02e353180ab4cfe6d18cfefcb |
| schemas/search-index.schema.json | b89e1d407dfbddb782e2adae88e391d8dd88714616cfba3cf49ec4499be7fdf8 |
| tools/assets/fonts/DejaVuSans.ttf | ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280 |
| tools/assets/fonts/DejaVuSans-Bold.ttf | 5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895 |
| tools/assets/fonts/LICENSE.txt | e180b3d65bf650dffffd71dd21b6180767b469a18dd87e1d8552be69bb9ecdf0 |
| tools/assets/templates/analysis.md | 922902a9b3431f1316ec563de8963371574d6332e9aee7a60b14f9b8038e831c |
| tools/assets/templates/analysis-profile.md | d86f9bcc4f4fc8af70f58df7c7b7ae1ca11acab1aa2a626d05c8baffa89643ac |
| tools/assets/layouts/media.json | d68b9b5a84d6f1c336a5edf4cfa8a1848aa2c77840d503d488e2fcf3fc3ece37 |
| tools/assets/layouts/media-aligned.json | 4e9787151c825046ea2c3b6e231c4cda84c6e4cf06c5c1b95965fe529d72a825 |
| audit/README.md | 61578db27350a4df96458d843afb6012e7b3cdb059af4ba3d982f43091a73170 |
| audit/visual-audit.md | cfa7f134107aefd24573ce9b9a1946e1bf799d413ae5934e6ed52b08fff4ab66 |
| audit/authoring.md | 50ae67d8455fa1bd00e8e2c85376a9e76b3223e288e9c7be77f20295af3efd5e |
| audit/json-guide.md | 0ec6e78fba15fd097d6e213870b1eb64c624a06cf127ace56df87fecf336b5fc |
| audit/vocabulary.md | 906b93fa09c6a47eeaf9ae9fed8fbc2d4bd26d1c41f0753b635fcf6b69b0fca2 |
| audit/camera-cases.md | abc831fa2715e080139f3242b2a130cc66cff66f83e7cda09b581e801525acb0 |
| audit/contracts/package.md | 297844d1239f9f59a754e25269861de979945b7dcc3cf28ba1662d7112145f83 |
| audit/contracts/report.md | f92d3e6411e8551495b92d3a9bd4e0aa5d3ab98261fc3679eb17a9d4cd86a2db |
| audit/contracts/reader.md | bcb88a2cf4c3560c6893048becc18dde5cfd66bfdb9aae68d120ae56de41b130 |
| audit/prompts/01-audit.md | cef5d7245eb8c6e8671df22defbdab8e93fc236b08f6ae59f7f71ddf3c79bf9d |
| audit/prompts/02-correct.md | 191d0c8214e921c483b353141f0d4a67f9af5a3f76965033bd1df12aa3330015 |
| audit/prompts/03-export.md | 34f49753e1089f459deac1fb4f7f8d2ce7b3381a110b670a22b7d186a2841e5c |
| audit/template-audit.json | 350461aa848a6301d0a0f7e2104478c51efca800d084c65c37c12b8c9992807f |
| audit/template-audit-info.json | c41cd39166ec3172f3de82661be303239f22010c0868800cf34a6e46cddf6825 |
| audit/examples/normal/audit.json | bbf3ec7f6ab6954f8645f819b8462441f85032e767b79e929869afe217d9758c |
| audit/examples/multi/audit.json | 4f7027da7952ce3b839b12e7a02f7bcdb2e20fbddb393a4489f0cce83e92554f |
| requirements.txt | 03edefdafb04435826494a85df70d8d442f7fb970e72d8e17bd56e0b94690c91 |
| requirements-audit-motion.txt | 3f8acbea4b15265731ade002c15440013043de43db747099a073ababc317a0eb |
