# Kit audit HOMEKU 3.0

Siapkan satu MP4 sumber terpisah dan ZIP kit ini. Ekstrak empat file input ke workspace chat.

1. Jalankan `python homeku_runtime.py --output .` untuk memulihkan resource lokal berhash. Audit memakai Python 3.11+, Pillow, jsonschema, dan FFmpeg/ffprobe.
2. Baca `audit/visual-audit.md` dan `audit/authoring.md`. Pastikan cut dan periksa baseline 6 FPS dengan batas native. Sumber ≤6 FPS dan shot <1 detik memakai seluruh native.
3. Isi audit dari gambar yang diperiksa. Nilai besaran tiap komponen gerak dan cantumkan estimasi yang wajar dari frame. Gunakan `mark-viewed` sesudah pemeriksaan, lalu `complete`, `check-input` dan `draft`.
4. Ikuti checklist isi di `audit/authoring.md`. Setelah kandidat lulus validasi, jalankan `review` dan langsung `export --receipt`. Tampilkan laporan enam bagian, Overview, Storyboard, semua kolase, dan tautan unduhan ZIP tanpa MP4 dalam balasan yang sama.
5. Jika ada koreksi, ulangi draft, review, dan ekspor. Berikan tautan ZIP yang terbaru. Simpan MP4 untuk ingest lokal.

Gunakan `audit/prompts/01-audit.md` untuk memulai, `02-correct.md` untuk koreksi, dan `03-export.md` sebagai panduan ekspor. Contoh normal dan multi area adalah fixture sintetis.


## Inventaris resource lokal

| File | SHA-256 |
| --- | --- |
| tools/audit.py | c7077638096e705dfa7e0eda27c5764dfbe9db54b7b93ca22ad2056882c38a4b |
| tools/homeku/__init__.py | df43fdd84c5a9d4d314eb47c88a02ff81e4cf95808205152bb37e0aec3d6c17f |
| tools/homeku/audit_performance.py | 99be30b6c19b04f64f16e6cf6e5abc56aa289b518e35e375bc524799bd8369c8 |
| tools/homeku/audit_quality.py | 4130110495baad61c1343c557f4dfc112ffcc9214fe4e140d47dabf6df973ea5 |
| tools/homeku/audit_session.py | 5f3d0144ad7736f73cc5fd1123eb9e1c87162a3698e79b14819a995bb70d53f6 |
| tools/homeku/authoring.py | 98e831e01a18fbe390828ba9a90eb122f7d4b4c600475f49548852390aa77e69 |
| tools/homeku/camera_notation.py | 2e3329def5b19e0d247029149683fbc81b01a891e6c1f173cadbaf8d509412d8 |
| tools/homeku/camera_pattern.py | c5708318a94415f68629d9703b7562f59e70b04d0f6ae28ede5ad627d52ea314 |
| tools/homeku/common.py | 84b7ef91c87be39753a8bca752557f8b9c16214bdfd6ac961326a924a47d8079 |
| tools/homeku/derivations.py | 22bf6ffff5a16dd562139d9c2233afc9cabcd16d7565e437821e619df4a89291 |
| tools/homeku/exporter.py | b6787f824b9d6fe3857a2247cd50fc0f8944af4fed1f6df9d1dea3721ab3d558 |
| tools/homeku/media.py | 207c1245f77d66bf594f4f0db6d4437ad56296485c8d47844ae0948da2d95a95 |
| tools/homeku/media_incremental.py | fa0316c02f5b7fe3e4df1a1e12ba21a64d5abe122b7135d216c5792cc4b1b919 |
| tools/homeku/models.py | 1274c7cde1a93e3c08ca110d0252b5e56fb0cc8563d3e337d497cb7433d846fe |
| tools/homeku/motion_analysis.py | b7906be8b6b943446258d25941dc4d5cb905602cd67ae5e5e40ee56794c6fe69 |
| tools/homeku/package_manifest.py | 2d26f9c1f4dec8ee2c949ad83b7c78945b465b54a2216d20777ac6c096c07862 |
| tools/homeku/preflight.py | b2a7b2205b9fdd3fd80f4166c79d049d63c9fa72c501e83a89b0526106d65276 |
| tools/homeku/render_assets.py | ed8b3e0de75db30ece170d8c1356d3b802087b8566209e6f86141729494f9604 |
| tools/homeku/report_validation.py | 4b7473a875d89e434275531ab8fb22a9d39d7d5d759e212474110ea6d85bfa69 |
| tools/homeku/reporting.py | 5ea49a8161a86cd1520a27e7451759f9abf86047503610817feeba05cc058828 |
| tools/homeku/storage.py | aa8310489011e0e5293a9766662a1040527f2085ce080fa40620c56c90ab1d5b |
| tools/homeku/validation.py | 7fe8555c5d32cb2f2cba0333f6feace31546b3ac5f55853d5076a36b0a4d81f7 |
| tools/homeku/video.py | 6258f3b76234885cdbc9cc96a2a398526ae7b433efd76d7308564ae455c37e88 |
| tools/homeku/video_cache.py | cb5a63ac34e16d291704bf29e6cfc8e44f104e2ebed48e33696e41e361fca8aa |
| schemas/audit.schema.json | 374276e3d7f382865463570ce8334c482c4fdddb39fa62bf53f0636fd8b24830 |
| schemas/audit-info.schema.json | ea05be764a74394b1a85056837385d8c7446f1f9bf310855beb13b3d58b68c78 |
| schemas/manifest.schema.json | bce67071a6a2a1360b2004ee2f54f7cb84aded417d74bb17b72df4c67f1c1a9d |
| schemas/reference-reader.schema.json | 99513f26de4d7425e7a644bc68c0b002e8b7b10cbf2a64f2cc37fddd22f0aba9 |
| schemas/search-index.schema.json | b89e1d407dfbddb782e2adae88e391d8dd88714616cfba3cf49ec4499be7fdf8 |
| tools/assets/fonts/DejaVuSans.ttf | ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280 |
| tools/assets/fonts/DejaVuSans-Bold.ttf | 5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895 |
| tools/assets/fonts/LICENSE.txt | e180b3d65bf650dffffd71dd21b6180767b469a18dd87e1d8552be69bb9ecdf0 |
| tools/assets/templates/analysis.md | 922902a9b3431f1316ec563de8963371574d6332e9aee7a60b14f9b8038e831c |
| tools/assets/layouts/media.json | d68b9b5a84d6f1c336a5edf4cfa8a1848aa2c77840d503d488e2fcf3fc3ece37 |
| audit/README.md | 6baace503dcbd97bedd6346f986318ae0ebb078641fb460d66bfde6a1d8f68af |
| audit/visual-audit.md | bfaee7b1e4df0464ed0a98be94306d0bb2e4d4b79699ca6305523532460ea595 |
| audit/authoring.md | 48fe12e06011cabf927e6fefd55ee96e06d383d930dc485f9087617a295cf4db |
| audit/json-guide.md | 825adc4780dc13f89c950a1fd62c9c0ebb5fa8383c2e657a7480f6672647c0a6 |
| audit/vocabulary.md | 2b985ec5d65f32cb4f4d6288ac1ec3207ef084ccddedd8412def8014948f4e29 |
| audit/camera-cases.md | 427026f5ee41a376b5a24f6090aab132dc117b035f3dce3a95694ff76634036e |
| audit/contracts/package.md | b649beb48dec7975b119dc980a8db0e6257d460123f7c4599f643866d87875f3 |
| audit/contracts/report.md | 067aad01ffa4e9fc540da86a4e42df65a3dc14e58d70efe5ec6ff2cf4d374355 |
| audit/contracts/reader.md | 223155aee4cce3efd093a75428db05adf67c479c887fcf3af8de020124a91dfb |
| audit/prompts/01-audit.md | b23388da2b8e0483ff6fa75c28ce7d67ef0b819d032a9f50cd6cdc533b96671e |
| audit/prompts/02-correct.md | 365dff37bbe66392cedef373722fed933305457878cef065420600d18a499ffb |
| audit/prompts/03-export.md | 34f49753e1089f459deac1fb4f7f8d2ce7b3381a110b670a22b7d186a2841e5c |
| audit/template-audit.json | 2f0d633d40e1eace981f1c53aab5160dbb1a1186b52dbf1ec250cee82a45a313 |
| audit/template-audit-info.json | c41cd39166ec3172f3de82661be303239f22010c0868800cf34a6e46cddf6825 |
| audit/examples/normal/audit.json | 35db0d27db9838f0b27b8eecb8a5880c39ec535b5f11357fb9ed88c2f8628ea0 |
| audit/examples/multi/audit.json | 5673304a4ad34cf92f1ceeb4b860102fa4fb146732ea3efa8ab94c8957e7713d |
| requirements.txt | 03edefdafb04435826494a85df70d8d442f7fb970e72d8e17bd56e0b94690c91 |
| requirements-audit-motion.txt | 3f8acbea4b15265731ade002c15440013043de43db747099a073ababc317a0eb |
