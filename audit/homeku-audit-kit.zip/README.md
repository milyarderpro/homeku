# HOMEKU — kit audit chat

Kit input ini dipakai berulang bersama satu MP4 yang dilampirkan terpisah. Hasil setiap audit adalah satu ZIP referensi baru. Kit berisi sembilan file tanpa video/audio. Baca panduan berikut dan gunakan helper, bukan meminta pengguna mengedit file repo.

## Helper di workspace chat

Buka kit ke folder kerja. Dependensi Python: Pillow dan jsonschema; FFmpeg/ffprobe tersedia pada PATH. Gunakan alat yang benar-benar tersedia; error aktual dilaporkan spesifik. Perintah berikut dijalankan AI di workspace chat, bukan oleh pengguna di repo.

```sh
python tools/audit.py inspect /path/<id>.mp4
python tools/audit.py sample /path/<id>.mp4 --output work/shot-01 --start 0 --end <AKHIR_SHOT_01> --shot-id shot-01
python tools/audit.py sample /path/<id>.mp4 --output work/dense --native --start <AWAL_RENTANG> --end <AKHIR_RENTANG> --shot-id shot-01 --reason "Pan atau orbit belum jelas"
python tools/audit.py draft /path/<id>.mp4 work/analysis.md --audit-info work/audit-info.json --output work/candidate
python tools/audit.py review work/candidate/<id> --source /path/<id>.mp4 --output work/review.md
python tools/audit.py export /path/<id>.mp4 work/analysis.md --audit-info work/audit-info.json --output work/final --reviewed-sha256 <SHA256_MD_YANG_DITINJAU> --include-source
```

inspect mengembalikan metadata/hash dan seluruh timestamp PTS; itu bukan bukti semua frame sudah dilihat. sample menghasilkan frame native dan contact sheet sementara. Pilih overview_timestamp_s dari PTS aktual. draft/export tidak mengubah isi MD; jika waktu overview bukan PTS sumber, perbaiki draft sebelum ditinjau.

audit-info.json hanya instruksi kerja: objek reviewed_ranges (start_s/end_s/mode aktual), frame_reviews (record baseline/pendalaman), ai (provider/model/model_build), dan created_at opsional. method/limitations diambil dari MD. Mode hanya sampling, playback atau frame-by-frame yang benar-benar dilakukan; ekstraksi tidak sama dengan pemeriksaan. frame_reviews memakai review_record_template dari sampling.json: isi viewed_frame_indices hanya setelah benar-benar dilihat; baseline seluruh shot wajib selesai. Jumlah frame berasal dari daftar indeks. --native memakai semua frame asli tanpa interpolasi, termasuk sumber 60 FPS. Tidak ada status persetujuan pengguna yang diisi otomatis.

Jika perlu, --extras menunjuk daftar objek shot_id/path/timestamp_s/crop, untuk reveal-NN atau detail-NN. crop null untuk frame utuh, atau [x,y,width,height] untuk detail. --supersedes menunjuk revision/content_sha256 versi aktif hanya untuk revisi berikutnya. JSON kerja ini tidak masuk ZIP referensi.

Input MD dan video harus berada di luar folder kandidat. Setiap build membuat media/manifest baru. Hasil candidate/<id>/ dapat ditampilkan untuk review; ZIP ada di candidate/packages/. Digest --reviewed-sha256 hanya mengunci snapshot MD, bukan bukti otomatis persetujuan manusia. Gunakan export setelah pengguna menyatakan isi sesuai. Tidak diperlukan API AI atau akses repo dari chat.

--include-source digunakan jika sumber belum terbukti ada dengan hash sama di repo; jika sumber cocok sudah ada, opsi ini dapat dihilangkan. Batas kontrak sumber tetap berlaku.


---

<!-- Source: audit/protocol.md -->

# Protokol audit HOMEKU

Versi workflow: 1.1. Kontrak paket/MD tetap provisional sampai seluruh pilot nyata selesai. Protokol berlaku untuk video baru maupun audit ulang; jumlah referensi tidak dibatasi daftar pilot.

## Alur dalam satu chat

1. Pengguna melampirkan MP4 dan homeku-audit-kit.zip, lalu mengirim prompt audit. MP4 diunggah terpisah dari kit.
2. AI membaca README kit, template dan kontrak. Ambil ID dari stem file; hitung SHA-256 dan metadata aktual dengan helper. Periksa seluruh durasi dan susunan shot dari video, bukan anotasi arsip.
3. Audit desain, hubungan spasial, komposisi dan gerak dalam lintasan terpisah. Mulai 10 FPS sepanjang setiap shot serta frame asli pertama/terakhir. Perdalam seluruh frame asli pada rentang meragukan, lalu seluruh shot bila belum cukup. Lihat frame yang dipilih; frame sampling bukan klaim seluruh frame video sudah dilihat.
4. Tulis analysis.md 1.1 lengkap sesuai template, termasuk profil DNA, narasi palet dan ikhtisar shot. Data teknis dilipat, narasi/gambar tetap terlihat. Pilih frame gambaran area dan perannya. Buat kandidat melalui helper draft, baca kembali gambar/storyboard, lalu selesaikan kesalahan teknis di chat.
5. Jalankan helper review atas kandidat terbaru. Tampilkan storyboard dan kartu setiap shot: gambar area, ikhtisar/pembeda, posisi/arah, awal/akhir, notasi kamera lengkap, fase/ritme, dasar dan ketidakpastian. Sediakan MD lengkap yang nyaman dibaca; pengguna tidak diwajibkan membaca seluruh tabel teknis. Kartu memuat hash snapshot MD yang sama.
6. Terapkan koreksi pengguna pada laporan lengkap. Jika perubahan menyentuh shot, waktu, media atau kamera, bangun ulang kandidat dan tampilkan bagian yang berubah beserta konteksnya. Satu snapshot terkini menjadi sumber ekspor.
7. Setelah pengguna menyatakan isi sesuai, hitung SHA-256 analysis.md yang disepakati. Jalankan export dengan digest tersebut. Helper membangun ulang media, manifest dan ZIP dari snapshot yang sama serta memvalidasi ZIP setelah dibuka ulang.
8. Berikan satu ZIP final untuk diunduh. Pengguna menaruh ZIP di incoming/ repo; alur repo memperbarui seluruh keluaran tanpa pemeriksaan isi kedua.

Pengujian perangkat ini tidak menandakan semua pilot telah diaudit atau pengguna telah menyetujui isi. Audit di chat implementasi dan audit di lingkungan ChatGPT/Gemini sehari-hari dicatat sebagai lingkungan berbeda.

## Kedalaman pengamatan

Catat yang benar-benar terlihat: geometri ruang/massa, plafon, bukaan, tampilan finishing, furnitur/perangkat, penyimpanan, dekorasi, lapisan cahaya, lingkungan, konfigurasi dan hubungan antar elemen. Beri posisi relatif, orientasi dan pembeda. Contoh bathroom dapat dibedakan oleh konfigurasi shower, posisi toilet/vanity, laundry, bentuk bukaan, ceruk dan sirkulasi, bukan hanya warna ubin.

Jangan memaksakan daftar furnitur yang sama pada semua ruang. Tidak ada kuota benda. Objek yang hanya sebagian terlihat tetap dapat dicatat dengan batas identifikasinya. Objek yang tak terlihat tidak otomatis tidak ada. Material fisik, ukuran, lensa, lokasi dan adjacency tidak dipastikan dari penampilan saja.

Prosa membuat laporan nyaman dibaca; tabel mencatat seluruh fakta yang perlu dicari/dibandingkan. Tidak boleh menyembunyikan variasi penting hanya di prosa sehingga generator tidak menemukannya. Fakta memakai satu klaim per baris beserta state/confidence/bukti. Label baru boleh dipakai secara konsisten; parser tidak menyimpulkan istilah dari narasi.

## Kamera dan gambar awal

Pisahkan posisi kamera, arah pandang dan jenis gerak. Frontal/serong/samping harus mengikuti video. Jelaskan foreground, lapisan kedalaman, target gerak, oklusi dan area yang terungkap. Data ini menjadi acuan saat AI merancang gambar baru dengan sudut yang sesuai lintasan.

area-overview.jpg adalah satu frame asli dengan cakupan area terbaik, mempertahankan rasio dan dimensi sumber. Untuk IN biasanya awal; untuk OUT biasanya akhir. Untuk orbit/pan/gabungan, pilih cakupan nyata dan jelaskan alasannya. Peran frame di dalam shot dicatat; pandangan akhir Dolly-Out tidak disamakan dengan posisi awal sumber.

Ringkasan kamera Inggris memakai → untuk fase berurutan dan + untuk komponen simultan. Setiap fase mempunyai interval, jangkar, tempo, perubahan kecepatan, dasar visual, confidence dan uncertainty. Wajib menilai besaran dan mengusahakan estimasi ~sudut/~rasio dari jangkar visual; bila belum dapat diperkirakan, jelaskan batasnya. Jangan mengarang angka atau menyalin contoh masterprompt. Jangan membalik arah atau memaksakan durasi 4/6 detik dari alur produksi.

## Bukti tersimpan dan bukti sementara

Paket final berisi storyboard, satu area-overview dan start/middle/end per shot, serta reveal/detail yang dibutuhkan. Storyboard merupakan gabungan area-overview seluruh shot dengan nomor, area dan timestamp. Tidak ada motion/, klip shot atau seluruh frame video dalam paket.

Pemeriksaan selama audit boleh memakai lebih banyak frame, contact sheet dan playback dalam workspace sementara. Gunakan folder sampling kosong yang berbeda untuk tiap lintasan pemeriksaan agar bukti lama tidak tercampur. Daftar waktu dibuat dari PTS integer dan time_base asli, bukan string waktu yang dibulatkan. Catat metode/rentang yang benar-benar dilihat, bukan hanya yang diekstrak. Jangan mengaku mendengar audio jika audio tidak diperiksa. Durasi stream video dapat berbeda dari audio/container.

## Koreksi, revisi dan pemulihan

Sebelum sebuah paket masuk repo, koreksi di chat dapat tetap memakai revisi paket yang sama: paket lama diganti seluruhnya sebelum diunggah. Sesudah revisi itu aktif, gunakan revisi berikutnya dan supersedes dari registry/hasil validate; jangan mengarang hash versi sebelumnya.

Simpan sumber dan analysis.md utama di luar folder kandidat yang dihasilkan helper. Draft selalu dibuat ulang ke folder bersih. Extras dan audit-info hanya instruksi kerja di chat; keduanya tidak ikut ZIP referensi dan tidak menjadi analysis.json kedua.

Jika sumber atau workspace chat hilang, minta lampiran yang diperlukan kembali dan bangun ulang dari snapshot teks terakhir yang ditinjau. Jika suatu operasi alat gagal, sebut kegagalan spesifik dan jangan membuat file palsu, hash perkiraan atau klaim validasi yang belum dijalankan. Pengguna tidak diminta memperbaiki struktur file di repo setelah download.


## Pemeriksaan adaptif dan log aktual

Jalankan sample per shot dengan default 10 FPS dan batas shot yang tepat. Sumber di bawah 10 FPS diperiksa seluruh frame tersedia. Helper selalu menambahkan frame asli pertama/terakhir dalam interval, terpisah dari grid 10 FPS. Gunakan --native untuk pendalaman: semua frame asli 24/30/60 FPS atau sesuai sumber, tanpa interpolasi. Rentang 0,5–1 detik bisa menjadi awal pendalaman; perluas sesuai perubahan, bukan batas wajib.

Pendalaman diperlukan ketika pan/orbit/truck belum terpisah, fase/arah/laju belum jelas, blur/oklusi/gerak cepat mengaburkan perubahan, atau koreksi pengguna berbeda dari tafsir audit. Jika belum dilakukan, bagian tersebut belum selesai. Catat alasan dan batas yang masih ada.

sampling.json mencatat indeks/PTS yang dipilih dan template review_record dengan viewed_frame_indices kosong. Setelah benar-benar melihat gambar, isi indeks yang telah dilihat dalam audit-info.frame_reviews. Setiap shot wajib memiliki baseline seluruh durasi; boleh dibagi beberapa rentang tanpa gap agar setiap ekstraksi tidak melebihi 1000 frame. Pendalaman disimpan sebagai record tambahan. Ekstraksi bukan pemeriksaan dan helper tidak mengisi persetujuan. Jangan menyatakan frame-by-frame penuh kecuali seluruh frame asli dalam rentang tersebut dilihat.

## Aturan Penentuan Arah & Fase

Terapkan tiga tes dari bagian audit kamera masterprompt audit-video.md: oklusi foreground, selisih paralaks, serta perubahan perspektif/pembingkaian. Ketentuan produksi dan durasi masterprompt tidak dipakai di pustaka; omniflash-v2.md hanya acuan notasi.

| Aspek | Cara memutuskan |
| --- | --- |
| Pan murni | Pada adegan statis, gambar menyapu kiri mendukung Pan Right; gambar menyapu kanan mendukung Pan Left. Pastikan rotasi pandangan, bukan gerak objek |
| Arah lateral | Foreground bergerak lebih kanan relatif background mendukung kamera ke kiri; kebalikannya mendukung ke kanan. Periksa bersama oklusi, posisi jangkar dan perspektif |
| Orbit / truck | Perubahan sisi/sudut mengelilingi jangkar yang tetap terbingkai mendukung orbit. Nilai perpindahan lateral dan orientasi pandangan untuk truck; gabungan boleh dicatat |
| IN / OUT | Catat bila didukung perubahan skala/kedalaman/oklusi; pan/orbit/static tidak dipaksa memiliki komponen maju/mundur |
| Fase | + hanya pada interval simultan. Jika komponen mulai/berhenti berbeda waktu, pecah fase dengan →. Catat waktu sumber dan waktu relatif shot pada kartu |
| Tilt tipis | Drift/jitter/goyangan vertikal kecil dan koreksi framing sesaat tidak disebut subtle tilt-up/down atau komponen tilt utama |
| Tilt nyata | Tilt-Up/Down memerlukan rotasi pandangan vertikal yang jelas/berkelanjutan dan pengungkapan bagian atas/bawah. Bedakan dari perpindahan ketinggian kamera |

Delta fg_dx − bg_dx hanya petunjuk pendukung. Dolly, pan gabungan, jangkar, perspektif dan deformasi dapat mengubahnya; jangan menetapkan arah dari satu angka. Tidak ada kesimpulan ketiadaan gimbal hanya dari gambar. Pertahankan tilt yang jelas pada sumber.

## Profil DNA dan pemeriksaan silang

Lengkapi seluruh aspek profil dengan pengamatan atau interpretasi berbukti; unknown eksplisit jika belum diketahui. Periksa gaya/pengaruh, skala tampak, tingkat/massa/atap, entrance/porch/bukaan, hierarki material/palet/cahaya/lingkungan, konfigurasi/pembeda dan kontinuitas. Material tampak bukan material fisik; urutan edit bukan denah. Mood/gaya diberi dasar interpretasi.

Periksa kesesuaian narasi, profil, fakta, komposisi, ringkasan/fase kamera dan media sebelum menampilkan kartu. Generator tidak memeriksa makna prosa atau menyintesis fakta. Tidak ada uji membuat konsep/gambar atau benchmark manfaat pustaka dalam workflow audit.


---

<!-- Source: audit/rubric.md -->

# Rubrik audit dan kalibrasi HOMEKU

Gunakan penilaian berbukti, bukan skor total yang dapat menutupi salah arah kamera. Ketepatan satu angka tidak dapat menggantikan kelengkapan ruang atau salah identifikasi cut.

## Desain dan konfigurasi

| Aspek | Bukti yang dicatat | Kesalahan yang harus diperbaiki di chat |
| --- | --- | --- |
| Bentuk | Dinding/volume, bidang melengkung, proporsi tampak, level lantai/plafon | Hanya menyebut nama gaya dan warna |
| Isi | Elemen yang terlihat beserta bentuk, orientasi dan posisi relatif | Mengisi ruangan dari furnitur generik yang tidak terlihat |
| Hubungan | Susunan terhadap bukaan, sudut ruang, kabinet dan jalur yang tampak | Mengarang denah atau koneksi dari urutan edit |
| Pembeda | Kombinasi fungsi, solusi penyimpanan, bukaan, platform, ceruk | Menyamakan semua bathroom sebagai tub/vanity yang sama |
| Material/cahaya | Tampilan tekstur, warna, arah dan lapisan cahaya | Memastikan spesies kayu, batu asli, negara atau lux tanpa bukti |
| Ketidakpastian | Bagian tertutup/crop, fungsi parsial, tafsir alternatif | Mengubah not-visible menjadi not-present |

## Membedakan gerakan kamera

| Tafsir | Petunjuk pendukung | Batas tafsir |
| --- | --- | --- |
| Dolly-In/Out | Perubahan skala subjek beserta perubahan kedalaman/oklusi antar lapisan | Skala saja juga dapat berasal dari zoom/crop digital |
| Pan Left/Right | Reorientasi pandangan ke kiri/kanan dan pergeseran susunan elemen | Arah benda di layar berlawanan dengan rotasi kamera; bukan label gerak kamera otomatis |
| Truck/Tracking | Pergeseran lateral dengan parallax foreground/background | Translasi lateral tidak otomatis orbit |
| Orbit Left/Right | Perubahan sisi/sudut pandang mengelilingi jangkar dan hubungan perspektif | Jangan menyebut orbit hanya karena gambar bergeser mendatar |
| Tilt/Pedestal | Rotasi vertikal versus perpindahan ketinggian dengan parallax | Perubahan crop/kemiringan generatif dapat meniru keduanya |
| Zoom | Skala relatif cenderung berubah tanpa parallax yang mendukung translasi | Tidak cukup untuk mengklaim kamera fisik atau focal length |
| Uncertain/other | Bukti tidak membedakan beberapa tafsir atau label baru | Pertahankan teks/bukti dan alternatif; jangan paksa ke gerakan yang populer |

Perubahan perspektif pada video generatif juga dapat mengandung deformasi. Pisahkan petunjuk yang diamati dari interpretasi gerak. Estimasi derajat bukan hasil rekonstruksi pose 3D; ~2× harus menyebut jangkar dan dimensi/skalanya, bukan faktor percepatan.

## Tempo dan percepatan

Bandingkan perubahan pada interval waktu sama dalam shot yang sama: perpindahan jangkar relatif lebar gambar aktif, perubahan skala, perubahan sisi yang terlihat dan laju pengungkapan area. Jika ada black bar, bedakan bidang gambar aktif dari resolusi file. Tidak ada ambang fisik universal dari video monokuler.

| Label | Pedoman operasional |
| --- | --- |
| slow | Perubahan kecil per detik; reveal berlangsung bertahap dalam rentang yang diperiksa |
| moderate | Perubahan framing/kedalaman jelas dalam beberapa detik tanpa lompatan besar setiap interval |
| fast | Perubahan framing/skala/reveal besar dalam rentang pendek dibanding fase lain yang dikalibrasi |
| variable | Laju berubah bermakna; jelaskan urutan, misalnya awal slow lalu ekor moderate/fast |
| unknown | Bukti waktu/gerak tidak cukup; wajib jelaskan batasnya |

Kelancaran adalah karakter berbeda dari tempo. Gerakan smooth dapat fast; durasi shot pendek tidak otomatis gerak fast. Pisahkan ritme edit antarshot dari kecepatan kamera di dalam shot. Jangan memaksa distribusi label agar mengikuti dugaan bahwa sebagian besar koleksi sedang/cepat.

Accelerating memerlukan perubahan yang lebih besar pada interval akhir daripada awal, dengan jangkar/observasi yang dijelaskan. Pelebaran proyeksi saat mendekati objek tidak sendirian membuktikan percepatan fisik: gunakan istilah percepatan visual pada tafsir sumber dan beri batasnya. Jika kecepatan fisik tidak teridentifikasi, simpan batas tersebut dalam uncertainty.

## Konsistensi lintas model

1. Pakai MP4 dengan hash yang sama, template, kontrak dan pembagian fase yang eksplisit.
2. Periksa arah, IN/OUT, cut, fase, tempo dan posisi overview terlebih dahulu; label gaya diperiksa setelahnya.
3. Jika Gemini/GPT berbeda, bandingkan timestamp, jangkar dan bukti. Jangan memilih jawaban karena model lebih terkenal atau tulisan lebih panjang.
4. Koreksi di chat dan tampilkan kartu dari snapshot terbaru; MD lengkap tersedia. Tidak perlu mengaudit setiap pilot dua kali; kedua lingkungan diuji di antara enam pilot yang tersisa.
5. Catat lingkungan/model yang diketahui dan perbedaan yang diselesaikan. Kontrak tetap provisional sampai pengalaman nyata selesai.

## Siap ditinjau pengguna

- Seluruh durasi tercakup; cut dibedakan dari segmen fungsi.
- Seluruh area dan pembeda yang terlihat tercatat dalam MD/tabel, dengan bukti yang tepat.
- Kamera mempunyai arah, fase, estimasi besaran yang diusahakan, tempo, dasar dan batas; tidak ada default slow/frontal atau tilt tipis dari jitter.
- Gambaran area sesuai IN/OUT atau pengecualian dijelaskan; storyboard memakai gambaran area setiap shot.
- Gambar awal produksi dapat ditentukan dari posisi/peran frame dan target lintasan, tanpa mengubah kronologi sumber.
- Kandidat lolos validasi teknis di chat. Pengguna kemudian menilai isi; kelulusan kode tidak menjadi pengganti penilaian visual.


## Kriteria 1.1

- Seluruh aspek profil DNA dicatat beserta nilai/status/confidence/bukti, bukan hanya nama gaya. Unknown eksplisit untuk yang belum diketahui.
- Baseline 10 FPS mencakup setiap shot dan frame asli pertama/terakhir; pendalaman native dilaksanakan bila arah/fase/laju meragukan. Jumlah serta rentang dilaporkan dari indeks yang benar-benar dilihat.
- Gunakan aturan arah/fase pada protokol: pan murni menyapu berlawanan arah kamera; delta paralaks mendukung translasi tetapi perlu oklusi dan perspektif. Orbit mengubah sudut mengelilingi jangkar, truck menilai arah translasi dan orientasi pandangan.
- Drift/jitter kecil bukan tilt utama. Rotasi vertikal yang jelas dan berkelanjutan dibedakan dari perubahan tinggi. Penyebab goyangan atau penggunaan gimbal tidak dipastikan.
- Ringkasan literal, tabel fase dan kartu identik pada notasi. + untuk simultan, → untuk berurutan; kartu menampilkan waktu sumber dan relatif shot.
- Usahakan ~×/~° dengan jangkar/basis. Rasio skala bukan faktor percepatan; angka tidak diketahui dijelaskan tanpa rekaan.
- MD mudah dibaca dengan gambar/narasi dan tabel terlipat; JSON reader mempertahankan isi serta batasnya. Kartu dan ZIP mengacu hash MD yang sama.


---

<!-- Source: audit/vocabulary.md -->

# Kosakata pencatatan

Gunakan label domain/subject/attribute yang konsisten untuk konsep yang sama. Nilai penjelasan tetap bahasa Indonesia. Daftar berikut pedoman awal, bukan whitelist; label baru tetap boleh dicatat bila maknanya berbeda.

| Domain | Subject contoh | Attribute yang dianjurkan |
| --- | --- | --- |
| space | bathroom, kitchen, bedroom, living, exterior | layout, room-shape, combined-functions, circulation, floor-level |
| architecture | house, roof, canopy, window, doorway, ceiling | massing, shape, opening, position, structure-appearance |
| furnishing | shower, vanity, toilet, sofa, bed, coffee-table, refrigerator, range | type, shape, configuration, orientation |
| storage | cabinet, wardrobe, niche, shelf, laundry-tower | type, configuration, capacity-appearance |
| relation | subjek yang sama dengan benda terkait | position, alignment, adjacency-visible |
| material | wall, floor, countertop, facade, frame | appearance, physical-material |
| lighting | ceiling-light, task-light, niche-light, wall-light | type, placement, light-character |
| environment | site, landscape, exterior-view | visible-setting, vegetation, surface-condition |
| decoration | textile, artwork, plant, seasonal-decoration | type, pattern, placement |

Untuk hubungan, tulis jangkar dan perspektifnya, misalnya 'tower laundry di kanan shower menurut layar awal'. Jangan menulis 'di kanan' tanpa referensi yang jelas. Subject yang berulang tidak berarti objek identik lintas shot; ID fisik/adjacency hanya ditetapkan jika terlihat.

Pisahkan material appearance yang terlihat dari physical-material yang belum diketahui. Contoh 'tampak kayu cokelat' observed tidak membuktikan teak; physical-material dapat unknown. Jangan menerjemahkan state not-visible menjadi daftar barang yang tidak ada.

Label areas memakai fungsi eksplisit, misalnya bathroom; laundry bila keduanya tampak. Kabinet dalam bedroom bukan otomatis ruang walk-in closet. Jika variasi penting tidak cocok daftar ini, beri label baru yang spesifik dan pertahankan bukti/statusnya.


## DNA, alias dan notasi

Profil memakai aspek kontrak 1.1: gaya/pengaruh, skala tampak, tingkat, massa/atap/entrance/porch/bukaan, material/palet/cahaya/lingkungan, konfigurasi/pembeda/kontinuitas. Nilai diskret ditulis per klaim dengan state/confidence/bukti. Gaya adalah interpretasi beralasan; tidak memastikan asal budaya/lokasi.

Alias eksplisit Indonesia/Inggris berada di data/taxonomy.json: area, gaya, skala, sudut, massa dan gerak. Nilai asli tidak diganti. Contoh american cattage → american cottage hanya normalisasi ejaan label eksplisit, bukan deteksi gaya dari benda. Label baru dan klaim nonpositif tetap tersedia.

Notasi kamera: Dolly-In/Out, Orbit Left/Right, Pan Left/Right, Truck Left/Right, Tilt-Up/Down, Pedestal Up/Down, Zoom-In/Out, Static atau Uncertain. Parser mengenali Tilt-Up dan Tilt Up tanpa mengubah teks literal. Label lain disimpan sebagai other beserta literalnya. Gentle/strong menjelaskan komponen, bukan otomatis tempo. Jangan memakai subtle tilt untuk drift/jitter kecil.


---

<!-- Source: audit/providers.md -->

# Menggunakan ChatGPT dan Gemini

Gunakan chat baru per video agar sumber, revisi dan koreksi mudah diikuti. Lampirkan MP4 secara terpisah dan homeku-audit-kit.zip, lalu kirim prompt mulai audit. Kit tidak mengandung video atau audio dan dibatasi sembilan file agar tetap sederhana untuk input lintas chat.

Pilih lingkungan chat yang dapat memeriksa video/frame, menjalankan helper dan menghasilkan file unduhan. Jalankan operasi yang diperlukan langsung; jangan menyimpulkan kemampuan hanya dari nama model. Jika suatu operasi benar-benar gagal, catat operasi/error tersebut dan pulihkan di chat tanpa membuat metadata palsu.

Pada ChatGPT, tampilkan hasil dan minta koreksi terarah sebelum file final diunduh. Panduan resmi menjelaskan alur sumber/format/kriteria review dan revisi file: [Work with files](https://learn.chatgpt.com/docs/artifacts-viewer?surface=app).

Pada Gemini, video diunggah sendiri, di luar ZIP kit. Panduan resminya menyatakan ZIP input tidak memuat video/audio dan mempunyai batas jumlah file; ketersediaan akun dapat berbeda. [Attach and analyze files](https://support.google.com/gemini/answer/14903178?hl=en).

Dokumentasi tersebut mendukung cara memasukkan/meninjau file; bukan bukti bahwa pilot HOMEKU telah dijalankan pada akun/model tertentu. Model/build yang tidak diketahui tetap unknown/null. Tidak ada asumsi frame rate internal model atau jaminan bahwa Gemini dan ChatGPT memberi jawaban identik.

Sisa enam pilot dibagi di antara kedua lingkungan agar keduanya diuji. Tidak wajib mengaudit setiap video dua kali. Pengguna menilai isi di chat dan mengunduh ZIP final setelah koreksi; importer repo tidak menambahkan review isi kedua.


---

<!-- Source: audit/calibration.md -->

# Contoh notasi dan bahan kalibrasi

Contoh berikut menunjukkan sintaks, bukan label yang harus disalin ke setiap video:

```text
Orbit Right (~15°–20°) →
Accelerating Dolly-In (~2×) toward teak entrance door.
```

```text
Dolly-In (~1.3×) +
Orbit Left + strong Pan Right (~35°).
```

```text
Dolly-In (~2×) +
gentle Pan Right (~15°).
```

Pan/orbit tunggal, gerakan lain, fase Static dan Uncertain tetap sah. Angka/material pada contoh tidak menjadi default. Interpretasi hanya ditulis bila didukung sumber; batasnya dicatat terpisah agar ringkasan tetap ringkas.

## Kasus pembeda

| Kasus | Cara membaca |
| --- | --- |
| Dua shot dengan framing sama, satu menempuh perubahan dalam 2 s dan satu dalam 6 s | Perubahan per waktu berbeda; keduanya dapat smooth tetapi temponya berbeda |
| Ukuran objek membesar tanpa parallax yang jelas | Cukup untuk menyatakan perubahan skala; dolly fisik versus zoom belum tentu terpisah |
| Kamera mundur dan membuka seluruh area | Gambaran area biasanya di akhir; gambar awal sumber tetap lebih dekat |
| Objek bergeser ke kanan layar | Belum membuktikan Pan Right; periksa rotasi pandangan dan translasi/parallax |
| Satu lintasan melewati exterior, entry, living dan kitchen tanpa cut | Fungsi bertambah tetapi tidak otomatis menjadi empat shot |
| Enclosure shower, laundry tower dan dua bukaan berbeda | Catat hubungan serta konfigurasi ini; jangan mengganti dengan bathroom generik |

## Pilot edh001: audit diterima; kalibrasi lintas pilot masih terbuka

Laporan edh001 berasal dari video asli, bukan anotasi arsip. Durasi stream 18.4 s dengan cut pada 4.733333333, 8.3, 11.566666667 dan 15 s. Snapshot audit ulang memisahkan orbit kanan awal eksterior dari pendekatan yang meningkat, membedakan arc OUT pada living/bedroom, pan kiri kitchen dan pan kanan bathroom.

Laporan itu belum menjadi ground truth seluruh video. Pengguna telah menerima koreksi gerakan shot 02 berikut, setelah pemeriksaan ulang seluruh 107 frame asli pada indeks 142–248 (4.733333333–8.266666667 s; akhir interval shot 8.3 s):

```text
Dolly-Out (~2×) + Orbit Left + Pan Right.
```

Penerimaan awal ini khusus gerakan shot 02. Pada 22 November 2026, koreksi tersebut sudah diterapkan ke draf audit ulang format 1.1. Seluruh durasi diaudit ulang dengan 10 FPS dan pendalaman native; 461 frame unik diperiksa, termasuk seluruh shot 02/04. Setelah meninjau hasil audit ulang, pengguna menyetujui keseluruhan snapshot dan meminta ekspor final. Ekspor telah dilakukan dengan MD SHA-256 2d04d6bbd7fd35ee813ea7298322d593f195322f864dc2ca23142af57c4a260f; riwayat dan hash paket ada pada docs/edh001-re-audit.md. Persetujuan isi tidak menjadikan estimasi visual sebagai pengukuran pose fisik. Jangan menyalin gerak/angka ini ke sumber lain. Setelah koreksi pengguna dan enam pilot lintas chat selesai, bekukan contoh dengan versi/hash yang sesuai.


---

<!-- Source: audit/prompts/01-audit.md -->

# Prompt mulai audit

Audit MP4 terlampir untuk pustaka referensi HOMEKU. Buka homeku-audit-kit.zip dan baca README, template serta helper di dalamnya. Kerjakan pemeriksaan sumber dan pembuatan kandidat di workspace chat; jangan meminta saya menata file hasil di repo.

Tujuan laporan: AI kreatif dapat menemukan variasi desain yang nyata, memahami posisi/arah pandang kamera, lalu membangun konsep baru dengan DNA referensi dan gerakan yang sesuai. Catat bentuk, konfigurasi, fungsi, bukaan, furnitur, penyimpanan, dekorasi, cahaya dan lingkungan yang terlihat. Hindari isi furnitur generik atau hanya label gaya/warna. Ketidakpastian dan bagian yang tidak terlihat harus tetap jelas.

Gunakan ID dari stem nama sumber. Jalankan inspect untuk metadata/hash/PTS aktual, lalu periksa seluruh durasi. Tentukan shot/cut dari bukti, bukan jumlah ruangan. Periksa baseline 10 FPS sepanjang setiap shot dan frame asli pertama/terakhir. Perdalam dengan --native pada rentang arah/fase/laju yang meragukan, blur/oklusi, atau koreksi yang belum cocok; perluas ke seluruh shot bila perlu. Gunakan FPS asli, bukan dipaksa 30 FPS. Isi frame_reviews dari indeks yang benar-benar dilihat; jangan menandai selesai jika pendalaman yang diperlukan belum dilakukan. Lihat gambar yang diambil; jumlah ekstraksi bukan klaim jumlah frame yang sudah diperiksa.

Periksa kamera secara khusus: pisahkan dolly/pan/orbit/tracking/zoom; arah kamera dari arah benda di layar; smooth dari tempo; percepatan visual dari ukuran proyeksi. Gunakan notasi Inggris → berurutan dan + simultan. Semua fase harus mempunyai interval, jangkar, tempo, perubahan kecepatan, dasar dan uncertainty. Usahakan estimasi ~×/~° berdasarkan jangkar visual, dan jelaskan batasnya bila belum dapat diperkirakan. Terapkan aturan arah/fase pada protokol: gabungkan tes oklusi, paralaks dan perspektif; arah kamera berbeda dari arah benda di layar. Drift/jitter vertikal kecil bukan subtle tilt-up/down; tilt nyata harus jelas dan berkelanjutan, berbeda dari perubahan tinggi. Pertahankan kronologi sumber; jangan menerapkan reverse atau durasi produksi 4/6 detik.

Pilih satu frame asli area-overview.jpg per shot: biasanya awal untuk IN, akhir untuk OUT. Untuk gerakan gabungan, pilih cakupan area terbaik dengan alasan. Catat posisi, arah pandang, sudut serong/frontal/samping, foreground, kedalaman, komposisi awal/akhir dan peran overview sebagai acuan prompt gambar. Jangan memaksa semua pandangan frontal.

Tulis analysis.md 1.1 lengkap dengan narasi profil DNA/palet, ikhtisar dan uraian shot, serta tabel teknis terlipat mengikuti template, kemudian bangun kandidat dengan perintah draft. Simpan sumber, MD utama, audit-info dan extras di luar folder kandidat. Baca kembali storyboard dan frame kandidat. Perbaiki kesalahan struktur/waktu/hash dengan alat, tanpa mengarang fakta agar lolos validasi.

Jalankan helper review dan tampilkan storyboard serta kartu semua shot dari snapshot MD yang sama: gambar area, ikhtisar/pembeda, posisi/arah pandang, awal/akhir sumber, notasi kamera lengkap, fase/ritme, dasar dan ketidakpastian. Tampilkan sumber waktu dan waktu relatif shot. Sediakan analysis.md lengkap yang nyaman dibaca; saya tidak perlu membaca seluruh tabel teknis untuk mengoreksi. Periksa kesesuaian narasi/fakta/kartu sebelum ditampilkan. Jangan mengurangi isi MD demi kartu ringkas. Tunggu koreksi atau pernyataan saya bahwa isinya sesuai sebelum ekspor ZIP final.

Audit ini mengumpulkan pengetahuan dari sumber. Tidak ada tugas membuat konsep/gambar baru atau benchmark manfaat pustaka.


---

<!-- Source: audit/prompts/02-correct.md -->

# Prompt koreksi

Perbaiki audit terakhir berdasarkan catatan saya berikut:

[TULIS SHOT/TIMESTAMP DAN KOREKSI DI SINI]

Periksa kembali rentang sumber terkait; perdalam seluruh frame native bila koreksi menyentuh arah/fase/laju yang belum jelas. Perbarui log frame_reviews hanya untuk frame yang benar-benar dilihat. Terapkan tiga tes arah/fase dari protokol, usahakan estimasi berbukti dan saring drift/jitter vertikal kecil dari tilt utama. Terapkan perubahan pada analysis.md lengkap yang terbaru, termasuk fakta, arah/urutan fase, tempo, posisi/arah pandang, peran overview, bukti dan ketidakpastian yang terdampak. Bagian lain tetap dibawa ke snapshot baru agar tidak hilang.

Bangun ulang kandidat beserta seluruh media dan manifest dari snapshot baru. Jangan mencampur gambar atau metadata revisi lama. Periksa ulang konsistensi ringkasan kamera dengan tabel fase dan timestamp. Jalankan helper review, lalu tampilkan kartu shot yang berubah beserta konteksnya serta tautan/preview MD lengkap terbaru. Pastikan hash snapshot kartu sama dengan MD; persetujuan satu aspek tidak berarti seluruh audit disetujui. Jika ada interpretasi yang belum dapat dipastikan, jelaskan buktinya dan pertahankan uncertainty.

Jangan mengekspor ZIP final sebelum saya menyatakan isi terbaru sesuai. Revisi chat sebelum ingest tidak perlu menaikkan revisi paket. Jika revisi sebelumnya sudah aktif di repo, gunakan revisi berikutnya dan supersedes yang benar.


---

<!-- Source: audit/prompts/03-export.md -->

# Prompt ekspor final

Isi audit terbaru sudah sesuai. Buat satu ZIP final HOMEKU dari keseluruhan snapshot terbaru yang saya periksa.

Pastikan frame_reviews mencatat seluruh baseline serta pendalaman yang benar-benar dilihat dan kartu terakhir memakai snapshot MD yang sama. Hitung SHA-256 analysis.md tersebut dan gunakan perintah export dengan --reviewed-sha256. Bangun ulang seluruh frame pilihan, storyboard dan manifest; hash, waktu dan dimensi harus dihitung dari file nyata. Gunakan identitas AI yang diketahui; model_build yang tidak diketahui null. Jangan mengubah penjelasan atau membalik gerakan sumber saat ekspor.

Sertakan source.mp4 jika sumber belum terbukti tersedia dengan hash yang sama di video/<id>.mp4 repo. Jika ketersediaannya belum diketahui, sertakan sumber agar paket tidak kehilangan sumber. Untuk pilot yang sudah memiliki sumber cocok di repo, MP4 dapat tidak disertakan. Jangan menaruh script helper, audit-info, extras, motion/, klip shot atau seluruh frame dalam ZIP referensi.

Jalankan validasi atas folder kandidat dan atas ZIP yang dibuka ulang. Pastikan MD dalam ZIP mempunyai hash yang sama dengan snapshot yang saya setujui dan seluruh media berasal dari sumber yang sama. Jika tes gagal, perbaiki masalah teknis di chat; perubahan isi yang dibutuhkan harus ditampilkan kembali kepada saya.

Berikan satu tautan download <id>-r0001.zip atau nomor revisi yang benar, jumlah shot/gambar, identitas/hash sumber, dan ringkasan pemeriksaan teknis yang benar-benar dijalankan. Saya cukup mengunduh ZIP lalu mengunggahnya ke incoming/; jangan meminta saya memperbaiki file atau melakukan review isi lagi di repo.


---

<!-- Source: docs/contracts/package-v1.md -->

# Kontrak paket HOMEKU 1.1 — provisional

Paket baru memakai 1.1. Parser tetap menerima 1.0 sebagai format lama secara eksplisit; isi dan cakupannya tidak dianggap telah memenuhi audit 1.1.

Format 1.1 menyempurnakan kontrak teknis awal Phase 1. Pengalaman tujuh pilot pada Phase 2 dapat menghasilkan revisi berversi; parser tidak menebak atau menerima versi baru secara diam-diam.

## Identitas dan ZIP

Nama `<id>-r0001.zip`; satu folder teratas `<id>/`. ID mengikuti stem MP4, 1–80 karakter ASCII huruf/angka/underscore/hyphen, dimulai huruf atau angka. Kapitalisasi dipertahankan; tabrakan kapitalisasi ditolak. Revisi 1–9999, dimulai 1 dan bertambah satu.

```text
<id>/
  analysis.md
  manifest.json
  source.mp4                  # Hanya jika sumber belum tersedia
  media/
    storyboard.jpg
    shot-01/
      area-overview.jpg
      start.jpg
      middle.jpg
      end.jpg
      reveal-01.jpg           # Opsional
      detail-01.jpg           # Opsional
    shot-02/
      ...
```

Tidak ada motion/, klip per shot, seluruh frame video, executable atau file tambahan yang tidak tercantum. ZIP maksimal 256 MiB terkompresi maupun hasil ekstraksi, 2000 entri, 95 MiB per file; analysis.md dan manifest.json maksimal 2 MiB masing-masing. Direktori ZIP boleh ada; symlink, file spesial, path traversal, path absolut, enkripsi dan path bentrok ditolak. Gambar harus JPEG yang dapat didekode, maksimal 60 juta piksel.

## Manifest

Schema JSON adalah definisi field yang diperiksa. Seluruh field wajib, termasuk nilai null yang diizinkan.

| Field | Isi |
| --- | --- |
| contract_version | String `1.1` untuk audit baru; `1.0` masih dibaca sebagai legacy |
| purpose | `reference` untuk paket nyata; `fixture` hanya untuk tes terisolasi |
| id, revision | Identitas yang sama dengan ZIP, folder dan tabel identitas MD |
| supersedes | null pada revisi 1; berikutnya objek revision dan content_sha256 versi aktif yang diganti |
| source | path `video/<id>.mp4`, SHA-256 aktual, duration_s stream, width/height tampilan, fps numerator/denominator, video_stream_index |
| audit | method, reviewed_ranges, limitations, created_at berzona waktu dan identitas AI yang diketahui |
| media | Semua JPEG: path, SHA-256, kind, shot_id, timestamp_s, width, height, derived_from, crop |

`audit.reviewed_ranges` berisi start_s/end_s dan mode `sampling`, `playback`, atau `frame-by-frame`. Gabungan rentang mencakup durasi sumber; mode menjelaskan metode yang benar-benar digunakan. Nilai `model_build` boleh null; versi model yang tidak diketahui tidak dikarang.

Source harus tersedia dalam ZIP atau di video/ dengan hash cocok. Importer membaca metadata menggunakan ffprobe; durasi mengikuti stream video pertama non-cover-art, dengan fallback durasi container jika stream tidak mencatat durasi. Width/height mengikuti orientasi tampilan; fps adalah avg_frame_rate. Toleransi pembulatan durasi 0.001 detik. Hash di manifest adalah SHA-256 file, bukan Git blob SHA-1.

`content_sha256` dihitung importer dari daftar path dan SHA-256 isi folder yang diurutkan, tanpa source.mp4. Identitas ini mengikat laporan, manifest dan semua media; manifest sudah mengikat hash sumber. Nilainya tersedia dalam registry dan hasil validate, untuk supersedes revisi berikutnya.

## Media dan asal bukti

| kind / nama | Ketentuan |
| --- | --- |
| area-overview / shot-XX/area-overview.jpg | Satu frame utuh yang paling jelas dan luas memperlihatkan area; biasanya awal untuk IN dan akhir untuk OUT |
| start, middle, end | Frame awal, pertengahan dan akhir setiap shot, disimpan terpisah |
| reveal / reveal-NN.jpg | Opsional untuk bagian area yang belum terwakili |
| detail / detail-NN.jpg | Opsional; dapat berupa crop detail dari sumber |
| storyboard / storyboard.jpg | Gabungan seluruh area-overview dalam urutan shot, disusun ke bawah, dengan label shot, area dan timestamp |

Frame utuh mempertahankan dimensi dan rasio tampilan sumber. Frame tidak diperluas generatif atau dijadikan panorama. Timestamp sumber memakai detik desimal dan harus berada di dalam interval shot [start_s, end_s). Boundary frame berada dalam sekitar satu frame awal dan dua frame sebelum akhir; middle berada dalam satu frame dari midpoint. VFR atau batas shot yang ambigu perlu dikalibrasi pada pilot; jangan mengklaim ketepatan frame asli hanya dari fps rata-rata.

Semua media selain storyboard memiliki shot_id dan timestamp_s. `derived_from` berupa daftar kosong, `crop` null. Khusus detail crop, crop adalah [x, y, width, height] dalam koordinat frame tampilan sumber pada timestamp terkait; dimensi JPEG sama dengan ukuran crop.

Storyboard mempunyai shot_id/timestamp_s/crop null dan derived_from berisi semua path area-overview dalam urutan shot. Asal, urutan dan integritas file diperiksa secara teknis; kesesuaian piksel dengan sumber, label gambar, keterbacaan dan kebenaran interpretasi diperiksa saat audit/pilot.

MD mencatat overview_role start/middle/end berdasarkan sepertiga awal/tengah/akhir shot, timestamp dan alasan pemilihan. Untuk Dolly-In murni biasanya start; Dolly-Out murni biasanya end. Pengecualian dijelaskan dalam overview_exception. Pan/orbit/gabungan dipilih dari cakupan nyata. Simpan posisi serta arah pandang kamera dan peran frame agar penggunaan untuk prompt gambar sesuai lintasan, termasuk pandangan serong/samping.

## Penerimaan dan revisi

Audit/koreksi isi selesai di chat sebelum ZIP dibangun dari keseluruhan revisi final. Upload menjadi penyerahan versi tersebut. Repo memeriksa struktur, integritas dan konsistensi; tidak mengaudit ulang kebenaran visual atau meminta review isi baru.

Replay ZIP identik menghasilkan unchanged tanpa commit baru. ZIP yang dikompresi ulang dengan isi revisi aktif identik juga unchanged. Perubahan isi dengan ID/revisi aktif yang sama ditolak. Revisi baru menyebut supersedes yang benar. Sumber aktif identik pada ID lain ditolak berdasarkan hash; kesamaan rumah pada video berbeda tidak disimpulkan.

Paket fixture ditolak di repo produksi. Tes memerlukan root berbeda dari repo tooling dan marker .homeku-fixture-root.


## Log pemeriksaan frame pada 1.1

`audit.frame_reviews` wajib dan berisi satu atau beberapa lintasan per shot. Gabungan lintasan harus mencakup seluruh shot tanpa gap pada minimal 10 FPS, atau seluruh frame native. Shot panjang boleh diperiksa dalam rentang terbatas; setiap rentang menyertakan frame asli pertama/terakhirnya. Helper selalu menyertakan frame asli pertama/terakhir dalam interval. Rentang pendalaman boleh tumpang tindih baseline; semuanya harus benar-benar diperiksa.

| Field record | Makna |
| --- | --- |
| shot_id | Shot yang diperiksa |
| start_s / end_s | Interval waktu sumber [start, end), dalam batas shot |
| mode | sampling atau frame-by-frame |
| sampling_fps | FPS target sampling (minimal 10); null pada mode frame-by-frame |
| selected_frame_indices | Indeks asli berbasis 0, berurutan, yang dipilih dari PTS sumber |
| viewed_frame_indices | Indeks yang benar-benar dilihat; seluruh pilihan harus selesai diperiksa sebelum paket diekspor |
| reason | Tujuan baseline atau alasan pendalaman, misalnya orbit/pan belum terpisah |

Jumlah frame adalah panjang daftar indeks, bukan estimasi durasi × FPS. FPS sumber ada dalam source.fps; timestamp tepat diperoleh dari PTS sumber. Mode native tidak membatasi ke 30 FPS. Sampel di atas FPS sumber menggunakan semua frame tersedia, tanpa duplikasi/interpolasi. Reviewed_ranges tetap mencatat cakupan metode keseluruhan, selaras dengan frame_reviews dan method/limitations.

Validasi memeriksa indeks terhadap video dan kelengkapan deklarasi, bukan membuktikan AI sungguh melihat atau benar menafsirkan frame. Helper sample mengisi viewed_frame_indices kosong; AI mengisinya hanya setelah melihat. Frame/log kerja sementara tidak disertakan sebagai file tambahan ZIP. Log ringkas masuk manifest, tanpa seluruh JPEG pemeriksaan.


---

<!-- Source: docs/contracts/analysis-v1.md -->

# Kontrak laporan Markdown 1.1 — provisional

Format 1.1 dipakai untuk audit baru. Parser tetap membaca 1.0 secara eksplisit untuk draf/paket lama; dukungan ini tidak memperkaya atau menyetujui audit lama secara otomatis. Versi MD harus sama dengan manifest.

Laporan memakai bahasa Indonesia, dengan istilah gerak kamera dalam bahasa Inggris. Prosa menjelaskan desain secara lengkap; tabel menjadi sumber fakta untuk katalog. Jangan menambah fakta katalog melalui narasi yang tidak masuk tabel. Tidak ada analysis.json yang diedit terpisah.

Gunakan template awal. Heading dan nama kolom berikut stabil serta peka kapitalisasi. Setiap tabel memakai satu baris header/separator; sel wajib diisi. Gunakan unknown untuk nilai belum diketahui, '-' untuk field yang secara eksplisit tidak berlaku, dan `\|` untuk pipe dalam sel. Daftar dipisahkan titik koma hanya pada kolom yang disebutkan.

## Heading utama

| H2 | Isi |
| --- | --- |
| Identitas | Tabel field/value: format_version, id, revision, title |
| Ringkasan | Karakter referensi dan pembeda, dalam prosa |
| Profil DNA | Narasi manusia dan tabel klaim DNA; wajib pada 1.1 |
| Palet dan suasana | Uraian hierarki material/warna/cahaya/lingkungan; wajib pada 1.1 |
| Cakupan | Tabel field/value: method dan limitations; sama dengan manifest |
| Timeline | Tabel shot, start_s, end_s, areas, transition, continuity |
| Shot shot-XX | Enam H3 pada 1.1, sesuai daftar di bawah |
| Hubungan antarshot | Tabel from, to, relation, description, state, confidence, evidence; boleh tanpa baris data |
| Keterbatasan | Ketidakpastian keseluruhan, termasuk hal yang belum diamati |

Tabel teknis boleh dibungkus `<details>` dan `<summary>Judul</summary>` dengan baris kosong di sekitarnya. Heading tetap di luar pembungkus. Narasi dan gambar tidak disembunyikan. Tabel menjadi data eksplisit; generator tidak menebak klaim dari narasi. Komposisi dan Kamera menyediakan penjelasan natural di luar tabel; proyeksi mempertahankannya sebagai composition_notes/camera_notes. Timeline boleh memiliki uraian natural di luar tabel, disimpan sebagai timeline_notes.

### Profil DNA 1.1

Kolom `id | aspect | value | state | confidence | evidence`. ID dna-01 dst. unik; satu nilai/klaim per baris. State/confidence memakai aturan Fakta, termasuk interpretasi uncertain dan unknown. Klaim selain unknown harus menautkan frame asli terdaftar; storyboard bukan bukti detail DNA. Nama gaya adalah interpretasi yang dijelaskan dalam narasi, bukan kepastian sejarah arsitektur.

Aspek wajib: primary-style, style-influence, apparent-scale, levels-visible, massing, roof, entrance, porch, openings, material-hierarchy, palette, lighting, environment, spatial-configuration, distinctive-features, continuity. Gunakan unknown secara eksplisit bila tidak terlihat/belum diketahui. Aspek boleh berulang untuk beberapa nilai; aspek baru disimpan. Nilai pencarian bukan daftar prosa yang ditebak parser: tulis nilai diskret pada baris terpisah bila perlu ditemukan secara mandiri.

Narasi Profil DNA disimpan sebagai profile_notes, Palet dan suasana sebagai palette_notes. Tabel menjadi profile. Seluruh field sumber tetap tersedia dalam JSON pembaca; status negasi/ketidakpastian tidak diubah.

Shot bernomor shot-01, shot-02, dan seterusnya tanpa lompatan; tambahkan anchor eksplisit `<a id="shot-01"></a>` sebelum heading shot. Timeline mencakup durasi sumber tanpa gap/overlap. `areas` memuat satu atau beberapa fungsi eksplisit dipisahkan ';'. Cut dibedakan dari segmen fungsi dalam shot kontinu; anotasi tidak membuat cut yang tidak terlihat.

MD menampilkan/menautkan media/storyboard.jpg dan gambaran area setiap shot dengan tautan relatif. Bukti hanya menautkan media yang terdaftar, anchor shot, atau sumber ../../video/<id>.mp4.

## Bagian per shot (enam pada 1.1; lima pada 1.0)

### Ikhtisar — wajib pada 1.1

Paragraf ringkas tentang area, konfigurasi dan pembeda untuk kartu tinjauan. Desain lengkap tetap pada bagian berikutnya. Satu gambar area ditampilkan sebelum Ikhtisar.


### Desain dan konfigurasi

Prosa lengkap: bentuk, proporsi visual, plafon, bukaan, tampilan material, furnitur, penyimpanan, dekorasi, cahaya, lingkungan dan hubungan spasial yang terlihat. Susunan, bentuk dan fungsi lebih penting daripada sekadar nama gaya/warna. Tidak ada kuota objek wajib.

### Fakta

Kolom: `id | domain | subject | attribute | value | state | confidence | evidence`.

ID fakta f-01 dst., unik dalam shot. Domain/subject/attribute berupa label eksplisit; label baru tetap dipertahankan. Misalnya domain space, architecture, furnishing, material, lighting, environment, relation. Setiap baris menyatakan satu klaim dengan statusnya:

- observed: terlihat dan mendukung nilai yang dicatat.
- uncertain: interpretasi masih meragukan.
- not-visible: tidak terlihat pada bukti; tidak menyatakan objek tidak ada.
- not-present: audit secara eksplisit menyatakan tidak ada pada cakupan yang diperiksa.
- unknown: informasi belum diketahui.

Confidence: high, medium, low, unknown. Evidence memakai tautan Markdown lokal, misalnya `awal; detail`. Klaim membutuhkan bukti dalam shot yang sama; unknown dapat memakai '-'. Katalog tidak mengubah status nonpositif menjadi observed.

### Komposisi

Tabel field/value wajib berisi:

```text
overview_timestamp_s
overview_role
overview_reason
overview_exception
camera_position
camera_direction
view_angle
camera_height
camera_tilt
foreground
depth
reveal
start_composition
end_composition
motion_compatibility
```

overview_role: start/middle/end, mengikuti sepertiga durasi sumber. overview_exception '-' bila tidak diperlukan. camera_position/direction relatif terhadap area/subjek, bukan hanya lokasi objek di layar. view_angle dapat frontal, oblique, side atau deskripsi eksplisit lain; label baru disimpan. Besaran fisik yang tidak diketahui memakai unknown, bukan angka rekaan.

motion_compatibility menjelaskan hubungan posisi, orientasi, framing, foreground dan kedalaman dengan lintasan sumber. Catat peran gambaran area: gambar luas pada akhir Dolly-Out bukan posisi awal sumber. Data ini membantu AI membuat gambar dengan sudut yang cocok dengan gerak yang dituju, tanpa selalu memakai frontal.

### Kamera

Satu ringkasan dalam fenced block text, mempertahankan simbol →, +, ~, ° dan ×. → menyatakan fase berurutan; + menyatakan komponen simultan pada interval yang sama. Ikuti notasi plan; angka mengikuti bukti, bukan contoh wajib.

Tabel: `phase | start_s | end_s | components | anchor | tempo | speed_change | basis | evidence | confidence | uncertainty`.

Satu baris per fase berurutan, phase-01 dst. components memuat semua komponen simultan dengan '+'. Setelah whitespace dan titik penutup dinormalisasi, urutan components harus sama dengan ringkasan. Fase mencakup seluruh shot tanpa gap/overlap; jika komponen simultan mulai/berhenti di waktu berbeda, pecah fase pada batas tersebut.

Tempo: slow, moderate, fast, variable, unknown. Speed_change: accelerating, decelerating, constant, variable, unknown. Kelancaran gerak tidak menentukan tempo. Basis menjelaskan perubahan visual, dasar perkiraan dan jangkar. Uncertainty menjelaskan batas tafsir; wajib bila tempo unknown. Evidence menautkan frame terkait; bukti temporal lengkap tetap bersumber pada video.

~1.3×/~2× adalah estimasi pendekatan/perubahan skala terhadap jangkar, bukan faktor percepatan atau jarak fisik. Sudut adalah estimasi visual dengan batas yang dijelaskan. Accelerating harus konsisten dengan speed_change; strong/gentle berlaku pada komponen terkait. Label gerak baru disimpan sebagai other beserta teks literal, bukan diubah menjadi gerakan yang dikenal.

### Ketidakpastian

Jelaskan hal yang belum terlihat, klaim yang belum pasti dan batas bukti. Pemeriksaan sampling/playback/frame-by-frame dilaporkan sesuai yang benar-benar dijalankan. Media tersimpan bukan bukti bahwa seluruh frame telah diperiksa.

## Hubungan antarshot dan turunan

Hubungan memakai status/confidence yang sama dengan fakta. from/to harus ID shot yang ada; bukti dari media terdaftar. Adjacency, material pasti, dimensi, lokasi dan rumah independen tidak disimpulkan tanpa dukungan.

Generator menyalin nilai, status, confidence, notasi kamera dan pointer sumber. Knowledge mengelompokkan variasi atribut; hitungan adalah pasangan referensi/shot unik yang mencatat atribut tersebut, dengan denominator eksplisit. Tidak ada sintesis AI bebas pada ingest.


## Cakupan audit 1.1 dan kartu tinjauan

Awali setiap shot dengan 10 FPS sepanjang durasi, termasuk frame asli pertama/terakhir. Perdalam rentang meragukan pada seluruh frame asli; perluas ke seluruh shot bila belum cukup. FPS asli dapat 24/30/60 atau lainnya, tanpa interpolasi. Sumber kurang dari 10 FPS memakai seluruh frame yang ada. Log frame_reviews pada manifest mencatat pilihan dan pernyataan pemeriksaan aktual; lihat kontrak paket. Tidak ada seluruh rangkaian frame di paket final.

Arah kamera ditentukan memakai oklusi, paralaks, perspektif dan pembingkaian bersama. Pan murni menyapu gambar berlawanan arah kamera; arah lateral tidak ditetapkan dari satu objek atau satu angka delta. Orbit mengubah sudut mengelilingi jangkar; truck menilai translasi lateral dan orientasi kamera. Jangan menyebut drift/jitter vertikal kecil sebagai subtle tilt. Tilt-Up/Down memerlukan rotasi pandangan vertikal yang jelas dan berkelanjutan, berbeda dari perubahan tinggi.

Estimasi ~×/~° wajib diusahakan berdasarkan jangkar dan dijelaskan dalam basis; bila tidak cukup, catat batasnya tanpa mengarang angka. ~× adalah rasio perubahan skala, bukan tempo/percepatan. Fase menyimpan waktu sumber; kartu juga menampilkan waktu relatif shot.

Perintah review menghasilkan kartu dari model MD yang sama serta hash snapshot. Kartu berisi gambar, ikhtisar, posisi/arah, awal/akhir, notasi lengkap, ritme, dasar dan ketidakpastian. Pengguna tidak diwajibkan membaca semua tabel teknis; MD lengkap tersedia. Pemeriksaan kesesuaian narasi dengan fakta tetap dilakukan AI saat audit/koreksi; parser hanya memeriksa konsistensi teknis eksplisit.


---

<!-- Source: docs/contracts/ai-reader-v1.md -->

# Kontrak pembaca AI 1.0 — provisional

Mulai dari `data/search-index.json`, cocokkan label/alias melalui `data/taxonomy.json`, lalu muat hanya `data/projections/<id>.json` yang relevan, shot/media terkait dan `knowledge/principles.json` bila dibutuhkan. Koleksi aktif hanya registry. JSON adalah keluaran otomatis; tidak diedit terpisah.

## Referensi lengkap

Schema referensi memakai schema_version 1.0 dan kind homeku.reference. `reference` mempertahankan isi model MD: identitas, summary, profile beserta status/bukti, profile_notes, palette_notes, timeline_notes, coverage, shots, relations, limitations dan links; dilengkapi source, media, audit dan content_sha256 dari manifest/sumber validasi.

Setiap shot memuat design, review_summary, composition_notes, camera_notes, composition, facts, camera_summary, phases, uncertainty dan timeline. Komponen kamera menyimpan literal, jenis yang dikenali atau other, arah, qualifiers, estimates dan target. Unknown, label baru, negasi serta alternatif dalam narasi tidak dihapus. Bukti dalam reference tetap memakai path relatif MD.

`paths` memberi jalur dari root repo ke MD, manifest dan sumber. `provenance` memetakan JSON Pointer ke bagian MD dan bukti lengkap dengan jalur root, timestamp, hash, kind serta crop. Pointer fakta/phase/DNA mengidentifikasi klaim. Seluruh media tetap tercantum dalam reference.media, termasuk storyboard dan frame awal/akhir. Membaca JSON tidak mewajibkan membuka MD.

Tidak ada fingerprint/cache dalam kontrak pembaca. Metadata cache berada dalam data/build.json dengan fingerprint sumber/tooling dan hash proyeksi. Cache boleh dibuang, dan rebuild penuh harus setara. Format sumber legacy 1.0 tetap dipertahankan sebagai format_version 1.0: profile kosong dan profile_available false, tanpa menebak data yang tidak diaudit.

## Indeks ringan

Schema indeks memuat schema_version, kind, taxonomy, principles, knowledge dan references. Record referensi memuat id/title/revision/json, profile_available, profile_facets dan shots. Facet mempertahankan nilai asli, canonical alias bila tersedia, state/confidence dan pointer.

Facet DNA mencakup gaya/pengaruh, skala, tingkat, massa/atap, entrance/porch/bukaan, material/palet/cahaya/lingkungan, konfigurasi/pembeda/kontinuitas. Shot memuat fungsi asli/canonical, sudut, gerakan literal/ringkasan, jenis gerak, tempo dan pointer JSON/MD/media. Design_facets hanya atribut konfigurasi/bentuk/bukaan/sirkulasi utama; fakta lengkap dan narasi tetap dalam proyeksi terpilih, tidak diduplikasi seluruhnya dalam indeks.

Facet nonpositif bukan kecocokan positif. Not-visible berarti tidak terlihat, not-present berarti ketidakhadiran yang dinyatakan pada cakupan audit, uncertain adalah tafsir, unknown belum diketahui. Pencarian tidak menyimpulkan ketidakhadiran dari field yang tidak ada. Alias menyamakan istilah eksplisit, bukan menyimpulkan gaya dari paragraf. Label baru tetap tersedia.

## Knowledge

Knowledge perbandingan menyalin variasi fakta dengan status dan pointer sumber. Jalur knowledge pada indeks menuju knowledge/topics/index.json; setiap topik menunjuk index.json dan halaman JSON maksimal 40 klaim, dengan denominator serta sumber eksplisit. Prinsip umum berasal dari sources/design-principles.json, diterbitkan verbatim ke knowledge/principles.md dan JSON. Claim_type design-principle membedakannya dari observasi video dan keputusan konsep baru. Generator tidak menjalankan AI, membuat konsep, atau menggabungkan fakta arsip saat ingest.

Schema masih provisional sampai tujuh pilot selesai. Perubahan breaking memerlukan versi kontrak baru. Versi schema pembaca terpisah dari versi format MD dan versi generator.


## Inventaris runtime

| File | SHA-256 |
| --- | --- |
| tools/audit.py | acf6dcd59e8b55226f52449d802d243b97b6c43326e832a5a4d259aca81b6f94 |
| tools/homeku/__init__.py | fb6bf4e9cd2570906205e81a55dddd41c65a0e5d3a2e7ff49c88c11e059916ef |
| tools/homeku/common.py | f55e0eb824c1c991c85030fec6180a383d0e664f57c3ac40f48e7191f2739abf |
| tools/homeku/markdown.py | 98c8fce8d82e826c7bb1e674bdfe2c7f235c3cdf0a7ecdd2fae75d0763e2baeb |
| tools/homeku/validation.py | f012517fe84f68fb8b6d1b8ce11d17f49c9a838c55e2a559b71c8e3e8e461408 |
| tools/homeku/exporter.py | 368b871087903cc858f5a66b72d17d7789e9db821aa41d4074d456dac5c3454a |
| docs/contracts/manifest-v1.schema.json | 2646fc5eabc6c99044ee9ee27b2fc6af2a5cfc63279769908b04a46903be8852 |
| audit/template-analysis.md | aa5aa2dd50acdb034d63b2f93e9c1664ffaea554907f3dd2b6d5d57338aa7ded |
