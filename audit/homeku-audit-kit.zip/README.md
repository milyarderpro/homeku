# Kit audit HOMEKU 3.1

Siapkan satu MP4 sumber terpisah dan ekstrak keempat file kit ke workspace chat. Jalankan `python homeku_runtime.py --output .` untuk memulihkan resource lokal. Audit memakai Python 3.11+, Pillow, jsonschema, dan FFmpeg/ffprobe.

Baca `audit/authoring.md` dan jalankan empat fase dalam satu chat memakai `audit/prompts/01-audit.md`.

1. Petakan cut dan siapkan frame baseline dengan `prepare`.
2. Audit kamera dengan `audit/visual-audit.md` dan `audit/camera-cases.md`, lalu jalankan `check-camera`.
3. Lengkapi desain, framing, panel dan Overview dengan `audit/design-audit.md`.
4. Jalankan `complete → check-input → draft → review → export`. Setelah lulus, berikan laporan, media dan ZIP final tanpa MP4.

Gunakan `audit/prompts/02-correct.md` atau `03-export.md` untuk melanjutkan sesi yang sama. Contoh JSON berisi data sintetis.


## Inventaris resource lokal

| File | SHA-256 |
| --- | --- |
| tools/audit.py | 703bb4da1e51dc2e321a687f99e7fb54b2b279efa08e9b6af13ba3432f5440a8 |
| tools/homeku/__init__.py | 229779955f355dd66c0719feb9aa98ecd0217239d2a989b61c737856495d5803 |
| tools/homeku/audit_performance.py | 99be30b6c19b04f64f16e6cf6e5abc56aa289b518e35e375bc524799bd8369c8 |
| tools/homeku/audit_quality.py | a933f4b7616f364f27767484b8af5f08bfb11ce6b5d1e5ede5c0beb557d3ef92 |
| tools/homeku/audit_session.py | 169c95594c451f5bfee4007bbcb8327b21575dbd8a27ae8fc658d508c65977aa |
| tools/homeku/authoring.py | 35efb406d5cf7bb7d5916997fb61f2f3b330be7254aecf23dbe78329825869d3 |
| tools/homeku/camera_notation.py | 2e3329def5b19e0d247029149683fbc81b01a891e6c1f173cadbaf8d509412d8 |
| tools/homeku/camera_pattern.py | c5708318a94415f68629d9703b7562f59e70b04d0f6ae28ede5ad627d52ea314 |
| tools/homeku/common.py | 84b7ef91c87be39753a8bca752557f8b9c16214bdfd6ac961326a924a47d8079 |
| tools/homeku/derivations.py | 726dfdb7986696293a437a5506a3bdcbf8ca500a2413efe326e7827da089c29f |
| tools/homeku/exporter.py | f94dd1dc1f0edd92c846fd0d7bd5736603870c57d65bcf47d624b867c76c1f96 |
| tools/homeku/media.py | 5e0c80a374cfd2190b8c98a34b0c34e82846cb6584a375a9299364009c6ca81a |
| tools/homeku/media_incremental.py | fa0316c02f5b7fe3e4df1a1e12ba21a64d5abe122b7135d216c5792cc4b1b919 |
| tools/homeku/models.py | 2d048e8cd96d2919c375f3943ea826e845d184b51f926d6a180e49ce435fd516 |
| tools/homeku/motion_analysis.py | 6a485f1a0b5799a635887f8057c46aae8c1e7ae1c35c46555e284f6d9dd7c538 |
| tools/homeku/package_manifest.py | fd6ac353a0c42439b7f1d82ac6816df1e69cb1c06fdd5e05b9a01d33e7da4cda |
| tools/homeku/preflight.py | ce6752074736d321b498ce3f758dc3d94d9fbfa1ab8bc9e8e5ae8f36c3ed4bbc |
| tools/homeku/render_assets.py | c49719ad4f7e5dfba89dac89d876f1072c20518a36b0dd96a1f30774a81aa0dc |
| tools/homeku/report_validation.py | 6b152b9af0e07b32e1811453bc52ea83118491a569409fc05f754376c23ee228 |
| tools/homeku/reporting.py | 8547fcc78e7cb7008731271083522390eab16ce61a144543e870243dec27b002 |
| tools/homeku/storage.py | bbe7daf97d12e29adcc606bb136c37f134effde42a77d1d3fffb1fcdecad29c9 |
| tools/homeku/validation.py | ad40f2cb8283b7e617bb0ff38ea64bc3c77c5d6d9348e833fe05a1f6077dcf0b |
| tools/homeku/video.py | 6258f3b76234885cdbc9cc96a2a398526ae7b433efd76d7308564ae455c37e88 |
| tools/homeku/video_cache.py | cb5a63ac34e16d291704bf29e6cfc8e44f104e2ebed48e33696e41e361fca8aa |
| schemas/audit.schema.json | 855206a3e5e7c4bcca7361249a9550ab544cd895bb6fabb3e0548d930494ff76 |
| schemas/audit-info.schema.json | ea05be764a74394b1a85056837385d8c7446f1f9bf310855beb13b3d58b68c78 |
| schemas/manifest.schema.json | 09704e75d4ae0f4c4bc5aec932f0f47328c5ad2e165bba9b18a8b04f52d1b705 |
| schemas/reference-reader.schema.json | 9794da0f3293deadbd35616e9b9840b6de4c1e2605e3f5a8d14be811c282ead4 |
| schemas/search-index.schema.json | f65f47ce3fdbac9e128417793ad2e958a30a1011045142c1db272188a03dbd21 |
| tools/assets/fonts/DejaVuSans.ttf | ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280 |
| tools/assets/fonts/DejaVuSans-Bold.ttf | 5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895 |
| tools/assets/fonts/LICENSE.txt | e180b3d65bf650dffffd71dd21b6180767b469a18dd87e1d8552be69bb9ecdf0 |
| tools/assets/templates/analysis.md | 66a15912eb9782b1823ba9aa4dc00e190c2a67787c716979bc1614503266e1b5 |
| tools/assets/layouts/media.json | 8d7f59138e617569a2986a8f2bf35ef3609344efa088366ec77b171e25b10a3f |
| audit/README.md | 013b1e3d8fb32e765533b6852cc5a330bc2b98abec32a41ac02a92dedeb56beb |
| audit/visual-audit.md | af8e9918c263553cbf30507522c0bac695654cf9a49e7ab40603bf75d8fd37ba |
| audit/design-audit.md | 9f0ef143ae537adb63ec317425c203b02402bbf2f73f81e3802a0dd91ad2da96 |
| audit/authoring.md | 7bc83d278aa8dfa93c9a161a60b0820f871561875d537a5d2470ee76dd2d7e92 |
| audit/json-guide.md | 188edd2293e8dc3c6041799060254a7735c84ef5f6176598ff4d44139b67a330 |
| audit/vocabulary.md | 4583f04cf171aaeb72f3332486e7b28cd17289e3a3685f64e8ae4d649e9629cb |
| audit/camera-cases.md | 36e4b7b56009775aeb7a1e3312e9628e8351089f85fb57a016b729d9b7036265 |
| audit/contracts/package.md | 19cb989c6c9e8349871d06763cf7721ac8b324d0c245d54ce5a4773d5f3adf60 |
| audit/contracts/report.md | 98957c6a60fd713c9bf590ac6a7db132a31f1f4908156bdd493d254d4818752a |
| audit/contracts/reader.md | 1c2b718b176958e224943c2ca450803959d256c56bf89dcf50864a1e45dc413a |
| audit/prompts/01-audit.md | b112f74a05c0cfefbd24f6e4bc86f61268b5ba526fe2b04af7589605e4acf687 |
| audit/prompts/02-correct.md | 6753cc4fb372743b963cd75ab745630afb2cfa414fb11e64fde21ea5386d2273 |
| audit/prompts/03-export.md | 8eba17baf052ad3e70cc75d4248815069653ecd56478c431b64002f0dbd1d82b |
| audit/template-audit.json | 2f4896281ac3b7efd284de57e473dd7de5816f976d1981c9afc126ee8647f7da |
| audit/template-audit-info.json | c41cd39166ec3172f3de82661be303239f22010c0868800cf34a6e46cddf6825 |
| audit/examples/normal/audit.json | 138f98aa0227fc9ff69001b3ed9ed61cca3ed25612b1ab4d43ee31e52b77ff82 |
| audit/examples/multi/audit.json | a2e854e548c9ed1e807cd14ae13ff85985ee2d350930eebfb1de4cfa3a81f4cb |
| requirements.txt | 03edefdafb04435826494a85df70d8d442f7fb970e72d8e17bd56e0b94690c91 |
| requirements-audit-motion.txt | 3f8acbea4b15265731ade002c15440013043de43db747099a073ababc317a0eb |
