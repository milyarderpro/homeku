# HOMEKU — kit audit2.5

Input: MP4 asli terpisah + ZIP ini. Hasil akhir satu ZIP tanpa video.

1. Ekstrak4file dan jalankan python homeku_runtime.py --output . untuk memulihkan seluruh resource lokal berhash. Python3.11+, Pillow, jsonschema dan FFmpeg/ffprobe diperlukan; tanpa unduhan kode.
2. Baca audit/visual-audit.md dan audit/authoring.md. Inspect dan periksa cut nyata; prepare menghitung PTS/panel serta baseline6FPS. Amati kamera/desain sebelum menulis isi.
3. Isi work/audit/audit.json dan metadata provider. Angka ~×/~° opsional per komponen; angka tunggal default, rentang sah; confidence tidak tergantung angka. Piksel/helper flow opsional. Deklarasikan viewed hanya sesudah melihat. complete menghitung metadata mekanis, check-input/draft memeriksa sebelum render.
4. Tampilkan MD enam bagian, Overview, Storyboard dan semua kolase. Koreksi memakai pekerjaan/cache yang cocok; satu persetujuan keseluruhan kandidat terbaru.
5. Sesudah persetujuan, export-v2 --source /path/<id>.mp4 --receipt work/review.md.json membungkus byte snapshot sama. ZIP tanpa MP4/cache/log/receipt.

Sumber2.5/report2.2.4/media2.2.1. Detail desain, estimasi luas, gaya English/prosa Indonesia tetap lengkap. Semua moderate boleh. Pendalaman10FPS/native terarah; bukan mengulang semua shot secara rutin. Panduan JSON dibaca sesuai kebutuhan; contoh normal/multi hanya sintetik. Jangan menyalin contoh atau menganggap ekstraksi sebagai viewed. Kontrak lama tidak dilonggarkan.


## Inventaris resource lokal

| File | SHA-256 |
| --- | --- |
| tools/audit.py | 6c23265600ecfbbbfda22ce529d664015b8e6f6a291babad49e14fac4ca9c6d1 |
| tools/homeku/__init__.py | 895997aa9997a5dfb1b257f9fe48bda6322a749a38ddb7f6f517adc12830e23f |
| tools/homeku/common.py | e9fce85aa4cd50f6f8e73d68cd7aeb90d9e82dffdf4a6b67f66f37dde59d95b4 |
| tools/homeku/markdown.py | bbb2f3efd72fe5fed2be1bb8635017f4e45ddd31e283146625c3681acd8e4c50 |
| tools/homeku/validation.py | 528249edba2d24a4a82172b6e684eb2c0e547f431a6037b90ea6de0b8ac4da5a |
| tools/homeku/exporter.py | 8f9678df0d2e3573c5a4a331803434339348a3056fba1442a68ab25977649b14 |
| docs/contracts/manifest-v1.schema.json | 2646fc5eabc6c99044ee9ee27b2fc6af2a5cfc63279769908b04a46903be8852 |
| audit/template-analysis.md | aa5aa2dd50acdb034d63b2f93e9c1664ffaea554907f3dd2b6d5d57338aa7ded |
| tools/homeku/video.py | 7918be90acbfc30500e85084e8c8c76829a034d1c780cd1c37a055d17462647e |
| tools/homeku/models.py | c3a5e87f897598b9cc4dd1aa8b547bedbef257cb503906e14c2f9ce897b45ab6 |
| tools/homeku/media.py | d27f5ffee7840b9a829b1892ee4448b9521102b5cd5b39c86c353641db2d1039 |
| tools/homeku/reporting.py | 5e623975990bfcd35ee87e097489524a40c39cc4febe8c7705e89af4f1f1c14e |
| docs/contracts/audit-v2.schema.json | a383005f6724ed1d0e254073ff39c0919bf95c4b838b82f46e5bfe5ffc83470f |
| docs/contracts/manifest-v2.schema.json | e1dd593c3f835090c60e351a3c30e582b2625e1f1bb04e1a43438dcf2ceba904 |
| tools/homeku/media_v2_0.py | f2c7232a9c09ab55a4190b2e0905e9c8b502b68decf23d5bf16ce379c6d204ab |
| tools/homeku/media_v2_1.py | ba0df816b72c760a90c5ebf9d41804e84613d7bff293de8aa84d314df0f5699c |
| tools/homeku/media_v2_1_1.py | 9875b1a4eabd71388db59e8c21f39f18e41440becd8f1cf5a387b9d8b05f936c |
| tools/assets/templates/analysis-2.1.2.md | 4d3eed42a800cc8f4806013dbdf7c7801eac457f77cc163066814a626aa9a0be |
| tools/assets/templates/analysis-2.1.1.md | 6793a4be71cf4ad1d1222aba3d5354e397ee6b9c4f21213de33f4911d4c15d82 |
| tools/assets/fonts/DejaVuSans-Bold.ttf | 5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895 |
| tools/assets/templates/analysis-2.1.0.md | c34e4df89b949b437c9f7010c778f0165a12f9b28fe8597faf6e6d2e3a52be85 |
| tools/assets/fonts/DejaVuSans.ttf | ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280 |
| tools/assets/fonts/LICENSE.txt | e180b3d65bf650dffffd71dd21b6180767b469a18dd87e1d8552be69bb9ecdf0 |
| tools/assets/templates/analysis-2.0.0.md | 25ebc37f6bfe06d3b5bc7d51ef81c6fb02b25a97b5b9cb569ebaafc0466f5c7a |
| tools/homeku/reporting_v2_legacy.py | a11e22c7cfce39da7f4c61dd3dd33814c8b1f267a35f1c89a33b026707df0c5e |
| tools/homeku/media_v2_1_2.py | d824aca4cc5e9ef89ac3ff08f284961058e0d0c5f00e889295667289e9d98c6d |
| tools/homeku/camera_pattern.py | e0cb8ff09300145cfd86cf7b5920034f8b814c02e64a43c97fbabbef70ac3d33 |
| tools/homeku/media_v2_2.py | ca1189a4f7d20c43cdf52c6d2db58e3a1ecee606934010500c633246dcdb15c4 |
| tools/homeku/reporting_v2_2.py | e5371d8105704e22d7833be9e52ad1a5f9ad316d5cc83a131296ad68466dc4cc |
| docs/contracts/audit-v2-1.schema.json | 8018c2210ff0c21cd82ba75c08becd4cff9e75dca1e6ad1719e933528006ec5a |
| docs/contracts/manifest-v2-1.schema.json | e3fdea353dc5725f1ff7452a258b3349957f019db667c93e68b8a4fbeec551f1 |
| tools/assets/templates/analysis-2.2.0.md | 1e909dc3e97016221ca1331e0243497557921d89694b3d425ec98f0d98a481e0 |
| tools/assets/layouts/media-2.2.0.json | 174b4bd2e59497d43449375f77ecf4ff91bc2fb7cb79ee7f9d65cf56f70b590b |
| tools/homeku/versions.py | af83ed862bde1bf87ed45163b0108acaa0c5b8e890a8dbf728abddbadc5b2d75 |
| tools/homeku/audit_quality.py | e7b1cb8c9443034f36597313daa3d1c9ae817b808676f0af89070077c20ee6e9 |
| tools/homeku/report_validation.py | 48a1a2da1d3b14183e9a5fe7e032ae7930eac30cde4dd18c4788f0b3a771cd56 |
| tools/homeku/reporting_v2_2_1.py | 39f916996e135da297d78050bd7ce03eb3c574a082174cd5848e7e51bb91d293 |
| docs/contracts/audit-v2-2.schema.json | 501bdec8f7e2f8ad128958786ff2369634edd90fd7f03089d7726571e91df3d7 |
| docs/contracts/manifest-v2-2.schema.json | 2e5b11e1bdd0c11bcdda9b13171a44bc60302293fcdeb30637dcb800ebf7591b |
| tools/assets/templates/analysis-2.2.1.md | 79f5550cc081d9c0708e75de20f3aca82baa94aa29e9bd1b4d63d795d2e0e0ad |
| tools/homeku/reporting_v2_2_2.py | b81a06a1f037ecb33aeb7eeadcc160c836be63e25c30e477bb9cc7b624492a51 |
| docs/contracts/audit-v2-3.schema.json | 11b1d53842f926780502869f35d7e775fe2405bf6ad28809e9207a2fdf656faf |
| docs/contracts/manifest-v2-3.schema.json | 169612a7b551be024600b647510bbdb1045e4133a4071c6f87f4551119ad4dba |
| tools/assets/templates/analysis-2.2.2.md | 79f5550cc081d9c0708e75de20f3aca82baa94aa29e9bd1b4d63d795d2e0e0ad |
| tools/homeku/reporting_v2_2_3.py | 8a4a7c5a4f37836273e2c57a262e914cef7f5fdaf3c8567b8ac620b34eeb99d4 |
| docs/contracts/audit-v2-4.schema.json | 54029f04e1a53c71eb071e566d228e146dabe2f3f101eeafe5e893b8236e45f0 |
| docs/contracts/manifest-v2-4.schema.json | 19015d8fefb3356c9fc45bb9bf3f007584d05316ed698dad646bdc9b21686420 |
| tools/assets/templates/analysis-2.2.3.md | 79f5550cc081d9c0708e75de20f3aca82baa94aa29e9bd1b4d63d795d2e0e0ad |
| tools/homeku/authoring.py | ac5039e67c82b49a60dc5155537113c12f4be9489afc8a3257b632292b56e012 |
| tools/homeku/preflight.py | e8e0c220879ab7ceb3014ee4403840bb1e9a7e56cc133069eae0bb7e4b4e09a3 |
| tools/homeku/audit_session.py | fe64e708fe7894f0d9a22d3c9794bfb3071977165d87b83fb1161c6d7572002a |
| tools/homeku/video_cache.py | 3b2cd9a4bfc564f7ab2be3e986e771c0f51805f730bf5cc857c925c4971c10aa |
| tools/homeku/audit_performance.py | 99be30b6c19b04f64f16e6cf6e5abc56aa289b518e35e375bc524799bd8369c8 |
| tools/homeku/media_incremental.py | 7e49066fea92f395e5142116b0105951def8b72487e09ee4cd91c837f50b7cf2 |
| audit/template-audit.json | 6c5e135d6153d657cfa4e492ee7d2e6061ab4179541e5e50a7fc7b6d9ddd0677 |
| audit/template-audit-info.json | 870897d1c63369c1900ece933489b00b477bf0d90b5232ecefd491fa7b21a34f |
| tools/homeku/reporting_v2_2_4.py | 23f4fbfcb1acd69f9db00a6f920fbbcdcf8f8af70a17716bc06c7f1ece5e58b1 |
| tools/homeku/media_v2_2_1.py | 8bd0e1514280394e8e317fead926a99a5bd3fe89f98e4ce549157fc3a63f8154 |
| tools/homeku/camera_notation.py | 825723a001fbf8e7b3784e51287d996984d3ee9e15826413ffedc7968f2173d8 |
| tools/homeku/motion_analysis.py | 3b42f577b7168103d511d2229c15b327b48bd5b915d470cfe14c8cdf6e3bf7a8 |
| tools/assets/templates/analysis-2.2.4.md | 79f5550cc081d9c0708e75de20f3aca82baa94aa29e9bd1b4d63d795d2e0e0ad |
| tools/assets/layouts/media-2.2.1.json | 019816f0d070bbb1d1c90cd95e5e46bec18a7baa056e3f255537b4fc140dcc70 |
| docs/contracts/audit-v2-5.schema.json | 00fddcde8f539ec05acbceee874c1b838963d435dd171b0a8213e049b9d886e7 |
| docs/contracts/manifest-v2-5.schema.json | 8cb7080e8793326847a9617c8d08f4633d53f5ca9c6a92833ba0a52a643f1d02 |
| requirements-audit-motion.txt | 3f8acbea4b15265731ade002c15440013043de43db747099a073ababc317a0eb |
| audit/README.md | 42bce3dc924e6cbeb2a3df20f5271d649a97567554ab196d2bae1cc0276dc844 |
| audit/visual-audit.md | 5d0cef2218c8635faa85acc1bf9b7251c1d7628b5c93b34b2877a4e811ee254d |
| audit/protocol.md | e14fb521548144a7ccaed33d45569fa2b553641c2d4e22cc5e7441af554f5b81 |
| audit/rubric.md | c8572d4b50b17b748dfa6b7dd96a7cd0932be78d818ea8265b19b3f07d355265 |
| audit/json-guide.md | 2b38758637d8dd61f0727e7ca2ca41166f650752726394d528e6b3428876b183 |
| audit/vocabulary.md | 2dca8efaa5abcf5efc8d69a99454cbcd0201bb16a4387eac07ed11081d8ef8db |
| audit/providers.md | 6a325defb91c8d14139c665e792d874e0463f27365e7625055411fe64724c0cb |
| audit/calibration.md | e94a2b194dabb200ca89b76d28a7c2084ae890340f332f586a78e48577c62fe0 |
| audit/prompts/01-audit.md | a5d5474a2f6e290aa40dc602e3a4a31eeaefc2877c3e4622f834b1ac5eb6cdd8 |
| audit/prompts/02-correct.md | 4774c1c38265e5d8bb9e14a2f2ca129c1f22ae830b31ee790f58ddb8f8e43ebb |
| audit/prompts/03-export.md | d549a2f7facdc7ddee7385496830b6bdbd4828a8bdcb5beb9da4ba9cbde4063d |
| docs/contracts/package-v2-3.md | 3cfac1a516c9c047bc3d1f0f8cc4ba402dd22a3d24c5fe898bc92d99da3ecd12 |
| docs/contracts/analysis-v2-2-2.md | 6dbd90032efaf3da99fe4f902fbfc22541e65d73631b657cb7c550f4fed114ea |
| docs/contracts/package-v2-2.md | 680b330d6748626703b745b3c2ab2adb90590d91b30c2a3e93ef6568c80e9969 |
| docs/contracts/package-v2-1.md | 05d5545ad2fa0be9c6fcfd834beed11d09e9fe0787aeb86f5c476adced81cd6f |
| docs/contracts/package-v2.md | 25b3cfdf5604fbf758b333a6f9515804c8564350d593a9ef1b7127c43c31e920 |
| docs/contracts/analysis-v2-2-1.md | 00a9c738f7274eb618a080915b9d40408ab9a9674855f9ea138879ffa75e0ca0 |
| audit/authoring.md | 578e0f2db5f1556d8fe055217a420d70a4e9f2944dec522b05a377df44347646 |
| docs/contracts/package-v2-4.md | 4be617192d5d46637bc832679fc96440c423de5806a7b1389f6fbdd4af214583 |
| docs/contracts/analysis-v2-2-3.md | 500153f5e8476ab04feae5da953314ea6d131af9e6f9c13fced9040a46436d1f |
| audit/examples/normal/audit.json | 20e71c329e627ea4f8fb43bb9beeeeffcc3957ecf6033eb3abbfe08d73565919 |
| audit/examples/multi/audit.json | 2157ba905e5fb361f020ffac46b3ee795981e05aacd339eccb364067032a74c0 |
| audit/camera-cases.md | c1d706341b94f0aacdd6581d9ef17174c75cf945ca6053aa5bd0de3c0bdcb7cc |
| docs/contracts/package-v2-5.md | ac88d2b0fdd11ea89e67673e02306f680261813518f9be5c553cf78ed59b2bc8 |
| docs/contracts/analysis-v2-2-4.md | 8aa488c071acd3659148466e3cc198105e303180bab3bb4f9a8542d59e9b21c3 |
