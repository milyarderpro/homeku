# HOMEKU — kit audit2.4

Input: MP4 asli terpisah + ZIP ini. Hasil akhir satu ZIP tanpa video.

1. Ekstrak4file dan jalankan python homeku_runtime.py --output . untuk memulihkan seluruh resource lokal berhash. Python3.11+, Pillow, jsonschema dan FFmpeg/ffprobe diperlukan; tanpa unduhan kode.
2. Baca audit/visual-audit.md dan audit/authoring.md. Inspect dan periksa cut nyata; prepare menghitung PTS/panel serta baseline6FPS. Amati kamera/desain sebelum menulis isi.
3. Isi work/audit/audit.json dan metadata provider. Estimasi visual ~×/~° dengan asumsi wajar sah; piksel opsional. Deklarasikan viewed hanya sesudah melihat. complete menghitung metadata mekanis, check-input/draft memeriksa sebelum render.
4. Tampilkan MD enam bagian, Overview, Storyboard dan semua kolase. Koreksi memakai pekerjaan/cache yang cocok; satu persetujuan keseluruhan kandidat terbaru.
5. Sesudah persetujuan, export-v2 --source /path/<id>.mp4 --receipt work/review.md.json membungkus byte snapshot sama. ZIP tanpa MP4/cache/log/receipt.

Sumber2.4/report2.2.3/media2.2.0. Detail desain, estimasi luas, gaya English/prosa Indonesia tetap lengkap. Semua moderate boleh. Pendalaman10FPS/native terarah; bukan mengulang semua shot secara rutin. Panduan JSON dibaca sesuai kebutuhan; contoh normal/multi hanya sintetik. Jangan menyalin contoh atau menganggap ekstraksi sebagai viewed. Kontrak lama tidak dilonggarkan.


## Inventaris resource lokal

| File | SHA-256 |
| --- | --- |
| tools/audit.py | 6545dd8fa1e04f9632d3764f1dc23944fa163c056a67762b2af16d2995afcc92 |
| tools/homeku/__init__.py | 7c1d41521200bdc13b8513b1b8c991fb531e1aaedd3e3035729378986c1d9ab5 |
| tools/homeku/common.py | e9fce85aa4cd50f6f8e73d68cd7aeb90d9e82dffdf4a6b67f66f37dde59d95b4 |
| tools/homeku/markdown.py | 98c8fce8d82e826c7bb1e674bdfe2c7f235c3cdf0a7ecdd2fae75d0763e2baeb |
| tools/homeku/validation.py | 4e4e19b4e6d0237331886f4a73834d9b0931c66fe48a275a4df8d071c14dd8ad |
| tools/homeku/exporter.py | 4a0788584974bf0509982dde79f88c07871fa6718af08a5f5fddf3bee2d740e3 |
| docs/contracts/manifest-v1.schema.json | 2646fc5eabc6c99044ee9ee27b2fc6af2a5cfc63279769908b04a46903be8852 |
| audit/template-analysis.md | aa5aa2dd50acdb034d63b2f93e9c1664ffaea554907f3dd2b6d5d57338aa7ded |
| tools/homeku/video.py | 7918be90acbfc30500e85084e8c8c76829a034d1c780cd1c37a055d17462647e |
| tools/homeku/models.py | b3815d989a40da0ba149ac4e519584180ae1411d2080c9a29e9fc38b504e4319 |
| tools/homeku/media.py | 7119afdec088af27bb40a410a7b833659198e3ff3c14c1e042ea12110b4c6ff1 |
| tools/homeku/reporting.py | 23085dc547c2800b07acb901aa379eaf41e6c40be2361e53a559ed0df2ef40d4 |
| docs/contracts/audit-v2.schema.json | a383005f6724ed1d0e254073ff39c0919bf95c4b838b82f46e5bfe5ffc83470f |
| docs/contracts/manifest-v2.schema.json | e1dd593c3f835090c60e351a3c30e582b2625e1f1bb04e1a43438dcf2ceba904 |
| tools/homeku/media_v2_0.py | f2c7232a9c09ab55a4190b2e0905e9c8b502b68decf23d5bf16ce379c6d204ab |
| tools/homeku/media_v2_1.py | ba0df816b72c760a90c5ebf9d41804e84613d7bff293de8aa84d314df0f5699c |
| tools/homeku/media_v2_1_1.py | 9875b1a4eabd71388db59e8c21f39f18e41440becd8f1cf5a387b9d8b05f936c |
| tools/assets/templates/analysis-2.1.2.md | 4d3eed42a800cc8f4806013dbdf7c7801eac457f77cc163066814a626aa9a0be |
| tools/assets/templates/analysis-2.1.1.md | 6793a4be71cf4ad1d1222aba3d5354e397ee6b9c4f21213de33f4911d4c15d82 |
| tools/assets/fonts/DejaVuSans-Bold.ttf | 5c1247acef7f2b8522a31742c76d6adcb5569bacc0be7ceaa4dc39dd252ce895 |
| tools/assets/templates/analysis-2.1.0.md | c34e4df89b949b437c9f7010c778f0165a12f9b28fe8597faf6e6d2e3a52be85 |
| tools/assets/fonts/DejaVuSans.ttf | ae7b7855e115a5966d8b1b3f80f254ccc117ec86f9965e202ee2940453837280 |
| tools/assets/fonts/LICENSE.txt | e180b3d65bf650dffffd71dd21b6180767b469a18dd87e1d8552be69bb9ecdf0 |
| tools/assets/templates/analysis-2.0.0.md | 25ebc37f6bfe06d3b5bc7d51ef81c6fb02b25a97b5b9cb569ebaafc0466f5c7a |
| tools/homeku/reporting_v2_legacy.py | a11e22c7cfce39da7f4c61dd3dd33814c8b1f267a35f1c89a33b026707df0c5e |
| tools/homeku/media_v2_1_2.py | d824aca4cc5e9ef89ac3ff08f284961058e0d0c5f00e889295667289e9d98c6d |
| tools/homeku/camera_pattern.py | e0cb8ff09300145cfd86cf7b5920034f8b814c02e64a43c97fbabbef70ac3d33 |
| tools/homeku/media_v2_2.py | ca1189a4f7d20c43cdf52c6d2db58e3a1ecee606934010500c633246dcdb15c4 |
| tools/homeku/reporting_v2_2.py | e5371d8105704e22d7833be9e52ad1a5f9ad316d5cc83a131296ad68466dc4cc |
| docs/contracts/audit-v2-1.schema.json | 8018c2210ff0c21cd82ba75c08becd4cff9e75dca1e6ad1719e933528006ec5a |
| docs/contracts/manifest-v2-1.schema.json | e3fdea353dc5725f1ff7452a258b3349957f019db667c93e68b8a4fbeec551f1 |
| tools/assets/templates/analysis-2.2.0.md | 1e909dc3e97016221ca1331e0243497557921d89694b3d425ec98f0d98a481e0 |
| tools/assets/layouts/media-2.2.0.json | 174b4bd2e59497d43449375f77ecf4ff91bc2fb7cb79ee7f9d65cf56f70b590b |
| tools/homeku/versions.py | 657e37cbd2f28323968e9b1df7750c9e4dd2a236cf1ebafab7baa8dcad513789 |
| tools/homeku/audit_quality.py | 009d6b3c052a741b002e6775852bc0c36b11ba46b62ae3cdca08b8ca96fb6a44 |
| tools/homeku/report_validation.py | 48a1a2da1d3b14183e9a5fe7e032ae7930eac30cde4dd18c4788f0b3a771cd56 |
| tools/homeku/reporting_v2_2_1.py | 39f916996e135da297d78050bd7ce03eb3c574a082174cd5848e7e51bb91d293 |
| docs/contracts/audit-v2-2.schema.json | 501bdec8f7e2f8ad128958786ff2369634edd90fd7f03089d7726571e91df3d7 |
| docs/contracts/manifest-v2-2.schema.json | 2e5b11e1bdd0c11bcdda9b13171a44bc60302293fcdeb30637dcb800ebf7591b |
| tools/assets/templates/analysis-2.2.1.md | 79f5550cc081d9c0708e75de20f3aca82baa94aa29e9bd1b4d63d795d2e0e0ad |
| tools/homeku/reporting_v2_2_2.py | b81a06a1f037ecb33aeb7eeadcc160c836be63e25c30e477bb9cc7b624492a51 |
| docs/contracts/audit-v2-3.schema.json | 11b1d53842f926780502869f35d7e775fe2405bf6ad28809e9207a2fdf656faf |
| docs/contracts/manifest-v2-3.schema.json | 169612a7b551be024600b647510bbdb1045e4133a4071c6f87f4551119ad4dba |
| tools/assets/templates/analysis-2.2.2.md | 79f5550cc081d9c0708e75de20f3aca82baa94aa29e9bd1b4d63d795d2e0e0ad |
| tools/homeku/reporting_v2_2_3.py | 8a4a7c5a4f37836273e2c57a262e914cef7f5fdaf3c8567b8ac620b34eeb99d4 |
| docs/contracts/audit-v2-4.schema.json | 54029f04e1a53c71eb071e566d228e146dabe2f3f101eeafe5e893b8236e45f0 |
| docs/contracts/manifest-v2-4.schema.json | 19015d8fefb3356c9fc45bb9bf3f007584d05316ed698dad646bdc9b21686420 |
| tools/assets/templates/analysis-2.2.3.md | 79f5550cc081d9c0708e75de20f3aca82baa94aa29e9bd1b4d63d795d2e0e0ad |
| tools/homeku/authoring.py | c0671005a3d4d4345a367c92734976f1e1eef02c784d9be2df399f216572e53d |
| tools/homeku/preflight.py | a9bc2fdf19498b14471bdecda8e80b92a72e017021625560f1202a1f2cd6feb1 |
| tools/homeku/audit_session.py | 593305f5f7008b81a173dd600b0f3477745f953592a69fd60807f3001c7b7549 |
| tools/homeku/video_cache.py | 314eed5dfbc026f9799ca9a7e86d48539432bc11f168da13bae4a4db9d19a69e |
| tools/homeku/audit_performance.py | 99be30b6c19b04f64f16e6cf6e5abc56aa289b518e35e375bc524799bd8369c8 |
| tools/homeku/media_incremental.py | 3d054442bddee167f9e087097040538cf98b8337ff6bbf830732fd48e728d42a |
| audit/template-audit.json | 2cf1c4b9ded6c0f7ce550d96f4b2855bb6770e65a19b94c8835e71a519db6a7d |
| audit/template-audit-info.json | 870897d1c63369c1900ece933489b00b477bf0d90b5232ecefd491fa7b21a34f |
| audit/README.md | 11dcf46bcb4ab1b5b87b9c1016829e34ff3328750bf54e234be547dd5c6c9723 |
| audit/visual-audit.md | 81c740dea26ad58fd6fc49cb94037239fc245acebdddae8a4406d994d3e5c78d |
| audit/protocol.md | 128f666e54a246e45cf813b3774b483d38c977ea05a6109b8b42afe32b43a30f |
| audit/rubric.md | 23d8ab2383292c424b96ddec0c705456bcc0a24ccbd469cc80cf0c7d4954fb70 |
| audit/json-guide.md | 5e7b35162207cf67dcdcaaab37b3b74d3d2c017aaeb15d66f315639e4c7c5e6b |
| audit/vocabulary.md | e738f66c6ef062f95734dd10b59c2d45111c1c359e142f1e394ca3a3d97806fe |
| audit/providers.md | 590500aff9b899ebdb7d01f52be6e82bdc70fb495a4aa8e49d536e59cf2221e2 |
| audit/calibration.md | 4f306a765192ccd2f0176bd6668a91170674aa71d2bb50e164b52a25335a595f |
| audit/prompts/01-audit.md | 60316653c623ac30c7d34c63d8d194ae46f2752f5ef43eeb7d07eef866552b32 |
| audit/prompts/02-correct.md | 1854b356b271aff389957d79619f14e0c595d185b57008fef1e5b21ca0623e58 |
| audit/prompts/03-export.md | d549a2f7facdc7ddee7385496830b6bdbd4828a8bdcb5beb9da4ba9cbde4063d |
| docs/contracts/package-v2-3.md | 3cfac1a516c9c047bc3d1f0f8cc4ba402dd22a3d24c5fe898bc92d99da3ecd12 |
| docs/contracts/analysis-v2-2-2.md | 6dbd90032efaf3da99fe4f902fbfc22541e65d73631b657cb7c550f4fed114ea |
| docs/contracts/package-v2-2.md | 680b330d6748626703b745b3c2ab2adb90590d91b30c2a3e93ef6568c80e9969 |
| docs/contracts/package-v2-1.md | 05d5545ad2fa0be9c6fcfd834beed11d09e9fe0787aeb86f5c476adced81cd6f |
| docs/contracts/package-v2.md | 25b3cfdf5604fbf758b333a6f9515804c8564350d593a9ef1b7127c43c31e920 |
| docs/contracts/analysis-v2-2-1.md | 00a9c738f7274eb618a080915b9d40408ab9a9674855f9ea138879ffa75e0ca0 |
| audit/authoring.md | 81717f0c3850e79c26985090755de8febcc145cec0c904b1409d74a318ad9413 |
| docs/contracts/package-v2-4.md | 4be617192d5d46637bc832679fc96440c423de5806a7b1389f6fbdd4af214583 |
| docs/contracts/analysis-v2-2-3.md | 500153f5e8476ab04feae5da953314ea6d131af9e6f9c13fced9040a46436d1f |
| audit/examples/normal/audit.json | 0c43296f0914cb55242c5a017c2381c739439a52454eb6a909d429bf08f2838d |
| audit/examples/multi/audit.json | 9ee8984e74b8bafb2477d1ff30d8f135e024d90cb07e1a960da07ad5af0fb95d |
