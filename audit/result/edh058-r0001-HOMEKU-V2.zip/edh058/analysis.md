# edh058 — Cottage Krem dengan Taman Bunga dan Interior Kayu Hangat

<a id="profil-dna"></a>

## 1. Identitas desain

- **Nama desain rumah:** Cottage Krem dengan Taman Bunga dan Interior Kayu Hangat
- **Gaya utama:** European Country Cottage
- **Pengaruh gaya:** English Country Cottage pada shutters, flower boxes dan taman; Mediterranean Cottage pada stucco tampak serta genteng warna tanah (interpretatif).
- **Gaya interior:** Warm Cottage Transitional — palet krem, kabinet shaker, linen putih, kayu hangat, anyaman dan aksen metal hitam.
- **Ciri pengenal:** Fasad pelana plester krem dan pintu kayu berkaca diapit lampu lantern serta flower-box shutters hitam; Jendela melengkung gelap berulang, putih hangat dan bunga di ambang beberapa ruang; Walk-in closet dengan atap pelana dan balok kayu terlihat, storage dua sisi serta window ujung; Bathroom bak mandi freestanding di bawah window dengan pot pohon dan vanity kayu
- **Palet utama:** Krem-gading, putih hangat, kayu oak tampak, beige-tan, terracotta/rust, bingkai hitam dan hijau dedaunan.
- **Suasana dan lingkungan:** Suasana cottage terang, hangat dan floral; fasad di halaman rumput rindang saat siang cerah, interior mendapat daylight lewat jendela dengan lapisan cahaya lampu dekoratif.

## 2. Ukuran dan proporsi bangunan

| Aspek | Estimasi visual |
| --- | --- |
| Ukuran rumah | small |
| Bentuk bangunan | Massa satu lantai tampak padat, atap pelana pusat dan sayap rendah kiri, tanpa geometri belakang teridentifikasi. |
| Skala vertikal | Satu lantai terlihat dari fasad; ceiling beberapa ruang lebih tinggi dengan balok terbuka, lantai tambahan tidak dapat dipastikan. |
| Tapak bangunan | Kesan tapak kompak namun kedalaman/panjang penuh tak terlihat; halaman cukup lega pada muka. |
| Proporsi utama | Fasad lebih lebar daripada tinggi satu lantainya, pintu pusat di bawah muka pelana; interior berupa ruang-ruang kompak dengan closet sempit memanjang. |
| Perkiraan luas lantai | **65–100 m²** |

## 3. Struktur dan timeline video

Durasi stream video 19,90 s dan 597 frame asli pada 30 FPS; lima hard cut pada 5,30; 8,3667; 11,5333; 14,5667; 17,10 s membentuk enam take terpisah. Bukan continuous tour dari eksterior ke semua ruang.

| Shot | Waktu (detik) | Durasi | Area/Scene | Gerakan singkat | Ritme |
| --- | --- | --- | --- | --- | --- |
| 01 | 0–5.3 | 5.3 detik | Exterior & front garden | Kamera maju dari halaman mengikuti arah jalur batu menuju pintu depan. Rumah, pot dan lampu membesar; batang pohon di kanan keluar bingkai. Orientasi tetap terutama ke pintu, tanpa bukti kuat orbit besar. | Moderate dan mulus; kenaikan perubahan ukuran yang terasa di akhir konsisten juga dengan perspektif saat mendekat, bukan bukti percepatan fisik. |
| 02 | 5.3–8.367 | 3.067 detik | Living room | Kamera mundur menjauhi konsol TV sambil mengarahkan pandangan perlahan ke kiri. Sofa yang semula sangat dekat menjadi lebih kecil; meja, kursi dan bukaan kaca kiri masuk ke komposisi. | Moderate, stabil, reveal ruang bertahap; tidak ditemukan titik perubahan gerak tajam dalam 3,07 detik. |
| 03 | 8.367–11.533 | 3.167 detik | Kitchen | Kamera mendekat ke area kompor sambil menggeser arah pandang ke kanan. Jendela lengkung dan peninsula perlahan keluar sisi kiri, sementara kompor stainless, cooker hood dan rak kayu mengisi komposisi. | Moderate, aliran ke kanan kontinu dan terasa lebih rapat saat mencapai kompor; tidak ada cut di tengah shot. |
| 04 | 11.533–14.567 | 3.033 detik | Bedroom | Kamera mundur menjauh dari kepala ranjang sambil sedikit mengarahkan pandangan ke kiri. Mulanya kasur dan jendela memenuhi bingkai; akhirnya ranjang hampir seluruhnya, meja kedua sisi, tanaman dan balok plafon terlihat. | Moderate dan smooth, reveal kasur serta sudut kiri terjadi secara berangsur tanpa fase gerak baru yang jelas. |
| 05 | 14.567–17.1 | 2.533 detik | Walk-in closet | Kamera maju lurus memasuki lorong lemari menuju jendela di ujung. Jendela serta dekorasi bunga membesar, sedangkan susunan gantungan, rak, dan balok plafon di tepi terpangkas secara bertahap. | Moderate kontinu; perubahan ukuran visual terasa lebih cepat dekat jendela, tanpa bukti motor kamera mempercepat. |
| 06 | 17.1–19.9 | 2.8 detik | Bathroom | Kamera mundur dari bathtub dan tanaman sambil sedikit bergeser ke kanan serta menoleh ke kiri. Pemandangan melebar sehingga toilet, lantai, dan wastafel di atas kabinet kayu kanan menjadi jelas. Besar komponen geser belum bisa dipastikan. | Moderate dan mulus; reveal vanity serta lantai berkembang terus hingga akhir shot. |

## 4. Storyboard

![Storyboard overview seluruh area](media/storyboard.jpg)

## 5. Detail shot

<a id="shot-01"></a>

### Shot 01 — Exterior & front garden · 5.3 detik

![Kolase Shot 01](media/shot-01.jpg)

**Urutan panel:** Start · 0.00s → Middle · 2.63s → End · 5.27s.

#### A. Desain area

**Arsitektur**

Rumah kecil satu lantai memperlihatkan fasad plester tampak krem/ivory dan massa utama beratap pelana rendah, dengan penutup menyerupai genteng tanah liat dan cerobong pendek di massa samping kiri. Pintu masuk kayu berpanel bawah dan kaca atas berada hampir di tengah muka pelana, dinaungi ujung atap; anak tangga/teras dangkal berada tepat di depannya. Jendela berbingkai hitam dan daun penutup hitam tampak di kiri, serta jendela samping di dinding kanan. Di sekitar pintu terdapat tiga lampu dinding bergaya lentera, satu di atas dan dua mengapit; pagar kayu muncul di belakang sisi kanan.

**Furnitur dan properti**

Kotak tanaman pada ambang jendela, beberapa pot besar bermotif putar di kedua sisi pintu, semak ramping menyerupai cemara, dan rangkaian bunga merah-jingga-putih di tepi teras. Pada panel kaca pintu tampak karangan daun hias. Tidak ada interior yang dipastikan dari shot eksterior.

**Lingkungan**

Halaman rumput hijau terawat dengan jalan setapak batu tidak beraturan melengkung dari kiri-bawah menuju teras. Pohon berbatang tinggi berada di kanan depan rumah; ranting serta daun pohon menaungi tepi atas bidang, dan pepohonan berwarna hijau-kuning mengisi belakang. Siang cerah menghasilkan bayang-bayang daun tajam di rumput dan lintasan.

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Fokus utama | Fasad pelana dan pintu masuk kayu berkaca. |
| Posisi kamera awal | Dari halaman depan di luar jalur setapak, agak serong terhadap muka rumah, dengan batang pohon kanan sebagai foreground; Menghadap pintu depan dan bidang fasad pelana; dinding samping kanan masih tampak; Sudut tiga-perempat frontal ringan dari halaman, lalu makin terpusat pada pintu. |
| Framing awal → akhir | Wide shot rumah dan taman dengan jalan batu menuju pusat pintu dan batang pohon dominan di kanan. → Medium-wide fasad pintu/teras, pot dan lampu lebih besar; sebagian besar rumput dan pohon terpotong. |
| Pencahayaan | Matahari terang dari atas-samping dengan bayangan pohon nyata; lentera tampak tidak perlu diklaim menyala. |

#### C. Gerakan kamera

**Bahasa sederhana**

Kamera maju dari halaman mengikuti arah jalur batu menuju pintu depan. Rumah, pot dan lampu membesar; batang pohon di kanan keluar bingkai. Orientasi tetap terutama ke pintu, tanpa bukti kuat orbit besar.

**Ritme:** Moderate dan mulus; kenaikan perubahan ukuran yang terasa di akhir konsisten juga dengan perspektif saat mendekat, bukan bukti percepatan fisik.

**Notasi teknis**

```text
Dolly-In (~1.7×) toward front door
```

---

<a id="shot-02"></a>

### Shot 02 — Living room · 3.067 detik

![Kolase Shot 02](media/shot-02.jpg)

**Urutan panel:** Start · 5.30s → Middle · 6.83s → End · 8.33s.

#### A. Desain area

**Arsitektur**

Dinding krem dengan lis plafon putih dan satu ceruk arched/berlengkung di tengah bidang tempat televisi diletakkan. Sisi kanan ceruk ditandai kolom tebal, dan dua lampu dinding hitam mengapitnya. Lantai papan bernuansa kayu hangat terlihat mengelilingi karpet bermotif klasik. Di kiri, bukaan kaca berkusen gelap dengan tirai krem panjang menjadi makin terlihat ketika kamera mundur; plafon putih memperlihatkan beberapa lampu downlight dan elemen balok kayu dekat akhir shot.

**Furnitur dan properti**

Sofa upholstery krem berlapis bantal polos dan bantal motif titik mendominasi foreground kanan. Meja kopi kayu berbentuk persegi panjang berisi tumpukan buku dan vas rangkaian bunga warna jingga; di bawahnya karpet terang berpola. Dalam ceruk TV ada konsol kayu dengan dua pintu samping serta rak terbuka di tengah yang menyimpan keranjang/buku. Kursi single berlapis terang dengan bantal beraksen oranye dan tanaman rindang diletakkan dekat bukaan kiri; keranjang anyam lantai muncul di tepi depan saat kamera menjauh.

**Lingkungan**

Sinar matahari dari pintu/jendela kaca kiri menghasilkan petak bayangan geometris di papan lantai dan karpet. Melalui kaca hanya tampak tanaman serta warna cerah di luar, bukan denah taman yang teridentifikasi.

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Fokus utama | Ceruk TV dan konsol kayu, lalu keseluruhan susunan ruang tamu. |
| Posisi kamera awal | Di sisi dekat sofa kanan, sedikit di muka meja kopi dan mengarah ke alcove televisi; Awalnya ke ceruk TV berlengkung; arah pandang sedikit bergeser ke kiri untuk membuka bukaan kaca/kursi; Frontal-serong terhadap alcove TV, melebar saat kamera mundur. |
| Framing awal → akhir | Medium dekat pada TV dalam ceruk dengan sofa besar memotong sisi kanan dan meja hanya sebagian. → Wide living room: pintu kaca hampir utuh di kiri, kursi, tanaman, coffee table, sofa, konsol TV, rug dan basket lantai. |
| Pencahayaan | Daylight kuat dari kiri dipadu downlight plafon, lampu dinding sisi TV terlihat sebagai fixture. |

#### C. Gerakan kamera

**Bahasa sederhana**

Kamera mundur menjauhi konsol TV sambil mengarahkan pandangan perlahan ke kiri. Sofa yang semula sangat dekat menjadi lebih kecil; meja, kursi dan bukaan kaca kiri masuk ke komposisi.

**Ritme:** Moderate, stabil, reveal ruang bertahap; tidak ditemukan titik perubahan gerak tajam dalam 3,07 detik.

**Notasi teknis**

```text
Dolly-Out (~1.4×) + gentle Pan Left (~10°)
```

---

<a id="shot-03"></a>

### Shot 03 — Kitchen · 3.167 detik

![Kolase Shot 03](media/shot-03.jpg)

**Urutan panel:** Start · 8.37s → Middle · 9.93s → End · 11.50s.

#### A. Desain area

**Arsitektur**

Dapur berbentuk lorong/U ringkas dengan kabinet shaker krem gading sampai plafon di sisi belakang dan kanan. Jendela arched hitam berada di atas sink sudut belakang kiri; meja kerja bercorak batu terang membelok di bawah jendela. Kompor/range stainless lebar menempati sisi kanan, dengan chimney hood stainless tegak di atasnya; dua rak kayu floating di dinding kanan. Lantai papan bernuansa cokelat dengan runner anyaman, lampu recessed pada plafon dan dua pendant silinder di atas peninsula kiri depan.

**Furnitur dan properti**

Peninsula top terang menonjol ke kamera dari kiri dengan dua bangku kayu bulat di bawahnya dan alas/platter serta vas bunga di atasnya. Sink farmhouse berwarna putih di bawah jendela dilengkapi keran tegak. Countertop memiliki talenan bersandar, keranjang anyam, container alat masak, botol dan aksesori. Pot putih di atas burner stove dan mangkuk buah oranye di counter kanan; rak kayu membawa piring dan pot tanaman.

**Lingkungan**

Jendela arched memperlihatkan cahaya putih terang dan tanaman merah di dekat ambang, tanpa identifikasi pasti arah halaman/ruang luar. Pencahayaan kerja di bawah hood dan lampu plafon menyorot backsplash bertekstur plester/batu tampak.

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Fokus utama | Range stainless, hood, shaker cabinetry dan lapisan counter. |
| Posisi kamera awal | Dari mulut dapur dekat ujung peninsula kiri, menghadap diagonal ke kabinet dan kompor di kanan; Awal mengarah ke sudut sink/jendela dan kompor; bergeser ke kanan untuk menekankan kompor, hood dan rak; Serong sepanjang countertop, makin sempit ke sisi kompor. |
| Framing awal → akhir | Wide kitchen meliputi peninsula, dua stool, sink arched window, kabinet, kompor dan hood. → Close medium sisi kompor dan hood, kabinet atas, backsplash, rak serta mangkuk buah; window keluar dari bingkai. |
| Pencahayaan | Daylight dari jendela kiri ditambah recessed/pendant dan lampu bawah range hood. |

#### C. Gerakan kamera

**Bahasa sederhana**

Kamera mendekat ke area kompor sambil menggeser arah pandang ke kanan. Jendela lengkung dan peninsula perlahan keluar sisi kiri, sementara kompor stainless, cooker hood dan rak kayu mengisi komposisi.

**Ritme:** Moderate, aliran ke kanan kontinu dan terasa lebih rapat saat mencapai kompor; tidak ada cut di tengah shot.

**Notasi teknis**

```text
Dolly-In (~1.5×) toward range + Pan Right (~15°)
```

---

<a id="shot-04"></a>

### Shot 04 — Bedroom · 3.033 detik

![Kolase Shot 04](media/shot-04.jpg)

**Urutan panel:** Start · 11.53s → Middle · 13.07s → End · 14.53s.

#### A. Desain area

**Arsitektur**

Kamar tidur kecil dengan dinding berwarna gading dan aksen abu-hijau pucat di sekitar jendela lengkung hitam pada dinding kepala ranjang. Tirai putih tebal membingkai jendela; di atasnya plafon terang dilintasi balok-balok kayu gelap yang mulai tampak ketika shot mundur. Jendela menampilkan tanaman dan bunga merah pada ambang serta cahaya luar.

**Furnitur dan properti**

Tempat tidur berlapis linen/selimut rajut putih bertekstur ditempatkan di bawah jendela arched, dengan tumpukan bantal gading dan satu cushion berkarakter rust/oranye. Di kedua sisinya meja laci kayu terang: lampu meja dan cermin kecil terlihat di kiri; vas bunga pucat berada di meja kanan. Lampu dinding kecil bernuansa kuning hangat mengapit area kepala ranjang. Sebuah pendant anyam/rangka ringan dan sedikit sisi bangku kayu di kaki ranjang terbuka ketika framing lebih lebar, beserta tanaman berdaun gelap di kiri belakang.

**Lingkungan**

Cahaya alami dari jendela berbingkai hitam menyinari seprai; dedaunan hijau serta kotak bunga merah terlihat di luar, tetapi arah/identitas ruang luar tidak terverifikasi.

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Fokus utama | Tempat tidur putih dan jendela lengkung di dinding kepala ranjang. |
| Posisi kamera awal | Dekat sisi kaki/kanan ranjang, mengarah ke headboard dan jendela di atasnya; Berlawanan dengan dinding kepala ranjang, sedikit bergeser ke kiri sehingga nightstand kiri dan sisi kamar bertambah; Awal close-medium diagonal ranjang/jendela, akhir wide tiga-perempat dari kaki ranjang. |
| Framing awal → akhir | Close pada separuh atas ranjang, jendela lengkung dan meja laci kanan. → Hampir seluruh ranjang, nightstand di dua sisi, pendant, balok plafon dan kamar terang masuk satu frame. |
| Pencahayaan | Daylight dari jendela, lampu sisi ranjang dan lampu meja yang tampak hangat. |

#### C. Gerakan kamera

**Bahasa sederhana**

Kamera mundur menjauh dari kepala ranjang sambil sedikit mengarahkan pandangan ke kiri. Mulanya kasur dan jendela memenuhi bingkai; akhirnya ranjang hampir seluruhnya, meja kedua sisi, tanaman dan balok plafon terlihat.

**Ritme:** Moderate dan smooth, reveal kasur serta sudut kiri terjadi secara berangsur tanpa fase gerak baru yang jelas.

**Notasi teknis**

```text
Dolly-Out (~1.4×) + gentle Pan Left (~10°)
```

---

<a id="shot-05"></a>

### Shot 05 — Walk-in closet · 2.533 detik

![Kolase Shot 05](media/shot-05.jpg)

**Urutan panel:** Start · 14.57s → Middle · 15.83s → End · 17.07s.

#### A. Desain area

**Arsitektur**

Walk-in closet sempit memanjang dengan plafon pelana tinggi dan beberapa balok/rangka kayu terbuka di bagian atas. Penyimpanan terbuka full-height di kiri dan kanan mengapit satu sumbu sirkulasi lurus. Di ujung ada jendela arched gelap, dinding putih hangat, dan cahaya masuk dari luar. Lantai papan warna terang dengan karpet woven panjang; tidak ada bukti bahwa koridor ini menyambung langsung ke bedroom dalam video ber-cut.

**Furnitur dan properti**

Rak dan gantungan dua tingkat kiri memegang kemeja, celana serta tekstil warna netral dan terakota, sementara sisi kanan menampilkan hanging rail, kabinet laci kayu bertumpuk serta shelf atas berisi keranjang anyam. Ottoman empuk warna krem berdiri di tengah jalur dekat ujung jendela. Pot bunga putih/pale dan dekorasi anyam mengisi sekitar ambang; beberapa niche diberi lampu task tersembunyi.

**Lingkungan**

Jendela ujung memperlihatkan bunga merah, jingga dan tanaman hijau berlawanan dengan dinding luar terang. Cahaya alami pada ambang berpadu lampu kecil/recessed di atap, tanpa bukti lokasi geografis.

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Fokus utama | Arched end window dan sistem storage terbuka dua sisi. |
| Posisi kamera awal | Pada ambang masuk/ujung depan closet, di antara dua deretan storage; Nyaris lurus searah sumbu tengah menuju jendela ujung; Simetris frontal masuk lorong kecil, dengan konvergensi rak di kedua sisi. |
| Framing awal → akhir | Wide simetris tampak keseluruhan closet: balok atap, dua rel pakaian, laci kanan, karpet dan jendela ujung. → Closer terhadap jendela, bunga, laci kanan dan sebagian rel kiri; entrance dan atap tinggi sebagian terpotong. |
| Pencahayaan | Cahaya dari jendela ujung, lampu built-in di niche, recessed plafon kecil. |

#### C. Gerakan kamera

**Bahasa sederhana**

Kamera maju lurus memasuki lorong lemari menuju jendela di ujung. Jendela serta dekorasi bunga membesar, sedangkan susunan gantungan, rak, dan balok plafon di tepi terpangkas secara bertahap.

**Ritme:** Moderate kontinu; perubahan ukuran visual terasa lebih cepat dekat jendela, tanpa bukti motor kamera mempercepat.

**Notasi teknis**

```text
Dolly-In (~1.5×) toward arched closet window
```

---

<a id="shot-06"></a>

### Shot 06 — Bathroom · 2.8 detik

![Kolase Shot 06](media/shot-06.jpg)

**Urutan panel:** Start · 17.10s → Middle · 18.50s → End · 19.87s.

#### A. Desain area

**Arsitektur**

Bathroom cerah berukuran kompak, dengan jendela persegi panjang tinggi berbingkai hitam pada dinding bak mandi dan ambang berisi pot. Dinding plester krem/putih hangat serta bidang belakang tanaman berlapis ubin kecil warna abu-putih terlihat. Cekungan/niche melengkung dengan rak kayu dan pot tanaman tampak di sisi kanan jendela, sementara di atas ada detail balok plafon kayu dan pencahayaan downlight. Lantai terlihat berubin kotak nuansa terakota/beige; tidak ada shower yang terlihat dari angle ini.

**Furnitur dan properti**

Bathtub berdiri berbentuk oval putih berada di bawah jendela dengan faucet hitam dinding dan papan caddy di bibir tub. Toilet putih terletak di depan kanan bathtub. Satu tanaman berbatang ramping berdaun mirip olive dalam pot putih berada di sebelah toilet. Pada kanan depan tampak vanity kayu berpanel dengan wastafel vessel putih, faucet gelap, cermin berbingkai lengkung dan lampu sconce; keranjang berisi handuk dan pot hijau berada di kiri lantai pada akhir shot. Ada tirai ivory di samping jendela dan handuk digantung di dinding kanan.

**Lingkungan**

Lewat jendela terlihat dedaunan hijau, bunga merah-jingga serta bagian atap bangunan tetangga/struktur di luar, tetapi hubungan tempat dengan eksterior shot 01 belum terbukti. Daylight menerangi bathtub dan lantai, ditambah lampu sconce hangat.

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Fokus utama | Hubungan bathtub di bawah jendela dengan toilet, tanaman pot dan vanity kanan. |
| Posisi kamera awal | Sangat dekat area bathtub/tanaman dan sebagian sisi wastafel, menghadap diagonal ke window dan niche; Menghadap jendela di belakang tub dengan sedikit penyesuaian kiri sambil mundur/bergeser membuka vanity kanan; Close tiga-perempat bagian dalam bath, melebar menjadi pandangan atas tub–toilet–vanity. |
| Framing awal → akhir | Tight pada setengah tub, jendela, tanaman besar serta tutup toilet; vanity hampir tidak terlihat. → Wide bathroom dengan tub, window, toilet, potted tree, vessel sink dan kabinet vanity kanan. |
| Pencahayaan | Sinar daylight kuat dari jendela dan sconce dinding kanan serta downlight atas. |

#### C. Gerakan kamera

**Bahasa sederhana**

Kamera mundur dari bathtub dan tanaman sambil sedikit bergeser ke kanan serta menoleh ke kiri. Pemandangan melebar sehingga toilet, lantai, dan wastafel di atas kabinet kayu kanan menjadi jelas. Besar komponen geser belum bisa dipastikan.

**Ritme:** Moderate dan mulus; reveal vanity serta lantai berkembang terus hingga akhir shot.

**Notasi teknis**

```text
Dolly-Out (~1.3×) + gentle Truck Right + gentle Pan Left (~10°)
```
