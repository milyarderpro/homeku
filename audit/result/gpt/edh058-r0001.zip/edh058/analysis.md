# edh058 — Garden Cottage with Warm Wood Interiors

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Garden Cottage with Warm Wood Interiors
- **Gaya utama:** **English Cottage**
- **Pengaruh gaya:** French Country
- **Gaya interior:** Cottagecore
- **Ciri khas:** Massa rendah beratap pelana dan pintu kayu berkaca dengan lentera hitam; Jendela lengkung bergrid hitam, balok kayu dan tekstil krem; Taman bunga berlapis, jalan batu dan pot tanaman
- **Warna & material:** Krem hangat, kayu madu, hitam pada bukaan, hijau lembut, aksen rust dan bunga merah-jingga.
- **Suasana dan lingkungan:** Hangat, intim dan teduh dengan taman bunga, pohon besar serta cahaya matahari alami.

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Massa rendah mendatar dengan volume masuk beratap pelana maju. |
| **Lantai & bentuk atap** | Satu lantai tampak; tidak terlihat tingkat tambahan. |
| **Tapak bangunan** | Kompak, melebar di muka; batas belakang dan bentuk denah tidak terlihat. |
| **Proporsi utama** | Fasad lebih lebar daripada tinggi, bukaan dan teras berukuran domestik; ruang interior relatif kompak. |
| **Perkiraan luas lantai** | **65–105 m²** |

## 3. Shot Timeline

Enam take kontinu dipisahkan lima hard cut; urutan edit eksterior, living room, kitchen, bedroom, walk-in closet, bathroom. Urutan tersebut tidak membuktikan hubungan denah.

**Camera Pattern:** IN – OUT – IN – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–5.30 | 5.30s | Exterior | Dolly-In (~2.1×). |
| 02 | 5.30–8.37 | 3.07s | Living Room | Dolly-Out (~1.5×) + Pan Left (Ease-Out). |
| 03 | 8.37–11.53 | 3.17s | Kitchen | Dolly-In (~1.6×) + Pan Right. |
| 04 | 11.53–14.57 | 3.03s | Bedroom | Dolly-Out (~1.4×) + Pan Left (Ease-Out). |
| 05 | 14.57–17.10 | 2.53s | Walk-in Closet | Straight Dolly-In (~1.5×). |
| 06 | 17.10–19.90 | 2.80s | Bathroom | Diagonal Dolly-Out (~1.5×). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Exterior · 0.00s**

> Dari halaman, pandangan wide sedikit serong ke pintu dan sisi kanan rumah pada tinggi mata, agak menunduk. Jalan batu memandu mata melewati hamparan rumput dan bunga ke teras; pohon kanan membingkai fasad dengan cahaya matahari dan bayangan tajuk.

**Shot 02 · Living Room · 8.33s**

> Dari posisi lebih jauh di sisi ruang duduk, pandangan serong ke ceruk TV dan bukaan taman kiri, pada tinggi dada-mata dengan sedikit arah turun. Sofa kanan dan keranjang membingkai meja di tengah, kursi serta jendela di belakang; bayangan grid melintang di karpet.

**Shot 03 · Kitchen · 8.37s**

> Dari ambang pada tinggi mata, pandangan wide serong ke lorong kerja dan jendela lengkung di ujung, sedikit menunduk. Island dan stool mengisi kiri depan, kabinet dan range kanan membentuk garis kedalaman dengan cahaya hangat dan terang dari jendela.

**Shot 04 · Bedroom · 14.53s**

> Dari kaki ranjang yang lebih jauh, pandangan wide serong ke dinding jendela pada tinggi dada-mata, sedikit menunduk. Ranjang menjadi pusat dengan nightstand kanan dan kiri, kursi di sudut kiri serta balok melintang di atas; cahaya alami dan lampu hangat menonjolkan tekstil.

**Shot 05 · Walk-in Closet · 14.57s**

> Dari ambang pada tinggi mata, pandangan wide hampir lurus menyusuri lorong, sedikit mengarah turun. Rak terbuka di kedua sisi dan balok pelana mengarahkan mata ke ottoman serta jendela lengkung bercahaya di ujung.

**Shot 06 · Bathroom · 19.87s**

> Dari dekat ambang pada tinggi dada-mata, pandangan wide sedikit serong menuju jendela belakang dengan sedikit arah turun. Vanity di kanan depan, tub di bawah jendela dan toilet serta pohon di sisi kanan membentuk lapisan ruang; sinar jendela menerangi ubin lantai.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Exterior

**Time:** 0.00–5.30s · **Duration:** 5.30s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Rumah satu lantai dengan massa mendatar dan volume pintu maju beratap pelana rendah. Bidang dinding krem halus, lis dan ujung kasau bernuansa kayu, genteng lengkung kecokelatan serta cerobong putih. Pintu kayu berkaca dengan karangan daun, jendela grid hitam dan shutter gelap, tiga lentera hitam di muka pintu. Akses melalui jalan setapak batu tak beraturan ke undakan/teras dangkal.

**Furnitur & dekorasi**

> Pot terakota dan pot bermotif berisi semak tegak mengapit pintu; kotak bunga di bawah jendela, tanaman berbunga merah dan putih di tepi jalan.

**Lingkungan**

> Rumput hijau terawat, pohon besar dekat kanan, tajuk menggantung dan pepohonan keemasan di belakang, pagar kayu di kanan. Matahari siang menghasilkan bayangan tajuk di halaman.

#### **B. Framing & Lighting**

- **Fokus:** Pintu kayu dan pelana muka
- **Camera Start:** Di halaman depan sebelum jalan setapak; Ke fasad dan pintu depan, agak dari sisi kanan; Wide tiga perempat ringan
- **Framing:** Wide rumah dan taman dengan jalan setapak diagonal → Medium dekat pintu dan teras dangkal
- **Lighting:** Matahari hangat dengan bayangan pepohonan

#### **C. Camera Movement**

Kamera maju menuju pintu depan; halaman dan pohon dekat keluar dari bingkai saat detail fasad membesar.

**Tempo:** Awal lembut, perpindahan layar kian besar saat mendekati pintu; tempo keseluruhan sedang.

**Camera:** Dolly-In (~2.1×).

---

<a id="shot-02"></a>

### Shot 02 · Living Room

**Time:** 5.30–8.37s · **Duration:** 3.07s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding krem dengan ceruk lengkung dangkal untuk TV, pilaster dekat kanan, lis plafon putih dan balok kayu melintang. Lantai papan warna kayu; bukaan kaca grid hitam tinggi di kiri dengan tirai krem panjang. Downlight bulat dan lentera dinding hitam mengapit ceruk.

**Furnitur & dekorasi**

> Sofa krem berlengan gulung di kanan menghadap area meja dan TV, bantal bermotif gelap dan polos. Meja kopi persegi panjang kayu dengan rak bawah, buku, vas bunga jingga; karpet pola klasik terang. Konsol TV kayu dengan rak tengah dan pintu samping, kursi aksen dekat jendela, keranjang anyam di samping sofa serta pohon pot.

**Lingkungan**

> Melalui kaca kiri terlihat rumput dan bunga taman; cahaya matahari berpola grid jatuh pada lantai dan karpet.

#### **B. Framing & Lighting**

- **Fokus:** Ceruk TV dan konsol kayu
- **Camera Start:** Di samping belakang sofa kanan, dekat area duduk; Ke ceruk TV pada dinding depan; Serong dari kanan area duduk
- **Framing:** Medium wide ceruk TV dengan sofa besar di kanan → Wide ruang duduk dengan bukaan kiri
- **Lighting:** Cahaya taman dari kiri dan downlight hangat

#### **C. Camera Movement**

Kamera mundur sambil mengarahkan pandangan ke kiri; meja kopi, kursi dan bukaan taman terbuka sementara sofa dan ceruk TV mengecil.

**Tempo:** Perubahan framing sedang, melandai menjelang akhir.

**Camera:** Dolly-Out (~1.5×) + Pan Left (Ease-Out).

---

<a id="shot-03"></a>

### Shot 03 · Kitchen

**Time:** 8.37–11.53s · **Duration:** 3.17s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dapur dengan kabinet panel recessed warna krem hingga plafon, susunan counter sudut/L yang terlihat dan island terpisah di kiri. Permukaan counter serta backsplash batu terang bermotif halus, lantai papan kayu. Jendela lengkung grid hitam di ujung, kusen dinding bertekstur batu dekat kanan awal. Downlight, pendant silinder dan pencahayaan bawah kabinet.

**Furnitur & dekorasi**

> Range gas dan oven stainless di sisi kanan dengan hood cerobong stainless, panci putih di kompor, faucet tinggi gelap pada counter, dua rak terbuka kayu di kanan berisi pot tanaman dan mangkuk. Island top terang dengan stool kayu bundar, talenan dan keranjang; buah jingga dalam mangkuk, papan potong dan wadah alat masak. Runner anyam di lorong.

**Lingkungan**

> Cahaya dari jendela ujung dengan bunga merah dan vegetasi tampak; lampu kerja membuat backsplash hangat.

#### **B. Framing & Lighting**

- **Fokus:** Range dan hood stainless
- **Camera Start:** Di ambang dapur, di belakang island; Serong ke kanan sepanjang lorong kabinet menuju jendela dan range; Wide oblique
- **Framing:** Wide dapur dengan island dan jendela ujung → Medium dekat area kompor dan hood
- **Lighting:** Downlight, pendant, lampu bawah kabinet dan cahaya jendela

#### **C. Camera Movement**

Kamera maju dari ambang dapur sekaligus menyapu ke kanan menuju kompor dan hood; island dan jendela bergeser keluar ke kiri.

**Tempo:** Gerak sedang dan cukup berkesinambungan menuju bidang kerja.

**Camera:** Dolly-In (~1.6×) + Pan Right.

---

<a id="shot-04"></a>

### Shot 04 · Bedroom

**Time:** 11.53–14.57s · **Duration:** 3.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding aksen abu-hijau lembut, jendela lengkung tinggi bergrid hitam tepat di atas kepala ranjang dengan tirai krem panjang. Plafon putih dengan balok kayu terbuka; lantai bernuansa kayu dan karpet krem. Sconce hitam hangat di kedua sisi bukaan dan lampu gantung kerangka lentera.

**Furnitur & dekorasi**

> Ranjang double dengan headboard kayu rendah dan linen putih berlapis, selimut rajut/bertekstur dan bantal aksen rust. Nightstand kayu berlaci di kanan dan kiri, vas bunga di kanan, lampu meja putih di kiri. Kursi aksen krem dan pohon pot di sudut kiri, tepi furnitur kayu terlihat di foreground akhir.

**Lingkungan**

> Vegetasi hijau dan bunga merah di luar jendela; cahaya siang bercampur lampu hangat di sisi ranjang.

#### **B. Framing & Lighting**

- **Fokus:** Jendela lengkung di atas ranjang
- **Camera Start:** Dekat sisi kanan/kaki ranjang; Serong ke kepala ranjang dan jendela; Medium oblique
- **Framing:** Medium dekat kepala ranjang dan jendela → Wide ranjang, nightstand dan sudut kiri
- **Lighting:** Cahaya jendela, sconce dan lampu meja hangat

#### **C. Camera Movement**

Kamera mundur sambil membuka pandangan ke kiri; ranjang terlihat lebih utuh bersama nightstand, kursi dan balok plafon.

**Tempo:** Tempo sedang, reveal melandai pada framing wide akhir.

**Camera:** Dolly-Out (~1.4×) + Pan Left (Ease-Out).

---

<a id="shot-05"></a>

### Shot 05 · Walk-in Closet

**Time:** 14.57–17.10s · **Duration:** 2.53s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang ganti memanjang dengan plafon pelana terbuka, balok/rafter kayu dan bidang putih di antaranya. Bukaan lengkung grid hitam dengan ceruk tebal di dinding ujung, ambang gelap di depan awal. Sistem kabinet terbuka di kedua sisi menyisakan lorong tengah; lantai kayu terang dan lampu sorot kecil.

**Furnitur & dekorasi**

> Gantungan pakaian bertingkat, rak atas dengan keranjang anyam dan kotak, laci kayu bertarikan gelap di sisi kanan, rak/counter dan dekor tanaman. Ottoman kotak berlapis krem di tengah dekat jendela, rug terang, pot bunga putih dekat ujung kanan.

**Lingkungan**

> Bukaan ujung memperlihatkan bunga merah-jingga dan bagian bangunan luar; cahaya siang masuk ke lorong.

#### **B. Framing & Lighting**

- **Fokus:** Jendela lengkung ujung lorong
- **Camera Start:** Di luar atau tepat di ambang ruang ganti; Sepanjang sumbu lorong ke jendela ujung; Wide hampir frontal
- **Framing:** Wide lorong utuh dibingkai ambang → Medium dekat jendela dan rak ujung
- **Lighting:** Cahaya ujung dan sorot plafon hangat

#### **C. Camera Movement**

Kamera maju lurus melewati ambang menuju jendela ujung; rak dan pakaian kedua sisi terbuka lalu terpotong di tepi bingkai.

**Tempo:** Tempo sedang, gerak kontinu di lorong.

**Camera:** Straight Dolly-In (~1.5×).

---

<a id="shot-06"></a>

### Shot 06 · Bathroom

**Time:** 17.10–19.90s · **Duration:** 2.80s

![Kolase Shot 06](media/shot-06.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding putih-krem dengan jendela persegi grid hitam berpasangan di ujung, tirai krem dan balok kayu plafon. Ceruk lengkung kanan dengan ubin kecil abu-hijau pada bagian bawah, dinding terang dan lantai ubin kotak warna tanah. Bukaan pintu membingkai akhir; sconce hitam dan downlight.

**Furnitur & dekorasi**

> Bathtub freestanding putih oval di bawah jendela dengan faucet dinding hitam, tray dan botol amber. Toilet putih di kanan tub dekat pohon pot tinggi; vanity kayu berpintu panel dan laci pada dinding kanan dengan wastafel putih berbentuk mangkuk, keran hitam serta cermin lengkung berbingkai gelap. Keranjang anyam berisi tekstil/daun di kiri tub, keset terang di lantai.

**Lingkungan**

> Bunga jingga-merah, tanaman pot di ambang dan vegetasi luar terlihat lewat jendela; cahaya siang kuat jatuh ke lantai.

#### **B. Framing & Lighting**

- **Fokus:** Jendela dan bathtub freestanding
- **Camera Start:** Di dalam kamar mandi dekat bathtub dan toilet; Ke jendela belakang dan sudut ceruk kanan; Medium serong ringan
- **Framing:** Medium dekat tub, pohon dan jendela → Wide dari dekat ambang dengan tub dan vanity
- **Lighting:** Cahaya siang jendela, sconce hangat dan downlight

#### **C. Camera Movement**

Kamera mundur agak menyamping dari dekat bathtub dan pohon pot, membuka toilet, vanity kanan, lantai serta ambang pintu.

**Tempo:** Tempo sedang dengan perubahan framing lebih kecil mendekati akhir.

**Camera:** Diagonal Dolly-Out (~1.5×).
