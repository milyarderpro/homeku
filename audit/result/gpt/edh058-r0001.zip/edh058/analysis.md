# edh058 — Garden Cottage with Warm Country Interiors

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Garden Cottage with Warm Country Interiors
- **Gaya utama:** **Country Cottage**
- **Pengaruh gaya:** English Cottage; Mediterranean Revival
- **Gaya interior:** Modern Country
- **Ciri khas:** Atap genteng melengkung di atas fasad gable rendah dengan lantern hitam dan jalan batu melengkung di taman berbunga.; Jendela lengkung berkisi gelap berulang di kitchen, bedroom dan closet, dengan kabinet kayu hangat, penyimpanan terbuka, balok plafon dan pencahayaan kuning lembut.
- **Warna & material:** Krem gading, putih hangat, kayu madu, aksen hitam, terakota, hijau daun serta warna bunga rust/merah muda.
- **Suasana dan lingkungan:** Cottage taman yang ramah dan intim dengan cahaya alami terang, bunga rapat, interior natural yang hangat dan rapi; geografi dan hubungan antar-ruang belum terverifikasi.

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Eksterior menampakkan cottage satu lantai bermassa rendah dengan gable depan dan perpanjangan kiri, bukan blok bertingkat tinggi. |
| **Lantai & bentuk atap** | Satu tingkat terlihat pada fasad; jumlah lantai aktual tidak bisa diverifikasi dari montage interior. |
| **Tapak bangunan** | Massa depan kompak dengan serambi masuk dangkal; bidang lain, kedalaman bangunan dan hubungan closet/bathroom tidak ditampilkan. |
| **Proporsi utama** | Fasad horizontal rendah, gable berukuran kecil dan bukaan vertikal teratur; di dalam, ceiling cukup tinggi dengan balok dekoratif. |
| **Perkiraan luas lantai** | **60–105 m²** |

## 3. Shot Timeline

Enam take kontinu dengan hard cut antar exterior, living room, kitchen, bedroom, walk-in closet dan bathroom; tidak ada jalan kamera yang terlihat menghubungkan ruang antarshot. Arah gerak dinilai dari frame native, bukan default produksi reverse atau durasi baku.

**Camera Pattern:** IN – OUT – IN – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–5.30 | 5.30s | Exterior / Front Garden | Dolly-In ~2.9× |
| 02 | 5.30–8.37 | 3.07s | Living Room | Dolly-Out ~1.3× + Pan Left |
| 03 | 8.37–11.53 | 3.17s | Kitchen | Dolly-In ~2.0× + Pan Right |
| 04 | 11.53–14.57 | 3.03s | Bedroom | Dolly-Out ~1.5× + Pan Left |
| 05 | 14.57–17.10 | 2.53s | Walk-in Closet | Dolly-In ~1.6× |
| 06 | 17.10–19.90 | 2.80s | Bathroom | Dolly-Out ~1.7× + Pan Right |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Exterior / Front Garden · 0.00s**

> Pada awal sudut tiga-perempat ringan dari jalan taman menuju rumah, arah pandang kurang lebih ke pintu; tinggi setara mata dan hampir horizontal, atap gable, jalur batu, rumput, bunga, batang pohon dan cahaya pagi/siang terbaca dalam satu komposisi wide.

**Shot 02 · Living Room · 8.33s**

> Overview F250 berada pada cakupan ruang lebar dari sisi sofa, arah menyilang ke dinding TV dan jendela kiri, kira-kira tinggi mata. Sofa kanan, meja pusat, armchair dekat bukaan, karpet dan console TV membentuk lapisan kedalaman; cahaya jendela memercik di karpet.

**Shot 03 · Kitchen · 8.37s**

> Pada Overview F251 terlihat kitchen lebar dari posisi depan dan sedikit miring: peninsula/stool memimpin foreground kiri, sink+jendela arched menjadi latar tengah, deret range/hood di kanan; pencahayaan campuran alami dan hangat menegaskan permukaan terang.

**Shot 04 · Bedroom · 14.53s**

> Overview F436 memperlihatkan kamar tidur secara wide dari area kaki ranjang, menghadap kepala ranjang/jendela lengkung sedikit serong; bed di tengah dengan nightstand di kiri kanan, kursi pada sisi kiri, balok plafon di atas, dan cahaya jendela plus lampu hangat.

**Shot 05 · Walk-in Closet · 14.57s**

> Overview F437 memakai pandangan wide hampir aksial dari mulut lorong walk-in closet setinggi mata: rak, gantungan dan laci mengapit tengah, balok pelana atap memandu ke jendela arched kecil di ujung; runner/ottoman bawah dan campuran cahaya window serta rak terbaca jelas.

**Shot 06 · Bathroom · 19.87s**

> Overview F596 dari posisi lebih jauh di depan pintu atau sisi luar kamar mandi, tinggi kira-kira mata dan sedikit menghadap kanan: jendela hitam di atas tub di kiri, toilet tengah, vanity vessel+mirror di kanan, lantai terang/basket foreground, niche tanaman dan wall light pada dinding kanan.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Exterior / Front Garden

**Time:** 0.00–5.30s · **Duration:** 5.30s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Massa cottage satu lantai berfasad krem tampak stucco/plester; satu gable depan menonjol di atas pintu masuk dan sayap kiri lebih rendah. Atap miring bertutup genteng melengkung warna tanah dengan cerobong kecil di belakang. Pintu kayu bernada madu memiliki bidang kaca dan karangan daun; jendela persegi berbingkai gelap serta daun shutter hitam di sisi kiri. Dua lantern dinding mengapit pintu; undakan/teras masuk sangat dangkal menyambung jalan setapak batu berpola tidak beraturan.

**Furnitur & dekorasi**

> Pintu berhias wreath dedaunan. Pot tanah liat dan pot keramik bermotif berpola gelap menahan konifer kecil dan tanaman hijau di kiri-kanan ambang. Lampu dinding hitam berbentuk lentera berpasangan; planter box di bawah jendela kiri dengan bunga dan tanaman rimbun.

**Lingkungan**

> Taman terawat dengan hamparan rumput hijau, jalan batu berbelok, bedeng bunga putih dan jingga-merah, pohon tinggi berdaun rindang dan satu batang besar di tepi kanan. Tampak pagar kayu batas tapak dan secuil bangunan di balik vegetasi, tanpa lokasi geografis yang teridentifikasi. Cahaya matahari siang mencetak bayangan di rumput dan ubin.

#### **B. Framing & Lighting**

- **Fokus:** Fasad depan dan pintu masuk berpenerang lantern.
- **Camera Start:** Dari tepi taman di depan agak menyudut ke fasad, kamera setinggi pandangan manusia menatap gable tengah; halaman rumput dan jalan batu mengisi foreground, batang pohon besar di kanan, seluruh massa mungil dan sayap kiri terlihat.; Arah pandang awal ke fasad depan dan pintu masuk berpenerang lantern.; Satu pandangan perspektif interior/eksterior; sudut kira-kira tiga-perempat ringan atau aksial sesuai objek, bukan sudut geometri terkalibrasi.
- **Framing:** Dari tepi taman di depan agak menyudut ke fasad, kamera setinggi pandangan manusia menatap gable tengah; halaman rumput dan jalan batu mengisi foreground, batang pohon besar di kanan, seluruh massa mungil dan sayap kiri terlihat. → Kamera kini dekat ambang depan, bidang pintu kayu dan lampu-lampu fasad menguasai tengah; sisi kiri bangunan, sebagian pepohonan dan hamparan rumput telah keluar frame.
- **Lighting:** Matahari hangat menerangi dinding krem dan taman; shadow pohon tampak jelas.

#### **C. Camera Movement**

Kamera bergerak mendekat langsung ke fasad dan pintu depan; pintu dan lampu tampak semakin besar sementara taman lebar menyempit. Rotasi atau geser samping yang terpisah tidak terbukti cukup kuat.

**Tempo:** Gerakan masuk mulus berkecepatan sedang, relatif konstan pada interval waktu sebanding; tidak ada bukti akselerasi fisik khusus.

**Camera:** Dolly-In ~2.9×

---

<a id="shot-02"></a>

### Shot 02 · Living Room

**Time:** 5.30–8.37s · **Duration:** 3.07s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang duduk beratap krem dengan crown moulding, downlight tanam dan balok kayu terlihat di bagian atas saat frame melebar. Ceruk lengkung dangkal di dinding memuat layar televisi besar; dua lampu dinding hitam di kedua sisi ceruk. Di kiri terbuka jendela/pintu kaca hitam berkisi dengan tirai panjang warna gading; papan lantai tampak berwarna kayu hangat.

**Furnitur & dekorasi**

> Sofa tiga-dudukan berlapis kain putih krem berada di kanan foreground, diberi bantal krem dan motif bintik. Meja kopi kayu persegi panjang berkaki kokoh di atas karpet motif pucat membawa vas bunga berwarna tembaga/jingga dan tumpukan buku. Kabinet TV kayu rendah dengan kompartemen terbuka dan keranjang di bawah layar; di dekat bukaan kiri kursi duduk berwarna terang dengan bantal terracotta, pohon berdaun kecil, serta keranjang anyam di lantai depan.

**Lingkungan**

> Cahaya alami masuk melalui bukaan kaca kisi di kiri dan membentuk petak terang pada karpet/lantai. Lewat kaca terlihat tanaman berbunga di luar; lokasi dan hubungan langsung dengan taman shot pertama belum pasti. Lampu plafon dan wall lantern menambah lapisan hangat.

#### **B. Framing & Lighting**

- **Fokus:** Ceruk televisi, sofa, meja dan bukaan kaca berkisi.
- **Camera Start:** Dari sisi dekat sofa menghadap ceruk televisi pada dinding depan. Bagian belakang sofa mengisi kanan foreground, kabinet TV mendominasi tengah-kiri, sementara sisi kiri ruangan serta bukaan luar belum utuh terlihat.; Arah pandang awal ke ceruk televisi, sofa, meja dan bukaan kaca berkisi.; Sedikit oblique dari sisi foreground menuju dinding/jendela area.
- **Framing:** Dari sisi dekat sofa menghadap ceruk televisi pada dinding depan. Bagian belakang sofa mengisi kanan foreground, kabinet TV mendominasi tengah-kiri, sementara sisi kiri ruangan serta bukaan luar belum utuh terlihat. → Dari titik yang tampak lebih mundur dan mengarah lebih ke kiri; jendela/pintu kaca berkisi, kursi dekatnya, meja kopi, karpet luas, sofa dan lemari TV kini bersama-sama terlihat sebagai komposisi wide.
- **Lighting:** Sinar jendela kuat jatuh di rug, disertai downlight dan wall lantern bergaya hangat.

#### **C. Camera Movement**

Kamera mundur sambil mengalihkan pandangan ke kiri; sofa dan detail TV mengecil, lalu jendela berkisi dan meja kopi lengkap tersingkap. Gerak mundur dan putaran kiri terjadi bersamaan.

**Tempo:** Moderate, halus dan relatif merata tanpa jeda atau peningkatan tempo yang pasti.

**Camera:** Dolly-Out ~1.3× + Pan Left

---

<a id="shot-03"></a>

### Shot 03 · Kitchen

**Time:** 8.37–11.53s · **Duration:** 3.17s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Kitchen memanjang berbentuk L/U tampak dari area masuk, dengan kabinet shaker berwarna gading tinggi di dinding belakang dan kanan. Jendela lengkung berkisi hitam berada di atas sink apron depan, countertop berpenampilan batu muda. Kompor/range logam besar dengan oven dan cooker hood stainless pada sisi kanan, backsplash bertekstur batu warna lembut, rak melayang kayu terbuka di kanan, serta downlight dan dua pendant silinder dekat island.

**Furnitur & dekorasi**

> Island atau peninsula sempit dengan permukaan terang dan dua bangku kayu bundar di sisi dekat; faucet lengkung warna tembaga/bronze di atas sink putih. Range dengan panci bertutup putih; bowl jeruk oranye pada countertop kanan. Toples, papan kayu, baki kecil, pot tanaman serta wadah perkakas masak di counter; kabinet banyak laci dan pintu dengan hardware hitam tipis. Lantai papan kayu hangat diberi runner tenun pucat.

**Lingkungan**

> Sinar siang masuk melalui jendela lengkung hitam dengan bunga merah di luar, berbaur cahaya pendant/downlight serta lampu hangat bawah hood di atas backsplash. Pemandangan melalui jendela terbatas vegetasi, tidak membuktikan orientasi ruangan terhadap shot lainnya.

#### **B. Framing & Lighting**

- **Fokus:** Zona kompor stainless, hood, kabinet shaker dan sink.
- **Camera Start:** Dari ambang terbuka di depan kitchen, diagonal menghadap deret kabinet kanan; island dan bangku berada di kiri depan, jendela lengkung belakang-kiri, kompor serta hood berada di kanan tengah pada sudut tiga-perempat.; Arah pandang awal ke zona kompor stainless, hood, kabinet shaker dan sink.; Satu pandangan perspektif interior/eksterior; sudut kira-kira tiga-perempat ringan atau aksial sesuai objek, bukan sudut geometri terkalibrasi.
- **Framing:** Dari ambang terbuka di depan kitchen, diagonal menghadap deret kabinet kanan; island dan bangku berada di kiri depan, jendela lengkung belakang-kiri, kompor serta hood berada di kanan tengah pada sudut tiga-perempat. → Kamera dekat deret kanan sehingga kompor stainless, permukaan counter, hood dan rak melayang mengisi hampir seluruh bidang; island dan jendela sebagian telah hilang ke kiri.
- **Lighting:** Lampu hangat dari under-hood/spot backsplash, downlight plafon dan siang jendela berbaur.

#### **C. Camera Movement**

Kamera mendekat sambil mengarah ke kanan menuju kompor. Island dan jendela lengkung menyusut cakupannya lalu terpotong di kiri; range, hood, kabinet dan mangkuk buah diperbesar serentak.

**Tempo:** Gerak masuk sedang dan mulus, tanpa titik hentian/fase arah baru yang meyakinkan.

**Camera:** Dolly-In ~2.0× + Pan Right

---

<a id="shot-04"></a>

### Shot 04 · Bedroom

**Time:** 11.53–14.57s · **Duration:** 3.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar tidur hangat dengan satu tempat tidur utama di bawah jendela lengkung berkusen hitam dan muntins, tepat di belakang sandaran ranjang. Tirai gading panjang pada batang hitam, balok kayu dekoratif melintasi plafon, pendant berlindung kerangka bertekstur terlihat pada frame lebar; dua sconce hitam mengapit area kepala ranjang. Lantai tampak kayu terang dan permadani lembut krem di sisi bawah.

**Furnitur & dekorasi**

> Tempat tidur kayu untuk dua orang dengan headboard panel, selimut/quilt krem bertekstur dan bantal gading dengan satu bantal aksen bata/rust. Dua nightstand laci kayu di kiri/kanan, lampu meja berkap putih pada meja kiri, vas bunga krem/peach di meja kanan. Jendela di atas kepala ranjang dipenuhi pot bunga merah muda pada sill. Pada wide kiri terlihat kursi berlapis kain, tanaman pot besar dan meja/ujung bangku kayu dekat footboard.

**Lingkungan**

> Jendela busur menghadap rimbunan hijau terang, pot bunga merah muda mengisi ambang. Pencahayaan lembut kuning dari lampu meja dan sconce ditambah daylight dominan dari bukaan belakang ranjang.

#### **B. Framing & Lighting**

- **Fokus:** Tempat tidur dan jendela arched sebagai sumbu visual.
- **Camera Start:** Kamera sangat dekat sisi kanan kaki tempat tidur, memandang headboard dan jendela lengkung di atasnya. Bantal besar, tekstur quilt dan nakas kanan menempati sebagian besar frame; cakupan sisi kiri masih sempit.; Arah pandang awal ke tempat tidur dan jendela arched sebagai sumbu visual.; Sedikit oblique dari sisi foreground menuju dinding/jendela area.
- **Framing:** Kamera sangat dekat sisi kanan kaki tempat tidur, memandang headboard dan jendela lengkung di atasnya. Bantal besar, tekstur quilt dan nakas kanan menempati sebagian besar frame; cakupan sisi kiri masih sempit. → Dari belakang dan sedikit ke kiri tampak bed lengkap dengan footboard kayu, kedua nakas, chair/plant di kiri, tirai dan balok plafon; jendela di belakang ranjang lebih kecil dan menjadi pusat wide.
- **Lighting:** Daylight dari jendela belakang tempat tidur dan lampu samping dengan warna hangat.

#### **C. Camera Movement**

Kamera menjauh sambil menyapu pandangan agak ke kiri; dari close-up bantal dan jendela menuju seluruh ranjang, kedua nakas, area kursi serta balok plafon.

**Tempo:** Sedang, mulus dan stabil; perubahan cakupan datang dari lintasan, bukan pergantian shot.

**Camera:** Dolly-Out ~1.5× + Pan Left

---

<a id="shot-05"></a>

### Shot 05 · Walk-in Closet

**Time:** 14.57–17.10s · **Duration:** 2.53s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang walk-in closet panjang seperti lorong dengan rak built-in dan batang gantungan di kedua sisi. Langit-langit pelana miring menampilkan beberapa balok/rafter kayu terbuka mengikuti bubungan ke arah jendela akhir. Pada dinding ujung ada jendela berkepala lengkung hitam. Sisi kiri berderet rak terbuka bertingkat; sisi kanan mempunyai kabinet laci kayu, cubbies dan rak atas dengan strip cahaya di bawahnya.

**Furnitur & dekorasi**

> Koleksi baju digantung secara terbuka di kiri dan kanan pada rel hitam; laci kayu warna madu berpegangan gelap di bawah beberapa rel. Keranjang anyaman persegi mengisi rak atas. Stool/ottoman persegi kulit/kain gading berada dekat jendela, dengan runner anyam netral di tengah jalur. Pot bunga putih dan vas di sisi jendela serta beberapa pajangan pada rak.

**Lingkungan**

> Jendela ujung menghadap tanaman bunga jingga-merah dan pot pada sill; sumber terang dari jendela sekaligus lampu recessed plafon dan lampu rak menghangatkan kabinet. Hubungan pintu closet dengan kamar tidur sebelumnya tidak terlihat.

#### **B. Framing & Lighting**

- **Fokus:** Jendela arched di ujung, sumbu corridor dan storage built-in.
- **Camera Start:** Dari pintu/celah lorong closet di tengah, kamera setinggi mata mengarah sepanjang axis simetris menuju jendela ujung. Rel pakaian, kabinet kanan/kiri dan balok atap nampak memanjang, ottoman dan runner menjadi layer bawah.; Arah pandang awal ke jendela arched di ujung, sumbu corridor dan storage built-in.; Hampir aksial mengikuti lorong closet.
- **Framing:** Dari pintu/celah lorong closet di tengah, kamera setinggi mata mengarah sepanjang axis simetris menuju jendela ujung. Rel pakaian, kabinet kanan/kiri dan balok atap nampak memanjang, ottoman dan runner menjadi layer bawah. → Kamera lebih dekat ke jendela dan area penyimpanan ujung: lemari sisi kanan serta pakaian kiri menjadi lebih besar dan terpotong; jendela arched dan bunga memenuhi tengah.
- **Lighting:** Downlight plafon dan LED rak berwarna hangat, cahaya alami pada jendela belakang.

#### **C. Camera Movement**

Kamera maju lurus menyusuri walk-in closet menuju jendela lengkung dan ottoman. Lemari, gantungan serta rel di kiri-kanan membesar, sedangkan jendela tetap sekitar sumbu tengah.

**Tempo:** Moderate dan konstan dengan pergeseran halus; tidak diperlukan fase arah baru.

**Camera:** Dolly-In ~1.6×

---

<a id="shot-06"></a>

### Shot 06 · Bathroom

**Time:** 17.10–19.90s · **Duration:** 2.80s

![Kolase Shot 06](media/shot-06.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi terang dengan jendela berkisi hitam besar di belakang bak mandi putih oval. Faucet/pengisi tub terpasang pada dinding di bawah jendela. Di sisi kanan bak berdiri toilet putih, dengan bidang dinding sebagian berlapis ubin mosaik kecil berwarna pucat. Ceruk dinding berkepala lengkung berisi rak dan tanaman; balok kayu dekoratif terlihat pada plafon. Pada kanan foreground ada vanity/laci kayu bernada hangat dengan basin/vessel putih dan keran hitam, mirror berbingkai gelap serta lampu dinding hangat.

**Furnitur & dekorasi**

> Bak oval berdiri sendiri dengan bath tray kayu kecil berisi botol dan item mandi. Toilet putih di kanan bak, tanaman mirip pohon zaitun dalam pot putih berdiri antara bak dan niche, pot kecil di jendela. Vanity kayu berpintu/laci berkepala hitam, wastafel vessel putih dan keran hitam; handuk krem menggantung dari ring di bawah wall light, cermin gelap membingkai area wastafel. Keranjang anyam dengan handuk serta tanaman hijau di foreground kiri.

**Lingkungan**

> Jendela hitam berkisi menampilkan bunga jingga/merah di luar dan atap bangunan seberang yang tampak sekilas. Tirai putih lembut, lantai ubin kotak bernuansa krem-terakota dan cahaya alami terang dipadu wall sconce menegaskan material warm-neutral; identitas lokasi tidak dapat dipastikan.

#### **B. Framing & Lighting**

- **Fokus:** Bak di bawah jendela, toilet, niche dan vanity berkaca.
- **Camera Start:** Dekat bagian kiri/ujung bak mandi, kamera menatap jendela hitam, bath tray, tanaman pot besar dan sebagian toilet. Sisi kanan vanity hampir seluruhnya terpotong, sudut pandang cukup sempit.; Arah pandang awal ke bak di bawah jendela, toilet, niche dan vanity berkaca.; Sedikit oblique dari sisi foreground menuju dinding/jendela area.
- **Framing:** Dekat bagian kiri/ujung bak mandi, kamera menatap jendela hitam, bath tray, tanaman pot besar dan sebagian toilet. Sisi kanan vanity hampir seluruhnya terpotong, sudut pandang cukup sempit. → Kamera sekarang lebih mundur dan pandangannya bergeser ke kanan: bak oval lengkap, toilet, ruang ubin lantai, basket, niche, vanity kayu dengan basin vessel, cermin serta lampu dinding tampak sekaligus dalam wide.
- **Lighting:** Matahari melalui jendela besar, wall light warm di samping mirror, dan satu downlight plafon.

#### **C. Camera Movement**

Kamera mundur sambil menyapu pandangan ke kanan: mulanya dekat bak dan pohon pot, lalu bak dan toilet mengecil serta vanity, wastafel dan cermin kanan menjadi jelas. Kedua gerak terjadi bersamaan.

**Tempo:** Gerak sedang stabil dengan reveal berkelanjutan, tanpa penghentian atau lonjakan tempo yang dapat dipastikan.

**Camera:** Dolly-Out ~1.7× + Pan Right
