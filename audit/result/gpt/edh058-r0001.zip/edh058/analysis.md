# edh058 — Garden Cottage dengan interior hangat

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Garden Cottage dengan interior hangat
- **Gaya utama:** **European Cottage**
- **Pengaruh gaya:** French Country; English Cottage
- **Gaya interior:** Rustic Cottage
- **Ciri khas:** Fasad plester krem beratap pelana dengan genteng bernuansa tanah, pintu kayu berkaca, shutter hitam dan lampu lantern; Jendela lengkung berbingkai hitam, lemari panel krem, aksen balok kayu serta penyimpanan built-in; Kebun bunga, tanaman pot, lantai tampak kayu dan tekstil putih-krem dengan warna terracotta
- **Warna & material:** Krem hangat, putih gading, kayu cokelat alami, hitam pada bingkai dan logam, aksen hijau tanaman serta merah-jingga bunga.
- **Suasana dan lingkungan:** Rumah skala kecil yang terasa intim dan cerah, dengan taman rimbun berbunga serta interior berlapis tekstil lembut dan cahaya siang.

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Tampak satu massa utama rendah ber-atap pelana dengan bagian samping yang melebar ke kiri; tidak ada bukti massa belakang. |
| **Lantai & bentuk atap** | Satu lantai teramati pada eksterior; tidak terlihat tangga atau lantai atas, tetapi keberadaannya di balik frame tidak dapat dipastikan. |
| **Tapak bangunan** | Tapak tampak kompak dan memanjang; ruang dalam yang ditampilkan melalui cut tidak cukup untuk membuat denah terverifikasi. |
| **Proporsi utama** | Fasad lebih lebar daripada tinggi dinding; bukaan pintu dan jendela kecil–menengah; ruang interior tampak sempit hingga sedang. |
| **Perkiraan luas lantai** | **55–105 m²** |

## 3. Shot Timeline

Enam take kontinu dipisahkan lima hard cut: 5,30 s; 8,37 s; 11,53 s; 14,57 s; 17,10 s. Urutan penyuntingan bukan rute fisik yang terbukti.

**Camera Pattern:** IN – OUT – IN – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–5.30 | 5.30s | exterior | Dolly-In (~1.8–2.2×) + gentle Pan Right (~5–10°). |
| 02 | 5.30–8.37 | 3.07s | living room | Dolly-Out (~1.2–1.4×) + Pan Left (~15–25°). |
| 03 | 8.37–11.53 | 3.17s | kitchen | Dolly-In (~1.3–1.6×) + Pan Right (~10–20°). |
| 04 | 11.53–14.57 | 3.03s | bedroom | Dolly-Out (~1.2–1.4×) + Pan Left (~10–20°). |
| 05 | 14.57–17.10 | 2.53s | walk-in closet | Dolly-In (~1.1–1.3×) + gentle Pan Right (~5–15°). |
| 06 | 17.10–19.90 | 2.80s | bathroom | Dolly-Out (~1.2–1.5×) + Pan Left (~10–20°). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · exterior · 0.00s**

> Pada awal sumber, posisi wide dari taman menampilkan seluruh gable cottage, pintu tengah, jendela kiri dan kanan, jalur batu yang mengarah dari bawah kiri, pohon kanan serta hamparan rumput hijau. Pandangan hampir setinggi mata dengan tilt netral; taman memberi kedalaman berlapis dan cahaya siang kuat.

**Shot 02 · living room · 8.33s**

> Dari posisi akhir yang lebih wide di belakang sofa, pandangan menyilang ke konsol TV pada kanan serta jendela berbingkai hitam di kiri. Meja kopi, kursi samping, karpet dan lantai kayu menyusun kedalaman foreground–background; sinar siang dari jendela kuat, kamera relatif level.

**Shot 03 · kitchen · 8.37s**

> Frame awal menangkap dapur sudut secara wide dari dekat island, dengan jendela arch dan sink di belakang kiri, kabinet shaker krem dan range stainless pada kanan, stool pada foreground. Kamera setinggi mata, kemiringan datar, garis island membawa kedalaman ke sudut, campuran daylight dan task light hangat.

**Shot 04 · bedroom · 14.53s**

> Di akhir posisi kamera lebih mundur dari kaki ranjang, menyajikan komposisi hampir simetris dua nakas kayu dan ranjang berlapis putih di bawah jendela lengkung gelap. Balok plafon, tirai ivory, lampu gantung dan bunga luar terlihat; garis headboard menegaskan kedalaman dengan cahaya alami dan hangat.

**Shot 05 · walk-in closet · 14.57s**

> Dari pintu masuk yang lebar, pandangan lurus menuju jendela arch hitam pada sumbu tengah, rak pakaian terbuka simetris kiri-kanan dan balok plafon miring. Bangku krem dan karpet memandu kedalaman, tanaman luar terang dan lampu kabinet hangat; kamera setinggi mata dan hampir datar.

**Shot 06 · bathroom · 19.87s**

> Frame akhir wide dari dekat ambang memperlihatkan bathtub freestanding di bawah jendela hitam pada sisi kiri, toilet di tengah-bawah dan vanity kayu dengan basin serta cermin hitam di kanan. Pohon pot dan ceruk arched menambah layer, tile lantai tampak luas, daylight belakang bercampur lampu sconce; kamera nyaris level.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · exterior

**Time:** 0.00–5.30s · **Duration:** 5.30s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Fasad rumah satu lantai tampak plester krem dengan atap pelana bergenteng warna tanah, tepian kayu dan cerobong kecil; pintu masuk kayu dengan kaca, jendela berkisi hitam/shutter, tiga lantern hitam, teras bertangga satu tingkat.

**Furnitur & dekorasi**

> Pot terracotta dan keramik di kiri-kanan pintu, tanaman hias tegak, kotak bunga jendela dan hamparan semak berbunga merah, putih, oranye; jalur batu alam menuju ambang.

**Lingkungan**

> Halaman depan rumput hijau, pohon besar dekat sisi kanan, pepohonan tinggi kekuningan dan pagar kayu di kanan; cahaya siang terang dengan bayangan pohon.

#### **B. Framing & Lighting**

- **Fokus:** pintu kayu dan garis atap rumah
- **Camera Start:** Dari halaman rumput, relatif jauh dari cottage; Menghadap fasad depan sedikit serong dari kiri; Wide, mencakup rumah, jalur batu dan taman
- **Framing:** Kamera di halaman rumput cukup jauh, menghadap fasad depan serong ringan dari kiri pada ketinggian mata, sudut wide, hampir level. → Di akhir kamera jauh lebih dekat ke pintu, crop fasad depan mengutamakan entrance dan lantern; pohon depan sebagian keluar frame.
- **Lighting:** Terang alami dengan highlight pada dinding krem dan bayangan dedaunan.

#### **C. Camera Movement**

Kamera mendekat sambil sedikit memutar pandangan ke kanan, mempertahankan fokus pada pintu kayu dan garis atap rumah. Pendekatan ke pintu membuat detail panel kayu, lantern, pot dan tepi atap semakin jelas.

**Tempo:** Dorongan masuk stabil berkisar sedang, lebih terasa cepat di akhir karena jarak ke fasad berkurang.

**Camera:** Dolly-In (~1.8–2.2×) + gentle Pan Right (~5–10°).

---

<a id="shot-02"></a>

### Shot 02 · living room

**Time:** 5.30–8.37s · **Duration:** 3.07s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding krem dan plafon dengan lis sederhana serta downlight; ceruk TV berbentuk arch pada dinding seberang, jendela besar berbingkai gelap dan tirai panjang di kiri; lantai papan tampak kayu.

**Furnitur & dekorasi**

> Sofa upholstered krem menghadap konsol TV kayu, cushion bermotif kecil, meja kopi persegi panjang berkaki kayu dengan buku serta vas bunga jingga, kursi samping dan karpet motif pucat; lampu lantern dinding di ceruk.

**Lingkungan**

> Cahaya siang masuk dari jendela kiri memperlihatkan tanaman dan bunga luar; pohon hias di dekat kursi dan vas dekoratif dalam ruangan.

#### **B. Framing & Lighting**

- **Fokus:** TV pada ceruk, sofa dan jendela samping
- **Camera Start:** Dekat sisi-belakang sofa krem; Menghadap ceruk TV di seberang sofa; Medium-wide dengan sofa dominan di kanan depan
- **Framing:** Kamera berada dekat belakang/sisi sofa krem, memandang serong TV dalam ceruk di tengah, tinggi sekitar mata atau sedikit di atas sandaran, hampir horizontal. → Frame akhir lebih luas: sofa, coffee table, jendela tinggi kiri dan kursi samping terbaca bersama ceruk TV di kanan.
- **Lighting:** Cahaya siang bercak di lantai/karpet, dilengkapi downlight plafon; keseluruhan hangat.

#### **C. Camera Movement**

Kamera mundur sambil sedikit memutar pandangan ke kiri, mempertahankan fokus pada TV pada ceruk, sofa dan jendela samping. Mundur sambil menoleh kiri membuka jendela, kursi, bunga meja dan sebagian ruang yang tadinya tertutup sofa.

**Tempo:** Laju perubahan framing tampak konstan dan sedang, bukan akselerasi yang terverifikasi.

**Camera:** Dolly-Out (~1.2–1.4×) + Pan Left (~15–25°).

---

<a id="shot-03"></a>

### Shot 03 · kitchen

**Time:** 8.37–11.53s · **Duration:** 3.17s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dapur berbentuk L tampak dengan kabinet shaker warna krem sampai mendekati plafon, jendela lengkung hitam di belakang bak cuci, backsplash terang bermotif halus, downlight, hood stainless, beberapa ambalan kayu dan lantai tampak papan kayu.

**Furnitur & dekorasi**

> Island batu terang di kiri depan dengan dua stool kayu, sink di sisi jendela, range stainless dengan panci putih pada cooktop, lemari panel berjajar, mangkuk jeruk, utensil pot, pot tanaman dan pendant di atas island.

**Lingkungan**

> Di balik jendela lengkung terlihat hijaunya tanaman dan bunga; interior terang dari siang dan lampu titik di bawah hood.

#### **B. Framing & Lighting**

- **Fokus:** kompor/range serta hood stainless
- **Camera Start:** Di dekat sudut island pada sisi masuk dapur; Diagonal dari island kiri menuju kabinet dan kompor kanan; Wide meliputi island, jendela dan deret kerja
- **Framing:** Kamera di ambang dapur dekat sudut island, menghadap diagonal dari kiri menuju deret kabinet dan kompor di kanan pada ketinggian mata, hampir level. → Close framing pada range, hood dan kabinet kanan dengan sebagian island serta jendela kiri telah terpotong.
- **Lighting:** Downlight putih hangat dan task light hood menambah pencahayaan, bersama daylight jendela.

#### **C. Camera Movement**

Kamera mendekat sambil sedikit memutar pandangan ke kanan, mempertahankan fokus pada kompor/range serta hood stainless. Maju mendekati stove sambil berputar kanan; lingkup jendela dan island berkurang dan detail range/hood menguat.

**Tempo:** Gerak menyapu dan mendekat lancar berkategori sedang, tidak terbukti mempercepat.

**Camera:** Dolly-In (~1.3–1.6×) + Pan Right (~10–20°).

---

<a id="shot-04"></a>

### Shot 04 · bedroom

**Time:** 11.53–14.57s · **Duration:** 3.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar tidur berdinding krem dengan lis sederhana, jendela lengkung hitam besar di atas headboard kayu, tirai ivory panjang, balok kayu plafon yang terlihat pada akhir dan lampu gantung kecil.

**Furnitur & dekorasi**

> Ranjang double dengan sandaran kayu, duvet dan throw knit putih berlapis, bantal beige/terracotta, nakas kayu berlaci di kedua sisi, table lamp putih kiri, sconce logam gelap di dinding, pot bunga di nakas kanan.

**Lingkungan**

> Melalui jendela terlihat vegetasi hijau dan bunga merah muda; pencahayaan siang lembut bercampur lampu kamar bernuansa hangat.

#### **B. Framing & Lighting**

- **Fokus:** ranjang kayu dengan jendela lengkung di atasnya
- **Camera Start:** Di dekat kaki ranjang pada posisi agak ke kanan; Menghadap kepala ranjang dan jendela arch; Medium pada bedding dan jendela
- **Framing:** Kamera di dekat sisi kaki ranjang, membingkai jendela dan kepala ranjang cukup dekat, arah nyaris frontal sedikit serong, tinggi setara mata dan tilt netral. → Framing akhir melebar memperlihatkan ranjang secara lebih utuh, kedua nakas, sebagian plafon balok dan bidang lantai tepi.
- **Lighting:** Sinar jendela merata di duvet putih, diteruskan sconce dan lampu meja.

#### **C. Camera Movement**

Kamera mundur sambil sedikit memutar pandangan ke kiri, mempertahankan fokus pada ranjang kayu dengan jendela lengkung di atasnya. Mundur sedikit sambil melirik kiri membuka nakas kiri, standing plant dan balok plafon.

**Tempo:** Perubahan skala sedikit dan halus, ritme sedang-konsisten.

**Camera:** Dolly-Out (~1.2–1.4×) + Pan Left (~10–20°).

---

<a id="shot-05"></a>

### Shot 05 · walk-in closet

**Time:** 14.57–17.10s · **Duration:** 2.53s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Walk-in closet sempit memanjang dengan plafon pelana berbalok kayu tampak, jendela lengkung hitam pada dinding ujung, lis dan dinding krem, lantai terang berkarpet lari.

**Furnitur & dekorasi**

> Sistem open wardrobe kedua sisi: gantungan pakaian warna bumi pada dua tingkat, rak keranjang anyam di bagian atas, unit laci kayu kanan, bangku ottoman krem rendah tengah-depan, vas bunga putih dan storage kecil.

**Lingkungan**

> Bunga merah dan tanaman hijau tampak melalui jendela ujung; cahaya siang dan lampu kabinet menciptakan kontras hangat.

#### **B. Framing & Lighting**

- **Fokus:** jendela lengkung di ujung walk-in closet
- **Camera Start:** Di ambang walk-in closet di antara dua jajaran rak; Lurus menghadap jendela arch ujung; Wide dan sentral mengikuti sumbu koridor
- **Framing:** Kamera di ambang masuk closet, memandang lurus ke jendela ujung di antara rak gantungan, tinggi sekitar mata, hampir level. → Di akhir kamera lebih dekat ke jendela dan rak kanan, bangku depan lebih besar/terpotong oleh batas bawah.
- **Lighting:** Downlight pada plafon dan lighting rak, dengan daylight kuat di ujung.

#### **C. Camera Movement**

Kamera mendekat sambil sedikit memutar pandangan ke kanan, mempertahankan fokus pada jendela lengkung di ujung walk-in closet. Maju perlahan membuat jarak rak dan jendela memendek, menegaskan kombinasi rak terbuka dan laci.

**Tempo:** Gerak maju halus pada laju sedang tanpa perubahan fase yang perlu dipisah.

**Camera:** Dolly-In (~1.1–1.3×) + gentle Pan Right (~5–15°).

---

<a id="shot-06"></a>

### Shot 06 · bathroom

**Time:** 17.10–19.90s · **Duration:** 2.80s

![Kolase Shot 06](media/shot-06.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi memiliki dinding plaster krem, ceruk rak lengkung di kanan jendela, jendela hitam dua daun dengan tirai putih, balok kayu plafon, dinding aksen tile kecil di belakang toilet dan lantai tile terracotta terang.

**Furnitur & dekorasi**

> Bathtub freestanding oval putih di bawah jendela dengan faucet hitam dinding, WC putih di kanan bak, vanity laci kayu dengan basin putih menonjol di kanan, cermin hitam atas vanity, towel ring dengan handuk dan pohon pot tinggi.

**Lingkungan**

> Melalui jendela tampak tanaman hijau dan bunga merah serta atap bangunan lain; daylight kuat dipadukan sconce kanan yang hangat.

#### **B. Framing & Lighting**

- **Fokus:** bathtub, jendela hitam dan vanity kayu
- **Camera Start:** Dekat bathtub pada sisi kiri kamar mandi; Menghadap bak, jendela belakang dan WC kanan; Medium-tight, dengan vanity kanan belum masuk penuh
- **Framing:** Kamera dekat tub kiri, menghadap ke jendela dan toilet dengan pot tanaman tinggi di kanan, framing awal sempit, posisi sekitar dada/mata dengan tilt hampir datar. → Di akhir lebih lebar: bak mandi hampir utuh, WC, lantai tile dan vanity kayu dengan basin kanan terbaca bersama dalam satu frame.
- **Lighting:** Daylight dari jendela belakang sangat terang, dibantu sconce hangat di dekat cermin.

#### **C. Camera Movement**

Kamera mundur sambil sedikit memutar pandangan ke kiri, mempertahankan fokus pada bathtub, jendela hitam dan vanity kayu. Bergerak mundur sambil menoleh ke kiri sedikit menyingkap basin/vanity di kanan dan luas lantai sekitar toilet.

**Tempo:** Reframe ke wide terasa sedang dan mulus, tanpa akselerasi yang dapat dipastikan.

**Camera:** Dolly-Out (~1.2–1.5×) + Pan Left (~10–20°).
