# edh058 — Rumah Mungil Spanish Revival dengan Teras Masuk Berceruk dan Interior Hangat

<a id="profil-dna"></a>

## 1. Identitas desain

- **Nama desain rumah:** Rumah Mungil Spanish Revival dengan Teras Masuk Berceruk dan Interior Hangat
- **Gaya utama:** Spanish Revival
- **Pengaruh gaya:** Mediterranean Cottage dan Warm Transitional — terlihat pada kombinasi atap genteng barel terakota berlereng rendah, fasad plester krem hangat, bukaan serta ceruk dinding melengkung, balok kayu plafon ekspos, dan kabinet Shaker modern bernuansa hangat
- **Gaya interior:** Warm Mediterranean Transitional
- **Ciri pengenal:** Ceruk teras pintu masuk (recessed entrance porch) beratap pelana genteng barel terakota dengan pintu kayu berpanel kaca lengkung, karangan bunga hijau, dan tiga lentera dinding besi hitam; Konsistensi motif lengkung (arch motif) pada ceruk dinding TV ruang duduk, jendela dapur di atas farmhouse sink, jendela kamar tidur, jendela ruang pakaian, dan ceruk pohon zaitun berlapis mozaik di kamar mandi; Perpaduan elemen arsitektur mediterania (plester bertekstur lembut, balok kayu plafon ekspos, ubin lantai terakota di kamar mandi) dengan perabot transisional yang bersih dan pencahayaan berlapis
- **Palet utama:** Dinding plester krem gading hangat (dengan dinding aksen hijau sage lembut di kamar tidur), genteng barel terakota, kusen jendela dan lentera besi hitam matte, kayu cokelat medium hangat pada pintu/lantai/kabinet/balok plafon, marmer putih berurat abu-abu pada meja dapur, serta tekstil krem, putih gading, dan terakota/rust
- **Suasana dan lingkungan:** Suasana hunian siang hari yang cerah, hangat, tenang, dan asri; eksterior dikelilingi halaman rumput hijau rapi, jalan setapak batu alam melengkung, semak bunga oranye-putih, dan pepohonan tinggi yang teduh, sementara seluruh ruang interior bermandikan cahaya alami dari jendela berbingkai hitam yang berpadu dengan pendar hangat lampu dinding dan downlight plafon

## 2. Ukuran dan proporsi bangunan

| Aspek | Estimasi visual |
| --- | --- |
| Ukuran rumah | Small (rumah mungil satu lantai dengan tata ruang kompak dan enam area fungsional yang ditampilkan) |
| Bentuk bangunan | Massa bangunan satu lantai kompak dengan sayap utama beratap miring di sisi kiri dan volume teras pintu masuk beratap pelana yang menonjol ke depan di sisi kanan-tengah fasad |
| Skala vertikal | Satu lantai (single-story) dengan ketinggian plafon interior yang proporsional serta plafon miring mengikuti struktur atap berbalok kayu ekspos pada ruang pakaian |
| Tapak bangunan | Tapak persegi panjang kompak di tengah lahan hijau dengan teras masuk berceruk dua anak tangga dan jalur jalan setapak batu alam melengkung dari halaman depan |
| Proporsi utama | Fasad depan tampak rendah dan melebar seimbang dengan ceruk teras sebagai sumbu vertikal utama, sedangkan ruang-ruang dalam memiliki proporsi kedalaman pendek hingga sedang yang tertata efisien |
| Perkiraan luas lantai | **55–75 m²** |

## 3. Struktur dan timeline video

Video berdurasi 19.9 detik (597 frame @ 30 FPS) terdiri atas 6 shot satu area yang dipisahkan oleh 5 cut tajam pada 5.3 s, 8.367 s, 11.533 s, 14.567 s, dan 17.1 s. Tidak ada pengambilan kontinu lintas-area (multi-area continuous take); urutan shot menyusun tur bertahap dari eksterior depan menuju ruang duduk, dapur, kamar tidur, ruang pakaian (walk-in closet), dan kamar mandi.

| Shot | Waktu (detik) | Durasi | Area/Scene | Gerakan singkat | Ritme |
| --- | --- | --- | --- | --- | --- |
| 01 | 0–5.3 | 5.3 detik | Front Exterior and Entrance Porch | Kamera bergerak maju dari sisi kanan halaman depan sambil melingkar tipis ke kiri menuju sumbu jalan setapak dan memutar pandangan lembut ke kanan, lalu mendorong maju semakin cepat secara lurus ke arah ceruk pintu masuk utama. | Mengalir mulus dengan tempo sedang pada fase penyelarasan sumbu awal (0.0–2.2 s), lalu mengalami percepatan visual menjadi cepat saat mendekati tangga dan ceruk pintu masuk (2.2–5.3 s) |
| 02 | 5.3–8.367 | 3.067 detik | Living Room | Kamera bergerak mundur menjauhi ceruk TV sambil badan kamera melingkar ke kiri menuju ruang terbuka di depan meja kopi dan pandangan memutar ke kanan untuk menjaga ceruk TV serta sofa kanan tetap terbingkai saat area duduk dan pintu kaca di sisi kiri terbuka. | Bergerak dengan tempo sedang yang konsisten dan halus sepanjang 3.07 detik tanpa perubahan kecepatan mendadak |
| 03 | 8.367–11.533 | 3.167 detik | Kitchen | Kamera mendorong maju melewati ambang dinding plester dan sisi kanan meja semenanjung sambil badan kamera bergeser melingkar tipis ke kiri di dalam koridor dapur dan pandangan memutar ke kanan ke arah kompor gas serta tudung hisap stainless. | Bergerak maju dengan tempo sedang yang lancar saat melewati ambang pintu dan pulau dapur (8.37–10.5 s), lalu melambat halus saat mendekati dan mengunci komposisi pada kompor (10.5–11.53 s) |
| 04 | 11.533–14.567 | 3.033 detik | Bedroom | Kamera bergerak mundur menjauhi tempat tidur sambil badan kamera melingkar ke kiri menuju sudut depan-kiri kamar dan pandangan memutar tipis ke kanan sehingga tempat tidur tetap terbingkai saat sudut kursi baca, lampu gantung plafon, dan papan kaki tempat tidur terbuka. | Mengalir dengan tempo sedang pada dua detik pertama (11.53–13.5 s) lalu melambat halus menuju perhentian lembut di akhir shot (13.5–14.57 s) |
| 05 | 14.567–17.1 | 2.533 detik | Walk-in Closet | Kamera bergerak maju secara lurus dan simetris melewati ambang pintu ruang pakaian menyusuri lorong tengah langsung menuju jendela lengkung di dinding ujung. | Mengalir maju dengan tempo sedang yang stabil dan mulus sepanjang 2.53 detik tanpa perubahan arah |
| 06 | 17.1–19.9 | 2.8 detik | Bathroom | Kamera bergerak mundur menjauhi bak mandi dan ceruk pohon zaitun sambil bergeser tipis ke kiri dan menjaga pandangan tetap terarah sedikit ke kanan sehingga seluruh kabinet vanity kayu, wastafel, lampu dinding kanan, serta keranjang handuk di kiri-bawah terbuka. | Bergerak mundur dengan tempo sedang pada paruh awal-tengah (17.1–18.8 s), lalu melambat halus hingga berhenti dengan tenang di akhir video (18.8–19.9 s) |

## 4. Storyboard

![Storyboard overview seluruh area](media/storyboard.jpg)

## 5. Detail shot

<a id="shot-01"></a>

### Shot 01 — Front Exterior and Entrance Porch · 5.3 detik

![Kolase Shot 01](media/shot-01.jpg)

**Urutan panel:** Start · 0.00s → Middle · 2.63s → End · 5.27s.

#### A. Desain area

**Arsitektur**

Fasad depan rumah satu lantai bergaya Spanish Revival menampilkan dinding plester (stucco) krem gading dengan volume teras pintu masuk beratap pelana yang menonjol di sisi kanan-tengah dan sayap bangunan beratap miring di sisi kiri. Atap ditutup genteng barel terakota berlereng rendah dengan deretan balok kasau kayu gelap di bawah tritisan serta sebuah cerobong plester putih bertopi terakota di atas lereng atap kiri. Di tengah volume pelana terdapat ceruk teras pintu masuk berplafon datar dengan lantai batu/beton krem dua anak tangga dan pintu kayu cokelat hangat satu daun yang memiliki panel kaca lengkung di bagian atas. Pada dinding fasad depan di sebelah kiri ceruk teras terdapat jendela persegi berbingkai hitam dengan sepasang daun jendela (shutters) louvered hitam, sedangkan pada dinding samping kanan volume teras terdapat jendela serupa berdaun shutter hitam. Tiga lentera dinding besi hitam berkaca bening dipasang secara simetris: satu menggantung di atas ceruk pintu dan dua menempel di dinding pengapit kiri-kanan ceruk pintu. Di latar belakang kiri tampak sebagian kecil bangunan tambahan atau sayap samping dengan jendela berbingkai hitam.

**Furnitur dan properti**

Pada bidang kaca pintu depan tergantung sebuah karangan bunga (wreath) daun hijau melingkar. Di atas platform dan anak tangga teras depan tersusun beberapa pot terakota dan pot keramik bermotif ulir warna krem yang ditanami pohon konifer kerucut kecil serta semak bunga putih di sisi kiri dan kanan pintu. Di bawah jendela fasad kiri maupun jendela samping kanan terpasang kotak tanaman (window box planter) kayu cokelat yang dipenuhi tanaman hijau dan bunga kecil.

**Lingkungan**

Halaman depan ditata asri dengan dua bidang rumput hijau rapi yang dibelah oleh jalan setapak batu alam (flagstone) warna abu-abu krem yang melengkung dari kiri-bawah menuju tangga teras depan. Sepanjang tepi jalan setapak dan kaki dinding fasad tumbuh deretan bunga oranye-merah dan putih yang rimbun, ditambah tanaman cemara vertikal ramping di sudut kanan volume teras. Sebatang pohon konifer besar berbatang tegak berdiri di foreground kanan dekat pagar kayu cokelat, sementara pepohonan tinggi berdaun kuning-keemasan dan hijau menaungi latar belakang di bawah langit siang yang cerah.

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Fokus utama | Volume ceruk teras pintu masuk dengan pintu kayu cokelat dan tiga lentera dinding besi hitam |
| Posisi kamera awal | Di halaman depan di atas bidang rumput sisi kanan jalan setapak batu alam, sekitar 7–9 meter di depan fasad teras; Menghadap ke arah fasad depan dan ceruk pintu masuk dengan sumbu pandang awal sedikit menyerong ke kiri; Tiga perempat depan-kanan tipis yang berangsur menjadi hampir frontal terhadap ceruk pintu masuk |
| Framing awal → akhir | Wide establishing shot fasad rumah satu lantai secara utuh bersama halaman rumput, jalan setapak batu melengkung, dan pohon konifer tinggi di sisi kanan → Medium-close framing frontal pada volume pelana teras masuk, menonjolkan pintu kayu berkarangan bunga, tiga lentera dinding hitam, pot-pot tanaman di anak tangga, dan sebagian jendela kiri |
| Pencahayaan | Cahaya matahari siang hari yang cerah dari arah atas-depan-kiri (membentuk bayangan lembut di bawah tritisan atap dan di dalam ceruk pintu) dipadukan nyala hangat ketiga lentera dinding |

#### C. Gerakan kamera

**Bahasa sederhana**

Kamera bergerak maju dari sisi kanan halaman depan sambil melingkar tipis ke kiri menuju sumbu jalan setapak dan memutar pandangan lembut ke kanan, lalu mendorong maju semakin cepat secara lurus ke arah ceruk pintu masuk utama.

**Ritme:** Mengalir mulus dengan tempo sedang pada fase penyelarasan sumbu awal (0.0–2.2 s), lalu mengalami percepatan visual menjadi cepat saat mendekati tangga dan ceruk pintu masuk (2.2–5.3 s)

**Timeline gerakan**

Semua waktu dihitung dari awal video.

| Waktu (detik) | Area dan fokus | Gerakan Kamera | Ritme |
| --- | --- | --- | --- |
| 0–2.2 | Front Exterior and Entrance Porch · Fasad depan rumah, jalan setapak batu alam, dan penyelarasan sumbu ke ceruk teras masuk | Dolly-In (~1.35×) + Orbit Left (~10°–12°) + gentle Pan Right (~8°–10°) | Tempo sedang saat kamera maju menyusuri halaman depan dan menyejajarkan sumbu pandang ke jalan setapak batu |
| 2.2–5.3 | Front Exterior and Entrance Porch · Ceruk teras pintu masuk, pintu kayu berpanel kaca lengkung, tiga lentera hitam, dan pot tanaman di tangga | Accelerating Dolly-In (~1.8×) toward front entrance door | Tempo sedang saat kamera maju menyusuri halaman depan dan menyejajarkan sumbu pandang ke jalan setapak batu; Tempo meningkat menjadi cepat akibat ekspansi skala proyeksi saat kamera mendekati anak tangga dan ceruk pintu masuk |

**Notasi teknis**

```text
Dolly-In (~1.35×) + Orbit Left (~10°–12°) + gentle Pan Right (~8°–10°) → Accelerating Dolly-In (~1.8×) toward front entrance door
```

---

<a id="shot-02"></a>

### Shot 02 — Living Room · 3.067 detik

![Kolase Shot 02](media/shot-02.jpg)

**Urutan panel:** Start · 5.30s → Middle · 6.83s → End · 8.33s.

#### A. Desain area

**Arsitektur**

Ruang duduk memiliki dinding plester krem hangat dengan plafon putih rata yang dilengkapi lis profil (crown molding) berlapis serta dua lampu downlight bulat tersembunyi (recessed downlights), ditambah sebagian balok kayu ekspos di tepi atas-kiri pada akhir shot. Pada dinding utama di latar belakang terdapat ceruk dinding besar berbentuk lengkung (arched wall niche) yang menjorok ke dalam untuk menempatkan televisi dan kabinet media. Ceruk lengkung tersebut diapit secara simetris oleh dua lampu dinding (wall sconces) berbentuk kotak vertikal dari logam hitam dan kaca. Di dinding sisi kiri terdapat bukaan pintu kaca tinggi berbingkai hitam kisi-kisi (French/patio doors) yang menghadap ke halaman luar, dilengkapi tirai panjang warna krem yang digantung pada batang besi hitam di dekat plafon. Lantai ruangan menggunakan papan kayu cokelat hangat dengan lis plint (baseboard) putih di sepanjang kaki dinding.

**Furnitur dan properti**

Di dalam ceruk dinding lengkung terpasang televisi layar datar di atas kabinet media kayu cokelat hangat yang memiliki dua pintu panel di sisi kiri-kanan serta rak terbuka di tengah yang memuat perangkat elektronik dan sebuah keranjang anyaman. Di atas permukaan kabinet media diletakkan buku-buku bersandar di kiri serta pot keramik abu-abu berisi tanaman hijau di kanan. Pada sisi kanan ruangan berdiri sebuah sofa kain krem berlengan gulung (rolled-arm sofa) dengan deretan bantal punggung krem dan bantal dekoratif putih bermotif titik-titik hitam. Di tengah ruangan terhampar karpet motif tradisional warna krem-abu-abu pucat dengan meja kopi kayu persegi berkaki miring dan rak bawah yang menyimpan keranjang anyaman; di atas meja kopi tertata tumpukan buku, nampan kecil, dan vas kaca gelap berisi rangkaian daun musim gugur berwarna oranye-cokelat. Di sudut kiri-belakang dekat tirai berdiri sebuah kursi baca (accent armchair) berlapis kain krem dengan bantal pinggang warna terakota/cokelat dan pohon zaitun buatan/indoor berbatang ramping dalam pot putih, sementara di sisi kiri meja kopi tampak ujung sofa krem kedua serta sebuah keranjang anyaman bulat bertelinga di lantai foreground tengah-kiri.

**Lingkungan**

Melalui pintu kaca berbingkai hitam di sisi kiri terlihat halaman luar yang cerah di siang hari dengan hamparan tanaman berbunga merah-oranye, semak hijau, serta sebagian dinding krem dan atap genteng bangunan di latar luar. Cahaya matahari siang masuk secara miring dari bukaan kiri, membentuk pola petak cahaya terang dan bayangan kisi jendela di atas karpet serta lantai kayu.

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Fokus utama | Ceruk dinding TV melengkung yang beralih ke keseluruhan kelompok duduk meja kopi dan bukaan taman kiri |
| Posisi kamera awal | Dimulai tepat di atas/sisi dalam sofa kanan menghadap ceruk TV, lalu mundur dan melingkar ke kiri menuju area depan meja kopi di tengah ruang duduk; Menghadap ke dinding ceruk TV dengan sudut pandang yang berorientasi dari serong kiri-depan menuju pandangan ruang duduk yang lebih menyeluruh; Tiga perempat ruang duduk yang menyapu dari fokus ceruk dinding kanan-belakang ke bukaan taman di sisi kiri |
| Framing awal → akhir | Framing medium-close pada ceruk dinding lengkung berisi TV dan kabinet media kayu, dengan punggung sofa krem dan bantal bermotif memenuhi kuadran kanan-bawah → Wide shot ruang duduk yang seimbang: pintu kaca halaman, kursi baca, pohon zaitun, dan meja kopi di sisi kiri-tengah, sofa berlengan gulung di kanan-bawah, serta ceruk TV di kanan-belakang |
| Pencahayaan | Sinar matahari siang alami yang kuat dari bukaan kaca di dinding kiri (membentuk sorotan terang di lantai dan karpet) dipadukan cahaya hangat dari dua lampu dinding pengapit ceruk TV serta dua downlight plafon |

#### C. Gerakan kamera

**Bahasa sederhana**

Kamera bergerak mundur menjauhi ceruk TV sambil badan kamera melingkar ke kiri menuju ruang terbuka di depan meja kopi dan pandangan memutar ke kanan untuk menjaga ceruk TV serta sofa kanan tetap terbingkai saat area duduk dan pintu kaca di sisi kiri terbuka.

**Ritme:** Bergerak dengan tempo sedang yang konsisten dan halus sepanjang 3.07 detik tanpa perubahan kecepatan mendadak

**Notasi teknis**

```text
Dolly-Out (~1.5×) + Orbit Left (~12°–15°) + Pan Right (~10°–15°)
```

---

<a id="shot-03"></a>

### Shot 03 — Kitchen · 3.167 detik

![Kolase Shot 03](media/shot-03.jpg)

**Urutan panel:** Start · 8.37s → Middle · 9.93s → End · 11.50s.

#### A. Desain area

**Arsitektur**

Dapur dirancang dengan konfigurasi bentuk L (L-shaped layout) ditambah sebuah meja semenanjung (peninsula island) di sisi kiri depan. Pada frame awal tampak bingkai bukaan ambang dinding berplester putih bertekstur kasar (textured stucco portal) di tepi kiri dan kanan layar, dengan sebatang balok kayu melintang di bagian atas ambang. Dinding dapur berwarna krem hangat dengan backsplash plester bertekstur lembut yang bergelombang organik di bawah kabinet atas dan di belakang kompor. Di dinding belakang-kiri terdapat sebuah jendela melengkung (arched window) berbingkai hitam kisi-kisi tepat di atas bak cuci piring. Kabinet dapur atas dan bawah menggunakan pintu model Shaker warna krem/putih hangat dengan tarikan batang vertikal hitam matte dan lis mahkota (crown molding) yang menyatu hingga plafon. Seluruh meja dapur (countertop) termasuk meja semenanjung berlapis batu marmer/kuarsa putih berurat abu-abu lembut. Di dinding kanan terpasang tudung hisap cerobong (chimney range hood) baja tahan karat, diapit oleh kabinet atas di sebelah kirinya dan dua ambalan kayu terbuka (floating wooden shelves) di sebelah kanannya, serta sebuah stopkontak dinding ganda warna putih di bawah ambalan. Plafon putih rata memiliki lima titik lampu downlight tersembunyi, sementara lantai menggunakan papan kayu cokelat hangat.

**Furnitur dan properti**

Di bawah meja semenanjung kiri di foreground awal berdiri dua kursi bar (barstools) kayu bundar berkaki empat, sedangkan di atas permukaan meja semenanjung diletakkan talenan kayu dengan serbet lipat serta pot terakota berisi tanaman berbunga merah-oranye di dekat tiang ambang kiri dan dua lampu gantung silinder putih di atasnya. Pada dinding belakang di bawah jendela lengkung terpasang bak cuci piring model apron-front (farmhouse sink) putih dengan keran lengkung hitam dan vas kaca berisi bunga merah-oranye di ambang jendela. Di sebelah kanan bak cuci terdapat mesin pencuci piring (dishwasher) baja tahan karat di bawah meja, sementara di sudut meja tertata nampan rotan bulat bersandar, talenan kayu, dan botol/dispenser sabun. Pada sisi kanan berdiri kompor gas (freestanding/slide-in gas range) baja tahan karat dengan tungku kisi besi hitam dan oven ganda, dengan sebuah panci dutch oven warna krem bertutup di atas tungku kanan-belakang. Di sebelah kiri kompor terdapat wadah kayu berisi spatula/alat masak, dan di meja sebelah kanan kompor diletakkan mangkuk keramik putih bertekstur berisi buah jeruk segar. Dua ambalan kayu di kanan tudung hisap memuat tumpukan piring/mangkuk keramik di rak bawah serta pot tanaman hijau menjuntai dan pot kecil di rak atas. Sehelai karpet lorong (runner rug) anyaman warna krem-cokelat muda terhampar di lantai kayu di sepanjang depan kompor dan dishwasher.

**Lingkungan**

Melalui jendela lengkung berbingkai hitam di atas bak cuci piring pada paruh awal shot tampak cahaya langit siang yang terang serta siluet dedaunan luar yang lembut. Setelah jendela keluar dari tepi kiri frame, suasana ruang didominasi oleh pendar hangat lampu interior di atas permukaan plester bertekstur.

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Fokus utama | Tata ruang dapur bentuk L secara keseluruhan yang beralih menuju kompor gas stainless, tudung hisap, dan tekstur backsplash di dinding kanan |
| Posisi kamera awal | Dimulai tepat di ambang bukaan plester di depan meja semenanjung kiri, lalu bergerak maju masuk ke koridor dapur di antara semenanjung dan kompor; Menghadap ke dalam dapur dari arah sumbu jendela-sudut kabinet lalu berputar ke kanan menuju bidang depan kompor gas dan tudung hisap; Perspektif koridor dapur yang bergeser menjadi sudut tiga perempat depan-kiri terhadap deret kompor dan kabinet kanan |
| Framing awal → akhir | Wide shot interior dapur dari balik ambang plester kasar yang memperlihatkan meja semenanjung dengan dua kursi bar di kiri, jendela lengkung di atas farmhouse sink di belakang, serta deret kabinet Shaker dan kompor di kanan → Medium-close tiga perempat pada zona memasak di dinding kanan: kabinet atas Shaker krem, tudung hisap stainless, backsplash plester bertekstur, kompor gas dengan panci krem, ambalan kayu berhias tanaman, dan mangkuk jeruk |
| Pencahayaan | Pencahayaan berlapis hangat dari lima downlight plafon, dua lampu gantung silinder di atas semenanjung, dan lampu kolong kabinet (under-cabinet lighting) yang menonjolkan tekstur plester, dipadukan cahaya siang dari jendela lengkung belakang |

#### C. Gerakan kamera

**Bahasa sederhana**

Kamera mendorong maju melewati ambang dinding plester dan sisi kanan meja semenanjung sambil badan kamera bergeser melingkar tipis ke kiri di dalam koridor dapur dan pandangan memutar ke kanan ke arah kompor gas serta tudung hisap stainless.

**Ritme:** Bergerak maju dengan tempo sedang yang lancar saat melewati ambang pintu dan pulau dapur (8.37–10.5 s), lalu melambat halus saat mendekati dan mengunci komposisi pada kompor (10.5–11.53 s)

**Notasi teknis**

```text
Dolly-In (~1.8×) toward stainless range and hood + Orbit Left (~8°–10°) + Pan Right (~15°–20°)
```

---

<a id="shot-04"></a>

### Shot 04 — Bedroom · 3.033 detik

![Kolase Shot 04](media/shot-04.jpg)

**Urutan panel:** Start · 11.53s → Middle · 13.07s → End · 14.53s.

#### A. Desain area

**Arsitektur**

Kamar tidur menampilkan dinding utama di belakang kepala tempat tidur yang dicat hijau sage lembut (muted sage green), berpadu dengan dinding samping kiri berwarna krem hangat dan plafon putih rata yang dihiasi balok-balok kayu cokelat ekspos melintang. Di tengah dinding hijau sage tepat di atas kepala tempat tidur terdapat sebuah jendela melengkung (arched double casement window) berbingkai hitam kisi-kisi yang diapit sepasang tirai panjang warna krem gading pada batang besi hitam. Pada dinding samping kiri terdapat bukaan jendela kedua yang juga dilengkapi tirai panjang krem. Dua lampu dinding (wall sconces) logam hitam bergaya industrial-klasik dengan bola lampu pijar hangat ekspos dipasang mengapit jendela lengkung, sementara dari plafon di antara balok kayu tergantung sebuah lampu gantung (chandelier) berbentuk lentera kaca berbingkai kayu dan logam. Lantai kamar menggunakan papan kayu cokelat hangat.

**Furnitur dan properti**

Di tengah ruangan berdiri tempat tidur kayu cokelat hangat berukuran double/queen dengan papan kepala (headboard) dan papan kaki (footboard) berpanel kayu horizontal. Tempat tidur ditata dengan sprei dan bedcover quilt putih bergaris jahitan memanjang, selimut rajut tebal (chunky knit throw) warna krem yang disampirkan secara diagonal di kaki kasur, serta susunan bantal berlapis: dua bantal tidur putih di belakang, dua bantal bergaris tekstur krem-beige di tengah, dan satu bantal persegi warna terakota/rust bertekstur timbul di depan-tengah. Mengapit tempat tidur terdapat sepasang nakas (nightstands) kayu tiga laci berlaci tarikan hitam: di atas nakas kiri berdiri lampu meja keramik putih bundar berkap silinder krem di bawah hiasan dinding berbingkai kayu berisi relief putih geometris, sedangkan di atas nakas kanan diletakkan vas keramik krem berisi rangkaian bunga kering. Di sudut kiri-belakang dekat jendela samping tertata sebuah kursi baca berlapis kain krem dengan bantal motif terakota-krem dan tanaman pohon indoor hijau berdaun rimbun di belakangnya. Di lantai di bawah tempat tidur terhampar karpet tenun warna krem, dan pada akhir shot tampak sudut kabinet/meja laci kayu (dresser) di foreground kiri-bawah.

**Lingkungan**

Melalui jendela lengkung berbingkai hitam di atas kepala tempat tidur terlihat tanaman berbunga merah-oranye yang cerah tepat di luar ambang jendela dengan latar dedaunan pohon hijau yang rimbun di bawah sinar matahari siang.

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Fokus utama | Susunan bantal tempat tidur dan jendela lengkung di atas headboard yang meluas ke keseluruhan tata ruang kamar tidur |
| Posisi kamera awal | Dimulai di dekat sisi depan-kiri kasur menghadap ke arah kepala tempat tidur dan jendela lengkung, lalu mundur melingkar ke kiri menuju sudut depan-kiri kamar di dekat kabinet dresser; Menghadap serong ke kanan-belakang ke arah tempat tidur dan dinding hijau sage dengan pandangan yang memutar tipis ke kanan menjaga tempat tidur tetap terbingkai; Sudut tiga perempat depan-kiri terhadap tempat tidur dan dinding kepala tempat tidur |
| Framing awal → akhir | Medium-close tiga perempat pada bagian atas tempat tidur, bantal terakota, nakas kanan, dan jendela lengkung berbingkai hitam di dinding hijau sage → Wide shot kamar tidur secara utuh yang menampilkan keseluruhan tempat tidur kayu dari footboard hingga headboard, kedua nakas, lampu gantung plafon berbalok kayu, sudut kursi baca kiri, dan sudut dresser depan-kiri |
| Pencahayaan | Cahaya siang alami yang cerah dari jendela lengkung belakang dan jendela samping kiri, diperkuat oleh pendar hangat bola lampu ekspos pada kedua wall sconces hitam, lampu meja nakas kiri, dan lentera gantung plafon |

#### C. Gerakan kamera

**Bahasa sederhana**

Kamera bergerak mundur menjauhi tempat tidur sambil badan kamera melingkar ke kiri menuju sudut depan-kiri kamar dan pandangan memutar tipis ke kanan sehingga tempat tidur tetap terbingkai saat sudut kursi baca, lampu gantung plafon, dan papan kaki tempat tidur terbuka.

**Ritme:** Mengalir dengan tempo sedang pada dua detik pertama (11.53–13.5 s) lalu melambat halus menuju perhentian lembut di akhir shot (13.5–14.57 s)

**Notasi teknis**

```text
Dolly-Out (~1.6×) + Orbit Left (~12°–15°) + Pan Right (~10°–12°)
```

---

<a id="shot-05"></a>

### Shot 05 — Walk-in Closet · 2.533 detik

![Kolase Shot 05](media/shot-05.jpg)

**Urutan panel:** Start · 14.57s → Middle · 15.83s → End · 17.07s.

#### A. Desain area

**Arsitektur**

Ruang pakaian (walk-in closet) berbentuk lorong simetris memanjang dengan dinding plester krem hangat dan plafon miring tinggi (pitched/vaulted ceiling) yang ditopang deretan balok kasau kayu cokelat ekspos berbentuk huruf V terbalik serta lampu-lampu downlight bulat tersembunyi. Di ujung dinding belakang terdapat sebuah ceruk jendela melengkung (arched window) berbingkai hitam kisi-kisi dengan ambang jendela (window sill) plester krem yang tebal di bagian bawahnya. Pada awal shot (14.57–14.93 s), di tepi kiri depan tampak kusen pintu masuk ruang pakaian dari logam hitam berkaca dengan handel batang hitam. Sepanjang dinding kiri dan kanan dibangun sistem lemari pakaian terbuka (built-in wardrobe cabinetry) warna krem yang terbagi atas kompartemen gantungan baju dua tingkat, ceruk-ceruk rak persegi di dinding belakang dan atas, serta deret kabinet laci kayu cokelat hangat berhandel hitam di sisi bawah kanan. Lantai ruang pakaian menggunakan papan kayu cokelat hangat.

**Furnitur dan properti**

Pada kompartemen lemari sisi kiri tergantung deretan pakaian rapi bernuansa warna bumi (putih, krem, terakota, oranye, cokelat, dan hijau zaitun) dalam dua tingkat gantungan atas-bawah, dilengkapi keranjang anyaman rotan di ceruk rak atas. Pada sisi kanan terdapat kabinet pulau/deret laci kayu cokelat hangat dengan banyak laci bertarikan hitam di bagian bawah, meja rias/lipat berlapis marmer putih di tengah dengan vas bunga putih dan kotak penyimpanan, serta gantungan pakaian dan deretan keranjang anyaman kotak di rak-rak atas yang disorot lampu strip LED hangat tersembunyi. Di ceruk rak dinding belakang sebelah kanan jendela lengkung tersusun keranjang anyaman dan pajangan logam hitam kecil, sementara di atas ambang jendela lengkung diletakkan keranjang bulat kecil berisi bunga kering. Di lantai lorong tengah terhampar karpet tenun warna krem dengan sebuah bangku ottoman persegi berlapis kain krem di sisi kiri-tengah dan sebuah pot/pitcher logam berisi rangkaian bunga mawar putih berdaun hijau rimbun di lantai sudut kanan-belakang di bawah jendela, ditambah tanaman hijau kecil di sudut kiri-bawah pada awal shot.

**Lingkungan**

Melalui jendela lengkung berbingkai hitam di dinding ujung terlihat halaman luar yang cerah di siang hari dengan tanaman berbunga merah-oranye dan kuning yang rimbun serta sebagian dinding krem dan atap genteng bangunan di latar belakang.

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Fokus utama | Ceruk jendela lengkung berbingkai hitam di ujung lorong ruang pakaian beserta bangku ottoman dan kabinet pengapitnya |
| Posisi kamera awal | Dimulai tepat di ambang pintu masuk ruang pakaian lalu bergerak maju lurus menyusuri sumbu tengah lorong menuju jendela lengkung di dinding ujung; Menghadap lurus (frontal simetris) sepanjang sumbu lorong ruang pakaian ke arah jendela lengkung belakang; Perspektif satu titik hilang (one-point perspective) yang simetris dan terpusat pada jendela lengkung |
| Framing awal → akhir | Wide axial shot dari ambang pintu kaca hitam yang menampilkan plafon miring berbalok kayu, kedua deret lemari kiri-kanan, bangku ottoman di atas karpet, dan jendela lengkung di ujung → Medium axial shot yang lebih dekat pada ceruk jendela lengkung berbingkai hitam, bangku ottoman krem di kiri-bawah, buket bunga putih di kanan-bawah, dan bagian tengah-belakang kabinet pakaian |
| Pencahayaan | Cahaya siang alami yang terang dari jendela lengkung di ujung lorong berpadu dengan deretan downlight plafon dan lampu strip LED hangat tersembunyi di dalam rak-rak lemari pakaian |

#### C. Gerakan kamera

**Bahasa sederhana**

Kamera bergerak maju secara lurus dan simetris melewati ambang pintu ruang pakaian menyusuri lorong tengah langsung menuju jendela lengkung di dinding ujung.

**Ritme:** Mengalir maju dengan tempo sedang yang stabil dan mulus sepanjang 2.53 detik tanpa perubahan arah

**Notasi teknis**

```text
Dolly-In (~1.7×) toward arched closet window
```

---

<a id="shot-06"></a>

### Shot 06 — Bathroom · 2.8 detik

![Kolase Shot 06](media/shot-06.jpg)

**Urutan panel:** Start · 17.10s → Middle · 18.50s → End · 19.87s.

#### A. Desain area

**Arsitektur**

Kamar mandi memiliki dinding plester krem hangat dengan sebuah balok kayu cokelat ekspos melintang di plafon bagian depan-kiri serta sebuah ceruk dinding tinggi berbentuk lengkung (arched alcove) di sisi kanan-belakang. Dinding bagian dalam ceruk lengkung tersebut dilapisi ubin mozaik persegi kecil berwarna abu-abu kehijauan mengilap hingga setengah tinggi dinding dan dilengkapi sebuah ambalan kayu terbuka di bagian atasnya. Di dinding belakang-kiri terdapat jendela casement ganda berbingkai hitam dengan tirai panjang warna krem di sisi kanannya (serta tirai di sisi kiri yang terbuka saat kamera mundur) pada batang besi hitam. Di bawah jendela terpasang keran pengisi bak mandi dinding (wall-mounted tub filler) warna hitam matte. Pada dinding kanan berdiri kabinet meja rias kamar mandi (vanity cabinet) kayu cokelat hangat berpintu panel dan berlaci dengan meja batu/kuarsa krem, wastafel mangkuk/semi-recessed persegi panjang putih berkeran hitam, cermin berbingkai hitam di dinding kanan, lampu dinding (wall sconce) logam hitam-kuningan berkap kaca silinder yang menyala hangat, serta gantungan cincin hitam di sebelah kiri lampu dinding. Lantai kamar mandi menggunakan ubin persegi/persegi panjang warna terakota-cokelat muda hangat dengan pola pemasangan berselang-seling.

**Furnitur dan properti**

Di bawah jendela belakang-kiri berdiri sebuah bak mandi rendam oval bebas (freestanding oval soaking tub) warna putih halus yang dilengkapi papan nampan kayu (wooden bath caddy) melintang di atasnya; di atas nampan kayu dan bibir bak tertata botol dispenser kaca cokelat amber, stoples kecil berlabel, dan lilin. Di atas ambang jendela di belakang bak mandi berjajar pot-pot kecil terakota dan keramik berisi tanaman hijau. Di sebelah kanan bak mandi berdiri kloset duduk (toilet) keramik putih satu unit. Tepat di dalam ceruk dinding lengkung di belakang kloset berdiri sebatang pohon zaitun indoor berbatang kayu tegak dan berdaun rimbun di dalam pot putih rendah berisi batu kerikil putih, sementara di ambalan kayu atas ceruk diletakkan bingkai cermin/pigura berbingkai hitam dan vas kaca berisi tangkai daun hijau. Di sisi kanan dekat meja vanity tergantung sehelai handuk tangan bertekstur waffle warna krem-beige, dan di sudut kiri-bawah foreground pada paruh akhir shot tampak sebuah keranjang anyaman rotan berisi gulungan handuk putih dengan tanaman pakis/hijau berdaun rimbun di atasnya.

**Lingkungan**

Melalui jendela berbingkai hitam di atas bak mandi terlihat pemandangan luar siang hari yang cerah dengan deretan bunga oranye-merah yang mekar, pepohonan hijau, serta sebagian dinding krem berjendela dan atap genteng bangunan di latar belakang luar.

#### B. Komposisi dan cahaya

| Aspek | Penjelasan |
| --- | --- |
| Fokus utama | Bak mandi freestanding dan ceruk pohon zaitun yang meluas mencakup meja vanity kayu di dinding kanan serta keseluruhan kamar mandi |
| Posisi kamera awal | Dimulai di tengah kamar mandi menghadap dekat ke bak mandi dan ceruk pohon zaitun, lalu bergerak mundur menyusuri ruang di depan meja vanity kanan; Menghadap lurus ke arah dinding belakang (jendela bak mandi dan ceruk pohon zaitun) dengan sedikit pergeseran sumbu ke kiri yang membuka dinding vanity kanan; Frontal terhadap dinding jendela dan ceruk belakang, sekaligus menampilkan sudut tiga perempat samping pada meja vanity kanan |
| Framing awal → akhir | Medium-close framing pada separuh kanan bak mandi putih, jendela berbingkai hitam, kloset duduk, dan pohon zaitun tinggi di dalam ceruk dinding lengkung berlapis mozaik → Wide shot kamar mandi yang lengkap: bak mandi di bawah jendela hitam dan keranjang handuk di sisi kiri, kloset dan ceruk pohon zaitun di tengah, serta kabinet vanity kayu berwastafel putih dan lampu dinding di sisi kanan |
| Pencahayaan | Cahaya matahari siang yang terang menembus jendela belakang-kiri dan memantul di atas lantai ubin terakota, dipadukan pendar hangat lampu dinding di sebelah cermin vanity kanan |

#### C. Gerakan kamera

**Bahasa sederhana**

Kamera bergerak mundur menjauhi bak mandi dan ceruk pohon zaitun sambil bergeser tipis ke kiri dan menjaga pandangan tetap terarah sedikit ke kanan sehingga seluruh kabinet vanity kayu, wastafel, lampu dinding kanan, serta keranjang handuk di kiri-bawah terbuka.

**Ritme:** Bergerak mundur dengan tempo sedang pada paruh awal-tengah (17.1–18.8 s), lalu melambat halus hingga berhenti dengan tenang di akhir video (18.8–19.9 s)

**Notasi teknis**

```text
Dolly-Out (~1.6×) + gentle Orbit Left (~5°–8°) + gentle Pan Right (~5°–8°)
```
