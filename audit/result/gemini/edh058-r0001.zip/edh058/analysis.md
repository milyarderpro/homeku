# edh058 — Warm Mediterranean Cottage

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Warm Mediterranean Cottage
- **Gaya utama:** **Mediterranean Revival**
- **Pengaruh gaya:** Spanish Colonial Revival; Cottage; Organic Modern
- **Gaya interior:** Warm Mediterranean Cottage
- **Ciri khas:** Atap pelana genteng barrel terakota dengan fasad plester krem hangat dan cerobong putih di sisi kiri atap; Bukaan jendela dan relung dinding melengkung (arched) berbingkai hitam matte yang konsisten di ruang keluarga, dapur, kamar tidur, walk-in closet, dan kamar mandi; Balok kayu ekspos pada langit-langit kamar tidur, walk-in closet beratap miring, ruang keluarga, dan kamar mandi; Pohon zaitun dalam pot pada relung melengkung kamar mandi dan sudut ruang keluarga sebagai aksen botani khas Mediterania
- **Warna & material:** Krem plester hangat pada dinding luar dan dalam, terakota pada genteng serta aksen bantal, kayu cokelat hangat pada pintu, kabinet, dan balok langit-langit, hijau sage lembut di kamar tidur, hitam matte pada kusen serta lampu, dan putih krem pada tekstil.
- **Suasana dan lingkungan:** Hangat, intim, dan teduh dengan cahaya matahari siang cerah yang masuk lewat bukaan jendela melengkung dan pintu kaca Prancis, berpadu lampu dinding hangat serta taman bunga oranye-putih dan pepohonan rimbun di luar rumah.

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Massa bangunan tunggal satu lantai berbentuk kompak dengan proyeksi serambi masuk beratap pelana rendah di tengah fasad depan. |
| **Lantai & bentuk atap** | Satu lantai tampak penuh dari eksterior tanpa indikasi lantai atas, loteng berjendela, atau tangga di ruang interior yang ditampilkan. |
| **Tapak bangunan** | Tapak ringkas berbentuk kompak satu lantai dengan bukaan taman langsung di sekitar ruang keluarga, kamar tidur, walk-in closet, dan kamar mandi. |
| **Proporsi utama** | Proporsi fasad horizontal rendah dan intim dengan bukaan jendela besar berbingkai hitam serta plafon interior sedang hingga miring ekspos di walk-in closet. |
| **Perkiraan luas lantai** | **65–95 m²** |

## 3. Shot Timeline

Video terdiri dari 6 shot kontinu yang dipisahkan 5 hard cut dengan pola kamera bergantian IN – OUT – IN – OUT – IN – OUT dari eksterior depan menuju ruang keluarga, dapur, kamar tidur, walk-in closet, dan kamar mandi.

**Camera Pattern:** IN – OUT – IN – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–5.30 | 5.30s | Exterior Front | Dolly-In (~2.2–2.5×). |
| 02 | 5.30–8.37 | 3.07s | Living Room | Dolly-Out (~1.6–1.9×) + Pan Left (~15–20°). |
| 03 | 8.37–11.53 | 3.17s | Kitchen | Dolly-In (~1.7–2.0×) + Pan Right (~12–18°). |
| 04 | 11.53–14.57 | 3.03s | Bedroom | Dolly-Out (~1.5–1.8×) + Pan Left (~10–15°). |
| 05 | 14.57–17.10 | 2.53s | Walk-in Closet | Dolly-In (~1.6–1.9×). |
| 06 | 17.10–19.90 | 2.80s | Bathroom | Dolly-Out (~1.6–1.9×). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Exterior Front · 0.00s**

> Kamera berada pada ketinggian mata di ujung jalan setapak batu alam halaman depan, mengarah datar dengan sudut tiga perempat ringan ke pintu masuk tengah. Cakupan wide merangkum seluruh massa cottage satu lantai beratap genteng barrel terakota, cerobong kiri, dua jendela berkisi gelap, hamparan rumput hijau, border bunga oranye-putih, dan batang pohon besar di tepi kanan sebagai pembingkai kedalaman di bawah cahaya siang cerah.

**Shot 02 · Living Room · 8.33s**

> Kamera berada pada posisi mundur di sisi kanan-depan ruang keluarga setinggi dada-mata dengan kemiringan datar, memandang serong ke kiri-tengah ruangan. Cakupan wide akhir ini menempatkan relung TV melengkung dan sofa krem di kanan, meja kopi kayu berkarpet bermotif di tengah, serta pintu kaca Prancis bertirai krem, kursi aksen, dan pohon zaitun di kiri dalam pencahayaan alami siang yang terang.

**Shot 03 · Kitchen · 8.37s**

> Kamera berdiri setinggi mata dengan sudut datar di ambang bukaan masuk dapur, memandang diagonal ke sudut L ruang. Cakupan wide merangkum meja semenanjung berbangku bar kayu dan dua pendant silinder di kiri depan, jendela melengkung hitam di atas wastafel farmhouse di belakang, serta kabinet shaker krem, kompor gas, dan cooker hood di kanan di bawah cahaya siang dan lampu plafon hangat.

**Shot 04 · Bedroom · 14.53s**

> Kamera berada pada posisi mundur di sisi kanan-depan kamar tidur setinggi dada-mata dengan kemiringan datar, memandang serong ke kiri-tengah ruangan. Cakupan wide akhir ini menempatkan ranjang kayu berseprai putih dan jendela melengkung di sisi tengah-kanan, kursi sudut dan tanaman pot tinggi di kiri, serta dua balok kayu plafon dan lampu gantung lentera di bagian atas dalam pencahayaan alami siang dan pendaran lampu hangat.

**Shot 05 · Walk-in Closet · 14.57s**

> Kamera berada di tengah ambang masuk walk-in closet setinggi dada-mata dengan arah datar lurus membentuk perspektif satu titik simetris. Cakupan wide merangkum tiga pasang balok kayu plafon miring, lemari tanam berpencahayaan LED hangat dan laci kayu di kedua sisi, ottoman krem berkarpet pelari, serta jendela melengkung hitam yang membingkai taman berbunga di ujung ruang.

**Shot 06 · Bathroom · 19.87s**

> Kamera berada pada posisi mundur di depan area lantai kamar mandi setinggi dada-mata dengan arah datar lurus ke dinding belakang. Cakupan wide akhir ini menempatkan jendela ganda bertirai krem, bathtub oval putih, dan keranjang rotan di kiri, pohon zaitun dalam relung melengkung dan kloset di tengah, serta vanity kayu berwastafel putih, handuk wafel, dan lampu dinding hangat di kanan di atas lantai ubin terakota-krem.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Exterior Front

**Time:** 0.00–5.30s · **Duration:** 5.30s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Rumah cottage satu lantai berfasad plester krem hangat dengan atap pelana rendah berpenutup tampak genteng barrel terakota, cerobong plester putih di sisi kiri atap, serta proyeksi serambi masuk di tengah. Pintu masuk utama berupa daun pintu kayu hangat berkaca di bagian atas dalam bukaan plester agak menjorok, diapit dua jendela kotak berbingkai hitam matte lengkap dengan daun kisi gelap dan kotak bunga kayu serta satu anak tangga serambi batu krem.

**Furnitur & dekorasi**

> Tiga lentera dinding bergaya kereta berwarna hitam matte (satu di atas pintu, dua mengapit bukaan pintu), karangan bunga botani bundar tergantung di kaca pintu, serta dua gugus pot terakota dan keramik bermotif spiral berisi cemara mini dan bunga putih-oranye di kedua sisi undakan serambi.

**Lingkungan**

> Halaman rumput hijau terawat dibelah jalan setapak batu alam melengkung yang dibingkai border bunga oranye dan putih rapat. Sebatang pohon konifer besar di tepi kanan depan menjatuhkan bayangan teduh, sementara tajuk pohon berdaun keemasan, pepohonan hijau tinggi di belakang rumah, dan pagar kayu di sisi kanan jauh melengkapi suasana siang cerah.

#### **B. Framing & Lighting**

- **Fokus:** Pintu masuk utama kayu hangat di tengah serambi.
- **Camera Start:** Berdiri di ujung jalan setapak batu alam halaman depan, agak miring dari sudut kiri-depan menuju pusat serambi.; Menghadap lurus ke pintu masuk utama kayu di tengah proyeksi serambi.; Sudut tiga perempat ringan dari depan-kiri dengan garis jalan setapak memandu mata ke pintu.
- **Framing:** Framing wide menampilkan keseluruhan fasad cottage, atap genteng terakota, cerobong, halaman rumput, jalan setapak batu, dan batang pohon kanan. → Framing medium-close menyorot proyeksi serambi, pintu masuk kayu berkarangan bunga, tiga lentera hitam, dan pot-pot di kedua sisi undakan.
- **Lighting:** Cahaya matahari siang cerah dari atas-kanan dengan bayangan dedaunan lembut di rumput dan nyala hangat lentera dinding.

#### **C. Camera Movement**

Kamera meluncur maju stabil sepanjang jalan setapak batu alam dari halaman depan langsung menuju pintu masuk utama tanpa berputar berarti.

**Tempo:** Stabil dan tenang dengan laju maju konstan yang terasa mengundang masuk ke rumah.

**Camera:** Dolly-In (~2.2–2.5×).

---

<a id="shot-02"></a>

### Shot 02 · Living Room

**Time:** 5.30–8.37s · **Duration:** 3.07s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang keluarga berdinding plester krem hangat dengan relung media melengkung dangkal di dinding utama, lis profil plafon (crown molding) dan plint putih, lantai papan kayu cokelat hangat, downlight plafon tersembunyi, balok kayu ekspos di tepi kiri atas plafon, serta bukaan pintu kaca Prancis berbingkai hitam matte tinggi di dinding kiri.

**Furnitur & dekorasi**

> Sofa berlapis kain krem di sisi kanan dengan bantal dekoratif bermotif titik hitam-krem, konsol media kayu hangat berpintu panel samping dan rak tengah terbuka di bawah TV layar datar dinding, meja kopi kayu persegi bersusun rak bawah dengan buku dan vas kaca berisi ranting daun musim gugur oranye-karat, karpet lebar bermotif krem-abu, kursi aksen krem di sudut dekat pohon zaitun dalam pot, kursi/sofa krem kedua di kiri jauh, keranjang anyaman di lantai depan, dua lampu dinding hitam matte mengapit relung TV, serta tirai krem setinggi plafon.

**Lingkungan**

> Cahaya matahari siang cerah masuk menembus pintu kaca Prancis di dinding kiri membentuk pola bayangan kotak kusen di atas karpet dan lantai kayu, dengan pemandangan dedaunan hijau taman, bunga merah-oranye, dan struktur bangunan luar terang di balik kaca.

#### **B. Framing & Lighting**

- **Fokus:** Relung TV melengkung di awal, meluas menjadi area duduk utama dan bukaan cahaya di dinding kiri.
- **Camera Start:** Mulai cukup dekat di samping kanan-depan area duduk, tepat di belakang sandaran tangan sofa krem menghadap relung TV.; Mengarah sedikit serong ke dinding utama tempat relung TV dan konsol kayu berada.; Sudut tiga perempat sempit pada awal shot sebelum terbuka lebar ke kiri ruangan.
- **Framing:** Framing medium-tight menyorot relung TV melengkung, konsol kayu, dua lampu dinding hitam, dan sandaran sofa krem di kanan bawah. → Framing wide ruang keluarga menempatkan relung TV di sepertiga kanan, meja kopi dan karpet di tengah, serta pintu kaca Prancis dan pohon zaitun di sisi kiri.
- **Lighting:** Cahaya alami terarah dari pintu kaca kiri dipadu cahaya lembut downlight plafon tanpa silau berlebih.

#### **C. Camera Movement**

Kamera bergerak mundur sambil menoleh ke kiri secara bersamaan untuk membuka keseluruhan ruang keluarga dari fokus relung TV hingga pintu kaca Prancis.

**Tempo:** Halus dan konstan dengan bukaan ruang yang bertahap dan seimbang hingga akhir shot.

**Camera:** Dolly-Out (~1.6–1.9×) + Pan Left (~15–20°).

---

<a id="shot-03"></a>

### Shot 03 · Kitchen

**Time:** 8.37–11.53s · **Duration:** 3.17s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dapur kompak berbentuk L yang dibingkai bukaan dinding plester putih bertekstur di tepi kanan depan dan balok header kayu gelap di atas. Plafon putih datar dilengkapi downlight tersembunyi, lantai papan kayu hangat, jendela melengkung berbingkai hitam matte berkisi kotak di atas wastafel dinding belakang, serta backsplash plester terang bertekstur halus di dinding kompor.

**Furnitur & dekorasi**

> Kabinet atas dan bawah bergaya shaker warna krem dengan pegangan batang hitam matte dan lis mahkota atas, meja kerja tampilan batu putih berurat lembut, meja semenanjung/pulau di kiri depan dengan dua bangku bar kayu dudukan bundar, wastafel farmhouse apron putih, mesin cuci piring stainless steel, kompor gas oven ganda stainless steel dengan panci Dutch oven krem di atasnya, cooker hood cerobong stainless steel, dua rak kayu melayang di dinding kanan dengan tanaman pot dan tumpukan piring, dua lampu gantung silinder krem di atas meja semenanjung, karpet pelari anyaman jute, mangkuk keramik berisi jeruk, serta talenan kayu.

**Lingkungan**

> Cahaya siang alami masuk lembut dari jendela melengkung berbingkai hitam di dinding belakang, berpadu dengan cahaya hangat downlight plafon dan lampu kerja di bawah cooker hood.

#### **B. Framing & Lighting**

- **Fokus:** Kompor gas stainless steel dan cooker hood di dinding kanan.
- **Camera Start:** Berada tepat di ambang bukaan masuk dapur, sedikit ke kiri dari tepi dinding plester putih kanan depan.; Menghadap serong masuk ke sudut L dapur antara wastafel berjendela melengkung dan zona kompor stainless steel.; Sudut diagonal perspektif satu-dua titik yang menampakkan meja semenanjung depan sekaligus dinding belakang dan kanan.
- **Framing:** Framing wide dapur merangkum meja semenanjung berbangku kayu, pendant, jendela melengkung, wastafel, kabinet shaker krem, dan kompor. → Framing medium-close menyorot kompor gas stainless steel, panci putih, cooker hood, kabinet krem sudut, dan rak kayu melayang.
- **Lighting:** Perpaduan cahaya siang lembut dari jendela melengkung dengan downlight plafon dan lampu hangat di bawah hood.

#### **C. Camera Movement**

Kamera meluncur maju memasuki dapur melewati meja semenanjung sambil menoleh lembut ke kanan ke arah kompor gas dan rak kayu melayang.

**Tempo:** Halus dan konstan tanpa hentakan saat berpindah dari tampilan penuh dapur ke detail area kompor.

**Camera:** Dolly-In (~1.7–2.0×) + Pan Right (~12–18°).

---

<a id="shot-04"></a>

### Shot 04 · Bedroom

**Time:** 11.53–14.57s · **Duration:** 3.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar tidur berdinding cat hijau sage lembut matte dengan plafon putih datar yang diperkuat dua balok kayu cokelat hangat ekspos, lantai kayu hangat berkarpet krem, jendela melengkung berbingkai hitam matte berkisi kotak terpusat tepat di atas kepala ranjang dengan ambang jendela dalam, serta jendela sekunder bertirai krem pada dinding kiri jauh.

**Furnitur & dekorasi**

> Ranjang kayu cokelat sedang berkepala dan kaki ranjang berpanel dengan seprai putih berjahit kuilt, selimut rajut tebal krem, bantal krem berlapis, dan satu bantal aksen terakota bertekstur; dua nakas kayu tiga laci bergagang hitam matte mengapit ranjang; lampu meja keramik putih di nakas kiri; dua lampu dinding hitam-kuningan mengapit jendela; lampu gantung lentera kaca berbingkai logam di plafon; tirai krem pada batang besi hitam; kursi berlengan krem di sudut kiri-belakang bersama tanaman pot tinggi dan lukisan relief krem berbingkai; vas bunga persik-merah muda di nakas kanan; serta tepi lemari laci kayu di kiri bawah depan.

**Lingkungan**

> Pepohonan hijau cerah bermandikan sinar matahari terlihat jelas di balik jendela melengkung belakang, dihiasi deretan tanaman bunga merah muda-koral di ambang jendela, berpadu pendaran hangat lampu meja, lampu dinding, dan lampu gantung.

#### **B. Framing & Lighting**

- **Fokus:** Kepala ranjang dan jendela melengkung di awal, meluas ke keseluruhan tata ruang kamar tidur.
- **Camera Start:** Mulai cukup dekat di samping kanan-depan ranjang, sejajar dengan nakas kanan menghadap bantal dan jendela melengkung.; Menghadap serong ke kepala ranjang dan jendela melengkung di dinding hijau sage.; Sudut tiga perempat sempit di awal yang kemudian melebar membuka sisi kiri kamar tidur.
- **Framing:** Framing medium-tight menyorot bagian kepala ranjang, bantal aksen terakota, jendela melengkung berbunga koral, dan tepi nakas kanan. → Framing wide kamar tidur merangkum ranjang utuh, kedua nakas, sudut baca berkursi dan tanaman, dua balok kayu plafon, dan lampu gantung lentera.
- **Lighting:** Cahaya alami siang cerah dari jendela melengkung dan jendela kiri berpadu pendaran hangat tiga lapis lampu kamar.

#### **C. Camera Movement**

Kamera bergerak mundur sambil menoleh lembut ke kiri untuk membuka keseluruhan kamar tidur dari detail kepala ranjang hingga sudut kursi, lampu gantung, dan balok plafon.

**Tempo:** Tenang dan konstan dengan pembukaan ruang yang lapang hingga akhir shot.

**Camera:** Dolly-Out (~1.5–1.8×) + Pan Left (~10–15°).

---

<a id="shot-05"></a>

### Shot 05 · Walk-in Closet

**Time:** 14.57–17.10s · **Duration:** 2.53s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Walk-in closet memanjang simetris berdinding plester krem hangat dengan plafon katedral miring yang diperkuat tiga pasang balok/kaso kayu ekspos dan downlight plafon, lantai papan kayu hangat, serta satu jendela melengkung tinggi berbingkai hitam matte berkisi kotak dengan ambang jendela dalam di dinding ujung tengah.

**Furnitur & dekorasi**

> Sistem lemari tanam terbuka dua sisi berwarna krem dengan gantungan pakaian dua tingkat dan strip lampu LED hangat tersembunyi, laci-laci kayu hangat bergagang hitam matte di sepanjang sisi kanan, keranjang anyaman penyimpanan di rak atas dan relung dinding samping, bangku ottoman penyimpanan kotak berlapis kain krem di atas karpet pelari anyaman krem, guci keramik abu berisi rangkaian bunga putih di lantai kanan jendela, mangkuk anyaman dan pot kecil di ambang jendela, serta koleksi pakaian bernuansa tanah (terakota, zaitun, krem, cokelat) tergantung rapi.

**Lingkungan**

> Pemandangan luar siang cerah melalui jendela melengkung memperlihatkan bunga oranye-merah dan rambatan bunga merah muda cerah serta bangunan tetangga berdinding krem beratap genteng terakota di bawah langit biru.

#### **B. Framing & Lighting**

- **Fokus:** Jendela melengkung berbingkai hitam di tengah dinding ujung.
- **Camera Start:** Berada tepat di sumbu tengah ambang masuk walk-in closet di antara kusen pintu gelap kiri dan rak kanan.; Menghadap lurus ke depan menyusuri lorong menuju jendela melengkung di dinding ujung.; Perspektif satu titik simetris (one-point perspective) yang kuat dan rapi.
- **Framing:** Framing wide lorong menampilkan tiga pasang balok plafon miring, lemari dua sisi penuh, ottoman krem, karpet pelari, dan jendela ujung. → Framing medium-close menyorot jendela melengkung berbingkai hitam, relung penyimpanan di kiri-kanan jendela, bunga putih, dan tepi atas ottoman.
- **Lighting:** Perpaduan cahaya siang cerah dari jendela ujung dengan cahaya hangat LED rak lemari dan downlight plafon.

#### **C. Camera Movement**

Kamera meluncur maju lurus menyusuri sumbu tengah walk-in closet menuju jendela melengkung tanpa berputar ke kiri atau kanan.

**Tempo:** Stabil dan terukur dengan simetri perspektif yang konsisten sepanjang lintasan.

**Camera:** Dolly-In (~1.6–1.9×).

---

<a id="shot-06"></a>

### Shot 06 · Bathroom

**Time:** 17.10–19.90s · **Duration:** 2.80s

![Kolase Shot 06](media/shot-06.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi berdinding plester krem lembut dengan relung dinding melengkung berlapis ubin kotak kecil abu-abu lembut di sisi kanan bathtub, plafon putih beraksen balok kayu ekspos di atas jendela, lantai ubin persegi bernuansa terakota-krem hangat, serta jendela ganda persegi berbingkai hitam matte berkisi kotak lengkap dengan tirai krem setinggi plafon di dinding belakang.

**Furnitur & dekorasi**

> Bathtub freestanding putih oval di bawah jendela dilengkapi keran dinding hitam matte dan baki kayu berisi botol sabun amber serta lilin; pohon zaitun dalam pot putih berbatu koral berdiri di dalam relung melengkung di bawah rak kayu kecil; kloset duduk keramik putih di depan relung; meja wastafel (vanity) kayu cokelat hangat berpintu panel dengan gagang hitam matte, baskom wastafel apron putih tinggi, keran hitam matte, cermin berbingkai hitam, cincin handuk berhanduk wafel krem, dan lampu dinding kaca-kuningan di dinding kanan; serta keranjang anyaman rotan berisi handuk putih gulung dan tanaman hijau di lantai kiri depan.

**Lingkungan**

> Cahaya siang cerah menembus jendela ganda berbingkai hitam dengan pemandangan bunga oranye cerah, dedaunan hijau, dan fasad bangunan tetangga beratap terakota di luar, berpadu sinar hangat lampu dinding di dekat cermin.

#### **B. Framing & Lighting**

- **Fokus:** Bathtub freestanding dan pohon zaitun dalam relung, meluas ke keseluruhan kamar mandi.
- **Camera Start:** Mulai cukup dekat di samping kloset dan tepi wastafel, menghadap langsung ke bathtub oval, jendela, dan pohon zaitun di relung.; Menghadap lurus ke dinding belakang antara jendela ganda dan relung pohon zaitun.; Sudut frontal-ringan yang semula sempit di sisi bathtub lalu membuka kedua sisi ruangan secara simetris.
- **Framing:** Framing medium-tight menyorot sisi kanan bathtub oval, sebagian jendela hitam, pohon zaitun di relung ubin, dan tepi atas kloset. → Framing wide kamar mandi merangkum jendela ganda bertirai penuh dan bathtub di kiri, pohon zaitun serta kloset di tengah, dan vanity kayu berlampu dinding di kanan.
- **Lighting:** Cahaya siang terang masuk lewat jendela belakang diimbangi pendaran hangat lampu dinding kaca di sisi kanan.

#### **C. Camera Movement**

Kamera bergerak mundur lurus dari area bathtub dan pohon zaitun untuk membuka keseluruhan kamar mandi termasuk lantai ubin, keranjang handuk kiri, dan vanity kayu di kanan.

**Tempo:** Stabil dan tenang sebagai penutup video yang membuka ruang secara merata ke kedua sisi.

**Camera:** Dolly-Out (~1.6–1.9×).
