# edh058 — Cottage Mediterania Fasad Plester Krem & Atap Genteng Terakota

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Cottage Mediterania Fasad Plester Krem & Atap Genteng Terakota
- **Gaya utama:** **Mediterranean Cottage**
- **Pengaruh gaya:** Spanish Revival; Warm Organic Modern
- **Gaya interior:** Mediterranean Organic Modern
- **Ciri khas:** Fasad plester krem hangat satu lantai dengan serambi pintu masuk menonjol beratap pelana genteng barel terakota dan tiga lentera dinding hitam; Jendela lengkung (arched) berbingkai hitam berkisi yang berulang di dapur, kamar tidur, dan ujung lorong walk-in closet; Ceruk dinding lengkung (arched niche) sebagai bingkai TV di ruang tamu dan tempat pohon zaitun di kamar mandi; Balok kayu ekspos hangat pada plafon datar (living room, bedroom, bathroom) dan plafon miring (vaulted ceiling) di walk-in closet
- **Warna & material:** Plester krem hangat pada fasad dan dinding interior, aksen hitam matte pada kusen jendela, shutter, lentera, serta keran; kayu cokelat madu/oak hangat pada pintu, kabinet, balok plafon, dan furnitur; genteng terakota dan aksen bunga/bantal oranye-karat; serta tekstil putih gading dan krem lembut
- **Suasana dan lingkungan:** Hunian cottage satu lantai yang hangat, intim, dan terang alami, dikelilingi halaman rumput hijau, pohon tinggi rindang, bed bunga oranye-merah-putih, serta bangunan tetangga beratap genteng yang tampak dari jendela interior

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Massa bangunan satu lantai kompak dengan volume utama rendah, proyeksi serambi masuk beratap pelana di tengah fasad depan, dan cerobong asap di sisi kiri atap |
| **Lantai & bentuk atap** | Satu lantai yang terlihat dari eksterior maupun seluruh ruang interior, tanpa tangga atau indikasi lantai kedua |
| **Tapak bangunan** | Tapak kompak persegi panjang/L sederhana pada lahan taman berumput, dengan lima ruang interior berbeda yang diperlihatkan secara terpisah |
| **Proporsi utama** | Proporsi cottage akrab dan manusiawi dengan ketinggian plafon interior sedang (~2.6–3.0 m, lebih tinggi pada plafon miring walk-in closet) serta bukaan jendela vertikal tinggi yang menyeimbangkan lebar ruang |
| **Perkiraan luas lantai** | **65–95 m²** |

## 3. Shot Timeline

Video terdiri dari 6 shot terpisah dengan hard cut bersih tanpa transisi lintas ruang; pola kedalaman kamera berselang-seling sempurna antara gerak maju (IN) dan mundur (OUT) dengan tempo moderate yang konsisten di seluruh durasi 19.90 detik.

**Camera Pattern:** IN – OUT – IN – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–5.30 | 5.30s | Exterior Front Facade | Dolly-In (~2.2×) toward wooden front door |
| 02 | 5.30–8.37 | 3.07s | Living Room | Dolly-Out (~1.4×) + Pan Left (~25–30°) |
| 03 | 8.37–11.53 | 3.17s | Kitchen | Dolly-In (~1.6×) + Pan Right (~15–20°) toward gas range and stainless range hood |
| 04 | 11.53–14.57 | 3.03s | Bedroom | Dolly-Out (~1.6×) + Pan Left (~15–20°) |
| 05 | 14.57–17.10 | 2.53s | Walk-in Closet | Dolly-In (~1.7×) toward arched end window |
| 06 | 17.10–19.90 | 2.80s | Bathroom | Dolly-Out (~1.8–2.0×) |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Exterior Front Facade · 0.00s**

> Kamera berada di halaman depan pada posisi eye-level datar dengan sudut three-quarter ringan dari sisi depan-kanan mengarah lurus ke serambi pintu masuk kayu. Cakupan wide memperlihatkan keseluruhan fasad cottage satu lantai berplester krem dan atap genteng terakota bersama cerobong asap kiri, kedua jendela shutter hitam, jalan setapak batu alam melengkung di tengah rumput, serta batang pohon besar di sisi kanan. Kedalaman berlapis dari taman bunga dan rumput depan ke fasad rumah hingga kanopi pepohonan latar diterangi cahaya siang alami yang terang dan merata.

**Shot 02 · Living Room · 8.33s**

> Kamera berada di sudut belakang-kanan ruang tamu pada ketinggian eye-level datar menghadap serong ke depan-kiri melintasi area duduk. Cakupan wide memperlihatkan pintu kaca Prancis berkisi hitam dan sofa kiri, meja kopi kayu persegi di tengah karpet bermotif, kursi aksen dan pohon zaitun di sudut belakang, sofa kanan dengan keranjang anyaman di depan, balok kayu plafon atas, serta ceruk lengkung TV dan kabinet media di sisi kanan. Cahaya siang lembut dari bukaan kiri berpadu dengan pencahayaan plafon hangat menciptakan kedalaman ruang yang terang dan akrab.

**Shot 03 · Kitchen · 8.37s**

> Kamera berdiri di ambang masuk dapur pada ketinggian eye-level datar menghadap lurus-serong menyusuri lorong kerja dapur. Cakupan wide merangkum meja semenanjung marmer dan dua bangku bar kayu di kiri bawah di bawah dua lampu gantung silinder, jendela lengkung berkisi hitam di atas bak cuci apron di dinding belakang, serta deretan kabinet shaker krem, kompor gas stainless, tudung hisap cerobong, dan rak kayu apung di sisi kanan. Kedalaman lorong berkarpet runner diterangi kombinasi cahaya siang jendela belakang dan lampu bawah kabinet hangat.

**Shot 04 · Bedroom · 14.53s**

> Kamera berada di sudut depan-kanan kamar tidur pada ketinggian eye-level datar menghadap serong melintasi ruangan. Cakupan wide merangkum tempat tidur kayu ber-footboard dan karpet krem di kanan-tengah, jendela lengkung berkisi hitam bertirai krem di belakang kepala tempat tidur, nakas kiri dengan lampu meja, lukisan relief, tanaman hijau tinggi, kursi baca sudut kiri, jendela samping kiri, ujung lemari kayu di kiri bawah, serta lampu gantung lentera kaca di antara dua balok kayu plafon. Cahaya siang dari dua jendela berpadu lembut dengan lapisan lampu hangat di seluruh kamar.

**Shot 05 · Walk-in Closet · 14.57s**

> Kamera berdiri di sumbu tengah ambang pintu walk-in closet pada ketinggian eye-level datar dengan perspektif satu titik simetris mengarah lurus ke jendela lengkung ujung. Cakupan wide memperlihatkan kusen pintu gelap di tepi kiri-kanan, plafon miring (vaulted) berbalok kayu ekspos dengan downlight, rel gantung pakaian dua susun di dinding kiri, lemari laci kayu dan rak terbuka putih berkeranjang di sisi kanan, serta ottoman krem di atas karpet tenun. Cahaya siang dari jendela lengkung berpadu dengan lampu rak hangat menciptakan kedalaman lorong yang rapi dan terang.

**Shot 06 · Bathroom · 19.87s**

> Kamera berada dekat ambang pintu kamar mandi pada ketinggian eye-level datar menghadap lurus ke dinding belakang secara seimbang. Cakupan wide merangkum bathtub freestanding oval di bawah jendela dua daun berkisi hitam bertirai krem, ceruk lengkung berubin abu-abu berisi pohon zaitun, kloset putih di kanan-tengah, meja wastafel kayu lengkap dengan bak wastafel, cermin berbingkai hitam, handuk gantung, dan lampu dinding di sisi kanan, keranjang tanaman di kiri bawah, lantai ubin terakota, serta dua balok kayu di plafon. Cahaya siang dari jendela belakang berpadu dengan cahaya lampu dinding hangat menonjolkan tekstur alami ruang.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Exterior Front Facade

**Time:** 0.00–5.30s · **Duration:** 5.30s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Rumah cottage satu lantai berdinding plester krem hangat dengan serambi pintu masuk menonjol beratap pelana landai dan genteng barel terakota berujung kasau kayu ekspos. Di sisi kiri atap berdiri cerobong asap plester krem, sementara fasad kiri dan sisi kanan serambi dilengkapi jendela kotak berkisi hitam dengan daun shutter kayu hitam dan kotak bunga kayu di bawahnya. Pintu masuk tunggal tampak kayu cokelat hangat dengan panel kaca bagian atas berada di dalam ceruk dangkal di atas satu anak tangga teras batu krem.

**Furnitur & dekorasi**

> Tiga lentera dinding hitam berkaca terpasang simetris di atas dan kiri-kanan pintu masuk, sementara pintu dihiasi karangan dedaunan hijau (wreath). Kiri dan kanan teras diapit kelompok pot terakota polos dan bermotif spiral berisi cemara mini serta tanaman hijau berbunga putih, disertai tanaman cemara tinggi ramping di sudut kanan teras.

**Lingkungan**

> Halaman depan berumput hijau rapi dibelah jalan setapak batu alam (flagstone) melengkung dari kiri bawah menuju teras, diapit bed bunga warna oranye, merah muda, dan putih. Pohon tinggi berbatang besar berdiri di kanan depan di sebelah pagar kayu vertikal, sementara tajuk pohon rimbun hijau dan kuning keemasan membingkai latar belakang di bawah cahaya siang cerah merata.

#### **B. Framing & Lighting**

- **Fokus:** Pintu masuk kayu dan serambi menonjol pada pusat bingkai
- **Camera Start:** Di halaman depan pada sisi depan-kanan jalan setapak, berjarak cukup jauh untuk menangkap keseluruhan fasad cottage, rumput, dan pohon besar di sisi kanan; Mengarah lurus ke serambi dan pintu masuk kayu di tengah fasad; Three-quarter ringan dari depan-kanan sehingga fasad depan dan dinding sisi kanan serambi sama-sama terlihat
- **Framing:** Establishing wide shot vertikal halaman depan dan keseluruhan fasad cottage satu lantai dengan jalan setapak batu alam memandu mata menuju pintu kayu di tengah → Medium-tight shot serambi masuk yang memenuhi bingkai dari atap pelana terakota dan lentera atas hingga undakan teras dan pot terakota kiri-kanan
- **Lighting:** Cahaya siang alami cerah dengan bayangan lembut pepohonan di rumput, diperhangat nyala lembut tiga lentera dinding

#### **C. Camera Movement**

Kamera bergerak maju lurus dengan mulus dari halaman depan melintasi jalan setapak batu alam mendekati teras dan pintu masuk kayu hingga serambi memenuhi bingkai, tanpa putaran arah pandang berarti.

**Tempo:** Gerak maju berlangsung stabil dengan tempo sedang (moderate) dan laju konstan sepanjang 5.30 detik sebagai pembuka tur yang tenang.

**Camera:** Dolly-In (~2.2×) toward wooden front door

---

<a id="shot-02"></a>

### Shot 02 · Living Room

**Time:** 5.30–8.37s · **Duration:** 3.07s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang tamu berdinding plester krem hangat dengan lis profil plafon (crown molding), plint putih di lantai, balok kayu ekspos melintang di plafon bagian kiri-depan, dan lampu downlight tanam. Dinding utama di kanan-tengah memiliki ceruk lengkung dangkal (arched TV niche) untuk layar TV, sementara dinding kiri memiliki bukaan pintu kaca Prancis ganda berbingkai hitam berkisi yang menghadap langsung ke taman luar. Lantai tampak papan kayu cokelat hangat yang sebagian besar ditutup karpet tenun bermotif lembut.

**Furnitur & dekorasi**

> Di dalam ceruk lengkung berdiri kabinet media kayu cokelat madu berpintu panel kiri-kanan dan rak terbuka tengah berisi keranjang anyaman, dihiasi buku berdiri di kiri dan pot hijau di kanan, serta diapit dua lentera dinding hitam berkaca. Area duduk membentuk konfigurasi L/menghadap tengah: sofa kain krem berbantal motif bintik-bintik di sisi kanan-depan dengan keranjang anyaman bundar di samping lengannya, sofa krem kedua berbantal aksen terakota di sisi kiri depan pintu kaca, kursi aksen berbingkai hitam berkain krem di sudut kiri-belakang dekat pohon zaitun pot, dan meja kopi kayu persegi berkaki tebal di tengah dengan buku tumpuk serta vas kaca berisi dedaunan oranye kering. Tirai panjang krem tergantung pada batang besi hitam membingkai pintu kaca kiri.

**Lingkungan**

> Melalui pintu kaca Prancis berkisi hitam di dinding kiri tampak halaman taman terang alami dengan bunga warna merah-oranye, dedaunan hijau, serta sebagian bangunan beratap genteng di latar luar.

#### **B. Framing & Lighting**

- **Fokus:** Bergeser dari ceruk TV dan kabinet media menuju keseluruhan tata ruang tamu dan bukaan taman kiri
- **Camera Start:** Berada dekat di belakang/samping sandaran sofa kanan-depan pada sudut dalam ruang tamu; Menghadap serong ke depan-kanan menuju ceruk lengkung TV dan kabinet media kayu; Sudut oblique ringan dari samping belakang sofa kanan
- **Framing:** Medium-tight shot mengarah ke ceruk TV dan kabinet media kayu dengan sandaran sofa krem mengisi sudut kanan bawah → Wide shot sudut ruang tamu yang merangkum pintu kaca taman dan sofa kiri, meja kopi persegi di tengah karpet, kursi aksen dan pohon zaitun di sudut belakang, serta ceruk TV di sisi kanan
- **Lighting:** Cahaya siang lembut masuk dari pintu kaca kiri menyinari karpet dan meja kopi, dibantu downlight plafon hangat

#### **C. Camera Movement**

Kamera bergerak mundur menjauhi ceruk TV sambil memutar arah pandang ke kiri secara bersamaan sehingga meja kopi, kursi sudut, pohon zaitun, sofa kiri, dan pintu kaca taman terbuka utuh.

**Tempo:** Gerak mundur dan putaran ke kiri berlangsung serempak dengan tempo sedang (moderate) dan laju konstan sepanjang 3.07 detik.

**Camera:** Dolly-Out (~1.4×) + Pan Left (~25–30°)

---

<a id="shot-03"></a>

### Shot 03 · Kitchen

**Time:** 8.37–11.53s · **Duration:** 3.17s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dapur kompak berbentuk L dengan lorong kerja di antara meja semenanjung/island kecil di kiri-depan dan deretan kabinet utama di dinding belakang-kanan. Di ambang masuk tampak dinding plester putih bertekstur kasar di tepi kanan dan balok kayu melintang di plafon atas; dinding belakang kiri memiliki jendela lengkung (arched) berbingkai hitam berkisi di atas bak cuci, sementara backsplash memakai tekstur plester/batu krem lembut dan lantai tampak papan kayu cokelat hangat.

**Furnitur & dekorasi**

> Kabinet dapur bergaya shaker warna krem hangat dengan tarikan hitam matte dan lis mahkota atas menampung meja kerja tampak marmer putih berurat halus. Perlengkapan utama meliputi bak cuci apron putih di bawah jendela lengkung, mesin pencuci piring (dishwasher) stainless di kanannya, keran leher angsa hitam di sudut kanan bak cuci, kompor gas freestanding stainless dengan oven ganda dan panci krem bertutup di atas tungku, serta tudung hisap (range hood) cerobong stainless. Di sisi kanan tudung hisap terpasang dua rak kayu apung berisi tanaman hijau pot, kaktus mini, dan tumpukan piring; di depan kiri berdiri semenanjung bermeja sama dengan dua bangku bar kayu bundar, dua lampu gantung silinder krem di atasnya, talenan dan serbet, karpet runner anyaman di lantai, serta mangkuk putih berisi jeruk segar di meja kanan.

**Lingkungan**

> Melalui jendela lengkung berkisi hitam di dinding belakang tampak cahaya siang terang dan siluet dedaunan hijau taman luar, dengan pot bunga merah diletakkan di ambang jendela.

#### **B. Framing & Lighting**

- **Fokus:** Bergeser dari keseluruhan lorong dapur menuju area kompor gas dan tudung hisap stainless di dinding kanan
- **Camera Start:** Di ambang masuk dapur sedikit di luar bukaan plester kanan-depan, sejajar koridor kerja; Mengarah masuk ke dalam dapur menuju dinding belakang berjendela lengkung dan deretan kabinet kanan; Perspektif satu titik serong ringan melihat lorong dapur dan sisi kanan kompor
- **Framing:** Wide shot dari ambang masuk yang menampilkan keseluruhan layout dapur bentuk L, semenanjung dua bangku, lampu gantung, jendela lengkung belakang, dan deretan kompor kanan → Medium-tight shot miring pada area memasak kanan yang menampilkan kabinet atas shaker, keran sudut, kompor gas stainless dengan panci krem, tudung hisap cerobong, rak kayu apung, dan mangkuk jeruk
- **Lighting:** Perpaduan cahaya siang dari jendela lengkung belakang dengan downlight plafon, lampu gantung, serta lampu bawah kabinet dan bawah tudung hisap yang menyinari backsplash hangat

#### **C. Camera Movement**

Kamera bergerak maju dari ambang masuk ke dalam lorong dapur sambil memutar arah pandang ke kanan mendekati kompor gas, tudung hisap stainless, dan rak kayu apung.

**Tempo:** Gerak maju dan putaran ke kanan berjalan serempak dengan tempo sedang (moderate) dan laju konstan selama 3.17 detik.

**Camera:** Dolly-In (~1.6×) + Pan Right (~15–20°) toward gas range and stainless range hood

---

<a id="shot-04"></a>

### Shot 04 · Bedroom

**Time:** 11.53–14.57s · **Duration:** 3.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar tidur berdinding warna abu-hijau lembut (muted sage/greige) dengan plafon krem berpangkal dua balok kayu ekspos melintang. Dinding belakang tempat tidur memiliki jendela lengkung (arched) berbingkai hitam berkisi yang dibingkai tirai panjang krem pada batang besi hitam, sementara dinding kiri memperlihatkan sebagian bukaan jendela kedua bertirai krem. Lantai tampak papan kayu pucat sebagian besar tertutup karpet krem polos bertekstur di sekitar tempat tidur.

**Furnitur & dekorasi**

> Tempat tidur rangka kayu cokelat hangat dengan headboard dan footboard berpanel bilah kayu berdiri membelakangi jendela lengkung, ditata dengan selimut putih berjahit lembut, selimut rajut krem di bagian kaki, deretan bantal krem, serta satu bantal aksen terakota bertekstur di tengah. Kedua sisi tempat tidur diapit nakas kayu berlaci dengan gagang hitam: nakas kanan dihiasi vas krem berisi bunga pastel, sedangkan nakas kiri menopang lampu meja berkap putih di bawah bingkai relief dinding putih. Dua lampu dinding (sconce) hitam bergaya lengan lengkung menyala hangat di kiri-kanan tirai jendela, ditambah lampu gantung lentera kaca berbingkai kayu/logam di plafon, kursi baca berlapis kain krem berbantal terakota bersama tanaman pot tinggi di sudut kiri belakang, serta tepi lemari/meja laci kayu di kiri depan bawah.

**Lingkungan**

> Di luar jendela lengkung terlihat kotak bunga merah-oranye cerah di ambang luar serta rimbun dedaunan hijau taman di bawah cahaya siang terang.

#### **B. Framing & Lighting**

- **Fokus:** Bergeser dari kepala tempat tidur dan jendela lengkung menuju keseluruhan tata ruang kamar tidur dan sudut baca kiri
- **Camera Start:** Berada dekat di sisi kanan-depan tempat tidur menghadap kepala ranjang dan jendela lengkung; Mengarah serong ke belakang-kanan menuju jendela lengkung dan kepala tempat tidur; Three-quarter dekat dari sisi kaki/samping tempat tidur
- **Framing:** Medium-tight shot kepala tempat tidur, bantal terakota, nakas kanan, dan jendela lengkung berkisi hitam yang mengisi bidang tengah-atas → Wide shot kamar tidur yang menampilkan seluruh tempat tidur dan karpet krem di kanan-tengah, sudut baca dan tanaman di kiri, jendela lengkung di kanan-belakang, serta lampu gantung dan dua balok kayu di plafon
- **Lighting:** Cahaya siang lembut dari jendela lengkung dan jendela kiri berpadu dengan nyala hangat lampu dinding hitam, lampu meja, dan lampu gantung kaca

#### **C. Camera Movement**

Kamera bergerak mundur menjauhi tempat tidur dan jendela lengkung sambil memutar pandangan ke kiri sehingga footboard kayu, karpet, sudut baca, jendela kiri, lampu gantung, dan dua balok kayu plafon terbuka utuh.

**Tempo:** Gerak mundur dan putaran ke kiri berjalan serempak dengan tempo sedang (moderate) dan laju konstan selama 3.03 detik.

**Camera:** Dolly-Out (~1.6×) + Pan Left (~15–20°)

---

<a id="shot-05"></a>

### Shot 05 · Walk-in Closet

**Time:** 14.57–17.10s · **Duration:** 2.53s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Walk-in closet berbentuk lorong simetris memanjang dengan langit-langit miring (vaulted ceiling) yang dipertegas empat pasang balok kayu ekspos dan downlight tanam. Dinding plester krem berujung pada satu jendela lengkung tinggi berbingkai hitam berkisi dalam ceruk dinding tebal di pusat sumbu, diapit ceruk rak dinding (recessed shelves) kecil di sisi kanan jendela. Pada awal shot terlihat kusen pintu gelap di kedua tepi ambang masuk, sedangkan lantai tampak papan kayu pucat dengan karpet tenun krem di bagian tengah lorong.

**Furnitur & dekorasi**

> Penyimpanan pakaian tertata dua tingkat di kedua sisi lorong: sisi kiri memiliki rel gantung logam hitam dua susun berisi pakaian bernuansa hangat (oranye, krem, hijau zaitun, cokelat) di bawah rak atas berkeranjang anyaman, sedangkan sisi kanan memadukan lemari laci kayu cokelat madu bertarikan hitam dengan meja atas putih, rak gantung pakaian berlampu LED tersembunyi, serta rak terbuka putih atas berisi keranjang anyaman seragam. Di lantai tengah agak ke kiri berdiri bangku ottoman persegi berlapis kain krem, sementara kendi/vas logam pucat berisi rangkaian bunga putih berdiri di sudut kanan bawah jendela, dan keranjang kecil serta pot kecil tertata di ambang jendela.

**Lingkungan**

> Melalui jendela lengkung tinggi di ujung lorong terlihat taman terang berbunga oranye dan merah muda/merah (tampak bougainvillea/bunga merambat) serta dinding dan atap genteng bangunan sebelah di bawah langit biru cerah.

#### **B. Framing & Lighting**

- **Fokus:** Jendela lengkung berkisi hitam pada titik hilang tengah lorong
- **Camera Start:** Tepat di ambang pintu masuk walk-in closet pada sumbu tengah lorong; Mengarah lurus ke depan menyusuri sumbu lorong menuju jendela lengkung ujung; Perspektif satu titik simetris (one-point centered perspective)
- **Framing:** Wide shot simetris dari ambang pintu yang menangkap penuh plafon miring berbalok kayu, kedua dinding lemari pakaian, ottoman, karpet, dan jendela lengkung ujung → Medium-tight shot simetris berfokus pada jendela lengkung ujung, rak pakaian kiri belakang, ceruk rak dinding kanan, vas bunga putih, dan bagian atas ottoman di kiri bawah
- **Lighting:** Cahaya siang terang masuk dari jendela lengkung ujung, diseimbangkan downlight plafon dan lampu strip hangat tersembunyi di dalam rak lemari kanan

#### **C. Camera Movement**

Kamera bergerak maju lurus sepanjang sumbu tengah lorong walk-in closet melewati ambang pintu dan ottoman menuju jendela lengkung di ujung tanpa putaran berarti.

**Tempo:** Gerak maju berlangsung lurus dan mulus dengan tempo sedang (moderate) dan laju konstan selama 2.53 detik.

**Camera:** Dolly-In (~1.7×) toward arched end window

---

<a id="shot-06"></a>

### Shot 06 · Bathroom

**Time:** 17.10–19.90s · **Duration:** 2.80s

![Kolase Shot 06](media/shot-06.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi berdinding plester krem hangat dengan dua balok kayu ekspos melintang di plafon datar dan downlight tanam. Dinding belakang kiri memiliki jendela dua daun berbingkai hitam berkisi bertirai panjang krem, sementara dinding kanan-belakang memiliki ceruk lengkung tinggi (arched niche) berpelapis ubin kotak kecil abu-abu pucat pada bagian bawah dindingnya dan rak kayu kecil di bagian atas ceruk. Lantai menggunakan ubin kotak warna terakota/batu pasir hangat dengan keset tenun kecil di dekat pintu, dan tepi kusen pintu kayu gelap tampak di tepi kiri pada akhir shot.

**Furnitur & dekorasi**

> Di bawah jendela berdiri bathtub freestanding putih berbentuk oval dilengkapi keran dinding hitam matte serta baki kayu (bath caddy) berisi botol sabun kuning-amber dan stoples kecil. Di depan ceruk lengkung berdiri pohon zaitun tinggi dalam pot silinder putih bertabur kerikil, disusul kloset duduk putih dua bagian di depan-kanannya. Pada dinding kanan berdiri meja wastafel (vanity) kayu cokelat hangat berpintu panel dan laci bertarikan hitam dengan bak wastafel putih menonjol dan keran hitam, dilengkapi cermin berbingkai hitam melengkung di atasnya, lampu dinding kaca berbingkai hitam, serta gantungan cincin hitam dengan handuk krem berumbai. Keranjang anyaman bundar berisi handuk putih dan tanaman pot hijau berdiri di lantai kiri depan dekat bathtub, sedangkan area shower terpisah tidak terlihat dalam bingkai.

**Lingkungan**

> Melalui jendela dua daun berkisi hitam di dinding belakang tampak rangkaian bunga oranye terang di ambang luar, dedaunan hijau, serta sebagian bangunan beratap genteng terakota di bawah cahaya siang cerah.

#### **B. Framing & Lighting**

- **Fokus:** Bathtub freestanding di bawah jendela hitam dan keseluruhan tata letak kamar mandi yang terbuka seimbang
- **Camera Start:** Di tengah ruang kamar mandi agak dekat dengan sisi bathtub dan pohon zaitun; Mengarah lurus ke dinding belakang tempat bathtub freestanding, jendela hitam, dan ceruk pohon zaitun berada; Frontal hampir simetris ke dinding belakang
- **Framing:** Medium-tight shot yang membingkai sisi kanan bathtub dan baki kayu, separuh kanan jendela hitam, pohon zaitun dalam ceruk lengkung, serta tepi atas kloset di kanan bawah → Wide shot kamar mandi dari dekat ambang pintu yang menampilkan utuh bathtub di bawah jendela hitam, pohon zaitun dan kloset di tengah-kanan, vanity kayu lengkap dengan cermin dan lampu dinding di kanan, keranjang tanaman di kiri bawah, lantai terakota, dan dua balok kayu di plafon
- **Lighting:** Cahaya siang terang masuk melalui jendela belakang menyinari bathtub dan lantai terakota, diperhangat nyala lampu dinding kaca di kanan dan downlight plafon

#### **C. Camera Movement**

Kamera bergerak mundur lurus menjauhi bathtub dan jendela belakang menuju ambang pintu sehingga lantai ubin terakota, keranjang tanaman kiri, kloset, meja wastafel kayu, cermin, lampu dinding kanan, dan dua balok kayu plafon terbuka seimbang.

**Tempo:** Gerak mundur berlangsung lurus dan tenang dengan tempo sedang (moderate) dan laju konstan selama 2.80 detik hingga menutup video.

**Camera:** Dolly-Out (~1.8–2.0×)
