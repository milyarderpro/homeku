# edh058 — Mediterranean Stucco Cottage

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Mediterranean Stucco Cottage
- **Gaya utama:** **Mediterranean Revival**
- **Pengaruh gaya:** Spanish Colonial Revival; Cottage
- **Gaya interior:** Warm Organic Mediterranean
- **Ciri khas:** Fasad plester krem satu lantai beratap genteng barrel terakota dengan volume teras masuk menjorok, pintu kayu berkaca berhias karangan daun, lampu lentera hitam, dan jendela berdaun shutter hitam; Bukaan dan ceruk melengkung (arched) yang konsisten di seluruh interior: ceruk TV ruang keluarga, jendela dapur, jendela kamar tidur, jendela walk-in closet, dan ceruk pohon zaitun di kamar mandi; Balok kayu ekspos pada plafon ruang keluarga, kamar tidur, plafon pelana walk-in closet, dan kamar mandi yang memadukan kehangatan kayu alami dengan tekstur plester lembut
- **Warna & material:** Krem plester hangat pada dinding, terakota dan bata alami pada atap serta lantai kamar mandi, kayu cokelat hangat pada pintu, furnitur, dan balok plafon, hitam matte pada kusen jendela dan lampu lentera, hijau zaitun/sage lembut di kamar tidur, serta tekstil krem-putih dan aksen bunga oranye-merah.
- **Suasana dan lingkungan:** Rumah taman satu lantai bernuansa hangat, terang alami, dan intim yang dikelilingi halaman rumput rapi, jalan setapak batu, semak berbunga oranye-putih, dan pepohonan rimbun.

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Massa tunggal satu lantai berukuran kompak dengan volume teras masuk beratap pelana yang menonjol di tengah fasad depan dan cerobong asap plester krem di sisi kiri atap. |
| **Lantai & bentuk atap** | Satu lantai (single-story) dengan proporsi rendah dan intim; di interior terlihat plafon datar berbalok kayu serta plafon pelana melengkung/miring berbalok kayu ekspos pada walk-in closet. |
| **Tapak bangunan** | Tapak relatif kompak dan melintang dengan teras masuk menjorok di depan serta lima ruang interior terpisah yang ditampilkan (ruang keluarga, dapur, kamar tidur, walk-in closet, dan kamar mandi). |
| **Proporsi utama** | Proporsi fasad lebar-rendah yang seimbang dengan bukaan vertikal jendela dan pintu kayu; ruang-ruang interior terasa akrab dan terukur tanpa bentang besar berlebihan. |
| **Perkiraan luas lantai** | **75–115 m²** |

## 3. Shot Timeline

Video berdurasi 19,90 detik (597 frame, 30 fps) terdiri dari enam shot kontinu yang dipisahkan lima hard cut pada frame 159, 251, 346, 437, dan 513. Pola gerak kedalaman berselang-seling rapi antara maju dan mundur (IN – OUT – IN – OUT – IN – OUT) dengan tempo moderate yang konsisten.

**Camera Pattern:** IN – OUT – IN – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–5.30 | 5.30s | Exterior | Straight Dolly-In (~2.3×). |
| 02 | 5.30–8.37 | 3.07s | Living Room | Dolly-Out (~1.7×) + Moderate Pan Left (~25°). |
| 03 | 8.37–11.53 | 3.17s | Kitchen | Dolly-In (~1.7×) + Moderate Pan Right (~20°, Ease-Out). |
| 04 | 11.53–14.57 | 3.03s | Bedroom | Dolly-Out (~1.6×) + Moderate Pan Left (~20°, Ease-Out). |
| 05 | 14.57–17.10 | 2.53s | Walk-in Closet | Straight Dolly-In (~1.8×). |
| 06 | 17.10–19.90 | 2.80s | Bathroom | Dolly-Out (~1.7×) + Subtle Pan Right (Ease-Out). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Exterior · 0.00s**

> Kamera berada di halaman depan sedikit ke kanan sumbu jalan setapak setinggi mata dengan sudut tiga perempat ringan dan orientasi datar menghadap teras masuk. Bingkai lebar memperlihatkan keseluruhan massa rumah satu lantai berplester krem dan atap genteng terakota di tengah, dibingkai batang pohon besar di kanan serta jalan setapak batu dan bunga oranye-putih di bagian bawah. Kedalaman ruang berlapis dari rumput depan menuju tajuk pohon rimbun di belakang di bawah cahaya siang cerah merata.

**Shot 02 · Living Room · 8.33s**

> Kamera berada di sudut belakang-kanan ruang keluarga pada ketinggian mata dengan sudut diagonal lebar dan orientasi datar menghadap serong ke tengah-kiri ruangan. Bingkai lebar menempatkan meja kopi kayu di pusat bawah, pintu kaca tinggi bertirai krem serta pohon zaitun dan kursi aksen di kiri, sedangkan ceruk TV lengkung dan sofa krem berada di sisi kanan. Kedalaman ruang terbaca dari keranjang anyaman dan lengan sofa depan menuju jendela taman di bawah paduan cahaya siang terang dari kiri dan lampu downlight serta lentera dinding hangat.

**Shot 03 · Kitchen · 8.37s**

> Kamera berdiri di ambang masuk dapur setinggi mata dengan sudut serong ringan dan orientasi datar menghadap ke dalam lorong kerja. Bingkai lebar membagi area secara seimbang antara meja pulau berkursi bar kayu, dua lampu gantung, dan jendela lengkung di sisi kiri melawan deretan kabinet shaker krem, kompor gas, tudung hisap, serta rak kayu di sisi kanan. Kedalaman ruang terbangun dari bingkai dinding plester depan menuju jendela belakang di bawah cahaya siang alami dan lapisan lampu tanam serta lampu kerja hangat.

**Shot 04 · Bedroom · 14.53s**

> Kamera berada di sudut kaki-kiri kamar tidur setinggi mata dengan sudut diagonal lebar dan orientasi datar menghadap serong ke kanan-belakang ruangan. Tempat tidur kayu beralas karpet krem mendominasi tengah-bawah diapit dua nakas kayu, jendela lengkung berbunga berada di kanan-tengah, sudut duduk bertanaman dan lampu gantung kaca mengisi sisi kiri, serta dua balok kayu ekspos membingkai tepi atas. Kedalaman ruang terbaca dari sudut lemari laci kiri depan menuju jendela taman di bawah cahaya siang lembut dan pendaran hangat lampu meja serta sconce.

**Shot 05 · Walk-in Closet · 14.57s**

> Kamera berada tepat di ambang masuk walk-in closet pada ketinggian mata dengan sudut perspektif satu titik simetris dan orientasi datar menghadap dinding ujung. Bingkai lebar memadukan plafon pelana berbalok kayu di atas, sistem lemari terbuka berlampu LED di kiri dan kanan, serta ottoman krem di atas karpet runner yang menuntun mata ke jendela lengkung di tengah. Kedalaman lorong yang kuat diterangi cahaya siang cerah dari jendela ujung serta pendaran hangat lampu rak dan downlight.

**Shot 06 · Bathroom · 19.87s**

> Kamera berdiri di bagian depan kamar mandi setinggi mata dengan sudut frontal lebar dan orientasi datar menghadap dinding belakang. Bingkai menempatkan jendela ganda bertirai krem dan bak rendam putih di sisi kiri, pohon zaitun dalam ceruk lengkung berubin abu-hijau serta kloset di tengah, dan kabinet wastafel kayu hangat berwastafel putih, lampu dinding, serta cermin di sisi kanan. Kedalaman ruang terbaca dari keranjang handuk dan lantai ubin terakota di bawah menuju pemandangan bunga luar di bawah cahaya siang cerah dan pendaran lampu dinding hangat.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Exterior

**Time:** 0.00–5.30s · **Duration:** 5.30s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Bangunan satu lantai berdinding tampak plester krem hangat dengan massa teras masuk menjorok beratap pelana di tengah serta atap utama miring berpenutup tampak genteng barrel terakota dan tritisan kayu cokelat. Di atap sisi kiri berdiri cerobong kotak plester krem. Pintu masuk tunggal tampak kayu cokelat hangat dengan panel kaca atas berhias karangan daun hijau berada dalam ceruk persegi yang diapit dua lampu lentera dinding hitam dan satu lampu lentera atas. Fasad kiri dan dinding samping kanan teras memiliki jendela hitam multipanel lengkap dengan daun shutter hitam serta kotak bunga kayu di bawahnya, berdiri di atas undakan teras satu tingkat berwarna krem.

**Furnitur & dekorasi**

> Tidak terdapat furnitur duduk eksterior; area teras masuk dan halaman diisi elemen dekoratif berupa kumpulan pot tampak terakota beraneka ukuran (sebagian bermotif spiral) berisi tanaman cemara mini dan semak berbunga putih di kiri-kanan pintu, serta karangan daun tergantung pada pintu kaca.

**Lingkungan**

> Halaman depan berupa hamparan rumput hijau rapi terpotong jalan setapak melengkung dari batu lempeng pucat bertabur kerikil, dibingkai petak bunga oranye dan putih sepanjang kedua sisinya. Sebuah batang pohon besar berdiri di tepi kanan depan dekat pagar kayu vertikal, sementara latar belakang didominasi tajuk pepohonan rimbun hijau dan kuning keemasan di bawah cahaya siang cerah.

#### **B. Framing & Lighting**

- **Fokus:** Volume teras masuk dan pintu kayu utama.
- **Camera Start:** Berada di halaman depan sebelah kanan poros tengah jalan setapak batu, cukup jauh di depan batang pohon besar sisi kanan.; Menghadap serong kiri-depan langsung ke arah volume teras masuk dan pintu kayu utama.; Sudut tiga perempat depan ringan (slight three-quarter front) yang menampilkan muka fasad sekaligus bidang samping kanan teras.
- **Framing:** Establishing wide shot vertikal yang membingkai seluruh rumah satu lantai di tengah, jalan setapak batu membelah bagian bawah, dan pohon tinggi membingkai sisi kanan. → Medium-close frontal ringan pada teras masuk dengan pintu kayu berkarangan daun tepat di tengah bingkai, diapit tiga lentera dan pot tanaman, sementara jendela kiri dan sisi kanan teras terpotong di tepi.
- **Lighting:** Cahaya siang hari alami terang dengan bayangan dedaunan lembut jatuh di atas rumput depan.

#### **C. Camera Movement**

Kamera meluncur maju lurus dengan tempo sedang menyusuri jalan setapak batu dari halaman depan mendekati teras dan pintu masuk utama.

**Tempo:** Stabil dan mengalir lembut dengan tempo sedang sepanjang 5,30 detik.

**Camera:** Straight Dolly-In (~2.3×).

---

<a id="shot-02"></a>

### Shot 02 · Living Room

**Time:** 5.30–8.37s · **Duration:** 3.07s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang keluarga berdinding tampak plester krem hangat dengan lis profil plafon (crown molding), balok kayu ekspos di tepi atas plafon (terlihat pada akhir shot), lampu downlight tanam, dan lantai papan tampak kayu cokelat hangat. Dinding fokus utama memiliki ceruk lengkung dangkal (arched alcove) untuk TV dinding yang diapit dua lampu lentera dinding hitam. Dinding sisi kiri memiliki bukaan pintu kaca tinggi berbingkai hitam multipanel (French doors/windows) berbingkai tirai krem penuh dari rel hitam.

**Furnitur & dekorasi**

> Di dalam ceruk TV berdiri konsol media kayu hangat berpintu dua dan rak terbuka berisi keranjang anyaman serta dekorasi buku dan tanaman kecil. Area duduk diisi sofa berlengan gulung berlapis kain krem dengan deretan bantal motif polkadot/geometris dan bantal polos berpiping di sisi kanan, meja kopi persegi kayu hangat beralas vas bunga nuansa musim gugur dan tumpukan buku di tengah, kursi aksen berlengan ramping berkain terang di sudut kiri dekat pohon zaitun dalam pot, sebagian sofa krem kedua di tepi kiri depan, keranjang anyaman di sudut kanan bawah, serta karpet bermotif krem-abu.

**Lingkungan**

> Melalui pintu kaca tinggi berbingkai hitam di dinding kiri terlihat teras/taman luar yang terang oleh sinar matahari siang dengan semak bunga merah-oranye, dedaunan hijau, serta sebagian bangunan eksterior bernuansa hangat.

#### **B. Framing & Lighting**

- **Fokus:** Ceruk TV lengkung dan konsol media di awal, meluas ke keseluruhan area duduk ruang keluarga.
- **Camera Start:** Berada cukup dekat di belakang-kanan sandaran sofa krem, tepat di sebelah kanan meja kopi.; Mengarah serong kiri-depan langsung ke ceruk TV lengkung dan konsol media kayu.; Sudut diagonal rapat (tight diagonal medium shot) melewati bahu sofa di kanan depan.
- **Framing:** Framing ketat pada ceruk TV lengkung dan konsol media yang menjadi pusat atas-kiri, dibingkai sandaran sofa krem di kanan bawah. → Wide shot sudut diagonal ruang keluarga dengan meja kopi kayu di pusat bawah, pintu kaca taman dan pohon zaitun di kiri, ceruk TV bergeser ke sepertiga kanan, serta sofa dan keranjang anyaman di kanan depan.
- **Lighting:** Cahaya siang alami masuk dari pintu kaca kiri menciptakan pantulan terang di lantai kayu dan karpet, dilengkapi downlight plafon dan lampu lentera dinding.

#### **C. Camera Movement**

Kamera bergerak mundur sambil menyapu pandangan ke kiri dengan tempo sedang, menjauh dari ceruk TV untuk membuka meja kopi, sofa, pohon zaitun, hingga pintu kaca taman di sisi kiri.

**Tempo:** Mengalir mulus dan konsisten dengan tempo sedang sepanjang 3,07 detik.

**Camera:** Dolly-Out (~1.7×) + Moderate Pan Left (~25°).

---

<a id="shot-03"></a>

### Shot 03 · Kitchen

**Time:** 8.37–11.53s · **Duration:** 3.17s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dapur berbentuk L dengan meja pulau/semenanjung kecil di sisi kiri depan, dimasuki melalui ambang dinding tampak plester putih bertekstur dengan balok kayu gelap di tepi atas. Dinding belakang kiri memiliki jendela melengkung (arched) berbingkai hitam multipanel tepat di atas bak cuci, sedangkan dinding utama memakai backsplash tampak plester bertekstur lembut. Plafon datar putih dipasangi deretan lampu downlight tanam serta dua lampu gantung silinder terang di atas meja pulau, beralaskan lantai papan tampak kayu hangat.

**Furnitur & dekorasi**

> Kabinet atas dan bawah bergaya shaker warna krem dengan lis mahkota atas dan tarikan logam gelap memanjang sepanjang dinding L, dipasangi meja konter tampak batu marmer/kuarsa pucat berurat halus. Peralatan utama mencakup bak cuci apron-front putih di bawah jendela, mesin pencuci piring stainless, kompor gas freestanding stainless beroven ganda dengan panci putih di atasnya, serta tudung hisap cerobong stainless. Meja pulau/semenanjung di kiri dilengkapi dua kursi bar bundar kayu; dinding kanan di sebelah tudung hisap memiliki dua rak kayu mengambang berisi tanaman pot dan piring tumpuk, mangkuk jeruk di meja konter, serta karpet runner tenun di lantai.

**Lingkungan**

> Melalui jendela lengkung hitam di dinding belakang terlihat dedaunan hijau rimbun dan cahaya luar siang hari yang terang; pot bunga merah-oranye berdiri di ambang dalam jendela.

#### **B. Framing & Lighting**

- **Fokus:** Keseluruhan ruang dapur di awal, mengerucut ke kompor gas dan tudung hisap stainless.
- **Camera Start:** Berada di ambang masuk dapur tepat di belakang tepi dinding plester kanan dan di atas/belakang dua kursi bar kayu kiri.; Menghadap serong kiri-depan ke dalam dapur, membingkai jendela lengkung belakang sekaligus deretan kabinet kanan.; Sudut satu titik serong ringan (slight diagonal medium-wide) dari ambang pintu.
- **Framing:** Wide shot vertikal dapur dari ambang masuk yang memperlihatkan jendela lengkung di kiri, pulau dan dua lampu gantung di kiri bawah-atas, serta deretan kabinet dan kompor di kanan. → Medium-close fokus pada kompor gas stainless dan tudung hisap cerobong di tengah-kanan, diapit kabinet shaker kiri dan dua rak kayu plus mangkuk jeruk di kanan sementara jendela dan kursi bar telah keluar dari bingkai kiri.
- **Lighting:** Perpaduan cahaya siang dari jendela lengkung belakang, lampu downlight plafon, dua lampu gantung silinder, dan cahaya hangat di bawah kabinet serta tudung hisap.

#### **C. Camera Movement**

Kamera meluncur masuk ke dalam dapur dengan tempo sedang sambil menyapu pandangan ke kanan yang melambat halus di akhir, melewati meja pulau menuju kompor gas dan tudung hisap.

**Tempo:** Halus dan terukur dengan tempo sedang; sapuan horizontal melambat lembut pada setengah detik terakhir.

**Camera:** Dolly-In (~1.7×) + Moderate Pan Right (~20°, Ease-Out).

---

<a id="shot-04"></a>

### Shot 04 · Bedroom

**Time:** 11.53–14.57s · **Duration:** 3.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar tidur berdinding cat tampak hijau sage/abu-hijau lembut dengan plafon putih berbalok kayu ekspos paralel (dua balok terlihat jelas di bagian atas). Dinding utama di belakang kepala ranjang memiliki jendela melengkung (arched) berbingkai hitam multipanel berbingkai tirai kain krem penuh pada rel hitam, serta sebagian jendela kedua bertirai tampak di dinding kiri jauh. Lantai tampak kayu cokelat dilapisi karpet krem polos berukuran besar, dengan lampu gantung lentera kaca berbingkai kuningan di plafon dan lampu dinding hitam-kuningan mengapit jendela.

**Furnitur & dekorasi**

> Tempat tidur berbingkai kayu hangat (terlihat headboard rendah dan footboard berpanel vertikal) ditata dengan seprai putih bertekstur quilt, selimut rajut tebal krem di ujung ranjang, serta susunan bantal krem dan satu bantal aksen terakota bertekstur. Di kedua sisi ranjang berdiri meja nakas kayu berlaci: nakas kiri menahan lampu meja keramik putih di bawah lukisan relief krem berbingkai, sedangkan nakas kanan menahan vas bunga pucat. Sudut kiri belakang diisi kursi aksen berlapis kain krem berbantal lembut dan tanaman pot tinggi, sementara di tepi kiri bawah muncul sudut lemari laci kayu.

**Lingkungan**

> Di luar jendela lengkung hitam terlihat kotak bunga berisi bunga merah-merah muda cerah dan rimbunnya dedaunan hijau tersinari cahaya siang alami.

#### **B. Framing & Lighting**

- **Fokus:** Jendela lengkung dan tempat tidur di awal, meluas ke keseluruhan tata ruang kamar tidur.
- **Camera Start:** Berada dekat di sisi kanan-bawah tempat tidur, sedikit di depan nakas kanan.; Menghadap serong kiri-atas ringan menuju jendela lengkung, bantal tempat tidur, dan nakas kiri.; Sudut diagonal rapat (tight diagonal medium shot) di atas sudut ranjang.
- **Framing:** Framing ketat menempatkan jendela lengkung bertirai krem di tengah atas dan tumpukan bantal ranjang di bawah, diapit lampu dinding kiri-kanan. → Wide shot diagonal kamar tidur dengan tempat tidur penuh dan karpet di tengah-bawah, jendela lengkung bergeser ke kanan-tengah, sudut duduk bertanaman dan lampu gantung kaca mengisi sisi kiri, serta dua balok kayu membingkai tepi atas.
- **Lighting:** Cahaya siang alami masuk lembut dari jendela lengkung dan jendela kiri, berpadu pendaran hangat lampu meja keramik, dua lampu dinding, dan lampu gantung kaca.

#### **C. Camera Movement**

Kamera menarik mundur sambil menyapu pandangan ke kiri dengan tempo sedang yang melambat halus menjelang akhir, menjauh dari jendela lengkung untuk membuka seluruh ranjang, sudut duduk kiri, dan balok plafon.

**Tempo:** Mengalir dengan tempo sedang lalu melambat halus (ease-out) pada paruh akhir shot.

**Camera:** Dolly-Out (~1.6×) + Moderate Pan Left (~20°, Ease-Out).

---

<a id="shot-05"></a>

### Shot 05 · Walk-in Closet

**Time:** 14.57–17.10s · **Duration:** 2.53s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang walk-in closet berbentuk lorong simetris sempit dengan plafon pelana (vaulted ceiling) berplester krem dan tiga pasang balok/kuda-kuda kayu ekspos plus balok bubungan serta lampu downlight tanam. Dinding ujung berplester krem memiliki satu jendela lengkung (arched) berbingkai hitam multipanel berambang dalam. Lantai tampak papan kayu terang, sementara tepi kusen pintu gelap terlihat singkat di sisi kiri depan pada frame pembuka.

**Furnitur & dekorasi**

> Sistem penyimpanan terbuka built-in berwarna krem melapisi kedua dinding kiri dan kanan secara penuh dengan pencahayaan strip LED hangat di bawah rak. Sisi kiri dilengkapi dua tingkat batang gantung gelap berisi pakaian bernuansa netral, cokelat, oranye, dan hijau zaitun serta ceruk rak atas berisi keranjang anyaman; sisi kanan memadukan lemari laci kayu hangat bertarikan hitam di bagian bawah, gantungan pakaian di tengah, serta rak atas berkeranjang anyaman dan ceruk kecil di dekat jendela. Di lantai lorong terhampar karpet runner tenun krem dengan bangku ottoman persegi berkain krem di tengah-kiri serta pot/teko logam berisi rangkaian bunga putih di sudut kanan bawah jendela.

**Lingkungan**

> Melalui jendela lengkung ujung terlihat taman luar terang matahari dengan tanaman berbunga merah-oranye, rambatan hijau, serta sebagian bangunan bertetangga berdinding terang dan beratap genteng terakota.

#### **B. Framing & Lighting**

- **Fokus:** Jendela lengkung berbingkai hitam di ujung lorong.
- **Camera Start:** Berada di ambang pintu masuk lorong walk-in closet tepat pada poros simetri tengah.; Menghadap lurus ke depan menyusuri lorong langsung menuju jendela lengkung ujung.; Perspektif satu titik (one-point symmetrical perspective) frontal lurus.
- **Framing:** Wide shot simetris satu titik yang merangkum plafon pelana berbalok kayu, kedua dinding lemari built-in, ottoman krem di bawah, dan jendela lengkung di tengah. → Medium-close simetris pada dinding ujung dengan jendela lengkung mendominasi tengah bingkai, bagian atas ottoman terpotong di kiri bawah, dan sebagian lemari kiri-kanan mengapit tepi.
- **Lighting:** Cahaya siang terang masuk dari jendela ujung berpadu pendaran hangat strip LED rak lemari dan downlight plafon.

#### **C. Camera Movement**

Kamera meluncur maju lurus dengan tempo sedang menyusuri poros tengah lorong walk-in closet langsung menuju jendela lengkung di ujung ruangan.

**Tempo:** Stabil, simetris, dan mengalir konsisten dengan tempo sedang sepanjang 2,53 detik.

**Camera:** Straight Dolly-In (~1.8×).

---

<a id="shot-06"></a>

### Shot 06 · Bathroom

**Time:** 17.10–19.90s · **Duration:** 2.80s

![Kolase Shot 06](media/shot-06.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi berdinding tampak plester krem hangat dengan balok kayu ekspos melintang di plafon atas jendela dan lampu downlight tanam. Dinding belakang memiliki jendela ganda berbingkai hitam multipanel dengan tirai kain krem penuh di kiri, berdampingan dengan ceruk dinding melengkung (arched niche) yang dilapisi ubin persegi panjang tampak zellige abu-hijau pucat di bagian bawah dan satu rak kayu kecil di atasnya. Lantai menggunakan ubin persegi bernuansa tampak terakota/batu cokelat hangat.

**Furnitur & dekorasi**

> Di bawah jendela kiri berdiri bak rendam freestanding oval putih dengan keran dinding hitam matte serta nampan kayu berisi botol dispenser kuning kecokelatan. Di sebelah kanan bak rendam berdiri pohon zaitun tinggi dalam pot berbatu kerikil putih di dalam ceruk lengkung, tepat di belakang kloset duduk putih. Dinding kanan dilengkapi kabinet wastafel (vanity) kayu hangat berpintu dua dengan wastafel mangkuk/apron putih, keran hitam matte, cincin handuk berhanduk krem bertekstur, lampu dinding hitam-kaca menyala, dan cermin berbingkai gelap. Di sudut kiri depan tampak keranjang anyaman berisi handuk putih gulung dan tanaman hijau.

**Lingkungan**

> Melalui jendela ganda berbingkai hitam di dinding belakang terlihat bunga oranye-merah cerah, dedaunan hijau, langit biru cerah, serta sebagian bangunan eksterior beratap genteng di kejauhan.

#### **B. Framing & Lighting**

- **Fokus:** Bak rendam dan pohon zaitun di awal, meluas ke keseluruhan ruang kamar mandi termasuk vanity kanan.
- **Camera Start:** Berada dekat di depan sudut bak rendam putih dan kloset, tepat di sebelah kiri ujung meja vanity.; Menghadap lurus ke dinding belakang antara jendela kiri dan pohon zaitun dalam ceruk lengkung.; Medium-close frontal ringan pada zona bak rendam dan pohon zaitun.
- **Framing:** Framing ketat menampilkan pohon zaitun dalam ceruk di kanan, bak rendam dan sebagian jendela hitam di kiri, serta kloset di kanan bawah sementara vanity kanan belum masuk. → Wide shot seimbang kamar mandi dengan jendela penuh dan bak rendam di kiri, pohon zaitun dan kloset di tengah, kabinet wastafel kayu serta cermin dan lampu dinding membingkai sisi kanan, dan lantai ubin terakota beserta keranjang handuk di bawah.
- **Lighting:** Cahaya siang alami cerah dari jendela ganda kiri berpadu pendaran hangat lampu dinding di dekat cermin kanan dan downlight plafon.

#### **C. Camera Movement**

Kamera menarik mundur dengan tempo sedang yang melambat halus di akhir disertai geseran arah pandang tipis ke kanan, menjauh dari bak rendam dan pohon zaitun untuk membuka jendela penuh, lantai ubin, serta meja wastafel kayu di kanan.

**Tempo:** Mengalir dengan tempo sedang lalu melambat lembut (ease-out) menutup video pada 19,90 detik.

**Camera:** Dolly-Out (~1.7×) + Subtle Pan Right (Ease-Out).
