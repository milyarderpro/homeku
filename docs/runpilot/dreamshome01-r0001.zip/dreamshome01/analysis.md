# dreamshome01 — Sage Woodland Cottage

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Sage Woodland Cottage
- **Tipe rumah:** Cottage
- **Gaya utama:** **American Cottage**
- **Pengaruh gaya:** Country Farmhouse
- **Gaya interior:** English Country
- **Susunan ruang utama:** Eksterior dan teras, ruang tamu berpusat perapian, dapur dan meja makan satu ruang, kamar tidur dan kamar mandi; koneksi denah tidak terverifikasi.
- **Ciri khas:** Trim putih, hijau sage, perapian batu, apron-front sink, tekstil alami.
- **Material utama:** Siding horizontal hijau pucat, trim putih, permukaan tampak kayu hangat, batu bulat di perapian, tekstil tenun.
- **Pencahayaan:** Cahaya siang tersaring pohon dan masuk melalui jendela; lampu teras, lampu meja, pendant dan sconce hangat.
- **Atmosfer:** Hangat, teduh, nyaman, bernuansa pedesaan dengan motif botani.
- **Lingkungan:** Pepohonan rapat, halaman rumput, kerikil dan jalur batu; vegetasi terlihat melalui jendela.

### Palet warna

| Peran | Warna | HEX |
| --- | --- | --- |
| Dominan | Warm Ivory | `#E1D6C0` |
| Dominan | Sage Green | `#849180` |
| Pendamping | Honey Oak | `#B98B60` |
| Pendamping | Oatmeal Beige | `#B6A083` |
| Pendamping | Stone Taupe | `#948477` |
| Aksen | Charcoal | `#39312B` |

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Massa rendah kompak dengan teras di kanan fasad. |
| **Lantai & bentuk atap** | 1 · Atap gelap dengan profil pelana melengkung lembut di depan, kanopi teras rendah. |
| **Tapak bangunan** | compact rectangular |
| **Proporsi utama** | low-rise, narrow-front |
| **Perkiraan luas lantai** | **35–60 m²** |

## 3. Shot Timeline

Durasi 20.03s · 5 shot.

**Camera Pattern:** IN – OUT – IN – OUT – IN.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–6.13 | 6.13s | Exterior | Diagonal Dolly-In (~2.4×, Accelerating) + Mild Pan Right (~10°). |
| 02 | 6.13–9.60 | 3.47s | Living Room | Diagonal Dolly-Out (~1.6×) + Moderate Pan Left (~20°). |
| 03 | 9.60–13.10 | 3.50s | Kitchen & Dining Area | Diagonal Dolly-In (~1.65×) + Subtle Pan Right (~5°). |
| 04 | 13.10–16.57 | 3.47s | Bedroom | Diagonal Dolly-Out (~1.7×) + Moderate Pan Left (~15°). |
| 05 | 16.57–20.03 | 3.47s | Bathroom | Straight Dolly-In (~2.2×). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Exterior · 0.00s**

> Kamera di halaman kerikil, sedikit menyudut ke fasad; rumah utuh, jendela, tangga, teras dan pohon mengisi latar.

**Shot 02 · Living Room · 9.57s**

> Dari sisi belakang sofa menghadap perapian di kanan dan jendela lebar di kiri; meja, kursi, karpet dan plafon terlihat.

**Shot 03 · Kitchen & Dining Area · 9.60s**

> Kamera berada di jalur masuk menghadap sink di belakang; meja bulat dan kursi kiri, kabinet serta range di kanan terlihat bersamaan.

**Shot 04 · Bedroom · 16.53s**

> Dari dekat ambang kamar menghadap ranjang secara menyudut, kedua bidang jendela, lampu, karpet dan lantai terlihat.

**Shot 05 · Bathroom · 16.57s**

> Kamera di ambang menghadap jendela dan toilet; kaca shower di kiri dan vanity sage di kanan terlihat utuh secara cukup lebar.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Exterior

**Time:** 0.00–6.13s · **Duration:** 6.13s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Rumah mungil berfasad siding horizontal sage dengan trim putih, jendela grid ber-shutter dan kotak bunga. Atap gelap berprofil pelana melengkung, cerobong tampak batu. Teras kanan beratap, tiang persegi putih, railing vertikal dan tangga kayu menuju pintu.

**Furnitur & dekorasi**

> Kursi putih di ujung teras, bendera, pot bunga dan dekorasi musiman warna jingga di dekat tangga.

**Lingkungan**

> Pepohonan tinggi di belakang dan sisi, halaman rumput dengan tepian batu, jalur batu tak beraturan di depan tangga serta halaman kerikil.

#### **B. Framing & Lighting**

- **Fokus:** Fasad dan entrance
- **Camera Start:** Halaman kerikil di depan rumah · Ke fasad dan tangga teras · oblique · eye-level · level
- **Framing:** Wide fasad utuh dengan pepohonan dan kerikil → Close pada teras; blur di ujung
- **Lighting:** Cahaya siang lembut, lampu teras jingga
- **Foreground dan kedalaman:** Kerikil dan tepi rumput · Halaman, fasad, pepohonan
- **Reveal:** Teras dan tangga semakin dominan
- **Kesesuaian gerak:** Cocok pendekatan dari halaman menuju tangga

#### **C. Camera Movement**

Lebar jendela depan dan tinggi kolom meningkat; batas rumput dan batu dekat membesar lebih kuat daripada fasad; bukan sekadar zoom. Batang dekat di kiri tersisih ke kiri relatif terhadap fasad; sisi kanan rumah terlihat lebih lebar pada tengah. Lintasan mendekat ke kanan menuju tangga; lengkung orbit tidak tegas. Jendela dan bagian belakang menyapu ke kiri ketika teras menjadi pusat; perubahan sudut bidang kecil, Pan Right ringan, tidak ada tilt terpisah.

**Tempo:** Awal lambat kemudian pembesaran dan gerak halaman lebih cepat pada interval 0–2, 2–4, 4–5,8 detik; perspektif juga memperkuat laju citra.

**Camera:** Diagonal Dolly-In (~2.4×, Accelerating) + Mild Pan Right (~10°).

---

<a id="shot-02"></a>

### Shot 02 · Living Room

**Time:** 6.13–9.60s · **Duration:** 3.47s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding fokus perapian berlapis batu bulat dengan mantel kayu dan inset hitam. Rak built-in mengapit perapian; dinding panel putih, plafon melengkung dengan rusuk putih dan jendela grid besar di sisi kiri.

**Furnitur & dekorasi**

> Sofa putih menghadap perapian, kursi berlengan hijau sage di kedua sisi meja kopi persegi panjang kayu berkaki bubut. Rak bawah meja berisi keranjang dan buku; karpet tenun, bantal botani, throw olive, lampu meja, vas bunga dan karya botani di mantel.

**Lingkungan**

> Vegetasi hijau dan terang siang melalui jendela kiri; cahaya api dan lampu meja hangat menyertai daylight.

#### **B. Framing & Lighting**

- **Fokus:** Perapian dan seating group
- **Camera Start:** Di sisi dekat meja kopi; awal tertutup blur · Ke dinding perapian · oblique · eye-level · slightly downward
- **Production Start:** F191 · 6.37s · Frame jernih pertama yang layak: kamera dekat meja kopi menghadap perapian batu dengan mantel dan rak built-in; sisi kursi tampak di tepi.
- **Framing:** Frame 184 kabur; perapian baru tampak jelas sesudah transisi → Wide ruang tamu, perapian kanan dan sofa depan kiri
- **Lighting:** Daylight kiri dan lampu hangat
- **Foreground dan kedalaman:** Blur; meja kopi setelah jernih · Meja, perapian, rak, jendela
- **Reveal:** Sofa, jendela dan plafon terbuka ketika mundur
- **Kesesuaian gerak:** Pull-back membuka susunan duduk

#### **C. Camera Movement**

Bukaan perapian mengecil sekitar 1,6×; meja kopi mengecil relatif lebih kuat dan sofa dekat masuk dari bawah, mendukung mundur. Meja dekat bergeser lebih sedikit ke kanan dibanding mantel jauh setelah koreksi skala; sudut dinding berubah saat jendela kiri terbuka. Mundur menyudut kiri; orbit tidak cukup terpisah dari lintasan diagonal. Mantel dan perapian bergeser kanan dan jendela terbuka kiri, mendukung sapuan Pan Left; tidak ada tilt mandiri yang konsisten.

**Tempo:** Pull-back bertahap selama 3,2 detik jernih; perubahan antarselang 0,7 detik relatif lancar, tidak cukup untuk profil laju terpisah.

**Camera:** Diagonal Dolly-Out (~1.6×) + Moderate Pan Left (~20°).

---

<a id="shot-03"></a>

### Shot 03 · Kitchen & Dining Area

**Time:** 9.60–13.10s · **Duration:** 3.50s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dapur berbentuk L terlihat pada dinding belakang dan kanan: apron-front sink putih di bawah jendela grid, kabinet bawah sage dan kabinet atas ivory, backsplash krem terang serta rak terbuka di kiri jendela. Meja makan menempati sisi kiri ruang yang sama; lantai papan tampak kayu.

**Furnitur & dekorasi**

> Meja makan bulat dan kursi kayu anyaman di kiri layar awal dengan vas bunga; lampu gantung di atasnya. Dishwasher tampak metal di kiri sink, range dan hood di kanan. Karpet pola tradisional di jalur kerja, talenan dan tanaman di counter.

**Lingkungan**

> Jendela belakang dan kiri memperlihatkan dedaunan. Lampu dinding di atas sink dan cahaya bawah kabinet membuat backsplash hangat.

#### **B. Framing & Lighting**

- **Fokus:** Sink dan susunan kabinet
- **Camera Start:** Sisi jalur antara meja makan dan dapur · Ke sink dan kabinet belakang · frontal · eye-level · level
- **Framing:** Wide ruang makan kiri dan dapur belakang-kanan → Dekat sink, kabinet dan countertop
- **Lighting:** Daylight jendela, pendant dan task light hangat
- **Foreground dan kedalaman:** Meja makan kiri dan lantai · Jalur kerja menuju sink, kabinet kanan
- **Reveal:** Meja terpotong, sink mendominasi
- **Kesesuaian gerak:** Push-in sepanjang lorong kerja

#### **C. Camera Movement**

Lebar jendela sink membesar sekitar 1,65×; meja dan kursi dekat melintas ke luar kiri lebih cepat, karpet membesar; paralaks mendukung Dolly-In. Kursi dekat bergerak kiri jauh lebih kuat daripada sink; badan maju sedikit ke kanan melewati meja. Bidang kabinet belakang tetap hampir frontal, tidak cukup untuk Orbit. Sink bergeser tipis ke kiri dan kabinet kanan tetap terbuka; sapuan kanan kecil; tidak ada perubahan tilt yang jelas.

**Tempo:** Kemajuan terlihat konsisten pada interval sekitar 0,7 detik; perubahan tepi dekat makin kuat oleh perspektif.

**Camera:** Diagonal Dolly-In (~1.65×) + Subtle Pan Right (~5°).

---

<a id="shot-04"></a>

### Shot 04 · Bedroom

**Time:** 13.10–16.57s · **Duration:** 3.47s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar dengan dinding aksen hijau sage di belakang headboard, dinding samping ivory, dua sisi jendela grid bertirai putih, plafon putih dengan lampu semi-flush serta lantai papan hangat.

**Furnitur & dekorasi**

> Tempat tidur ganda ber-headboard kayu, duvet ivory, bantal botanical dan throw sage berumbai. Meja samping dan lampu hangat di kedua sisi tampak pada wide, kursi di dekat jendela kanan, karpet tenun besar, karya botani dan tanaman.

**Lingkungan**

> Cahaya siang dari dua sisi jendela bervegetasi; lampu samping dan plafon memberi aksen hangat.

#### **B. Framing & Lighting**

- **Fokus:** Ranjang dan jendela
- **Camera Start:** Dekat sisi kaki ranjang · Ke headboard dan jendela kanan · oblique · eye-level · slightly downward
- **Framing:** Close kaki ranjang, jendela kanan dan headboard parsial → Wide ranjang dan dua sisi jendela
- **Lighting:** Daylight dan lampu samping hangat
- **Foreground dan kedalaman:** Throw dan duvet · Ranjang, headboard, dua bidang jendela
- **Reveal:** Seluruh ranjang, karpet, meja samping dan plafon
- **Kesesuaian gerak:** Pull-back membuka volume kamar

#### **C. Camera Movement**

Bantal dan jendela kanan mengecil, kaki ranjang terbuka utuh dan lantai depan muncul; skala ranjang sekitar 1,7×. Tepi ranjang dekat menyusut dan bergeser ke kanan relatif terhadap garis jendela; badan mundur agak ke kiri, sudut bidang ranjang berubah, tetapi lintasan orbit tidak terpisahkan dengan pasti. Jendela kanan bergeser kanan sementara headboard terpusat dan jendela kiri terbuka; Pan Left. Perubahan plafon mengikuti pull-back, tidak ada tilt jelas.

**Tempo:** Pembukaan ruang halus sepanjang interval sekitar 0,7 detik; perubahan tepi ranjang lebih kuat pada awal dan melandai secara perspektif.

**Camera:** Diagonal Dolly-Out (~1.7×) + Moderate Pan Left (~15°).

---

<a id="shot-05"></a>

### Shot 05 · Bathroom

**Time:** 16.57–20.03s · **Duration:** 3.47s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi kompak dengan walk-in shower berkaca di kiri, toilet di bawah jendela grid putih dan vanity sage di kanan. Dinding shower ubin krem, dinding belakang panel horizontal ivory, lantai ubin terang.

**Furnitur & dekorasi**

> Shower head bulat dan hand shower, niche perlengkapan, toilet putih, vanity dua laci sage dengan rak bawah terbuka berkeranjang dan handuk. Counter putih, cermin bingkai kayu, lampu dinding di atas, tanaman serta keranjang di tangki toilet.

**Lingkungan**

> Dedaunan hijau jelas melalui jendela, cahaya siang bercampur lampu hangat di vanity dan shower.

#### **B. Framing & Lighting**

- **Fokus:** Jendela dan toilet
- **Camera Start:** Ambang kamar mandi · Ke jendela di atas toilet · oblique · eye-level · level
- **Framing:** Wide shower, toilet dan vanity → Close jendela, tanaman dan keranjang tangki
- **Lighting:** Daylight jendela dan sconce hangat
- **Foreground dan kedalaman:** Kusen pintu dan keset · Shower kiri, toilet tengah dan vanity kanan
- **Reveal:** Detail jendela dan tangki toilet
- **Kesesuaian gerak:** Push-in menuju jendela

#### **C. Camera Movement**

Jendela membesar sekitar 2,2× dan tangki toilet membesar lebih kuat; kusen shower dan vanity keluar di sisi, mendukung pendekatan. Kusen shower bergerak ke kiri dan vanity ke kanan relatif jendela, simetris secara kasar; lintasan dominan lurus menuju jendela. Jendela tetap relatif terpusat, garis vertikal stabil; framing toilet turun karena perspektif pendekatan, tilt/pan terpisah tidak tegas.

**Tempo:** Pendekatan berkelanjutan dengan ekspansi lebih besar di akhir akibat jarak; profil laju badan tidak pasti.

**Camera:** Straight Dolly-In (~2.2×).

**Catatan referensi:** Transisi blur pada 177–190, batas editorial frame 184. Gerak pada frame kabur tidak ditafsirkan. Estimasi skala/sudut merupakan perubahan citra visual, bukan pengukuran lintasan 3D; material fisik, luas nyata, lokasi, dan kontinuitas bangunan tidak terverifikasi. Luas 35–60 m² merupakan perkiraan dari massa kompak dan ruang yang terlihat. HEX adalah estimasi tampilan permukaan, bukan warna cat terukur.
