# edh013 — Rumah Menara Organik dengan Tangga Spiral dan Taman Bunga

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Rumah Menara Organik dengan Tangga Spiral dan Taman Bunga
- **Gaya utama:** **Organic Architecture**
- **Pengaruh gaya:** Mediterranean Revival; Whimsical Cottage
- **Gaya interior:** Organic Romantic; Moroccan-inspired
- **Ciri khas:** Spiral luar, jendela bundar besar, ceruk dinding lengkung dan tanaman menjuntai
- **Warna & material:** Permukaan putih halus tampak plester; kayu tampak hangat; logam warna emas, batu tampak berurat; bahan fisik belum terverifikasi; Putih gading, krem, kayu cokelat, merah muda, hijau tanaman dan aksen emas
- **Suasana dan lingkungan:** Cahaya siang dari bukaan besar; lampu gantung emas dan rak berpendar hangat; Taman bunga merah muda, semak bulat, jalur putih, pepohonan dan perbukitan hijau

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | medium |
| **Bentuk bangunan** | Menara silindris putih dengan volume tambahan membulat di kiri |
| **Lantai & bentuk atap** | Tiga tingkat fasad dengan bukaan dan balkon bertumpuk · Siluet atas datar melengkung dengan tepi parapet; bidang atap tidak terlihat |
| **Tapak bangunan** | Kompak, massa bulat dengan tonjolan samping; keliling belakang tidak terlihat |
| **Proporsi utama** | Vertikal ramping, tinggi lebih dominan daripada lebar massa utama |
| **Perkiraan luas lantai** | **90–160 m²** |

## 3. Shot Timeline

Durasi 21.33s · 5 shot.

**Camera Pattern:** IN – OUT – IN – OUT – IN.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–4.60 | 4.60s | exterior | Orbit Right (~15–25°) + Pan Left (~15–25°) → Dolly-In (~1.4×). |
| 02 | 4.60–8.07 | 3.47s | living room | Dolly-Out (~1.9×). |
| 03 | 8.07–11.63 | 3.57s | kitchen | Dolly-In (~1.2×) → Dolly-In (~1.4×) + Pan Right (~20–30°). |
| 04 | 11.63–16.67 | 5.03s | bedroom | Truck Left → Dolly-Out (~1.4×) + Orbit Left (~25–40°) + Pan Right (~30–40°). |
| 05 | 16.67–21.33 | 4.67s | bathroom | Dolly-In (~2.1×) + gentle Pan Right (~5–10°). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · exterior · 2.00s**

> Kamera di luar pada jalur taman, menghadap serong ringan ke menara dari jarak wide. Seluruh tinggi massa, tangga melilit, akses depan, tanaman dan pegunungan masuk bingkai tanpa batang pohon besar menghalangi.

**Shot 02 · living room · 8.03s**

> Kamera berada lebih jauh dari sofa, dekat tepi undakan ruang, menghadap serong ke dinding bukaan. Wide mencakup sofa melengkung, meja dan karpet, tangga di kiri, jendela bundar besar di kanan serta sebagian plafon tinggi.

**Shot 03 · kitchen · 8.07s**

> Kamera di depan meja panjang membulat, menghadap serong ke bidang kerja di kanan. Wide awal mencakup permukaan meja depan, kabinet lengkung, oven, rak ceruk tinggi dan deretan lampu gantung.

**Shot 04 · bedroom · 16.63s**

> Kamera lebih jauh dari kaki ranjang di sisi kiri, menghadap serong ke kanan. Wide akhir memperlihatkan ranjang di platform, undakan kayu, jendela bundar di belakang, rak buku serta bukaan besar dan tanaman di kanan.

**Shot 05 · bathroom · 16.67s**

> Kamera di bagian depan kamar mandi menghadap ke bak mandi di balik lengkung dinding. Wide mencakup toilet kiri bawah, vanity kanan, cermin, karpet, undakan menuju bak dan jendela bundar di belakang.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · exterior

**Time:** 0.00–4.60s · **Duration:** 4.60s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Massa utama silindris putih bertingkat tiga, dengan volume samping lebih rendah. Tangga luar putih melilit secara heliks dengan parapet solid, menghubungkan balkon membulat; akses bawah berupa pintu ganda kayu berkaca berbentuk lengkung dan undakan setengah lingkaran. Bukaan tinggi melengkung dan jendela kecil bundar berulang; tepian atap tampak rata, tetapi bidang atap tidak terlihat.

**Furnitur & dekorasi**

> Pot tanaman berjajar di akses dan balkon; bunga merah muda lebat dan tanaman rambat menjuntai dari balkon. Furnitur luar tidak jelas di antara pot dan pagar.

**Lingkungan**

> Taman formal-organik dengan jalur terang berkelok, hamparan rumput, semak pangkas bulat, bunga merah muda dan pohon tinggi di foreground; hutan dan perbukitan hijau membentuk latar. Langit biru berawan sedikit, cahaya matahari terang.

#### **B. Framing & Lighting**

- **Fokus:** Massa menara serta spiral putih.
- **Camera Start:** Di taman, di balik beberapa batang pohon dekat kamera. · Menghadap fasad menara dari arah serong. · oblique · Sekitar tinggi mata hingga sedikit lebih tinggi dari jalur taman; tidak terkalibrasi. · Nyaris datar, puncak menara masih dalam bingkai.
- **Framing:** Wide berlapis batang pohon, rumah di tengah. → Medium wide lebih dekat ke fasad dan akses.
- **Lighting:** Cahaya matahari terang, bayang tanaman pada tanah.
- **Foreground dan kedalaman:** Batang pohon, rumpun bunga dan semak. · Batang dekat, rumah menengah, hutan dan gunung jauh.
- **Reveal:** Batang keluar kiri, fasad terbuka lalu membesar.
- **Kesesuaian gerak:** Paralaks kuat mendukung reveal mengitari, lalu pendekatan fasad.

#### **C. Camera Movement**

Kamera mula-mula melintas melingkar ke kanan menyingkap rumah di balik batang pohon dengan arah pandang mengompensasi ke kiri. Setelah sekitar 2,7 detik, pergeseran samping mengecil dan pendekatan ke akses depan mendominasi.

**Tempo:** Cepat pada reveal awal, lalu sedang menuju fasad.

- **0.00–1.30s · fast:** Pohon dekat menyapu cepat dan fasad segera terbuka.
- **1.30–3.00s · moderate:** Reveal lateral mereda, massa relatif stabil.
- **3.00–4.60s · moderate:** Pendekatan jelas; perubahan skala meningkat, tidak otomatis bukti percepatan badan kamera.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 0.00–2.70 | exterior · Massa menara serta spiral putih. | Orbit Right (~15–25°) + Pan Left (~15–25°) | Pohon dekat menyapu cepat dan fasad segera terbuka.; Reveal lateral mereda, massa relatif stabil. |
| 2.70–4.60 | exterior · Massa menara serta spiral putih. | Dolly-In (~1.4×) | Reveal lateral mereda, massa relatif stabil.; Pendekatan jelas; perubahan skala meningkat, tidak otomatis bukti percepatan badan kamera. |

**Camera:** Orbit Right (~15–25°) + Pan Left (~15–25°) → Dolly-In (~1.4×).

---

<a id="shot-02"></a>

### Shot 02 · living room

**Time:** 4.60–8.07s · **Duration:** 3.47s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang tamu bervolume tinggi dengan dinding putih melengkung dan ceruk tanaman. Tangga melengkung di kiri memiliki anak tangga warna kayu muda dan pagar bilah emas. Bukaan bundar besar berbingkai kayu dengan mullion gelap di kanan, bukaan bundar lebih kecil di atas serta jendela lengkung ganda di belakang sofa. Area duduk berada di platform berundak dengan lantai tampak kayu; plafon lengkung memakai downlight.

**Furnitur & dekorasi**

> Sofa sectional rendah krem melengkung mengikuti dinding, dengan banyak bantal krem. Meja kopi bundar rendah dua lapis warna kayu di depan sofa, di atas karpet bundar bermotif berlubang; vas rumput kering, buku dan cangkir di meja. Pot hijau di sudut dan rak tanaman berbunga menempel di dinding, beberapa lilin di sisi tangga.

**Lingkungan**

> Vegetasi hijau dan bunga merah muda terlihat melalui jendela. Cahaya siang masuk kuat dari kanan, dengan aksen downlight kecil di plafon.

#### **B. Framing & Lighting**

- **Fokus:** Sofa krem, jendela dan tangga.
- **Camera Start:** Dekat sofa dan meja, pada sisi ruang yang menghadap dinding bukaan. · Menghadap serong ke jendela dan tangga kiri. · oblique · Sekitar tinggi mata duduk/berdiri rendah relatif sofa. · Nyaris datar, sebagian plafon awal terpotong.
- **Framing:** Medium wide sofa dan bukaan, meja terpotong. → Wide platform duduk, tangga, meja, karpet dan plafon.
- **Lighting:** Cahaya siang kuat dari jendela; downlight kecil.
- **Foreground dan kedalaman:** Meja kopi dan vas muncul dari kanan bawah. · Meja dekat, sofa tengah, bukaan dan taman jauh.
- **Reveal:** Meja, karpet dan tepian platform terungkap saat mundur.
- **Kesesuaian gerak:** Gerak mundur memberi pembacaan volume tanpa cut.

#### **C. Camera Movement**

Kamera mundur dari sofa menuju tepi platform; meja yang semula terpotong masuk ke tengah, kemudian platform dan plafon terbuka. Pergeseran lateral kecil mungkin ada, tetapi tidak terpisah meyakinkan dari penyusutan perspektif.

**Tempo:** Mundur cukup merata, reveal meja dan platform berlanjut hingga akhir; sedikit mereda.

**Camera:** Dolly-Out (~1.9×).

---

<a id="shot-03"></a>

### Shot 03 · kitchen

**Time:** 8.07–11.63s · **Duration:** 3.57s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dapur putih dengan dinding serta plafon bertransisi lengkung, ceruk tinggi berlapis rak terbuka dan ceruk kecil lengkung di kiri. Bidang backsplash tampak batu bertekstur pucat dengan garis tidak beraturan; rak berlampu strip hangat. Kabinet bawah mengikuti kurva bidang kerja dan lorong dalam.

**Furnitur & dekorasi**

> Meja depan memanjang dengan ujung membulat, permukaan putih berurat dan panel vertikal warna kayu; piring, cangkir dan buah di atasnya. Kurva sisi dalam meja tampak menerus ke area bak cuci di kiri dan bidang kerja, menyerupai konfigurasi U; pertemuan ujung dengan dinding tidak seluruhnya terlihat, sehingga klasifikasi peninsula belum pasti. Kabinet bawah merah muda pucat dan putih mengikuti lengkung, oven hitam tertanam di bawah kompor gas hitam; sisi kiri tampak bak cuci merah gelap dengan keran emas. Rak memuat keranjang anyam, wadah, peralatan kayu dan tanaman; karpet runner bermotif merah di lorong serta lampu gantung emas berornamen.

**Lingkungan**

> Cahaya hangat dari lampu gantung dan rak bercampur cahaya terang dari luar bingkai yang membentuk bayang pada kabinet kanan. Pemandangan luar tidak terlihat.

#### **B. Framing & Lighting**

- **Fokus:** Kurva meja dan bidang kerja.
- **Camera Start:** Di depan ujung membulat meja, pada sisi luar lorong kerja. · Menghadap serong ke kanan menuju kabinet kompor. · oblique · Sekitar tinggi dada/mata di atas meja. · Sedikit menunduk ke bidang meja, tanpa Tilt berkelanjutan yang jelas.
- **Framing:** Wide meja depan, lampu, rak dan kabinet kerja. → Medium close kompor, oven dan rak utama.
- **Lighting:** Lampu gantung emas, strip rak dan cahaya terang dari samping.
- **Foreground dan kedalaman:** Meja putih dan peralatan makan. · Meja dekat, kabinet tengah dan ceruk di belakang.
- **Reveal:** Ujung meja menghilang; rak dan kompor menjadi dominan.
- **Kesesuaian gerak:** Pendekatan dan sapuan mengarahkan fokus ke fungsi memasak.

#### **C. Camera Movement**

Kamera mula-mula mendekati meja dan kabinet, kemudian tetap maju sambil memutar pandangan ke kanan menuju kompor dan rak; ujung meja depan keluar bingkai.

**Tempo:** Pendekatan sedang; sapuan horizontal meningkat pada paruh kedua tanpa perlu menyimpulkan percepatan translasi.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 8.07–9.30 | kitchen · Kurva meja dan bidang kerja. | Dolly-In (~1.2×) | Pendekatan sedang; sapuan horizontal meningkat pada paruh kedua tanpa perlu menyimpulkan percepatan translasi. |
| 9.30–11.63 | kitchen · Kurva meja dan bidang kerja. | Dolly-In (~1.4×) + Pan Right (~20–30°) | Pendekatan sedang; sapuan horizontal meningkat pada paruh kedua tanpa perlu menyimpulkan percepatan translasi. |

**Camera:** Dolly-In (~1.2×) → Dolly-In (~1.4×) + Pan Right (~20–30°).

---

<a id="shot-04"></a>

### Shot 04 · bedroom

**Time:** 11.63–16.67s · **Duration:** 5.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar tidur dengan jendela bundar besar berbingkai emas dalam dinding putih tebal membulat di belakang kepala ranjang. Rak buku kayu mengikuti sudut lengkung di atas dan kanan jendela. Ranjang berada di platform kayu bertingkat dua, lantai sekitar terang. Di kanan ada bukaan bundar besar lain dan rak putih kecil; belum jelas hubungan dengan ruang lain.

**Furnitur & dekorasi**

> Ranjang besar rendah dengan linen putih krem berlipat, selimut rajut terang dan bantal merah muda. Nakas kayu rendah di kedua sisi kepala ranjang memuat buku dan vas bunga. Dua lampu gantung berbentuk lonjong warna emas mengapit ranjang. Di kaki ranjang tampak vas bunga merah muda, buku, keramik putih dan mangkuk kayu di platform; tanaman merambat di kiri serta pot daun besar di kanan.

**Lingkungan**

> Jendela menampilkan tanaman berdaun runcing dan pepohonan, dengan sinar siang kuat yang menembus ke linen dan lantai. Bukaan kanan juga memperlihatkan vegetasi.

#### **B. Framing & Lighting**

- **Fokus:** Ranjang dan jendela bundar.
- **Camera Start:** Dekat kaki ranjang, hampir di sumbu tengah ranjang. · Menghadap lurus ke kepala ranjang dan jendela bundar. · frontal · Sekitar tinggi mata rendah relatif ranjang. · Nyaris datar; ranjang memenuhi bagian bawah.
- **Framing:** Medium frontal ranjang dan jendela, platform terpotong. → Wide serong dari kiri dengan platform, rak dan tanaman kanan.
- **Lighting:** Cahaya siang dari bukaan bundar.
- **Foreground dan kedalaman:** Linen dan kaki ranjang; vas depan muncul kemudian. · Platform dan ranjang dekat, jendela dan vegetasi jauh.
- **Reveal:** Undakan, rak buku dan bukaan kanan terungkap.
- **Kesesuaian gerak:** Perubahan sisi dan mundur memberi konteks tata ruang.

#### **C. Camera Movement**

Awalnya kamera bergeser ke kiri dekat kaki ranjang dengan skala jendela hampir tetap. Kemudian kamera mundur sekaligus melingkar ke kiri sambil memutar pandangan ke kanan sehingga platform dan sisi kanan kamar terbuka.

**Tempo:** Geser awal terkendali, reveal sisi kanan berlangsung jelas kemudian mereda menjelang akhir.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 11.63–13.30 | bedroom · Ranjang dan jendela bundar. | Truck Left | Geser awal terkendali, reveal sisi kanan berlangsung jelas kemudian mereda menjelang akhir. |
| 13.30–16.67 | bedroom · Ranjang dan jendela bundar. | Dolly-Out (~1.4×) + Orbit Left (~25–40°) + Pan Right (~30–40°) | Geser awal terkendali, reveal sisi kanan berlangsung jelas kemudian mereda menjelang akhir. |

**Camera:** Truck Left → Dolly-Out (~1.4×) + Orbit Left (~25–40°) + Pan Right (~30–40°).

---

<a id="shot-05"></a>

### Shot 05 · bathroom

**Time:** 16.67–21.33s · **Duration:** 4.67s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi memanjang dengan dinding/plafon putih berlengkung dan bukaan lengkung menuju zona bak. Bak berada di platform dua undakan membulat, permukaan putih berurat dan pola ubin krem di bawah bak. Jendela bundar besar berbingkai warna kayu di dinding belakang; rak kecil kayu mengikuti kurva dinding kiri. Cahaya terang dari atas zona bak tampak melalui bidang putih terang; tipe bukaan atap tidak pasti.

**Furnitur & dekorasi**

> Bak mandi oval freestanding putih dengan keran tinggi warna emas di sisi kiri belakang. Di kanan depan vanity permukaan putih berurat, wastafel mangkuk putih, keran emas, cermin oval berbingkai emas dan rak terbuka berisi gulungan handuk. Toilet putih terlihat sebagian di kiri bawah; ceruk oval dengan rak kayu di dinding kiri. Karpet merah muda di jalur masuk, pot terakota, tanaman menjuntai dan rimbun di sekitar bak, lampu gantung kecil bulat di kanan.

**Lingkungan**

> Jendela memperlihatkan langit biru terang dan sedikit vegetasi rendah di akhir. Sinar siang kuat dari bukaan belakang/atas membentuk bidang terang di tangga dan lantai.

#### **B. Framing & Lighting**

- **Fokus:** Bak oval di depan jendela bundar.
- **Camera Start:** Di depan ruang, dekat toilet kiri dan vanity kanan, sebelum undakan. · Menghadap ke bak dan jendela bundar di belakang. · frontal · Sekitar tinggi mata, di atas wastafel. · Sedikit menunduk untuk memuat lantai; tidak ada rotasi vertikal kuat.
- **Framing:** Wide melalui lengkung, toilet, vanity, jalur masuk dan bak. → Close wide bak dan jendela, sisi vanity keluar.
- **Lighting:** Cahaya siang kuat pada platform dan jendela; aksen lampu hangat.
- **Foreground dan kedalaman:** Toilet kiri dan vanity kanan. · Perlengkapan dekat, undakan, bak dan bukaan belakang.
- **Reveal:** Maju melewati framing lengkung sampai bak memenuhi bingkai.
- **Kesesuaian gerak:** Paralaks dan pembesaran mendukung pendekatan, fokus tetap bak.

#### **C. Camera Movement**

Kamera maju mendekati platform dan bak, dengan sapuan kanan ringan untuk memusatkan jendela dan bak. Toilet, vanity dan undakan keluar dari bingkai secara bertahap.

**Tempo:** Pendekatan mantap; ekspansi perspektif lebih kuat di akhir tanpa bukti wajib percepatan badan kamera.

**Camera:** Dolly-In (~2.1×) + gentle Pan Right (~5–10°).

**Catatan referensi:** Estimasi luas 90–160 m² adalah perkiraan kasar dari tiga tingkat tampak dan proporsi pintu/ruang, bukan ukuran terukur. Video dapat berupa visualisasi; material fisik, kamera/lensa, lokasi dan kesinambungan denah antarcut tidak diketahui. Arah serta besaran kamera adalah interpretasi visual 2D, bukan rekonstruksi pose 3D. Truck Left shot-04 tidak diberi angka karena perpindahan lateral tidak dapat diestimasi wajar dalam satuan skala atau sudut. Pada shot-02, pergeseran kecil tidak cukup untuk memisahkan Pan atau Truck dari perspektif mundur.
