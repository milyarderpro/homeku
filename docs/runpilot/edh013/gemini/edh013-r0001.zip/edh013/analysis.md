# edh013 — Rumah Menara Silindris Organik Mediterania

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Rumah Menara Silindris Organik Mediterania
- **Gaya utama:** **Organic Modernism**
- **Pengaruh gaya:** Mediterranean Revival; Cycladic
- **Gaya interior:** Organic Modern; Soft Minimalist; Biophilic
- **Ciri khas:** Tangga spiral putih eksterior melilit fasad, jendela bundar berbingkai kuningan di ruang keluarga/kamar tidur/kamar mandi, serta meja dapur organik melengkung berbentuk U
- **Warna & material:** Permukaan dominan tampak plester putih halus di eksterior dan interior, dipadukan aksen tampak kayu hangat, logam keemasan, marmer berurat, dan anyaman rotan; Putih krem hangat sebagai warna utama dengan aksen merah muda lembut, cokelat kayu, kuningan/emas, dan hijau dedaunan
- **Suasana dan lingkungan:** Cahaya alami cerah melalui bukaan bundar, lengkung, dan skylight, dilengkapi lampu gantung kuningan/anyaman serta lampu tersembunyi hangat pada rak; Berdiri di taman berumput dengan semak bunga merah muda, jalan setapak batu pucat, pepohonan rindang, dan latar perbukitan hijau di bawah langit biru cerah

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | medium |
| **Bentuk bangunan** | Massa silindris majemuk bertingkat tiga yang dililit tangga spiral eksterior terbuka |
| **Lantai & bentuk atap** | Tiga tingkat terlihat pada massa menara utama beserta balkon bertingkat · Atap datar tanpa overhang dengan parapet silindris polos |
| **Tapak bangunan** | Kompak bertumpuk vertikal dengan denah silindris majemuk |
| **Proporsi utama** | Tinggi menara silindris jauh lebih dominan dibanding lebar tapak fasad |
| **Perkiraan luas lantai** | **140–220 m²** |

## 3. Shot Timeline

Durasi 21.33s · 5 shot.

**Camera Pattern:** IN – OUT – IN – OUT – IN.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–4.60 | 4.60s | exterior | Orbit Right (~10°–15°) → Dolly-In (~1.4×) + subtle Pan Right (~8°–12°). |
| 02 | 4.60–8.07 | 3.47s | living | Dolly-Out (~2.0×). |
| 03 | 8.07–11.63 | 3.57s | kitchen | Dolly-In (~1.5×–1.6×) + Pan Right (~20°–25°). |
| 04 | 11.63–16.67 | 5.03s | bedroom | Gentle Truck Left → Dolly-Out (~1.7×) + Orbit Left (~25°–35°) + Pan Right (~15°–20°). |
| 05 | 16.67–21.33 | 4.67s | bathroom | Dolly-In (~1.8×–1.9×) → Dolly-In (~1.3×–1.4×) + subtle Pan Right (~8°–12°). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · exterior · 1.67s**

> Kamera berada di halaman depan pada sudut serong setelah melewati pohon birch di kiri, menghadap lurus ke fasad utama pada ketinggian sedikit di atas mata dengan kemiringan datar. Cakupan wide memperlihatkan keseluruhan menara silindris tiga tingkat, tangga spiral eksterior, jalur taman bunga merah muda, serta latar perbukitan hijau.

**Shot 02 · living · 8.03s**

> Kamera berada mundur di bagian depan ruang keluarga pada ketinggian mata rendah dengan kemiringan datar, menghadap penuh ke dinding lengkung dan jendela. Cakupan wide memperlihatkan sofa L krem, meja kopi bundar di atas karpet anyaman, tangga spiral di sisi kiri, jendela bundar raksasa di sisi kanan, serta plafon kubah tinggi.

**Shot 03 · kitchen · 8.07s**

> Kamera berada di sisi kiri atas dapur pada ketinggian agak tinggi menghadap serong ke kanan. Cakupan wide memperlihatkan keseluruhan meja dapur kontinu melengkung berbentuk U beralas kayu alur, lampu gantung anyaman di kiri, ceruk dinding lengkung, serta dinding kompor-oven dan rak bercahaya di kanan.

**Shot 04 · bedroom · 16.63s**

> Kamera berada mundur di sudut kiri depan kamar tidur pada ketinggian mata rendah dengan kemiringan datar, menghadap serong ke kanan belakang. Cakupan wide memperlihatkan tempat tidur di atas platform kayu dua undakan, jendela bundar berbingkai emas, rak buku kayu gelap, lampu gantung kuningan, serta sekat lengkung putih dengan tanaman pot di sisi kanan.

**Shot 05 · bathroom · 16.67s**

> Kamera berada di sumbu tengah lorong kamar mandi pada ketinggian mata datar, menghadap lurus ke ujung ruang. Cakupan wide simetris memperlihatkan kubah lengkung putih ber-skylight, tepi kloset kiri bawah, keset merah muda, meja wastafel melayang di kanan, cermin bundar kiri-kanan, undakan marmer, bathtub oval, dan jendela bundar besar.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · exterior

**Time:** 0.00–4.60s · **Duration:** 4.60s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Rumah menara tiga tingkat bermassa silindris majemuk dengan dinding tampak plester putih dan atap datar berparapet polos. Tangga spiral eksterior putih melilit badan menara dari sisi kanan bawah menuju balkon lantai dua, melengkapi pintu masuk ganda melengkung tampak kayu di atas tiga anak tangga setengah lingkaran, jendela lengkung tinggi, jendela oculus bundar kecil, dan balkon melingkar berpagar logam tipis keemasan.

**Furnitur & dekorasi**

> Teras masuk dan balkon dihiasi pot-pot keramik dan terakota berisi tanaman hijau serta semak berbunga merah muda dan tanaman menjuntai hijau yang menggantung dari tepi balkon.

**Lingkungan**

> Halaman depan berupa taman berumput dengan jalur batu pucat melengkung, diapit semak hijau terpangkas bundar dan rumpun bunga merah muda lebat. Batang pohon birch putih berdiri di tepi kiri depan, dengan deretan pepohonan hijau dan perbukitan melandai di bawah langit biru berawan tipis pada latar belakang.

#### **B. Framing & Lighting**

- **Fokus:** Fasad menara silindris putih, tangga spiral eksterior, dan pintu masuk ganda melengkung.
- **Camera Start:** Di halaman depan agak serong kiri di balik deretan batang pohon birch putih pada jarak menengah-jauh dari rumah. · Menghadap serong kanan menuju fasad utama rumah menara silindris dan pintu masuk lengkung. · oblique · Sedikit di atas ketinggian mata (setinggi lantai dasar atas) agar keseluruhan massa tiga tingkat dan taman depan terlihat utuh. · Datar dengan sedikit arah mendongak ringan untuk menampung puncak menara.
- **Framing:** Wide terbingkai batang pohon birch di sisi kiri depan yang sebagian menutupi sayap kiri rumah. → Medium wide tanpa halangan pohon yang menonjolkan tangga spiral eksterior, pintu lengkung kayu, dan anak tangga masuk.
- **Lighting:** Cahaya matahari siang cerah dari sisi kanan atas yang membentuk bayangan lembut di bawah tangga spiral dan lengkungan bukaan.
- **Foreground dan kedalaman:** Batang pohon birch putih di awal shot, disusul semak bunga merah muda, semak hijau bundar, dan jalur batu pucat melengkung. · Berlapis jelas dari batang pohon dan taman bunga di depan, massa menara di tengah, hingga barisan pohon dan pegunungan di latar belakang.
- **Reveal:** Pohon birch di kiri tersingkir keluar bingkai sehingga seluruh fasad silindris, sayap kiri, dan jalur taman depan terbuka penuh.
- **Kesesuaian gerak:** Transisi halus dari gerak menyamping melewati pepohonan menuju pendekatan stabil ke pintu masuk.

#### **C. Camera Movement**

Kamera mengorbit ke kanan melewati batang pohon birch di latar depan hingga fasad terbuka penuh, lalu bergerak maju mendekati pintu masuk sambil menyapu halus ke kanan.

**Tempo:** Tempo sedang dan stabil sepanjang 4,6 detik dari lintasan melewati pepohonan hingga pendekatan ke fasad.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 0.00–1.60 | exterior · Menyingkirkan halangan pohon birch di kiri depan dan membuka sudut fasad menara | Orbit Right (~10°–15°) | Tempo sedang dan stabil sepanjang 4,6 detik dari lintasan melewati pepohonan hingga pendekatan ke fasad. |
| 1.60–4.60 | exterior · Mendekati fasad depan, tangga spiral, dan pintu masuk melengkung | Dolly-In (~1.4×) + subtle Pan Right (~8°–12°) | Tempo sedang dan stabil sepanjang 4,6 detik dari lintasan melewati pepohonan hingga pendekatan ke fasad. |

**Camera:** Orbit Right (~10°–15°) → Dolly-In (~1.4×) + subtle Pan Right (~8°–12°).

---

<a id="shot-02"></a>

### Shot 02 · living

**Time:** 4.60–8.07s · **Duration:** 3.47s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang keluarga berplafon tinggi melengkung dengan dinding tampak plester putih dan lantai papan tampak kayu terang yang memiliki undakan rendah di depan. Sisi kanan didominasi jendela bundar raksasa berbingkai tampak kayu dengan rangka hitam silang, didampingi jendela lengkung kembar di tengah dan dua jendela bundar di dinding atas; sisi kiri memuat tangga spiral anak tangga tampak kayu dengan pagar logam tipis keemasan serta ceruk lengkung dinding.

**Furnitur & dekorasi**

> Sofa sudut rendah berbentuk L berlapis kain krem dengan deretan bantal krem-beige ditempatkan menghadap ke tengah ruang di depan jendela lengkung. Di depannya terdapat meja kopi bundar rendah tampak kayu di atas karpet bundar anyaman bermotif, dilengkapi vas rumput pampas kering, buku, rak ambalan dinding berisi tanaman hijau-bunga, serta lilin pilar di sepanjang anak tangga spiral.

**Lingkungan**

> Melalui jendela bundar besar dan jendela lengkung tampak pepohonan hijau lebat, cahaya matahari terang, dan semak bunga merah muda di luar ruangan.

#### **B. Framing & Lighting**

- **Fokus:** Area duduk ruang keluarga dengan sofa krem, meja kopi bundar, jendela bundar besar, dan tangga spiral interior.
- **Camera Start:** Di tengah ruang keluarga pada jarak dekat-menengah di depan sofa sudut krem, menghadap ke dinding lengkung dan jendela. · Menghadap lurus-serong ringan ke dinding belakang lengkung dengan tangga spiral di kiri dan jendela bundar raksasa di kanan. · front-oblique · Setinggi mata saat duduk/berdiri rendah (eye-level rendah). · Datar.
- **Framing:** Medium shot pada sofa sudut krem, jendela lengkung tengah, sebagian tangga spiral kiri, dan tepi jendela bundar kanan. → Wide shot menyeluruh menampilkan plafon tinggi berkubah, jendela bundar atas, meja kopi bundar, karpet anyaman, lantai kayu bertingkat, dan ranting bunga merah muda di kanan atas.
- **Lighting:** Cahaya alami melimpah dari jendela bundar raksasa dan jendela lengkung, dipadukan titik lampu plafon tanam serta lilin hangat di anak tangga.
- **Foreground dan kedalaman:** Meja kopi bundar dengan vas rumput pampas, karpet bundar berpola, tepi undakan lantai kayu, serta dedaunan dan bunga merah muda di sisi kanan pada paruh akhir. · Ruang dalam terbuka luas secara vertikal dan horizontal dengan pemandangan taman hijau berbunga merah muda di balik jendela kaca.
- **Reveal:** Gerak mundur membuka meja kopi bundar, karpet bundar, seluruh lekuk tangga spiral kiri, jendela bundar atas, dan langit-langit berkubah.
- **Kesesuaian gerak:** Mundur lurus yang sangat stabil dan simetris, ideal untuk membuka skala ruang vertikal.

#### **C. Camera Movement**

Kamera mundur lurus dan stabil menjauhi sofa untuk membuka seluruh volume tinggi ruang keluarga, meja kopi, tangga spiral, dan jendela bundar.

**Tempo:** Tempo sedang dan konstan sepanjang 3,47 detik penarikan mundur.

**Camera:** Dolly-Out (~2.0×).

---

<a id="shot-03"></a>

### Shot 03 · kitchen

**Time:** 8.07–11.63s · **Duration:** 3.57s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dapur bergaya organik dengan dinding dan plafon tampak plester putih yang membentuk lekukan kubah halus, pilar lengkung, serta ceruk dinding melengkung di belakang kiri. Dinding area memasak di sisi kanan memiliki relung besar bertekstur tampak batu/plester relief pucat dengan tiga tingkat rak plester melengkung menyatu dinding dan pencahayaan tersembunyi di bawah tiap rak.

**Furnitur & dekorasi**

> Meja dapur kontinu melengkung berbentuk U/peninsula berpermukaan putih mengilap dengan sisi luar kiri beralur tampak kayu vertikal dan kabinet bawah melengkung berwarna merah muda pastel. Di sisi kanan terpasang oven tanam hitam di bawah kompor gas hitam empat tungku, disertai keranjang anyaman, stoples, peralatan masak kayu, gelas, piring saji, karpet runner bermotif merah-krem di lantai, dan beberapa lampu gantung lentera anyaman keemasan; kursi bar tidak terlihat.

**Lingkungan**

> Tidak ada jendela atau pemandangan luar ruangan yang terlihat; suasana ruang diperkaya tanaman rambat hijau di rak atas dan pohon hias kecil di sudut kiri belakang.

#### **B. Framing & Lighting**

- **Fokus:** Berpindah dari lengkungan meja dapur dan lampu gantung anyaman menuju area memasak (kompor, oven, dan rak dinding).
- **Camera Start:** Di sudut kiri atas area dapur pada ketinggian sedikit di atas mata (high-angle ringan), melihat melintasi lengkungan meja dapur. · Menghadap serong ke kanan menuju meja dapur melengkung, area kompor-oven, dan rak dinding berpencahayaan hangat. · oblique · Sedikit tinggi (high-angle ringan) untuk memperlihatkan bidang atas meja dapur melengkung berbentuk U. · Menunduk ringan di awal menuju permukaan meja, lalu mengarah mendatar ke dinding kompor dan rak.
- **Framing:** Wide-oblique memperlihatkan keseluruhan meja dapur melengkung berbentuk U dengan alas kayu beralur, lampu gantung anyaman di kiri, ceruk dinding lengkung, dan dinding kompor di kanan. → Medium shot terpusat pada oven hitam tanam, kompor gas empat tungku, backsplash tekstur batu pucat, dan rak lengkung berpencahayaan hangat.
- **Lighting:** Cahaya interior hangat dari lampu gantung anyaman berlubang, lampu tersembunyi di balik rak dinding, dan refleksi lembut di permukaan meja.
- **Foreground dan kedalaman:** Permukaan meja tampak marmer putih melengkung berisi piring, mangkuk, baki kayu, dan buah di sisi kiri bawah, serta lampu gantung anyaman yang melintas di sisi atas. · Berlapis dari meja lengkung depan dan lampu gantung menuju ceruk dinding kiri dan relung rak dapur di kanan.
- **Reveal:** Mendekat dan memusatkan detail tekstur backsplash berpola batu pucat, oven hitam, kompor gas, serta susunan keranjang anyaman dan peralatan pada rak.
- **Kesesuaian gerak:** Gerak maju sambil menyapu ke kanan mengikuti kurva meja dapur sehingga transisi pandangan terasa menyatu.

#### **C. Camera Movement**

Kamera melaju maju melintasi lengkungan meja dapur sambil menyapu pandangan ke kanan hingga berpusat pada kompor, oven hitam, dan rak dinding bercahaya hangat.

**Tempo:** Tempo sedang dan mulus sepanjang 3,57 detik gerak maju dan sapuan kanan.

**Camera:** Dolly-In (~1.5×–1.6×) + Pan Right (~20°–25°).

---

<a id="shot-04"></a>

### Shot 04 · bedroom

**Time:** 11.63–16.67s · **Duration:** 5.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar tidur berdinding tampak plester putih organik dengan jendela bundar besar berbingkai tampak kayu/emas yang menjorok dalam tepat di atas kepala ranjang. Lantai area tidur dinaikkan pada platform tampak kayu hangat dua undakan; di sisi kanan jendela terdapat rak buku tanam tampak kayu cokelat tua mengikuti kontur lengkung, diikuti sekat dinding lengkung putih besar yang membuka ke area samping berambalan rak putih dan cahaya luar.

**Furnitur & dekorasi**

> Tempat tidur rendah beralas platform kayu menggunakan seprai putih krem, selimut rajut beige, dan dua pasang bantal putih serta merah muda pastel. Kedua sisi ranjang dilengkapi nakas melayang tampak kayu dengan vas bunga merah muda dan tumpukan buku, sepasang lampu gantung logam kuningan bergaris, rak buku kayu gelap penuh buku di kanan jendela, serta pot tanaman tropis besar di balik sekat lengkung kanan dan tanaman rambat hijau di kiri.

**Lingkungan**

> Melalui jendela bundar di atas ranjang tampak dedaunan palem, rumput hias tinggi, dan pepohonan hijau cerah di bawah langit terang.

#### **B. Framing & Lighting**

- **Fokus:** Tempat tidur berplatform kayu dan jendela bundar besar, lalu melebar mencakup ruang samping kanan bersekat lengkung.
- **Camera Start:** Di depan kaki tempat tidur pada jarak dekat, menghadap hampir tegak lurus ke kepala ranjang dan jendela bundar. · Menghadap lurus ke dinding kepala ranjang di awal, lalu bergeser miring dari sisi kiri depan menghadap serong ke kanan belakang. · front · Setinggi mata rendah (sejajar permukaan ranjang dan tepi bawah jendela bundar). · Datar.
- **Framing:** Medium close-up simetris pada tempat tidur putih berbantal merah muda dan jendela bundar besar berbingkai emas di dinding kepala ranjang. → Wide oblique dari sisi kiri memperlihatkan platform kayu dua undakan, nakas melayang, rak buku kayu gelap di kanan jendela, tanaman rambat kiri, serta sekat lengkung putih dan tanaman pot di sisi kanan.
- **Lighting:** Cahaya siang lembut masuk dari jendela bundar dan bukaan kanan, dipadukan pendaran hangat pada dinding putih dan kilau logam lampu gantung.
- **Foreground dan kedalaman:** Selimut putih di awal, kemudian vas bunga merah muda di atas buku, mangkuk logam keemasan, anak tangga platform kayu, dan daun rambat hijau di tepi kiri. · Ruang terbuka makin dalam dari panggung ranjang kayu di depan menuju jendela bundar dan celah lengkung putih ke ruang tanaman di sisi kanan.
- **Reveal:** Gerak mundur dan mengorbit ke kiri membuka platform kayu bertingkat dua, rak buku dinding kayu gelap, serta partisi lengkung putih berisi tanaman pot tropis di sisi kanan.
- **Kesesuaian gerak:** Diawali geseran lembut ke kiri sebelum membuka ruang secara melingkar dan mundur, cocok untuk transisi dari detail ranjang ke keseluruhan kamar.

#### **C. Camera Movement**

Kamera bergeser lembut ke kiri di depan ranjang, lalu mundur sambil mengorbit ke kiri dan memutar pandangan ke kanan untuk membuka platform kayu, rak buku, dan sekat lengkung kanan.

**Tempo:** Tempo sedang dan halus sepanjang 5,03 detik dari geseran kiri awal hingga penarikan mundur melingkar.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 11.63–13.13 | bedroom · Menggeser perspektif awal secara halus ke sisi kiri ranjang | Gentle Truck Left | Tempo sedang dan halus sepanjang 5,03 detik dari geseran kiri awal hingga penarikan mundur melingkar. |
| 13.13–16.67 | bedroom · Membuka keseluruhan kamar tidur, platform kayu dua undakan, dan sekat lengkung kanan | Dolly-Out (~1.7×) + Orbit Left (~25°–35°) + Pan Right (~15°–20°) | Tempo sedang dan halus sepanjang 5,03 detik dari geseran kiri awal hingga penarikan mundur melingkar. |

**Camera:** Gentle Truck Left → Dolly-Out (~1.7×) + Orbit Left (~25°–35°) + Pan Right (~15°–20°).

---

<a id="shot-05"></a>

### Shot 05 · bathroom

**Time:** 16.67–21.33s · **Duration:** 4.67s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi berlorong kubah melengkung organik tampak plester putih dengan skylight terang di bagian atas dan jendela bundar besar berbingkai tampak kayu di dinding belakang. Lantai tampak marmer putih berurat halus naik dua undakan melengkung menuju panggung bathtub beralas ubin bermotif geometris pucat; dinding lengkung kiri dilengkapi tiga ambalan tampak kayu yang mengikuti kurva kubah.

**Furnitur & dekorasi**

> Di puncak undakan berdiri bathtub oval freestanding berwarna putih-merah muda lembut dengan keran berdiri tampak kuningan di sisi kirinya. Di sisi kanan depan terdapat meja wastafel melayang dua tingkat dengan wastafel mangkuk bundar, keran kuningan, cermin bundar besar berbingkai emas, serta susunan gulungan handuk krem dan merah muda; di kiri depan terlihat tepi kloset, rak ceruk berpanel kayu dengan cermin lengkung, keset merah muda bermotif di tengah lantai, lampu gantung bola bertingkat di kanan atas, dan tanaman pot serta rambat hijau melimpah.

**Lingkungan**

> Melalui jendela bundar besar terlihat langit biru cerah berawan sangat tipis dengan semburat cahaya terang, sementara dedaunan hijau rambat dan tanaman pot mengelilingi sisi kubah dan bathtub.

#### **B. Framing & Lighting**

- **Fokus:** Bathtub oval freestanding dan jendela bundar di ujung sumbu ruang.
- **Camera Start:** Di pintu masuk lorong kamar mandi pada sumbu tengah, di antara tepi kloset kiri bawah dan meja wastafel melayang kanan. · Menghadap lurus sepanjang sumbu simetris menuju bathtub oval freestanding dan jendela bundar di dinding ujung. · front · Setinggi mata (eye-level) sejajar tengah jendela bundar. · Datar.
- **Framing:** Wide simetris menampilkan lorong berkubah lengkung putih, tepi kloset kiri bawah, keset merah muda, meja wastafel kanan dengan gulungan handuk, cermin bundar kiri-kanan, dan bathtub di ujung. → Medium close-up pada bathtub oval putih-krem, keran lantai kuningan, rak dinding melengkung kiri, tanaman rimbun kanan, dan jendela bundar besar berlatar langit biru.
- **Lighting:** Cahaya alami melimpah dari skylight atap melengkung dan jendela bundar besar, dilengkapi lampu gantung bola kuningan-merah muda di sisi kanan atas.
- **Foreground dan kedalaman:** Tepi kloset kiri bawah, keset merah muda bermotif, meja wastafel melayang dengan wastafel mangkuk dan gulungan handuk di kanan, serta undakan marmer berurat merah muda. · Perspektif terowongan lengkung simetris yang kuat mengarahkan mata langsung ke bathtub dan jendela bundar terang di ujung.
- **Reveal:** Gerak maju melewati area wastafel dan undakan marmer menuju detail bathtub oval, keran berdiri kuningan, dan pemandangan langit cerah di jendela bundar.
- **Kesesuaian gerak:** Laju maju lurus menyusuri sumbu simetris kubah memberi penutup tur yang tenang dan terfokus.

#### **C. Camera Movement**

Kamera melaju maju lurus menyusuri sumbu tengah lorong kamar mandi berkubah menuju bathtub oval, lalu menambahkan sapuan halus ke kanan pada bagian akhir pendekatan.

**Tempo:** Tempo sedang dan konsisten sepanjang 4,67 detik pendekatan di lorong kamar mandi.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 16.67–19.83 | bathroom · Melaju lurus melewati area wastafel dan undakan marmer menuju bathtub oval | Dolly-In (~1.8×–1.9×) | Tempo sedang dan konsisten sepanjang 4,67 detik pendekatan di lorong kamar mandi. |
| 19.83–21.33 | bathroom · Mendekati sisi kanan bathtub oval, tanaman hijau, dan jendela bundar | Dolly-In (~1.3×–1.4×) + subtle Pan Right (~8°–12°) | Tempo sedang dan konsisten sepanjang 4,67 detik pendekatan di lorong kamar mandi. |

**Camera:** Dolly-In (~1.8×–1.9×) → Dolly-In (~1.3×–1.4×) + subtle Pan Right (~8°–12°).

**Catatan referensi:** Kelima shot dipisahkan oleh 4 cut keras pada frame native 138, 242, 349, dan 500. Seluruh uraian material didasarkan pada tampilan visual tanpa memastikan bahan fisik, dan urutan edit tidak menyimpulkan keterhubungan denah fisik antarruang.
