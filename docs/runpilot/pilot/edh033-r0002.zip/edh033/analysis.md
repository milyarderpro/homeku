# edh033 — Woodland Modern Cottage dengan Loft dan Tangga Batu

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Woodland Modern Cottage dengan Loft dan Tangga Batu
- **Tipe rumah:** Detached Small House
- **Gaya utama:** **Modern Cottage**
- **Pengaruh gaya:** Rustic
- **Gaya interior:** Modern Farmhouse
- **Susunan ruang utama:** Ruang bawah terbuka berisi zona duduk, makan dan dapur; loft tidur terbuka dengan tangga kiri; kamar mandi/laundry diperlihatkan terpisah
- **Ciri khas:** Dinding batu bulat lengkung di samping tangga eksterior serta kamar tidur loft menghadap ruang duduk
- **Material utama:** Bidang putih halus, batu bulat natural-look, bingkai hitam; papan motif kayu dan panel putih interior
- **Pencahayaan:** Cahaya luar tersaring pepohonan, sconce hangat; interior lampu dinding, pendant dan downlight
- **Atmosfer:** Kompak, hangat dan nyaman dengan kontras rustic-modern
- **Lingkungan:** Rumput, pepohonan tinggi, lereng batu di belakang dan pagar kayu

### Palet warna

| Peran | Warna | HEX |
| --- | --- | --- |
| Dominan | Putih hangat | `#E2DED1` |
| Pendamping | Kayu cokelat | `#A17D55` |
| Pendamping | Abu muda | `#B7B9B8` |
| Aksen | Arang | `#252525` |
| Aksen | Hijau tua | `#24483C` |
| Aksen | Merah terang | `#C92115` |

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Volume bawah kubus dengan volume atas lebih kecil dan teras berpagar hitam |
| **Lantai & bentuk atap** | Dua tingkat tampak pada eksterior; interior dengan loft terbuka · Atap tampak datar/landai dengan lis hitam tipis |
| **Tapak bangunan** | Massa kompak mendekati persegi panjang |
| **Proporsi utama** | Massa utama tinggi relatif terhadap lebar; lantai atas sebagian mundur menjadi teras |
| **Perkiraan luas lantai** | **45–80 m²** |

## 3. Shot Timeline

Durasi 18.67s · 4 shot.

**Camera Pattern:** IN – IN – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–5.03 | 5.03s | Eksterior dan pelataran | Mild Dolly-In (~1.3×) + Accelerating Orbit Right + Pan Left. |
| 02 | 5.03–12.83 | 7.80s | Ruang duduk, makan dan dapur terbuka / Loft tidur | Gentle Tilt Down (~8°, Ease-Out) → Straight Dolly-In (~1.3×) + Tilt Up (~15°, Ease-Out). |
| 03 | 12.83–17.13 | 4.30s | Kamar mandi dan laundry | Diagonal Dolly-In (~1.8×) + Moderate Pan Right. |
| 04 | 17.13–18.67 | 1.53s | Eksterior dan pelataran | Mild Dolly-Out (~1.2×) + Orbit Left + Pan Right (Ease-Out). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Eksterior dan pelataran · 0.00s**

> Dari halaman, pandangan serong setinggi mata mencakup kedua volume putih, dinding batu lengkung, tangga, balkon, bukaan tinggi, rumput dan pepohonan belakang.

**Shot 02 · Ruang duduk, makan dan dapur terbuka / Loft tidur · 7.70s**

> Dari depan ruang duduk dengan pandangan relatif frontal dan sedikit menunduk, cakupan wide memperlihatkan sofa dan meja kopi, tangga kiri, zona makan/dapur di bawah loft serta tempat tidur terbuka di atas.

**Shot 03 · Kamar mandi dan laundry · 12.83s**

> Dari dekat akses, kamera menghadap serong pada deret counter kanan dan shower kiri; frame wide mencakup runner, tepi kloset, washer, kabinet, wastafel dan rak penyimpanan.

**Shot 04 · Eksterior dan pelataran · 18.63s**

> Dari halaman sedikit lebih jauh, pandangan serong mencakup kembali dinding batu dengan jendela lengkung, tangga, balkon, bukaan kaca tinggi dan pelataran berumput.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Eksterior dan pelataran

**Time:** 0.00–5.03s · **Duration:** 5.03s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Massa putih kompak dua tingkat dengan atap tipis gelap. Tangga luar beranak cokelat dan parapet putih melengkung naik di depan bidang batu bulat dengan jendela lengkung; lantai atas memiliki balkon railing vertikal hitam, bukaan grid dan pintu gelap. Di bawah terdapat bukaan kaca tinggi berbingkai hitam dan sepasang lampu dinding.

**Furnitur & dekorasi**

> Bangku luar beralas dan bantal terang di sisi kanan tangga, meja rendah rangka gelap, pot tanaman dan tanaman merambat pada dinding batu.

**Lingkungan**

> Pelataran paving terang membatasi rumput hijau; stepping stone di kanan, pagar kayu, pepohonan tinggi serta tebing batu terang di belakang.

#### **B. Framing & Lighting**

- **Fokus:** Rumah dan tangga
- **Camera Start:** Di halaman di depan-samping kiri relatif terhadap bukaan kaca tinggi · Menghadap serong ke massa dan tangga · oblique · Sekitar tinggi mata · Sedikit mendongak
- **Framing:** Wide massa utuh dan tapak → Medium-wide fokus tangga dan bukaan kaca
- **Lighting:** Cahaya luar lembut, sconce hangat
- **Foreground dan kedalaman:** Rumput dan paving · Lawn dan paving, rumah, pohon/lereng
- **Reveal:** Sisi bukaan tinggi dan bangku semakin terbuka
- **Kesesuaian gerak:** Lapisan batu, tangga, balkon dan latar memberi paralaks

#### **C. Camera Movement**

Kamera mendekat ringan sambil mengitari fasad ke kanan; perubahan sisi fasad makin cepat menuju akhir, dengan kompensasi arah pandang ke kiri. Tangga dan bukaan kaca menjadi fokus.

**Tempo:** Awal perubahan framing kecil; perubahan sisi fasad makin nyata pada paruh akhir.

**Camera:** Mild Dolly-In (~1.3×) + Accelerating Orbit Right + Pan Left.

---

<a id="shot-02"></a>

### Shot 02 · Ruang duduk, makan dan dapur terbuka / Loft tidur

**Time:** 5.03–12.83s · **Duration:** 7.80s

**Shot Type:** Continuous shot · Multi area · No cut.

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

##### **Ruang duduk, makan dan dapur terbuka**

**Arsitektur**

> Ruang bawah menyatu dengan void tinggi di depan dan loft di atas zona makan/dapur. Lantai motif papan kayu, dinding putih horizontal, tangga lurus berstruktur gelap di kiri; koridor dan pintu di belakang meja, kabinet hijau di kanan belakang.

**Furnitur & dekorasi**

> Sofa sectional abu muda di kanan depan dengan chaise ke kiri, bantal merah dan throw merah; meja kopi persegi panjang gelap dengan dekorasi lentera di atas karpet abu. Meja makan persegi panjang motif kayu dengan kursi kayu berada memanjang ke belakang; pendant di atasnya dan oven/microwave bertumpuk di dapur.

**Lingkungan**

> Cahaya masuk dari jendela kecil di bagian atas, tidak ada panorama luar yang jelas dari ruang bawah.

##### **Loft tidur**

**Arsitektur**

> Mezanin tidur terbuka ke void dengan railing hitam horizontal, dinding putih berpanel, plafon papan kayu gelap, bukaan berpintu kayu di kedua sisi dan jendela kecil di kiri.

**Furnitur & dekorasi**

> Tempat tidur menghadap railing dengan bedding putih, bantal merah dan headboard hijau tua; nakas gelap di kiri dan meja/penyimpanan di kanan. Tiga lampu dinding sejajar di atas headboard.

**Lingkungan**

> Jendela kecil kiri memberi cahaya; pemandangan luar tidak terbaca.

#### **B. Framing & Lighting**

- **Fokus:** Susunan ruang vertikal
- **Camera Start:** Di sisi zona duduk menghadap belakang rumah · Menghadap lurus ke loft dan zona makan · frontal · Relatif tinggi terhadap sofa · Sedikit menunduk pada awal
- **Framing:** Wide interior bertingkat → Lebih dekat loft dan meja makan; sofa hilang dari bawah
- **Lighting:** Sconce, pendant, jendela kecil dan lampu plafon
- **Foreground dan kedalaman:** Sofa abu dan aksen merah · Sofa dan meja kopi, makan, loft dan dapur
- **Reveal:** Meja kopi tampak lebih utuh lalu plafon dan loft lebih dominan
- **Kesesuaian gerak:** Jalur tengah memberi ruang menuju belakang
- **Area:** Ruang duduk, makan dan dapur terbuka / Loft tidur
- **Rute kamera:** —

**Hubungan antararea**

- **Penghubung area:** —
- **Peralihan:** Ruang duduk, makan dan dapur terbuka · 5.03–12.83s; Loft tidur · 5.03–12.83s
- **Orientasi ruang:** Satu take kontinu hingga batas shot, tanpa cut internal.

#### **C. Camera Movement**

Pandangan turun lembut dan mereda, memperlihatkan meja kopi serta sofa. Setelah berbalik, kamera maju dominan lurus sambil mengangkat pandangan menuju loft dan plafon; gerak naik mereda menjelang akhir.

**Tempo:** Gerak awal lembut, kemudian pendekatan dan sapuan vertikal lebih nyata pada tengah fase kedua sebelum mereda.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 5.03–7.70 | Ruang duduk, makan dan dapur terbuka / Loft tidur · Sofa dan meja kopi | Gentle Tilt Down (~8°, Ease-Out) | Gerak awal lembut, kemudian pendekatan dan sapuan vertikal lebih nyata pada tengah fase kedua sebelum mereda. |
| 7.70–12.83 | Ruang duduk, makan dan dapur terbuka / Loft tidur · Loft dan meja makan | Straight Dolly-In (~1.3×) + Tilt Up (~15°, Ease-Out) | Gerak awal lembut, kemudian pendekatan dan sapuan vertikal lebih nyata pada tengah fase kedua sebelum mereda. |

**Camera:** Gentle Tilt Down (~8°, Ease-Out) → Straight Dolly-In (~1.3×) + Tilt Up (~15°, Ease-Out).

---

<a id="shot-03"></a>

### Shot 03 · Kamar mandi dan laundry

**Time:** 12.83–17.13s · **Duration:** 4.30s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang sempit dengan lantai motif papan kayu dan dinding putih. Shower di kiri belakang dengan ubin kecil putih bergaris gelap serta tirai pola garis; ceruk washer di tengah dan vanity di kanan. Downlight pada plafon putih.

**Furnitur & dekorasi**

> Washer front-load gelap di bawah countertop putih; kabinet kayu vertikal di atas dan rak terbuka hitam-kayu dengan tanaman serta wadah. Wastafel putih menonjol di kanan di atas rak kayu terbuka berisi keranjang anyam dan handuk lipat; tepi toilet terlihat di kiri awal shot. Karpet runner pola hitam-putih.

**Lingkungan**

> Tidak tampak bukaan luar; pencahayaan buatan terang merata.

#### **B. Framing & Lighting**

- **Fokus:** Mesin cuci dan counter
- **Camera Start:** Dekat akses kamar mandi, serong ke counter · Menghadap ke shower kiri dan laundry kanan · oblique · Sekitar tinggi mata · Sedikit menunduk
- **Framing:** Wide kamar mandi-laundry → Close-up washer di bawah counter
- **Lighting:** Downlight terang
- **Foreground dan kedalaman:** Runner dan tepi toilet · Runner, washer/vanity, shower dan kabinet
- **Reveal:** Washer menjadi fokus; shower dan vanity keluar bingkai
- **Kesesuaian gerak:** Jarak antara runner, counter, kabinet dan shower memperjelas skala

#### **C. Camera Movement**

Kamera mendekati washer melalui lintasan diagonal, disertai sapuan pandang kanan yang sedang. Shower dan vanity keluar dari bingkai; washer memenuhi gambar. Rotasi vertikal tersendiri belum cukup terbukti.

**Tempo:** Pembesaran bertambah nyata pada bagian tengah hingga akhir, lalu sedikit mereda pada interval terakhir; bukan bukti percepatan fisik yang pasti.

**Camera:** Diagonal Dolly-In (~1.8×) + Moderate Pan Right.

---

<a id="shot-04"></a>

### Shot 04 · Eksterior dan pelataran

**Time:** 17.13–18.67s · **Duration:** 1.53s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Massa putih kompak dua tingkat dengan atap tipis gelap. Tangga luar beranak cokelat dan parapet putih melengkung naik di depan bidang batu bulat dengan jendela lengkung; lantai atas memiliki balkon railing vertikal hitam, bukaan grid dan pintu gelap. Di bawah terdapat bukaan kaca tinggi berbingkai hitam dan sepasang lampu dinding.

**Furnitur & dekorasi**

> Bangku luar beralas dan bantal terang di sisi kanan tangga, meja rendah rangka gelap, pot tanaman dan tanaman merambat pada dinding batu.

**Lingkungan**

> Pelataran paving terang membatasi rumput hijau; stepping stone di kanan, pagar kayu, pepohonan tinggi serta tebing batu terang di belakang.

#### **B. Framing & Lighting**

- **Fokus:** Fasad dan tangga
- **Camera Start:** Di halaman dekat sisi bukaan tinggi dan tangga · Menghadap serong ke fasad · oblique · Sekitar tinggi mata · Sedikit mendongak
- **Framing:** Medium-wide tangga dan bukaan tinggi → Wide lebih lengkap dinding batu dan rumput
- **Lighting:** Cahaya luar lembut, sconce hangat
- **Foreground dan kedalaman:** Paving, pot dan rumput · Paving dan tangga, balkon, pohon
- **Reveal:** Bidang batu lengkung dan halaman kembali terlihat
- **Kesesuaian gerak:** Tepi batu dekat dan pohon jauh berbeda gerak

#### **C. Camera Movement**

Kamera mundur ringan sambil mengitari fasad ke kiri dan mengompensasi arah pandang ke kanan; perubahan framing mereda menuju akhir sehingga bidang batu dan halaman kembali terlihat.

**Tempo:** Perubahan framing lebih besar di awal dan melambat menjelang akhir shot pendek.

**Camera:** Mild Dolly-Out (~1.2×) + Orbit Left + Pan Right (Ease-Out).

**Catatan referensi:** Rentang luas 45–80 m² adalah estimasi kasar visual dari volume kompak dan loft, bukan ukuran terukur. Tipe/gaya merupakan interpretasi; material hanya tampilan. Hubungan fisik eksterior, loft dan kamar mandi tidak dibuktikan oleh hard cut. Tidak ada kalibrasi pose kamera; kemungkinan perubahan proyeksi atau deformasi sumber tidak dapat disingkirkan.
