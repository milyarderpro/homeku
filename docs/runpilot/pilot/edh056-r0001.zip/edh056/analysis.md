# edh056 — Modern Woodland Villa — Warm Rustic Interior

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Modern Woodland Villa — Warm Rustic Interior
- **Tipe rumah:** Villa
- **Gaya utama:** **Contemporary Modern**
- **Pengaruh gaya:** Rustic
- **Gaya interior:** Modern Rustic
- **Susunan ruang utama:** Teras menuju living dan dapur yang terbuka secara visual; kamar tidur dan kamar mandi muncul pada cut terpisah
- **Ciri khas:** Tangga teras menyala, railing hitam, kabinet dua warna dan aksen batu bertekstur
- **Material utama:** Permukaan putih halus, bidang dan furnitur tampak kayu, tekstur batu pada backsplash dan kamar tidur
- **Pencahayaan:** Cahaya luar tersebar; lentera fasad, lampu tangga, downlight, pendant serta pencahayaan bawah kabinet berwarna hangat
- **Atmosfer:** Kontras eksterior modern yang tenang dengan interior hangat dan nyaman
- **Lingkungan:** Rumput dan pepohonan tinggi mengelilingi rumah

### Palet warna

| Peran | Warna | HEX |
| --- | --- | --- |
| Dominan | Putih hangat | `#E2DED2` |
| Pendamping | Krem linen | `#C6B9A6` |
| Pendamping | Cokelat kayu | `#976C47` |
| Aksen | Hitam arang | `#272421` |
| Aksen | Hijau zaitun | `#59613B` |
| Pendamping | Beige batu | `#B9A48E` |

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | medium |
| **Bentuk bangunan** | Volume kubus putih bertingkat dengan balkon terbuka |
| **Lantai & bentuk atap** | Dua tingkat tampak dari fasad · Garis atap datar dan kanopi tipis gelap |
| **Tapak bangunan** | Massa kompak bertingkat; denah penuh tidak terlihat |
| **Proporsi utama** | Massa bawah melebar dan volume atas lebih sempit, balkon di atas teras |
| **Perkiraan luas lantai** | **90–150 m²** |

## 3. Shot Timeline

Durasi 23.70s · 4 shot.

**Camera Pattern:** IN – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–12.67 | 12.67s | exterior / living / kitchen | Orbit Left + Subtle Pan Right + Mild Dolly-In (~1.2×) → Dolly-In + Gentle Pan Right → Dolly-In (~1.6×) + Moderate Pan Left (~20°). |
| 02 | 12.67–16.40 | 3.73s | bedroom | Dolly-Out (~1.4–1.9×) + Gentle Pan Left (~10°). |
| 03 | 16.40–21.13 | 4.73s | bathroom | Dolly-In (~1.8×) + Moderate Pan Left (~20°). |
| 04 | 21.13–23.70 | 2.57s | exterior | Dolly-Out (~2.1×, Ease-Out) + Subtle Orbit Left + Gentle Pan Right. |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · exterior · 2.33s**

> Dari halaman menghadap serong fasad; massa dua tingkat, balkon, teras, tangga, dan pohon terlihat dalam cakupan lebar.

**Shot 01 · living / kitchen · 7.33s**

> Dari sisi dalam pintu menghadap sofa dan dapur belakang; sofa, meja kopi, pintu samping, plafon dan kabinet terlihat bersama.

**Shot 01 · kitchen · 12.63s**

> Dari tepi living menghadap dapur, meja kerja depan dan kabinet belakang terlihat dengan area lantai di antaranya.

**Shot 02 · bedroom · 16.37s**

> Dari sisi kaki ranjang menghadap serong kepala ranjang; ranjang hampir utuh, nakas, jendela, balok plafon, dan lantai tampak.

**Shot 03 · bathroom · 16.40s**

> Dari sisi masuk menghadap serong ke shower; vanity kiri, toilet tengah, rak dan kaca shower terlihat bersama.

**Shot 04 · exterior · 23.63s**

> Dari halaman menghadap fasad serong, massa dua tingkat, balkon, tangga bercahaya, kursi dan pepohonan terlihat.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · exterior / living / kitchen

**Time:** 0.00–12.67s · **Duration:** 12.67s

**Shot Type:** Continuous shot · Multi area · No cut.

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

##### **exterior**

**Arsitektur**

> Massa dua tingkat putih dengan atap datar, volume atas mundur membentuk balkon berpagar hitam. Pintu dan jendela tinggi berkisi hitam, kanopi gelap tipis, teras bertangga dengan lampu di bawah anak tangga.

**Furnitur & dekorasi**

> Kursi santai anyaman dengan bantalan terang dan meja kecil di teras bawah; pot tanaman dan lentera dekoratif di tepi tangga.

**Lingkungan**

> Hamparan rumput hijau di antara batang pohon tinggi, cahaya luar lembut.

##### **living**

**Arsitektur**

> Ruang keluarga terbuka menghadap dapur, plafon putih rata dengan downlight, lantai netral dan pintu kaca tinggi bertransom di sisi kanan pandangan masuk.

**Furnitur & dekorasi**

> Sofa L krem mengelilingi meja kopi kayu persegi panjang dengan rak terbuka, karpet terang dan bantal campuran krem/cokelat.

**Lingkungan**

> Rumput dan pohon tampak melalui pintu kaca kanan.

##### **kitchen**

**Arsitektur**

> Dapur terbuka di belakang sofa; kabinet bawah tampak kayu, kabinet atas krem berpanel dan sebagian display bercahaya. Backsplash bertekstur batu, jendela kisi hitam di atas meja kerja, lampu bawah kabinet dan cahaya plafon tepi.

**Furnitur & dekorasi**

> Meja kerja depan berpanel kayu dengan countertop terang dan bangku kaki gelap; tampak terpisah dari deret belakang, tipe island kemungkinan. Kabinet berpanel, perangkat masak di bawah tudung berbingkai kayu, pendant lentera di atas meja.

**Lingkungan**

> Vegetasi tampak samar melalui jendela dapur.

#### **B. Framing & Lighting**

- **Fokus:** Fasad lalu living dan dapur
- **Camera Start:** Di halaman berumput di antara batang pohon · Serong ke fasad depan · oblique · Sekitar tinggi mata · Hampir datar
- **Framing:** Wide fasad terhalang batang pohon → Medium wide dapur di belakang sofa
- **Lighting:** Cahaya luar lembut dan lampu interior hangat
- **Foreground dan kedalaman:** Batang pohon, teras, kusen, sofa · Pohon → fasad → pintu → living → dapur
- **Reveal:** Batang membuka fasad, pintu membuka ruang, dapur mendominasi akhir
- **Kesesuaian gerak:** Gerak kontinu mengubah lapisan dan cakupan; gunakan batas sumber apa adanya.
- **Area:** exterior / living / kitchen
- **Rute kamera:** exterior (0.00–6.83s · awal halaman dan pintu teras · Fasad dan pintu) → living (6.83–12.67s · Pintu kaca terbuka · Sofa lalu dapur terlihat dari living)

**Hubungan antararea**

- **Penghubung area:** Pintu kaca teras membuka ke living.; Dapur terlihat di belakang sofa tanpa dinding penuh.
- **Peralihan:** exterior · 0.00–7.00s; living · 4.33–12.67s; kitchen · 5.17–12.67s
- **Orientasi ruang:** —

#### **C. Camera Movement**

Kamera mengitari fasad ke kiri dengan kompensasi pan kanan tipis dan gerak maju ringan. Kamera kemudian maju dominan melalui pintu sambil mengarahkan pandangan lembut ke kanan, lalu terus mendekati sofa dan dapur dengan sapuan kiri sedang.

**Tempo:** Awal menyapu pohon, laju mendekat lebih terasa di teras, lalu melambat relatif di living dan maju lagi ke arah dapur.

**Alur visual:** Halaman → tangga/teras → pintu → living; dapur menjadi fokus akhir, tetapi masuk ke zona kerja dapur tidak terkonfirmasi.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 0.00–2.50 | exterior / living / kitchen · Fasad | Orbit Left + Subtle Pan Right + Mild Dolly-In (~1.2×) | Awal menyapu pohon, laju mendekat lebih terasa di teras, lalu melambat relatif di living dan maju lagi ke arah dapur. |
| 2.50–7.00 | exterior / living / kitchen · Pintu dan living | Dolly-In + Gentle Pan Right | Awal menyapu pohon, laju mendekat lebih terasa di teras, lalu melambat relatif di living dan maju lagi ke arah dapur. |
| 7.00–12.67 | exterior / living / kitchen · Living menuju dapur | Dolly-In (~1.6×) + Moderate Pan Left (~20°) | Awal menyapu pohon, laju mendekat lebih terasa di teras, lalu melambat relatif di living dan maju lagi ke arah dapur. |

**Camera:** Orbit Left + Subtle Pan Right + Mild Dolly-In (~1.2×) → Dolly-In + Gentle Pan Right → Dolly-In (~1.6×) + Moderate Pan Left (~20°).

---

<a id="shot-02"></a>

### Shot 02 · bedroom

**Time:** 12.67–16.40s · **Duration:** 3.73s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding kepala ranjang bertekstur blok batu beige, jendela vertikal kisi hitam dengan tirai panjang krem, lampu dinding hitam di sela bukaan. Balok plafon tampak kayu dan chandelier gelap; lantai tampak papan kayu.

**Furnitur & dekorasi**

> Ranjang besar berbingkai kayu, selimut putih berlapis throw cokelat muda, bantal krem dan cokelat, nakas berlaci di samping serta dekorasi tanaman.

**Lingkungan**

> Cahaya siang masuk dari jendela dan jatuh ke lantai; detail lingkungan di luar tidak jelas.

#### **B. Framing & Lighting**

- **Fokus:** Ranjang dan dinding kepala
- **Camera Start:** Dekat sisi kaki ranjang · Serong menuju kepala ranjang dan jendela · oblique · Sekitar tinggi mata · Hampir datar
- **Framing:** Medium dekat tekstil dan kepala ranjang → Wide ranjang, nakas, plafon dan lantai
- **Lighting:** Cahaya jendela lembut dan lampu dinding hangat
- **Foreground dan kedalaman:** Selimut dan bantal · Ranjang → dinding batu → jendela
- **Reveal:** Mundur membuka kaki ranjang dan balok plafon
- **Kesesuaian gerak:** Gerak kontinu mengubah lapisan dan cakupan; gunakan batas sumber apa adanya.

#### **C. Camera Movement**

Kamera mundur secara halus dari ranjang sambil menyapu pandangan sedikit ke kiri, membuka footboard, lantai dan sisi kiri kamar.

**Tempo:** Mundur halus dengan perubahan cakupan konsisten.

**Camera:** Dolly-Out (~1.4–1.9×) + Gentle Pan Left (~10°).

---

<a id="shot-03"></a>

### Shot 03 · bathroom

**Time:** 16.40–21.13s · **Duration:** 4.73s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi dengan dinding terang, aksen papan kayu pada sisi vanity, ceruk rak vertikal dan shower kaca berhardware hitam. Lantai shower berpola kerikil kecil, jendela hitam di belakang dan lampu gantung kaca.

**Furnitur & dekorasi**

> Vanity kayu berlaci dengan rak bawah terbuka, wastafel vessel putih dan cermin bundar hitam. Toilet putih di bawah rak ceruk berisi handuk/keranjang; shower kepala bulat dan hand shower hitam, bangku kayu di belakang.

**Lingkungan**

> Vegetasi terlihat melalui jendela shower.

#### **B. Framing & Lighting**

- **Fokus:** Rak dan vanity
- **Camera Start:** Di sisi depan vanity · Serong ke toilet dan shower · oblique · Sekitar tinggi mata · Hampir datar
- **Framing:** Wide vanity, toilet dan shower → Close-up rak, tanaman dan vanity
- **Lighting:** Pendant hangat dan cahaya jendela
- **Foreground dan kedalaman:** Vanity dan tanaman · Vanity → toilet → shower
- **Reveal:** Shower keluar sisi kanan, rak mendominasi
- **Kesesuaian gerak:** Gerak kontinu mengubah lapisan dan cakupan; gunakan batas sumber apa adanya.

#### **C. Camera Movement**

Kamera mendekati vanity dan rak ceruk sambil menyapu pandangan ke kiri secara sedang; sapuan tampak lebih kuat menjelang akhir.

**Tempo:** Gerak maju dan sapuan kiri sedang; pembesaran melambat relatif di akhir ketika sapuan kiri semakin terasa.

**Camera:** Dolly-In (~1.8×) + Moderate Pan Left (~20°).

---

<a id="shot-04"></a>

### Shot 04 · exterior

**Time:** 21.13–23.70s · **Duration:** 2.57s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Massa dua tingkat putih dengan atap datar, volume atas mundur membentuk balkon berpagar hitam. Pintu dan jendela tinggi berkisi hitam, kanopi gelap tipis, teras bertangga dengan lampu di bawah anak tangga.

**Furnitur & dekorasi**

> Kursi santai anyaman dengan bantalan terang dan meja kecil di teras bawah; pot tanaman dan lentera dekoratif di tepi tangga.

**Lingkungan**

> Hamparan rumput hijau di antara batang pohon tinggi, cahaya luar lembut.

#### **B. Framing & Lighting**

- **Fokus:** Fasad
- **Camera Start:** Dekat pintu teras · Serong ke pintu dan fasad · oblique · Sekitar tinggi mata · Hampir datar
- **Framing:** Medium dekat pintu dan kursi → Wide fasad dengan tangga dan pohon
- **Lighting:** Lampu fasad dan tangga hangat, cahaya luar lembut
- **Foreground dan kedalaman:** Kusen dan tanaman · Pintu → teras → halaman dan pohon
- **Reveal:** Mundur membuka balkon, tangga dan halaman
- **Kesesuaian gerak:** Gerak kontinu mengubah lapisan dan cakupan; gunakan batas sumber apa adanya.

#### **C. Camera Movement**

Kamera mundur cepat dari teras dengan lintasan melengkung tipis ke kiri dan kompensasi pandangan lembut ke kanan; pelebaran framing melambat jelas menjelang akhir.

**Tempo:** Pelebaran framing cepat pada awal, melambat mendekati akhir shot.

**Camera:** Dolly-Out (~2.1×, Ease-Out) + Subtle Orbit Left + Gentle Pan Right.

**Catatan referensi:** Estimasi luas kasar 90–150 m² berdasarkan massa dua tingkat, bukan pengukuran denah. Identitas area bedroom dan bathroom relatif terhadap denah tidak diketahui; kemiripan desain bukan bukti satu bangunan fisik. Pada frame 679 ada diskontinuitas kecil tampilan fasad; arah gerak, subjek dan susunan tetap kontinu sehingga tidak dipisah sebagai cut. Tampilan interior melalui kaca di shot 04 merupakan glimpse, tidak ada perjalanan masuk.
