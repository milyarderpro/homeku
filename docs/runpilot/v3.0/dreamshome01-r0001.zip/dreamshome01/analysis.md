# dreamshome01 — Sage Green Woodland Cottage

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Sage Green Woodland Cottage
- **Tipe rumah:** Cottage
- **Gaya utama:** **American Cottage**
- **Pengaruh gaya:** Country Cottage
- **Gaya interior:** English Country
- **Susunan ruang utama:** Teras depan, ruang tamu berperapian, dapur dan meja makan dalam satu ruang, kamar tidur dan kamar mandi; koneksi denah tidak ditunjukkan.
- **Ciri khas:** Atap depan melengkung, planter jendela, perapian batu, kabinet sage dan motif botani.
- **Material utama:** Siding horizontal hijau pucat, trim putih, tampilan batu alam, kayu hangat, tekstil tenun dan kabinet panel.
- **Pencahayaan:** Cahaya siang tersaring pepohonan, jendela interior terang, lampu aksen kuning hangat dan perapian.
- **Atmosfer:** Hangat, intim, tenang dengan dekorasi botani dan tekstur alami.
- **Lingkungan:** Tapak hijau berhutan, jalur batu, kerikil dan tanaman berbunga; pepohonan terlihat dari jendela.

### Palet warna

| Peran | Warna | HEX |
| --- | --- | --- |
| Dominan | Putih krem | `#E5D9C3` |
| Pendamping | Sage green | `#858D78` |
| Pendamping | Kayu madu | `#B0875B` |
| Pendamping | Beige linen | `#C4AE8D` |
| Aksen | Abu batu | `#928578` |
| Aksen | Hijau olive | `#737451` |

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Massa rendah tunggal dengan volume depan beratap melengkung dan teras di samping. |
| **Lantai & bentuk atap** | 1 · Atap gelap berbentuk lengkung dangkal pada volume depan, atap teras lebih rendah; cerobong tampak di belakang. |
| **Tapak bangunan** | compact rectangular |
| **Proporsi utama** | Massa rendah kompak, fasad sempit, teras di kanan dan lantai terangkat. |
| **Perkiraan luas lantai** | **35–65 m²** |

## 3. Shot Timeline

Durasi 20.03s · 5 shot.

**Camera Pattern:** IN – OUT – IN – OUT – IN.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–6.13 | 6.13s | Exterior | Accelerating Diagonal Dolly-In (~2.5×) + Gentle Pan Right (~10°–15°). |
| 02 | 6.13–9.60 | 3.47s | Living Room | Diagonal Dolly-Out (~1.6×) + Moderate Pan Left (~20°–25°). |
| 03 | 9.60–13.10 | 3.50s | Kitchen & Dining Area | Dolly-In (~1.6×) + Subtle Pan Right (~5°–10°). |
| 04 | 13.10–16.57 | 3.47s | Bedroom | Diagonal Dolly-Out (~1.7×) + Moderate Pan Left (~15°–20°). |
| 05 | 16.57–20.03 | 3.47s | Bathroom | Straight Dolly-In (~2.4×) + Subtle Pan Right (~5°). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Exterior · 0.00s**

> Kamera di jalur kerikil menghadap fasad hampir frontal dari jarak jauh, setinggi mata. Wide memperlihatkan massa rumah, tangga teras di kanan, pohon besar dan halaman di kiri.

**Shot 02 · Living Room · 9.57s**

> Dari sisi belakang sofa, kamera menghadap serong ke perapian di kanan dan jendela besar di kiri. Wide menampakkan susunan tempat duduk, meja tengah, lantai dan langit-langit melengkung.

**Shot 03 · Kitchen & Dining Area · 9.60s**

> Dari sisi meja makan, kamera menghadap ke wastafel bawah jendela dan kabinet di kanan. Wide mencakup meja bundar kiri, lintasan tengah, peralatan dapur dan bidang kerja di belakang.

**Shot 04 · Bedroom · 16.53s**

> Kamera berada dekat sisi masuk pada sudut kaki ranjang, menghadap serong ke headboard dan jendela. Wide mencakup ranjang, meja samping, karpet, jendela belakang serta samping kanan.

**Shot 05 · Bathroom · 16.57s**

> Dari ambang pintu, kamera menghadap serong ke jendela tengah. Wide memperlihatkan shower kaca di kiri, toilet di tengah dan vanity kanan.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Exterior

**Time:** 0.00–6.13s · **Duration:** 6.13s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Rumah kompak berlantai terangkat, siding horizontal sage pucat dan trim putih. Atap depan melengkung dangkal dengan jendela kecil di atas jendela utama berkisi dan shutter; cerobong tampak di belakang. Teras kanan beratap rendah dengan tiang dan pagar putih, tangga kayu menuju pintu.

**Furnitur & dekorasi**

> Planter berbunga di bawah jendela, kursi putih di teras, pot bunga di sisi tangga, bendera dan lampu dinding hangat.

**Lingkungan**

> Pohon dewasa mengelilingi rumah, hamparan rumput di kiri, jalur batu tidak beraturan menuju tangga dari kerikil.

#### **B. Framing & Lighting**

- **Fokus:** Fasad, tangga dan teras.
- **Camera Start:** Di jalur kerikil depan rumah, agak ke kiri dari sumbu teras. · Menghadap fasad dan teras kanan. · frontal · Kira-kira setinggi mata. · Hampir datar.
- **Framing:** Wide eksterior dengan halaman. → Medium wide teras, kemudian tertutup efek blur.
- **Lighting:** Cahaya siang tersebar di bawah pohon; lampu teras hangat.
- **Foreground dan kedalaman:** Kerikil, tepi rumput dan jalan batu. · Jalur depan, rumah, pepohonan belakang.
- **Reveal:** Tangga dan sisi kanan teras semakin dekat dan dominan.
- **Kesesuaian gerak:** Pendekatan mengarahkan perhatian dari tapak ke akses.

#### **C. Camera Movement**

Kamera mendekat serong kanan ke teras, dengan sapuan kanan ringan. Perubahan framing per interval makin besar, tetapi perspektif turut memperkuat pembesaran; transisi blur di ujung bukan gerak kamera.

**Tempo:** Pendekatan sedang, perubahan tampilan lebih besar di paruh akhir.

**Camera:** Accelerating Diagonal Dolly-In (~2.5×) + Gentle Pan Right (~10°–15°).

---

<a id="shot-02"></a>

### Shot 02 · Living Room

**Time:** 6.13–9.60s · **Duration:** 3.47s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding krem dengan perapian berlapis tampilan batu bulat dan mantel kayu; rak terbuka serta kabinet bawah mengapitnya. Jendela besar berkisi di kiri, plafon melengkung dengan rusuk dan lantai tampak papan kayu.

**Furnitur & dekorasi**

> Sofa krem membelakangi kamera, dua kursi sage mengapit meja kopi kayu persegi panjang dengan rak keranjang. Karpet tenun, bantal botani, selimut olive, vas bunga, artwork botani dan lampu meja.

**Lingkungan**

> Jendela memperlihatkan vegetasi dan batang pohon di luar.

#### **B. Framing & Lighting**

- **Fokus:** Perapian batu dan zona duduk.
- **Camera Start:** Dekat meja tengah, menghadap dinding perapian; frame pertama tertutup transisi blur. · Ke perapian dan rak di kedua sisi. · oblique · Sekitar tinggi dada hingga mata. · Sedikit menunduk pada awal.
- **Framing:** Blur transisi menuju medium wide perapian. → Wide ruang tamu dari belakang sofa.
- **Lighting:** Jendela kiri, api, lampu meja dan lampu plafon hangat.
- **Foreground dan kedalaman:** Meja kayu dan tepian sofa setelah blur mereda. · Sofa, meja, kursi dan dinding perapian.
- **Reveal:** Jendela kiri, sofa depan dan plafon makin terlihat.
- **Kesesuaian gerak:** Mundur membuka hubungan furnitur dengan jendela.

#### **C. Camera Movement**

Sesudah efek blur, kamera mundur serong sambil menyapu ke kiri dari perapian menuju cakupan seluruh ruang duduk. Perubahan relatif cukup merata lalu sedikit mereda pada ujung.

**Tempo:** Sedang, perubahan framing terasa kontinu.

**Camera:** Diagonal Dolly-Out (~1.6×) + Moderate Pan Left (~20°–25°).

---

<a id="shot-03"></a>

### Shot 03 · Kitchen & Dining Area

**Time:** 9.60–13.10s · **Duration:** 3.50s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang makan dan dapur berbagi lantai papan hangat. Jendela berkisi di belakang dan kiri; bidang kerja membentuk L pada belakang dan kanan, kabinet atas krem, backsplash terang dan rak kayu terbuka di kiri jendela.

**Furnitur & dekorasi**

> Wastafel putih apron-front di bawah jendela, dishwasher metalik di kiri, kompor dan hood metalik di kanan serta kulkas di sisi kanan awal. Meja makan bundar kayu dengan kursi rangka kayu dan bantalan motif; karpet motif di depan kabinet, papan potong dan tanaman di countertop.

**Lingkungan**

> Vegetasi hijau terlihat melalui jendela.

#### **B. Framing & Lighting**

- **Fokus:** Wastafel apron-front dan kabinet sage.
- **Camera Start:** Di ujung akses dapur dekat meja makan. · Ke wastafel dan sudut kabinet belakang. · oblique · Sekitar setinggi mata. · Sedikit menunduk.
- **Framing:** Wide dapur dan makan. → Medium wide area kerja.
- **Lighting:** Jendela belakang dan kiri, lampu gantung dan lampu bawah kabinet hangat.
- **Foreground dan kedalaman:** Meja bundar dan kursi kiri, lemari es kanan. · Meja makan, lorong lantai, wastafel dan jendela.
- **Reveal:** Detail wastafel, kabinet dan kompor makin dominan.
- **Kesesuaian gerak:** Maju mengisolasi area kerja dari meja makan.

#### **C. Camera Movement**

Kamera maju dari meja makan menuju wastafel dan bidang kerja, dengan koreksi pandangan kecil ke kanan terutama paruh akhir. Laju perubahan framing cukup merata.

**Tempo:** Sedang, pendekatan kontinu.

**Camera:** Dolly-In (~1.6×) + Subtle Pan Right (~5°–10°).

---

<a id="shot-04"></a>

### Shot 04 · Bedroom

**Time:** 13.10–16.57s · **Duration:** 3.47s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding aksen sage pada sisi headboard, dinding samping krem, jendela berkisi tinggi di dua sisi dengan tirai krem dan rel gelap. Lantai papan hangat, plafon putih.

**Furnitur & dekorasi**

> Ranjang berheadboard kayu menghadap kamera, seprai krem dengan selimut rajut olive, bantal botani. Meja kayu dan lampu hangat di sisi headboard, artwork botani, kursi dekat jendela kanan, karpet tenun luas dan kabinet krem di kanan depan.

**Lingkungan**

> Jendela memperlihatkan pepohonan dan cahaya hijau dari luar.

#### **B. Framing & Lighting**

- **Fokus:** Ranjang dan pencahayaan jendela.
- **Camera Start:** Dekat sisi kaki ranjang, lebih ke kanan dari sumbu ranjang. · Ke arah headboard di kiri dan jendela samping kanan. · oblique · Kira-kira tinggi dada. · Sedikit menunduk ke ranjang.
- **Framing:** Medium close ranjang dan jendela. → Wide kamar tidur.
- **Lighting:** Cahaya siang jendela belakang dan kanan, dua lampu meja serta lampu plafon hangat.
- **Foreground dan kedalaman:** Selimut rajut olive dan seprai krem. · Kaki ranjang, headboard, jendela dan sudut dinding.
- **Reveal:** Ranjang utuh, meja kiri, karpet, plafon dan kabinet tepi kanan.
- **Kesesuaian gerak:** Gerak mundur membuka konteks ruang dari tekstil.

#### **C. Camera Movement**

Kamera mundur serong dari sisi ranjang sambil memutar pandangan ke kiri agar headboard dan seluruh ranjang masuk. Perubahan framing lebih besar di tengah dan mereda di akhir.

**Tempo:** Sedang, lebih kecil menjelang akhir.

**Camera:** Diagonal Dolly-Out (~1.7×) + Moderate Pan Left (~15°–20°).

---

<a id="shot-05"></a>

### Shot 05 · Bathroom

**Time:** 16.57–20.03s · **Duration:** 3.47s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi kompak dengan shower walk-in di kiri, panel kaca bening dan ambang rendah, ubin krem tampak persegi panjang. Jendela putih berkisi di atas toilet, lantai krem dan dinding berpanel horizontal di belakang.

**Furnitur & dekorasi**

> Shower kepala bulat dan hand shower, toilet putih dengan pot tanaman dan keranjang kecil di tangki. Vanity sage dua laci dengan rak bawah terbuka berisi keranjang/handuk, countertop putih, cermin berbingkai kayu, lampu dinding dan karpet tenun.

**Lingkungan**

> Jendela menampakkan vegetasi hijau rapat di luar.

#### **B. Framing & Lighting**

- **Fokus:** Jendela dan toilet.
- **Camera Start:** Di ambang pintu kamar mandi. · Ke jendela di atas toilet. · oblique · Sekitar tinggi mata. · Sedikit menunduk agar lantai dan toilet terlihat.
- **Framing:** Wide kamar mandi. → Close jendela dan tangki toilet.
- **Lighting:** Cahaya jendela, lampu cermin dan downlight hangat.
- **Foreground dan kedalaman:** Kusen kiri dan karpet tenun. · Ambang, shower dan vanity, toilet serta jendela belakang.
- **Reveal:** Detail jendela, tanaman dan keranjang di atas tangki toilet.
- **Kesesuaian gerak:** Maju menyempitkan perhatian ke jendela.

#### **C. Camera Movement**

Kamera maju dari ambang menuju jendela di atas toilet, dengan koreksi kanan kecil. Pembesaran makin besar mendekati jendela; belum cukup untuk memastikan akselerasi fisik.

**Tempo:** Sedang, pembesaran tampak lebih cepat di akhir karena kedekatan.

**Camera:** Straight Dolly-In (~2.4×) + Subtle Pan Right (~5°).

**Catatan referensi:** Transisi pertama berupa blur/fade sekitar frame 179–189; batas dipilih pada frame 184 sebagai titik tengah, bukan hard cut literal. Tiga batas lain hard cut. Panel batas pertama shot 02 memang blur. Estimasi gerak dari gambar, bukan pose kamera terkalibrasi; kemungkinan gerak virtual/generatif tidak dapat dipastikan. Luas, tipe, gaya dan kontinuitas fisik merupakan estimasi.
