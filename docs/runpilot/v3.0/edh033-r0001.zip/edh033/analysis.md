# edh033 — Modern Woodland Cottage with Sleeping Loft

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Modern Woodland Cottage with Sleeping Loft
- **Tipe rumah:** Cottage
- **Gaya utama:** **Modern Rustic Cottage**
- **Pengaruh gaya:** Contemporary; Rustic
- **Gaya interior:** Modern Rustic
- **Susunan ruang utama:** Living dan dining/kitchen terbuka di bawah sleeping loft; tangga di kiri; bathroom dan laundry berbagi ruang pada shot terpisah
- **Ciri khas:** Dinding lengkung batu di sisi tangga luar, balkon hitam dan loft terbuka dengan railing hitam
- **Material utama:** Bidang putih, batu bulat multitone, aksen hitam, permukaan kayu cokelat pada plafon/lantai/kabinet
- **Pencahayaan:** Cahaya luar difus, lampu dinding dan tangga hangat; interior lampu dinding, pendant dan downlight
- **Atmosfer:** Kompak, hangat dan nyaman dengan kontras kayu, batu, hitam dan aksen merah
- **Lingkungan:** Rumput, jalur pijakan, pagar kayu, pohon tinggi dan lereng berbatu di belakang

### Palet warna

| Peran | Warna | HEX |
| --- | --- | --- |
| Dominan | Putih gading | `#D8D5CB` |
| Pendamping | Cokelat kayu | `#A7805C` |
| Pendamping | Abu batu | `#A39B8D` |
| Aksen | Hitam arang | `#242522` |
| Aksen | Hijau tua | `#304B35` |
| Aksen | Merah terang | `#D52916` |

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Massa bertingkat berbidang putih dengan volume depan bertekstur batu dan balkon atas |
| **Lantai & bentuk atap** | Dua level tampak; ruang tidur loft di atas ruang utama · Atap rendah hampir datar dengan tepi hitam |
| **Tapak bangunan** | Massa kompak, denah lengkap tidak terlihat |
| **Proporsi utama** | Massa tegak, bertingkat dengan balkon dan tangga sisi |
| **Perkiraan luas lantai** | **35–65 m²** |

## 3. Shot Timeline

Durasi 18.67s · 4 shot.

**Camera Pattern:** IN – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–5.03 | 5.03s | Exterior | Dolly-In (~1.4×) + Moderate Orbit Right (~25°) + Gentle Pan Left. |
| 02 | 5.03–12.83 | 7.80s | Living & Dining & Kitchen / Sleeping Loft | Gentle Tilt-Down (~5°) + Mild Dolly-Out (~1.1×) → Moderate Tilt-Up (~15°–20°). |
| 03 | 12.83–17.13 | 4.30s | Bathroom & Laundry | Diagonal Dolly-In (~2.1×) + Gentle Pan Right (~10°–15°) + Mild Tilt-Down (~10°). |
| 04 | 17.13–18.67 | 1.53s | Exterior | Mild Dolly-Out (~1.15×) + Gentle Orbit Left (~10°) + Gentle Pan Right. |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Exterior · 0.00s**

> Dari sisi kiri-depan pelataran, kamera menghadap serong ke massa bertingkat; cakupan wide memuat halaman, dinding batu, tangga, balkon, bukaan tinggi serta pohon belakang.

**Shot 02 · Living & Dining & Kitchen / Sleeping Loft · 7.03s**

> Kamera tinggi di sisi depan living menghadap hampir lurus ke belakang; wide mencakup sofa, meja kopi, tangga kiri, dining/kitchen di bawah serta tempat tidur loft di atas.

**Shot 03 · Bathroom & Laundry · 12.83s**

> Dari ujung ruang, arah serong ke shower kiri dan counter kanan; wide memperlihatkan sebagian toilet, tirai, mesin cuci, vanity, rak serta lantai.

**Shot 04 · Exterior · 18.63s**

> Dari halaman lebih jauh, kamera memandang serong ke massa rumah dan tangga; wide akhir mencakup dinding batu, balkon, bangku serta rumput.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Exterior

**Time:** 0.00–5.03s · **Duration:** 5.03s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Massa kecil bertingkat dengan atap rendah tepi hitam, balkon berpagar metal gelap, tangga luar bertapak cokelat dengan sisi putih melengkung dan bidang batu bulat. Jendela lengkung hitam di bawah tangga, bukaan tinggi berpetak di sisi pelataran.

**Furnitur & dekorasi**

> Bangku kecil berkaki gelap dengan bantal terang di samping bukaan; pot tanaman di tepi tangga.

**Lingkungan**

> Rumput dan pelataran paving terang, pijakan terpisah, pagar kayu, pohon besar dan lereng berbatu.

#### **B. Framing & Lighting**

- **Fokus:** Fasad bertingkat dan tangga
- **Camera Start:** Di halaman di depan sisi batu · Serong ke sudut fasad dan sisi tangga · oblique · Sekitar tinggi mata · Sedikit ke atas
- **Framing:** Wide keseluruhan massa dan halaman → Medium wide tangga dan bukaan kaca
- **Lighting:** Cahaya difus luar, lampu dinding dan anak tangga hangat
- **Foreground dan kedalaman:** Rumput dan paving · Batu dan tangga dekat, balkon serta pohon jauh
- **Reveal:** Sisi bukaan tinggi lebih terbuka
- **Kesesuaian gerak:** Orbit mendekat menonjolkan sisi pelataran

#### **C. Camera Movement**

Mendekat mengitari fasad ke kanan sambil menjaga rumah dalam pandangan; sisi batu bergeser keluar dan tangga menjadi dominan.

**Tempo:** Perubahan pada 0–1,7 s lebih kecil daripada 1,7–3,3 s dan 3,3–5 s; perpindahan tetap terbaca sedang.

**Camera:** Dolly-In (~1.4×) + Moderate Orbit Right (~25°) + Gentle Pan Left.

---

<a id="shot-02"></a>

### Shot 02 · Living & Dining & Kitchen / Sleeping Loft

**Time:** 5.03–12.83s · **Duration:** 7.80s

**Shot Type:** Continuous shot · Multi area · No cut.

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

##### **Living & Dining & Kitchen**

**Arsitektur**

> Ruang bawah terbuka dengan lantai berpenampilan papan kayu, tangga terbuka kiri, dining di tengah kanan serta kabinet kitchen hijau di belakang kanan. Lorong di belakang kiri mengarah ke bukaan lain.

**Furnitur & dekorasi**

> Sofa sectional abu muda dengan bantal dan throw merah menghadap meja kopi gelap di atas rug; meja makan persegi panjang kayu dan kursi mengarah ke kitchen; kabinet hijau tua dan peralatan built-in tampak di belakang.

**Lingkungan**

> Pemandangan luar tidak jelas; jendela sempit di dinding kiri loft tampak sebagai sumber cahaya.

##### **Sleeping Loft**

**Arsitektur**

> Loft terbuka menghadap ruang bawah, railing hitam dengan tangga akses kiri; plafon tinggi berpenampilan papan kayu dan dinding putih.

**Furnitur & dekorasi**

> Tempat tidur putih dengan headboard hijau tua, bantal merah, meja sisi gelap di belakang railing.

**Lingkungan**

> Luar tidak terlihat jelas dari sudut ini.

#### **B. Framing & Lighting**

- **Fokus:** Hubungan vertikal living, dining dan loft
- **Camera Start:** Di atas level duduk, depan living · Menghadap loft dan ruang bawah · frontal · Lebih tinggi dari sofa · Miring ke bawah ringan
- **Framing:** Wide dua level dengan sofa di foreground → Wide loft dan dining, plafon dominan
- **Lighting:** Lampu dinding hangat dan pendant, permukaan terang
- **Foreground dan kedalaman:** Sofa dan meja kopi · Sofa dekat, dining tengah, loft jauh/atas
- **Reveal:** Plafon kayu dan loft semakin dominan
- **Kesesuaian gerak:** Gerak vertikal pandangan menonjolkan volume dua level
- **Area:** Living & Dining & Kitchen / Sleeping Loft
- **Rute kamera:** —

**Hubungan antararea**

- **Penghubung area:** —
- **Peralihan:** Living & Dining & Kitchen · 5.03–12.83s; Sleeping Loft · 5.03–12.83s
- **Orientasi ruang:** —

#### **C. Camera Movement**

Pandangan sedikit melebar ke bawah lalu terangkat menuju loft dan plafon; perubahan kedalaman awal kecil dan tidak pasti.

**Tempo:** Pada 151–211 perubahan kecil; 211–268 hampir bertahan; 268–326 dan 326–384 pandangan naik lebih nyata tetapi keseluruhan lambat.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 5.03–7.03 | Living & Dining & Kitchen / Sleeping Loft · Living dan loft | Gentle Tilt-Down (~5°) + Mild Dolly-Out (~1.1×) | Pada 151–211 perubahan kecil; 211–268 hampir bertahan; 268–326 dan 326–384 pandangan naik lebih nyata tetapi keseluruhan lambat. |
| 7.03–12.83 | Living & Dining & Kitchen / Sleeping Loft · Loft dan plafon | Moderate Tilt-Up (~15°–20°) | Pada 151–211 perubahan kecil; 211–268 hampir bertahan; 268–326 dan 326–384 pandangan naik lebih nyata tetapi keseluruhan lambat. |

**Camera:** Gentle Tilt-Down (~5°) + Mild Dolly-Out (~1.1×) → Moderate Tilt-Up (~15°–20°).

---

<a id="shot-03"></a>

### Shot 03 · Bathroom & Laundry

**Time:** 12.83–17.13s · **Duration:** 4.30s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang memanjang kompak; area shower tertutup tirai bermotif di kiri belakang, lantai kayu tampak, bidang countertop putih di kanan, lampu recessed di plafon.

**Furnitur & dekorasi**

> Mesin front-load gelap di bawah counter, kabinet kayu terang di atas, rak terbuka dengan tanaman dan dekorasi; vanity kanan dengan rak handuk dan keranjang, rug geometris, sebagian toilet di tepi kiri.

**Lingkungan**

> Bukaan luar tidak terlihat; cahaya buatan terang dan merata.

#### **B. Framing & Lighting**

- **Fokus:** Mesin cuci bawah counter
- **Camera Start:** Di ujung kamar mandi dekat toilet · Serong ke counter dan shower · oblique · Sekitar tinggi mata · Sedikit ke bawah
- **Framing:** Wide kamar mandi dan laundry → Close view mesin cuci dan counter
- **Lighting:** Downlight plafon terang, tanpa bukaan luar terlihat
- **Foreground dan kedalaman:** Rug geometris dan tepi toilet · Vanity dekat, shower belakang
- **Reveal:** Mesin front-load menjadi fokus, shower dan vanity keluar
- **Kesesuaian gerak:** Pendekatan diagonal menegaskan integrasi laundry

#### **C. Camera Movement**

Mendekat diagonal ke mesin cuci sambil mengarahkan pandangan ke kanan dan sedikit turun.

**Tempo:** Interval 385–425 kecil, 425–465 dan 465–505 lebih besar; sebagian akibat perspektif saat mendekat, profil laju belum pasti.

**Camera:** Diagonal Dolly-In (~2.1×) + Gentle Pan Right (~10°–15°) + Mild Tilt-Down (~10°).

---

<a id="shot-04"></a>

### Shot 04 · Exterior

**Time:** 17.13–18.67s · **Duration:** 1.53s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Massa kecil bertingkat dengan atap rendah tepi hitam, balkon berpagar metal gelap, tangga luar bertapak cokelat dengan sisi putih melengkung dan bidang batu bulat. Jendela lengkung hitam di bawah tangga, bukaan tinggi berpetak di sisi pelataran.

**Furnitur & dekorasi**

> Bangku kecil berkaki gelap dengan bantal terang di samping bukaan; pot tanaman di tepi tangga.

**Lingkungan**

> Rumput dan pelataran paving terang, pijakan terpisah, pagar kayu, pohon besar dan lereng berbatu.

#### **B. Framing & Lighting**

- **Fokus:** Massa rumah dan tangga luar
- **Camera Start:** Di pelataran dekat sisi tangga · Menghadap serong ke pintu kaca dan balkon · oblique · Sekitar tinggi mata · Sedikit ke atas
- **Framing:** Medium wide sisi tangga dan bukaan tinggi → Wide massa dan halaman
- **Lighting:** Cahaya difus luar dan lampu hangat
- **Foreground dan kedalaman:** Paving dan pijakan · Tangga dekat, pohon serta lereng belakang
- **Reveal:** Bidang batu kiri dan rumput kembali masuk
- **Kesesuaian gerak:** Mundur mengitari fasad memperluas konteks

#### **C. Camera Movement**

Mundur pendek mengitari rumah ke kiri dengan kompensasi pandangan ke kanan.

**Tempo:** Perubahan pada tiga interval sekitar setengah detik relatif berkelanjutan; durasi singkat tanpa bukti easing tegas.

**Camera:** Mild Dolly-Out (~1.15×) + Gentle Orbit Left (~10°) + Gentle Pan Right.

**Catatan referensi:** Estimasi luas, gaya dan gerak berdasarkan frame, tanpa kalibrasi atau denah. Kontinuitas antarcut tidak membuktikan identitas bangunan; beberapa frame tampak berulang. Palet perkiraan tampilan, bukan spesifikasi material.
