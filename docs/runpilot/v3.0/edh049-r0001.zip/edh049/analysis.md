# edh049 — Rounded Stone Garden House

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Rounded Stone Garden House
- **Tipe rumah:** Detached House
- **Gaya utama:** **Organic Contemporary**
- **Pengaruh gaya:** Rustic
- **Gaya interior:** Rustic Contemporary
- **Susunan ruang utama:** Teras dan balkon bertingkat di luar; dapur melengkung, kamar tidur menghadap teras, kamar mandi dengan bak bebas berdiri; koneksi antar interior tidak terlihat
- **Ciri khas:** Parapet lengkung, tangga luar, dinding batu bertekstur, bukaan kaca besar dan ruang mandi berlangit-langit lengkung
- **Material utama:** Permukaan blok batu krem, kayu madu, logam hitam dan tekstil terang; bahan fisik belum terverifikasi
- **Pencahayaan:** Siang difus dari kaca tinggi, ditambah lampu dinding hangat dan cermin bercahaya
- **Atmosfer:** Hangat, intim, natural dan terang dengan kontras bingkai hitam
- **Lingkungan:** Pepohonan rapat, kebun bunga, jalur dan teras berpaving; ruang duduk lantai bawah terlihat melalui kaca eksterior.

### Palet warna

| Peran | Warna | HEX |
| --- | --- | --- |
| Dominan | Krem batu | `#C2B8A5` |
| Pendamping | Kayu madu | `#B89567` |
| Aksen | Arang hitam | `#292826` |
| Pendamping | Putih linen | `#E1DBD0` |
| Aksen | Hijau daun | `#536442` |
| Aksen | Oker lembut | `#B99A6A` |

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | medium |
| **Bentuk bangunan** | rounded two-storey mass |
| **Lantai & bentuk atap** | Dua tingkat tampak · Atap tampak datar dengan tepian melengkung dan bidang gelap di atas |
| **Tapak bangunan** | rounded compact footprint |
| **Proporsi utama** | Massa kompak dua tingkat dengan balkon melingkar dan tangga samping |
| **Perkiraan luas lantai** | **75–130 m²** |

## 3. Shot Timeline

Durasi 18.97s · 4 shot.

**Camera Pattern:** (OUT → IN) – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–5.53 | 5.53s | Exterior | Dolly-Out (~1.2×) + Orbit Left (~20°) + Pan Right (Gentle) → Dolly-In (~1.35×). |
| 02 | 5.53–10.63 | 5.10s | Kitchen | Dolly-Out (~2.2×) + Orbit Right + Moderate Pan Left (Ease-Out). |
| 03 | 10.63–13.93 | 3.30s | Bedroom | Dolly-In (~1.3×) + Moderate Pan Right (~20°) + Truck Right. |
| 04 | 13.93–18.97 | 5.03s | Bathroom | Diagonal Dolly-Out (~2.0×) + Moderate Pan Right (~20°). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Exterior · 2.77s**

> Pada frame 83 kamera tinggi menghadap fasad hampir frontal, menunduk sehingga kedua tingkat, teras meja, tangga kanan, bedeng lengkung dan pepohonan terlihat.

**Shot 02 · Kitchen · 10.60s**

> Frame 318 wide dari atas tinggi meja menghadap ruang kerja melengkung; counter depan, sink kiri, range kanan, rak dan kaca tinggi terbaca bersama.

**Shot 03 · Bedroom · 10.63s**

> Frame 319 wide dari sisi kaki ranjang, arah serong menunduk ke kasur dan bukaan kaca melengkung; kepala ranjang, lampu dan teras terlihat.

**Shot 04 · Bathroom · 18.93s**

> Frame 568 wide menghadap bukaan lengkung dari dalam ruang mandi, vanity di kiri dan bak di kanan, toilet di depan serta teras di belakang; vault terbaca lengkap.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Exterior

**Time:** 0.00–5.53s · **Duration:** 5.53s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Massa dua tingkat berkulit blok batu krem dengan sudut membulat, balkon melengkung, kaca hitam tinggi di bawah dan atas, tangga luar melingkar di kanan menuju lantai atas. Teras depan bertangga lengkung dan atap datar tampak dengan bibir membulat.

**Furnitur & dekorasi**

> Meja luar persegi panjang permukaan kayu dengan kursi hitam di teras bawah; kursi santai dan pot di balkon. Sofa gelap, meja rendah dan lampu gantung tampak melalui kaca lantai bawah; kamera tidak masuk ke ruang tersebut.

**Lingkungan**

> Pepohonan rapat di belakang; bedeng bunga warna kuning dan merah muda mengikuti tepian, jalur paving terang.

#### **B. Framing & Lighting**

- **Fokus:** Fasad dua tingkat
- **Camera Start:** Dari udara di depan sisi kanan massa · Mengarah serong ke fasad dan tangga kanan · oblique · Tinggi di atas teras · Menunduk moderat
- **Framing:** Medium wide, sisi kanan dominan → Fasad lebih frontal dan meja depan terbuka
- **Lighting:** Siang difus, lampu interior hangat
- **Foreground dan kedalaman:** Tangga, bedeng, teras · Tangga dan bedeng di depan, pepohonan di belakang
- **Reveal:** Fasad lebih frontal dan meja depan terbuka
- **Kesesuaian gerak:** Orbit membuka fasad, pendekatan memperbesar massa

#### **C. Camera Movement**

Tinggi pintu dan volume fasad sedikit mengecil, bagian teras bawah makin terbuka. Sisi kanan tangga menyempit relatif fasad depan; lintasan badan bergeser kiri mengitari massa. Arah pandang berputar kanan untuk mempertahankan massa saat teras depan masuk; sudut pan sulit dipisahkan. Gerak awal lebih jelas lalu mereda. Pintu, parapet dan meja membesar, bagian bawah terpotong menjelang akhir; perubahan skala makin nyata, tetapi percepatan translasi tidak dapat dipisahkan dari perspektif. Sisi massa relatif stabil; tidak ada pergeseran lateral kuat. Pandangan hampir tetap pada fasad; tidak ada tilt berkelanjutan.

**Tempo:** Gerak melingkar dan mundur mereda sekitar tengah lalu pendekatan makin nyata, tempo keseluruhan sedang.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 0.00–2.67 | Exterior · Fasad dua tingkat | Dolly-Out (~1.2×) + Orbit Left (~20°) + Pan Right (Gentle) | Gerak melingkar dan mundur mereda sekitar tengah lalu pendekatan makin nyata, tempo keseluruhan sedang. |
| 2.67–5.53 | Exterior · Fasad dua tingkat | Dolly-In (~1.35×) | Gerak melingkar dan mundur mereda sekitar tengah lalu pendekatan makin nyata, tempo keseluruhan sedang. |

**Camera:** Dolly-Out (~1.2×) + Orbit Left (~20°) + Pan Right (Gentle) → Dolly-In (~1.35×).

---

<a id="shot-02"></a>

### Shot 02 · Kitchen

**Time:** 5.53–10.63s · **Duration:** 5.10s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding blok batu krem mengikuti kurva, bukaan kaca tinggi hitam di kiri. Kabinet bawah putih dan meja kayu membentuk bidang kerja melengkung, area tengah terbuka; ujung meja depan menyerupai peninsula, sambungan lengkap belum pasti.

**Furnitur & dekorasi**

> Range oven hitam di bawah hood cerobong, rak terbuka bertingkat berisi mangkuk dan alat dapur, kabinet panel putih, rak botol, sink hitam di bawah kaca dan pot tanaman di ujung meja.

**Lingkungan**

> Vegetasi dan teras terang tampak di balik kaca tinggi.

#### **B. Framing & Lighting**

- **Fokus:** Range dan rak kayu
- **Camera Start:** Dekat range di depan meja kerja · Menghadap range dan rak di belakang · oblique · Di atas tinggi meja · Menunduk ringan
- **Framing:** Medium range → Kaca kiri dan counter melengkung masuk
- **Lighting:** Cahaya siang dari kiri
- **Foreground dan kedalaman:** Meja kerja melengkung · Medium pada range dan dinding, lalu terbuka ke lantai dan jendela
- **Reveal:** Kaca kiri dan counter melengkung masuk
- **Kesesuaian gerak:** Mundur membuka keseluruhan dapur

#### **C. Camera Movement**

Range dan hood menyusut; lantai tengah dan ujung meja depan terbuka. Sisi kanan range semakin tampak dan bidang meja dekat bergeser terhadap rak belakang; kamera bergeser kanan sambil mundur, lintasan melingkar masuk akal. Range bergerak ke kanan dalam frame dan jendela kiri terbuka, menandakan sapuan pandangan ke kiri yang mengompensasi gerak badan. Sapuan mereda di akhir; sudut individual tidak pasti.

**Tempo:** Mundur dan sapuan jelas pada bagian tengah, mereda mendekati akhir.

**Camera:** Dolly-Out (~2.2×) + Orbit Right + Moderate Pan Left (Ease-Out).

---

<a id="shot-03"></a>

### Shot 03 · Bedroom

**Time:** 10.63–13.93s · **Duration:** 3.30s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding blok batu krem dan bukaan kaca tinggi melengkung dengan mullion hitam. Ranjang sejajar bidang bukaan, lantai terang dan karpet di sisi bawah.

**Furnitur & dekorasi**

> Ranjang lebar dengan linen putih, bantal gelap dan oker, selimut oker di kaki. Lampu dinding hitam hangat di sisi kepala dan tanaman pot dekat kaca.

**Lingkungan**

> Teras batu terang, furnitur luar dan vegetasi terlihat di balik kaca.

#### **B. Framing & Lighting**

- **Fokus:** Ranjang dan kaca
- **Camera Start:** Di sisi kaki ranjang agak tinggi · Menghadap serong sepanjang ranjang ke kaca · oblique · Di atas tinggi kasur · Menunduk ringan
- **Framing:** Wide ranjang dan lengkung kaca → Kaca dan tekstil memenuhi frame
- **Lighting:** Siang difus dari kaca, aksen lampu dinding
- **Foreground dan kedalaman:** Kaki ranjang dan selimut · Kasur dekat dan teras jauh
- **Reveal:** Kaca dan tekstil memenuhi frame
- **Kesesuaian gerak:** Pendekatan dan sapuan mengikuti ranjang

#### **C. Camera Movement**

Tekstil dan bentang kaca membesar; kaki ranjang serta kepala terpotong. Pot dekat jendela dan furnitur teras bergeser relatif mullion; perpindahan badan ke kanan masuk akal, namun besaran tidak pasti. Kepala ranjang keluar kiri dan arah pandang menuju kaca kanan. Perubahan per interval cukup stabil dengan sedikit peredaan akhir.

**Tempo:** Sapuan berlangsung sedang, relatif merata.

**Camera:** Dolly-In (~1.3×) + Moderate Pan Right (~20°) + Truck Right.

---

<a id="shot-04"></a>

### Shot 04 · Bathroom

**Time:** 13.93–18.97s · **Duration:** 5.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang mandi berlangit-langit lengkung blok batu krem dengan bukaan tinggi lengkung berbingkai hitam menuju teras. Lantai terang dan ceruk kerikil di bawah bak.

**Furnitur & dekorasi**

> Vanity kayu terbuka dua tingkat dengan wastafel putih vessel, keran hitam dan cermin oval bercahaya; lampu dinding hangat. Bak oval bebas berdiri di kanan, toilet di foreground dan kelompok tanaman pot.

**Lingkungan**

> Pintu kaca memperlihatkan teras terang, tanaman dan pepohonan.

#### **B. Framing & Lighting**

- **Fokus:** Cermin, wastafel, lalu bukaan
- **Camera Start:** Dekat vanity di sisi kiri · Mengarah serong ke cermin dan bukaan kanan · oblique · Sekitar tinggi mata · Hampir datar
- **Framing:** Medium vanity dan cermin → Bak, toilet, vault dan akses teras masuk
- **Lighting:** Cahaya siang dari pintu, cermin dan sconce hangat
- **Foreground dan kedalaman:** Vanity dan tanaman · Vanity dekat dan teras jauh
- **Reveal:** Bak, toilet, vault dan akses teras masuk
- **Kesesuaian gerak:** Mundur membuka ruang mandi

#### **C. Camera Movement**

Cermin dan wastafel menyusut sekitar dua kali; bak dan toilet dekat muncul dari tepi, vault terbuka. Vanity bergeser kiri relatif pintu dan bak muncul kanan; lintasan mundur serong kanan didukung perubahan sudut terhadap dinding. Pandangan beralih dari vanity ke pintu, sapuan kanan lebih nyata awal-tengah, kemudian berkurang; tidak ada tilt yang jelas.

**Tempo:** Mundur relatif kontinu dengan pergeseran framing lebih kecil di akhir.

**Camera:** Diagonal Dolly-Out (~2.0×) + Moderate Pan Right (~20°).

**Catatan referensi:** Luas dan gaya merupakan interpretasi visual, bukan data ukur. Arah dan besaran kamera merupakan estimasi tanpa kalibrasi; kontinuitas denah antarcut tidak terverifikasi. Tampilan permukaan tidak memastikan bahan fisik.
