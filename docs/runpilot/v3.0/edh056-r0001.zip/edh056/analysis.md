# edh056 — Woodland Modern Villa with Warm Rustic Interior

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Woodland Modern Villa with Warm Rustic Interior
- **Tipe rumah:** Villa
- **Gaya utama:** **Contemporary Modern**
- **Pengaruh gaya:** Modern Rustic
- **Gaya interior:** Modern Rustic
- **Susunan ruang utama:** Teras mengarah langsung ke ruang keluarga dan dapur terbuka; kamar tidur dan kamar mandi ditampilkan melalui cut tanpa bukti denah penghubung.
- **Ciri khas:** Teras dengan tangga bercahaya, balkon sudut, kabinet dapur dua warna dan dinding kamar bertekstur batu.
- **Material utama:** Fasad putih halus; interior tampak kayu cokelat, batu krem, tekstil netral dan aksen logam gelap.
- **Pencahayaan:** Cahaya luar lembut; lampu dinding, anak tangga, downlight, pendant dan strip kabinet bernuansa hangat. Kamar tidur mendapat cahaya jendela lebih terang.
- **Atmosfer:** Hangat, nyaman dan tenang dengan kontras modern-rustik.
- **Lingkungan:** Tapak berumput dikelilingi batang pohon tinggi; pepohonan terlihat dari sebagian bukaan.

### Palet warna

| Peran | Warna | HEX |
| --- | --- | --- |
| Dominan | Warm White | `#D8D2C5` |
| Pendamping | Sand Beige | `#B9AA96` |
| Pendamping | Medium Oak Brown | `#896443` |
| Pendamping | Stone Taupe | `#B2A18E` |
| Aksen | Charcoal Black | `#292622` |
| Aksen | Muted Olive Green | `#596044` |

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Volume kotak bertingkat dan set-back lantai atas. |
| **Lantai & bentuk atap** | two visible levels · Atap tampak datar berparapet dengan bidang kanopi tipis gelap. |
| **Tapak bangunan** | compact stepped mass |
| **Proporsi utama** | Massa bawah melebar, volume atas lebih kecil dengan teras atap. |
| **Perkiraan luas lantai** | **85–145 m²** |

## 3. Shot Timeline

Durasi 23.70s · 4 shot.

**Camera Pattern:** IN – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–12.67 | 12.67s | Exterior / Living & Kitchen | Mild Diagonal Dolly-In (~1.2×) + Orbit Right (Ease-Out) + Gentle Pan Left → Strong Diagonal Dolly-In (~2.7×) + Gentle Pan Left → Gentle Straight Dolly-In (~1.2×, Constant) → Moderate Diagonal Dolly-In (~1.6×) + Subtle Pan Left. |
| 02 | 12.67–16.40 | 3.73s | Bedroom | Moderate Diagonal Dolly-Out (~1.6×) + Subtle Pan Left (~8°–12°). |
| 03 | 16.40–21.13 | 4.73s | Bathroom | Moderate Diagonal Dolly-In (~1.7×) + Moderate Pan Left (~20°–25°, Ease-Out). |
| 04 | 21.13–23.70 | 2.57s | Exterior / Living & Kitchen | Strong Diagonal Dolly-Out (~2.6×) + Subtle Pan Right. |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Exterior · 2.00s**

> Dari halaman depan serong, rumah dua tingkat dan balkon terlihat hampir utuh tanpa batang besar menutup tengah; tangga dan patio kanan tampak bersama lawn serta pepohonan.

**Shot 01 · Living & Kitchen · 8.00s**

> Dari dalam ambang, pandangan wide serong memperlihatkan sofa L, meja kopi, karpet, dapur di belakang dan bukaan kaca di kanan.

**Shot 02 · Bedroom · 16.37s**

> Dari posisi mundur serong di sisi kaki ranjang, wide memperlihatkan rangka ranjang, nakas, jendela tinggi, dinding batu, balok plafon dan lantai berpola cahaya.

**Shot 03 · Bathroom · 16.40s**

> Dari dekat akses, wide serong menampilkan vanity kiri dengan cermin dan rak, toilet tengah dan shower kaca di kanan lengkap dengan jendela serta lantai shower.

**Shot 04 · Living & Kitchen · 21.13s**

> Dari teras dekat pintu kaca terbuka, pandangan parsial ke sofa dan dapur di belakang; frame ini memberi cakupan interior terbesar pada shot penutup, bukan wide seluruh ruang.

**Shot 04 · Exterior · 23.67s**

> Dari halaman pada jarak lebih jauh, wide memperlihatkan dua tingkat, balkon, teras, tangga bercahaya, kursi patio dan lawn dengan batang pohon di sisi kiri.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Exterior / Living & Kitchen

**Time:** 0.00–12.67s · **Duration:** 12.67s

**Shot Type:** Continuous shot · Multi area · No cut.

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

##### **Exterior**

**Arsitektur**

> Massa dua tingkat berupa kotak putih bertumpuk, lantai atas mundur membentuk balkon dengan railing vertikal hitam. Atap berparapet dan kanopi gelap tipis di atas pintu. Teras ditinggikan dengan tangga lebar bercahaya dan bidang duduk rendah di kanan. Pintu kaca bergrid hitam terbuka menuju interior; jendela tinggi sempit mengapitnya.

**Furnitur & dekorasi**

> Kursi anyaman dengan bantalan terang dan meja kecil bulat berada pada patio kanan tangga; pot tanaman di kedua sisi akses, lentera portabel pada teras.

**Lingkungan**

> Rumput hijau dan batang pohon tinggi rapat membingkai bangunan. Cahaya luar lembut, lampu fasad hangat menyala.

##### **Living & Kitchen**

**Arsitektur**

> Ruang keluarga terbuka menghadap dapur di belakang sofa. Bukaan kaca tinggi dengan transom di kanan, langit-langit putih dengan downlight dan pencahayaan tepi hangat. Dapur memiliki kabinet atas putih berprofil, kabinet bawah cokelat, backsplash batu tampak berlapis, jendela hitam di atas meja kerja dan lantai ubin besar netral.

**Furnitur & dekorasi**

> Sofa sectional L krem dengan bantal garis, putih dan cokelat menghadap meja kopi kayu persegi panjang berambalan terbuka di atas karpet terang. Dapur memiliki meja island tampak mandiri berpanel kayu dan top terang, bangku tinggi berkaki hitam, pendant lentera, kulkas tinggi di kiri, oven dan area sink pada dinding belakang. Pot hijau dan lentera menghias meja.

**Lingkungan**

> Lawn dan pepohonan terlihat melalui pintu kaca di kanan. Sumber alami bercampur cahaya warm-white dari kabinet, pendant dan plafon.

#### **B. Framing & Lighting**

- **Fokus:** Fasad, pintu, sofa, lalu island dapur.
- **Camera Start:** Di luar rumah pada sisi kiri-depan, di antara batang pohon. · Menghadap serong ke fasad dan teras. · oblique · Perkiraan setinggi pandang agak tinggi terhadap lawn. · Sedikit menunduk ke teras/lawn.
- **Framing:** Wide eksterior dengan pohon menghalangi sebagian fasad. → Medium wide dapur dengan tepi sofa di bawah.
- **Lighting:** Cahaya luar lembut dan lampu hangat; di dalam downlight, pendant dan cahaya jendela.
- **Foreground dan kedalaman:** Batang pohon, tangga, kusen, kemudian sofa. · Pohon dekat, rumah jauh; setelah masuk, sofa di depan kabinet dapur.
- **Reveal:** Fasad terbuka, ambang pintu dilalui, ruang keluarga lalu dapur menjadi dominan.
- **Kesesuaian gerak:** Paralaks pohon dan kusen mendukung lintasan translasi kontinu.
- **Area:** Exterior / Living & Kitchen
- **Rute kamera:** Exterior (0.00–6.83s · teras dan pintu kaca · fasad dan pintu) → Living & Kitchen (6.83–12.67s · pintu kaca terbuka · sofa lalu dapur)

**Hubungan antararea**

- **Penghubung area:** —
- **Peralihan:** Exterior · 0.00–6.83s; Living & Kitchen · 4.83–12.67s
- **Orientasi ruang:** Satu take kontinu dari lawn melewati pintu menuju ruang terbuka.

#### **C. Camera Movement**

Kamera mendekat sambil mengubah sudut fasad dari kiri ke hampir frontal, lalu bergerak maju menuju pintu kaca. Setelah melewati kusen, laju berkurang saat ruang keluarga terbuka; mendekat lagi ke sisi dapur dengan koreksi arah pandang ke kiri.

**Tempo:** Sedang saat membuka fasad; pendekatan pintu lebih cepat, melambat setelah ambang, lalu sedang menuju dapur.

- **0.00–2.50s · moderate:** Perubahan sudut fasad bertahap, batang dekat cepat tersapu karena paralaks.
- **2.50–6.83s · fast:** Perubahan framing besar per detik, pintu mendominasi dan lewat dalam sekitar empat detik.
- **6.83–9.33s · slow:** Perubahan sofa dan dapur kecil pada interval 20 frame.
- **9.33–12.67s · moderate:** Island membesar lebih nyata dan sofa tersingkir pada interval 20 frame.

**Alur visual:** Eksterior → teras → pintu kaca → ruang keluarga → pandangan dekat dapur.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 0.00–2.50 | Exterior / Living & Kitchen · Fasad | Mild Diagonal Dolly-In (~1.2×) + Orbit Right (Ease-Out) + Gentle Pan Left | Perubahan sudut fasad bertahap, batang dekat cepat tersapu karena paralaks. |
| 2.50–6.83 | Exterior / Living & Kitchen · Teras dan pintu masuk | Strong Diagonal Dolly-In (~2.7×) + Gentle Pan Left | Perubahan framing besar per detik, pintu mendominasi dan lewat dalam sekitar empat detik. |
| 6.83–9.33 | Exterior / Living & Kitchen · Ruang keluarga | Gentle Straight Dolly-In (~1.2×, Constant) | Perubahan sofa dan dapur kecil pada interval 20 frame. |
| 9.33–12.67 | Exterior / Living & Kitchen · Dapur | Moderate Diagonal Dolly-In (~1.6×) + Subtle Pan Left | Island membesar lebih nyata dan sofa tersingkir pada interval 20 frame. |

**Camera:** Mild Diagonal Dolly-In (~1.2×) + Orbit Right (Ease-Out) + Gentle Pan Left → Strong Diagonal Dolly-In (~2.7×) + Gentle Pan Left → Gentle Straight Dolly-In (~1.2×, Constant) → Moderate Diagonal Dolly-In (~1.6×) + Subtle Pan Left.

---

<a id="shot-02"></a>

### Shot 02 · Bedroom

**Time:** 12.67–16.40s · **Duration:** 3.73s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding kepala ranjang bertekstur blok batu krem dengan jendela tinggi bergrid hitam dan tirai panjang terang; lampu dinding hitam di sisi bukaan. Plafon putih dengan balok tampak kayu dan chandelier hitam; lantai tampak papan kayu cokelat.

**Furnitur & dekorasi**

> Ranjang besar dengan rangka kayu dan headboard rendah menghadap kamera secara serong, seprai putih berlapis, throw beige serta bantal putih dan cokelat. Nakas kayu di sisi ranjang, tanaman dan dekor kecil di kiri.

**Lingkungan**

> Cahaya siang terang masuk melalui jendela, membentuk bidang cahaya pada lantai kanan; detail lanskap di luar kurang jelas.

#### **B. Framing & Lighting**

- **Fokus:** Ranjang berlapis tekstil dan dinding batu.
- **Camera Start:** Di sisi kaki ranjang, agak serong dari kanan. · Menghadap kepala ranjang dan jendela. · oblique · Sekitar ketinggian mata. · Hampir datar, sedikit mengarah ke ranjang.
- **Framing:** Close/medium ranjang dan jendela. → Wide ranjang, nakas, balok dan lantai.
- **Lighting:** Cahaya jendela kuat bercampur lampu dinding hangat.
- **Foreground dan kedalaman:** Selimut dan bantal. · Ranjang dekat terhadap jendela di belakang.
- **Reveal:** Lantai, nakas kanan dan chandelier muncul saat mundur.
- **Kesesuaian gerak:** Ranjang menyusut lebih besar daripada dinding.

#### **C. Camera Movement**

Kamera mundur dengan sedikit pergeseran/putaran kiri, membuka ranjang, lantai dan plafon.

**Tempo:** Perubahan ukuran dan cakupan cukup merata pada 380–405, 405–430, 430–455, 455–480; akhir sedikit mereda.

**Camera:** Moderate Diagonal Dolly-Out (~1.6×) + Subtle Pan Left (~8°–12°).

---

<a id="shot-03"></a>

### Shot 03 · Bathroom

**Time:** 16.40–21.13s · **Duration:** 4.73s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi kompak dengan dinding terang, zona shower walk-in di belakang kaca transparan dengan rel hitam atas. Jendela persegi berbingkai hitam, niche vertikal dekoratif, bangku shower tampak kayu, lantai shower bermotif kerikil. Dinding vanity berlapis tampak kayu horizontal.

**Furnitur & dekorasi**

> Vanity kayu berkaki hitam dengan laci, rak terbuka di bawah, vessel sink putih persegi membulat dan cermin bulat berbingkai gelap. Rak ceruk vertikal menampung handuk, keranjang dan botol; toilet putih di antara vanity dan shower. Shower menggunakan rain head, handheld dan kontrol hitam; tanaman berdaun lebar dekat wastafel.

**Lingkungan**

> Vegetasi terlihat melalui jendela shower; lampu pendant hangat dan downlight menerangi dinding terang.

#### **B. Framing & Lighting**

- **Fokus:** Vanity dan rak vertikal.
- **Camera Start:** Dekat akses kamar mandi, menghadap serong ke vanity dan shower. · Menghadap ke sudut belakang tempat shower. · oblique · Sekitar ketinggian mata. · Hampir datar.
- **Framing:** Wide vanity kiri, toilet tengah dan shower kanan. → Close rak, tanaman, sebagian sink dan shower.
- **Lighting:** Pendant hangat, downlight dan jendela shower.
- **Foreground dan kedalaman:** Vanity kayu dan basin. · Vanity di dekat kamera, toilet di tengah, shower di belakang.
- **Reveal:** Rak ceruk dan tanaman menjadi dominan, jendela shower keluar.
- **Kesesuaian gerak:** Paralaks vanity, toilet dan rel kaca mendukung gerak mendekat.

#### **C. Camera Movement**

Kamera maju diagonal ke arah vanity sambil berputar ke kiri, meninggalkan jendela dan sebagian shower di kanan.

**Tempo:** Maju dan sapuan kiri cukup nyata pada interval 25 frame, melunak pada ujung tanpa perubahan tempo kelas yang tegas.

**Camera:** Moderate Diagonal Dolly-In (~1.7×) + Moderate Pan Left (~20°–25°, Ease-Out).

---

<a id="shot-04"></a>

### Shot 04 · Exterior / Living & Kitchen

**Time:** 21.13–23.70s · **Duration:** 2.57s

**Shot Type:** Continuous shot · Multi area · No cut.

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

##### **Exterior**

**Arsitektur**

> Massa putih bertingkat, balkon atas ber-railing hitam, kanopi tipis gelap dan pintu kaca grid; teras bertangga bercahaya terbuka utuh saat kamera menjauh.

**Furnitur & dekorasi**

> Kursi anyaman, meja kecil dan tanaman pot tersebar di teras dan patio bawah; lentera menghias tepi tangga.

**Lingkungan**

> Rumput dan batang pohon tinggi kembali membingkai rumah; cahaya luar lembut kontras dengan lampu hangat.

##### **Living & Kitchen**

**Arsitektur**

> Pintu kaca membuka pandangan parsial ke ruang keluarga dan dapur di belakang.

**Furnitur & dekorasi**

> Sofa krem dan lampu dapur terlihat sekilas di balik pintu.

**Lingkungan**

> Pandangan hanya melalui bukaan dari teras.

#### **B. Framing & Lighting**

- **Fokus:** Rumah dan teras.
- **Camera Start:** Di teras dekat pintu kaca kiri. · Menghadap serong ke fasad dari dekat akses. · oblique · Sekitar ketinggian mata di atas teras. · Hampir datar.
- **Framing:** Medium dekat pintu, pot dan kanopi. → Wide fasad dua tingkat, patio, tangga, lawn dan pohon.
- **Lighting:** Cahaya luar lembut dan lampu fasad/tangga hangat.
- **Foreground dan kedalaman:** Pintu bergrid, pot, kemudian tangga dan pohon. · Pintu dekat, volume atas dan pepohonan jauh.
- **Reveal:** Teras, balkon, tangga dan konteks tapak terbuka saat mundur.
- **Kesesuaian gerak:** Perubahan skala pintu dan masuknya pohon menunjukkan gerak menjauh.
- **Area:** Exterior / Living & Kitchen
- **Rute kamera:** —

**Hubungan antararea**

- **Penghubung area:** —
- **Peralihan:** Exterior · 21.13–23.70s; Living & Kitchen · 21.13–22.50s
- **Orientasi ruang:** —

#### **C. Camera Movement**

Kamera cepat mundur dari teras, sedikit diagonal sehingga keseluruhan fasad dan tangga terbuka, dengan koreksi pandang kanan ringan.

**Tempo:** Dalam 2,57 detik pintu dekat menjadi fasad wide; perubahan lebih besar pada 634–649 dan 649–664 daripada 694–710, sebagian karena perspektif.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 21.13–23.70 | Exterior / Living & Kitchen · Fasad dan teras | Strong Diagonal Dolly-Out (~2.6×) + Subtle Pan Right | Dalam 2,57 detik pintu dekat menjadi fasad wide; perubahan lebih besar pada 634–649 dan 649–664 daripada 694–710, sebagian karena perspektif. |

**Camera:** Strong Diagonal Dolly-Out (~2.6×) + Subtle Pan Right.

**Catatan referensi:** Estimasi luas lantai 85–145 m² berdasarkan skala pintu, massa dua tingkat dan cakupan ruang yang terlihat; tidak ada denah atau ukuran aktual. Material fisik dan identitas satu rumah lintas cut tidak dapat dipastikan; nama gaya, tipe rumah, sudut dan rasio gerak adalah perkiraan visual. Shot 4 merupakan tampilan eksterior kembali; kemiripan fasad tidak membuktikan teknik reverse edit.
