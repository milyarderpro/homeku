# edh058 — Spanish Colonial Revival Garden Cottage

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Spanish Colonial Revival Garden Cottage
- **Gaya utama:** **Spanish Colonial Revival**
- **Pengaruh gaya:** Mediterranean Cottage; California Cottage
- **Gaya interior:** Warm Mediterranean; Modern Organic Cottage
- **Ciri khas:** Ceruk dinding melengkung untuk TV dan pohon zaitun, balok plafon kayu ekspos, jendela lengkung berkusen hitam, serta konsistensi lentera dinding hitam
- **Warna & material:** Dominasi dinding tampak plester/stuko krem hangat dipadukan aksen tampak kayu sedang, kusen serta perangkat keras hitam matte, dan lantai tampak kayu atau ubin terakota; Krem hangat, putih gading, cokelat kayu sedang, terakota/karat, hijau zaitun/sage lembut, serta aksen hitam matte
- **Suasana dan lingkungan:** Perpaduan cahaya matahari alami yang melimpah dari jendela besar dengan lampu lentera dinding hitam, downlight plafon hangat, lampu gantung, dan lampu sorot rak; Taman depan rimbun dengan rumput hijau terawat, jalan setapak batu alam tak beraturan, bunga oranye-putih meriah, pohon konifer besar, dan rumah tetangga bergaya senada

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Massa satu lantai kompak dengan proyeksi vestibul masuk beratap pelana di bagian tengah dan cerobong asap stuko di sisi kiri |
| **Lantai & bentuk atap** | Satu lantai (single-story) yang tampak pada fasad eksterior dan seluruh interior · Atap pelana berlereng landai dengan penutup tampak genteng lengkung terakota (barrel tile) dan ujung kaso kayu gelap ekspos pada tritisan |
| **Tapak bangunan** | Kompak dengan massa utama melebar dan vestibul pintu masuk beratap pelana yang menonjol ke depan |
| **Proporsi utama** | Massa eksterior rendah dan intim, diimbangi bukaan vertikal melengkung dan plafon balok kayu di interior |
| **Perkiraan luas lantai** | **75–105 m²** |

## 3. Shot Timeline

Durasi 19.90s · 6 shot.

**Camera Pattern:** IN – OUT – IN – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–5.30 | 5.30s | exterior | Accelerating Dolly-In (~2.3×–2.4×) + Subtle Orbit Left. |
| 02 | 5.30–8.37 | 3.07s | living-room | Dolly-Out (~1.7×–1.8×) + Moderate Pan Left (~20°–25°). |
| 03 | 8.37–11.53 | 3.17s | kitchen | Dolly-In (~2.0×) + Moderate Pan Right (~20°–25°). |
| 04 | 11.53–14.57 | 3.03s | bedroom | Dolly-Out (~1.9×) + Gentle Pan Left (~10°–15°). |
| 05 | 14.57–17.10 | 2.53s | walk-in-closet | Straight Dolly-In (~1.9×). |
| 06 | 17.10–19.90 | 2.80s | bathroom | Straight Dolly-Out (~1.9×). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · exterior · 0.00s**

> Kamera berada di halaman depan sedikit serong dari sisi kanan-depan pada ketinggian mata dan kemiringan datar. Cakupan wide penuh menampilkan keseluruhan fasad cottage satu lantai beserta atap genteng lengkung, cerobong kiri, vestibul pintu masuk, jalan setapak batu bertepi bunga oranye-putih, hamparan rumput, batang pohon besar di kanan, dan tajuk pepohonan latar belakang.

**Shot 02 · living-room · 8.33s**

> Kamera berada di sudut belakang-kanan ruang keluarga pada ketinggian mata dan kemiringan datar, menghadap serong ke tengah-kiri ruangan. Cakupan wide akhir ini memperlihatkan utuh tata duduk dua sofa dan meja kopi di atas karpet motif, dinding ceruk TV di kanan, pohon zaitun dan kursi aksen di sudut belakang, pintu kaca Prancis bergorden krem di kiri, serta balok plafon kayu.

**Shot 03 · kitchen · 8.37s**

> Kamera berada di ambang bukaan dapur pada ketinggian mata dan kemiringan datar, menghadap serong ke dalam ruangan. Cakupan wide awal ini menampilkan keseluruhan dapur bentuk L, meja semenanjung beserta dua bangku bar kayu dan dua lampu gantung di kiri, wastafel di bawah jendela lengkung berkusen hitam, kabinet shaker krem, kompor dan kap stainless, serta rak melayang kayu di kanan.

**Shot 04 · bedroom · 14.53s**

> Kamera berada di sudut kaki-kiri kamar tidur pada ketinggian mata dan kemiringan datar, menghadap serong ke dinding kepala tempat tidur. Cakupan wide akhir ini menampilkan utuh ranjang kayu ber-footboard, sepasang nakas, jendela lengkung bergorden krem di dinding hijau sage, balok plafon kayu, lampu gantung lentera, serta sudut kursi aksen dan tanaman hijau di sisi kiri.

**Shot 05 · walk-in-closet · 14.57s**

> Kamera berada di ambang pintu masuk walk-in closet pada sumbu tengah, ketinggian mata, dan kemiringan datar menghadap lurus ke jendela ujung. Cakupan wide awal ini memperlihatkan utuh plafon miring berbalok kayu ekspos, unit gantungan pakaian dan rak berkeranjang di kedua sisi, laci kayu di kanan, ottoman krem di atas karpet lorong, serta jendela lengkung berkusen hitam.

**Shot 06 · bathroom · 19.87s**

> Kamera berada di sisi depan kamar mandi pada ketinggian mata dan kemiringan datar, menghadap lurus ke dinding belakang. Cakupan wide akhir ini memperlihatkan utuh bathtub freestanding di bawah jendela ganda bergorden krem, ceruk lengkung berisi pohon zaitun dan kloset di tengah-kanan, meja rias wastafel kayu berlampu dinding dan cermin di kanan, keranjang handuk di kiri bawah, dua balok plafon kayu, serta lantai ubin terakota berkeset tenun.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · exterior

**Time:** 0.00–5.30s · **Duration:** 5.30s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Rumah cottage satu lantai bergaya Spanish Colonial Revival dengan dinding tampak plester krem hangat dan atap pelana berlereng landai berpenutup tampak genteng lengkung terakota serta ujung kaso kayu gelap ekspos. Di tengah fasad terdapat proyeksi vestibul pintu masuk beratap pelana dengan bukaan ceruk pintu tunggal tampak kayu hangat berkaca atas dan karangan bunga hijau. Jendela kotak multi-pane berkusen hitam diapit daun penutup kisi (shutter) hitam dan kotak bunga di bawah ambang pada sayap kiri maupun sisi kanan vestibul, sementara cerobong asap stuko berdiri di lereng atap kiri. Teras masuk berupa undakan datar rendah tampak batu/beton krem, dan tiga lampu lentera dinding hitam terpasang simetris di kiri, kanan, dan atas pintu.

**Furnitur & dekorasi**

> Teras masuk dihiasi deretan pot terakota polos dan bermotif spiral yang berisi tanaman cemara mini berbentuk kerucut serta semak berbunga putih. Karangan bunga hijau dengan aksen putih menggantung di panel kaca pintu utama, dan kotak tanaman di bawah jendela diisi bunga putih dan hijau rimbun.

**Lingkungan**

> Halaman depan berumput hijau terawat dibelah jalan setapak batu alam tak beraturan yang diapit hamparan bunga oranye dan putih. Sebuah batang pohon besar berdiri di sisi kanan latar depan dengan tajuk menjuntai di atas, pagar kayu vertikal tampak di belakang kanan, dan pepohonan berdaun kuning keemasan serta hijau tinggi membingkai latar belakang rumah.

#### **B. Framing & Lighting**

- **Fokus:** Vestibul pintu masuk utama dengan pintu kayu berkarangan bunga dan simetri lampu lentera hitam.
- **Camera Start:** Berada di atas jalan setapak batu di halaman depan, sedikit menyerong dari sisi kanan-depan fasad. · Menghadap serong ke tengah fasad depan menuju vestibul pintu masuk utama. · oblique · Setara ketinggian mata orang dewasa (eye-level). · Datar (level), garis vertikal dinding dan batang pohon terjaga lurus.
- **Framing:** Wide eksterior penuh memperlihatkan keseluruhan cottage, atap genteng lengkung, cerobong kiri, jalan setapak batu, hamparan rumput, dan batang pohon besar di kanan. → Medium-tight menyorot vestibul pintu masuk beratap pelana, pintu kayu berkarangan bunga, tiga lampu lentera hitam, dan pot-pot teras.
- **Lighting:** Cahaya matahari siang cerah dari atas-kanan membentuk bayangan dedaunan lembut di rumput, dilengkapi pendar hangat dari tiga lampu lentera fasad.
- **Foreground dan kedalaman:** Hamparan rumput hijau, jalan setapak batu alam tak beraturan, rumpun bunga oranye-putih, dan batang pohon besar di sisi kanan. · Berlapis kuat dari rumput dan jalan setapak di latar depan, batang pohon di kanan, fasad cottage di tengah, hingga pepohonan rindang di latar belakang.
- **Reveal:** Detail tekstur plester dinding, pola ubin teras, ukiran pot terakota, panel kaca pintu kayu, dan rangkaian bunga pintu terlihat makin jelas saat kamera mendekat.
- **Kesesuaian gerak:** Sangat sesuai untuk pengenalan eksterior; pendekatan maju yang semakin cepat menarik perhatian alami menuju pintu masuk utama.

#### **C. Camera Movement**

Kamera bergerak maju mengikuti jalan setapak menuju pintu masuk utama sambil melengkung halus sedikit ke kiri sehingga fasad vestibul yang semula serong menjadi hampir frontal, dengan laju pendekatan yang makin cepat pada paruh akhir.

**Tempo:** Lambat pada tiga detik awal saat melintasi halaman, lalu meningkat menjadi sedang saat mendekati teras masuk.

- **0.00–3.00s · slow:** Pendekatan awal yang tenang dan perlahan melintasi jalan setapak.
- **3.00–5.30s · moderate:** Laju pendekatan meningkat menjadi sedang menuju ambang teras pintu utama.

**Camera:** Accelerating Dolly-In (~2.3×–2.4×) + Subtle Orbit Left.

---

<a id="shot-02"></a>

### Shot 02 · living-room

**Time:** 5.30–8.37s · **Duration:** 3.07s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang keluarga hangat berdinding tampak plester krem dengan lis plafon (crown molding) dan plin putih, lantai tampak papan kayu hangat, serta balok plafon tampak kayu gelap yang terlihat di bagian atas kiri. Dinding fokus memiliki ceruk melengkung landai (segmental arch niche) untuk menempatkan TV layar datar, diapit dua lampu lentera dinding hitam bergaya senada eksterior. Pada dinding kiri terdapat bukaan pintu kaca Prancis berkusen hitam multi-pane yang menghubungkan pandangan ke taman luar, dilengkapi downlight tanam di plafon putih.

**Furnitur & dekorasi**

> Di bawah TV dalam ceruk berdiri konsol media tampak kayu hangat berpintu dua di samping dan rak terbuka di tengah berisi keranjang anyaman serta buku dan tanaman pot kecil di atasnya. Area duduk membentuk tata hadap di atas karpet krem bermotif pudar: sofa berlengan gulung berlapis kain krem dengan bantal motif titik hitam-putih di sisi kanan, meja kopi persegi tampak kayu berrak bawah yang dihiasi vas putih berisi rangkaian daun oranye-karat dan tumpukan buku, kursi aksen berbingkai hitam dan dudukan krem di sudut belakang kiri, serta sebagian sofa krem berbantal terakota di tepi kiri. Sebuah keranjang anyaman bundar berada di depan lengan sofa kanan, gorden kain krem menjuntai di sisi pintu kaca, dan pohon zaitun pot tinggi berdiri di sudut belakang kiri.

**Lingkungan**

> Melalui pintu kaca Prancis di sisi kiri tampak halaman luar bermandikan sinar matahari dengan hamparan bunga merah-oranye, dedaunan hijau, serta sebagian bangunan stuko beratap genteng di seberang.

#### **B. Framing & Lighting**

- **Fokus:** Dinding ceruk TV di awal, lalu meluas ke keseluruhan tata duduk ruang keluarga dan bukaan taman di sisi kiri.
- **Camera Start:** Berada dekat sisi belakang-kanan sofa utama, agak dekat ke dinding ceruk TV. · Menghadap serong ke kiri-depan menuju dinding ceruk TV dan konsol kayu. · oblique · Setara ketinggian mata (eye-level) sedikit di atas sandaran sofa. · Datar (level), menjaga garis vertikal dinding dan kusen pintu kaca.
- **Framing:** Medium-tight menyorot ceruk lengkung TV, konsol media kayu, dua lentera dinding hitam, dan sandaran sofa krem berbantal motif di kanan-bawah. → Wide ruang keluarga penuh menampilkan kedua sofa, meja kopi kayu, karpet motif, kursi aksen, pohon zaitun, pintu kaca Prancis bergorden krem, balok plafon, dan dinding TV di sisi kanan.
- **Lighting:** Cahaya matahari alami terang masuk dari pintu kaca Prancis di sisi kiri menyapu lantai kayu dan karpet, dibantu downlight plafon hangat dan dua lentera dinding di sisi ceruk TV.
- **Foreground dan kedalaman:** Sandaran dan lengan sofa krem berbantal motif di sisi kanan bawah, diikuti keranjang anyaman bundar di lantai pada paruh akhir. · Berlapis dari sofa dan keranjang di latar depan kanan, meja kopi di tengah, hingga dinding ceruk TV dan pintu taman di latar belakang.
- **Reveal:** Gerak mundur sambil menyapu ke kiri membuka meja kopi dengan vas bunga musim gugur, pohon zaitun di sudut, kursi aksen, pintu kaca Prancis menuju taman, sofa kedua di kiri, dan balok plafon kayu di tepi atas.
- **Kesesuaian gerak:** Sangat efektif membuka skala dan konektivitas cahaya ruang keluarga dari titik fokus dinding media.

#### **C. Camera Movement**

Kamera mundur menjauhi dinding ceruk TV melewati sisi lengan sofa kanan sambil memutar pandangan ke kiri secara moderat untuk membuka meja kopi, kursi sudut, pohon zaitun, dan pintu kaca Prancis.

**Tempo:** Gerak mundur dan sapuan ke kiri berlangsung stabil pada tempo sedang dari awal hingga akhir shot.

**Camera:** Dolly-Out (~1.7×–1.8×) + Moderate Pan Left (~20°–25°).

---

<a id="shot-03"></a>

### Shot 03 · kitchen

**Time:** 8.37–11.53s · **Duration:** 3.17s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dapur kompak berbentuk L dengan bukaan masuk berbingkai plester krem bertekstur dan balok ambang atas tampak kayu gelap. Dinding dan backsplash berlapis tampak plester krem hangat bertekstur halus, berpadu dengan lantai papan tampak kayu hangat dan plafon putih rata ber-downlight tanam. Pada dinding belakang kiri terdapat jendela melengkung (arched) multi-pane berkusen hitam di atas area wastafel.

**Furnitur & dekorasi**

> Kabinet atas dan bawah model shaker berwarna krem pucat dengan tarikan vertikal hitam matte dan lis mahkota. Peralatan memasak mencakup kompor gas berdiri bebas ber-oven ganda berbahan tampak stainless steel, kap cerobong pengisap asap dinding stainless steel, mesin pencuci piring stainless di kiri sudut, serta wastafel apron putih di bawah jendela dengan keran leher angsa hitam di sudut kanan wastafel. Dua rak dinding melayang tampak kayu hangat di kanan kap kompor memajang tanaman hijau pot, tumpukan piring, dan cangkir. Di kiri depan berdiri semenanjung bermeja motif marmer dengan dua bangku bar kayu bundar tanpa sandaran dan dua lampu gantung silinder krem di atasnya; karpet memanjang tampak serat goni/sisal melapisi lantai, sementara mangkuk putih berisi jeruk, panci krem di kompor, talenan kayu, dan wadah perkakas mengisi meja kerja.

**Lingkungan**

> Melalui jendela lengkung di belakang kiri hanya tampak cahaya siang terang dan siluet tipis tanaman luar tanpa detail lanskap yang jelas, sementara bunga merah pot di ambang jendela dan tanaman hijau di sudut kiri memberi aksen alami.

#### **B. Framing & Lighting**

- **Fokus:** Tata dapur bentuk L di awal yang mengerucut ke area kompor gas dan kap cerobong stainless.
- **Camera Start:** Berada tepat di ambang bukaan dinding berplester pintu masuk dapur. · Menghadap serong ke kanan-depan masuk ke lorong dapur berbentuk L. · oblique · Setara ketinggian mata (eye-level). · Datar (level), garis vertikal kabinet dan kap pengisap asap tegak lurus.
- **Framing:** Wide dapur dibingkai kusen bukaan plester berbalok kayu atas, memperlihatkan semenanjung dengan dua kursi bar di kiri-bawah, jendela lengkung di belakang, kabinet L, dan kompor stainless. → Medium-tight menyorot zona memasak: kompor gas stainless steel, panci krem di atas tungku, kap cerobong stainless, kabinet atas shaker, dan dua rak melayang kayu di kanan.
- **Lighting:** Cahaya alami dari jendela lengkung di belakang kiri berpadu dengan downlight plafon, dua lampu gantung di atas semenanjung, dan lampu sorot hangat di bawah kabinet atas serta kap kompor.
- **Foreground dan kedalaman:** Tepi bukaan dinding plester kasar di kiri dan kanan awal, meja semenanjung dengan dua kursi bar kayu bundar, serta dua lampu gantung silinder di kiri atas. · Berlapis dari ambang bukaan dan semenanjung di latar depan, lorong lantai beralas karpet goni di tengah, hingga zona wastafel dan jendela lengkung di belakang.
- **Reveal:** Saat maju dan menyapu ke kanan, detail tekstur backsplash plester, tarikan hitam kabinet shaker, kontrol kompor gas, panci krem, dan dekorasi rak kayu kanan terlihat makin tajam.
- **Kesesuaian gerak:** Cocok untuk memperkenalkan keseluruhan layout dapur lalu menonjolkan detail zona memasak.

#### **C. Camera Movement**

Kamera meluncur maju melewati ambang bukaan masuk ke dalam dapur sambil memutar pandangan secara moderat ke kanan menuju kompor gas stainless steel, kap cerobong, dan rak melayang kayu.

**Tempo:** Gerak maju dan sapuan ke kanan berlangsung halus dan konstan pada tempo sedang.

**Camera:** Dolly-In (~2.0×) + Moderate Pan Right (~20°–25°).

---

<a id="shot-04"></a>

### Shot 04 · bedroom

**Time:** 11.53–14.57s · **Duration:** 3.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar tidur intim dengan dinding dicat hijau sage lembut (muted sage green) dan plafon putih beraksen dua balok tampak kayu gelap ekspos. Di tengah dinding kepala ranjang terpasang jendela melengkung (arched) multi-pane berkusen hitam dengan rel gorden hitam memanjang di atasnya, serta satu jendela bergorden lagi terlihat di dinding kiri belakang. Lantai tampak kayu hangat dilapisi karpet tenun polos krem di area bawah tempat tidur.

**Furnitur & dekorasi**

> Tempat tidur berangka tampak kayu hangat dengan headboard dan footboard berbilah vertikal diposisikan tepat di bawah jendela lengkung, dilapisi bedcover putih bertekstur jahit, selimut rajut krem tebal di ujung ranjang, bantal putih-krem, dan satu bantal aksen terakota bertekstur. Dua nakas berlaci tampak kayu hangat bertarikan hitam mengapit ranjang: nakas kiri menopang lampu meja keramik krem di bawah karya seni relief berbingkai krem, sedangkan nakas kanan menopang vas keramik berisi bunga krem-persik. Dua lampu dinding hitam bergaya industrial-cottage mengapit jendela, lampu gantung lentera kaca berangka keemasan menggantung di plafon, dan sudut kiri belakang diisi kursi aksen krem berbantal terakota, tanaman pot hijau rimbun, serta sebagian lemari laci kayu di tepi kiri bawah.

**Lingkungan**

> Di luar jendela lengkung terdapat kotak bunga berisi tanaman berbunga merah-koral cerah dengan latar belakang dedaunan hijau rimbun bermandikan sinar matahari.

#### **B. Framing & Lighting**

- **Fokus:** Komposisi tempat tidur berlatar jendela lengkung dan gorden krem.
- **Camera Start:** Berada dekat sisi kaki-kiri tempat tidur, mengarah agak dekat ke bantal dan jendela lengkung. · Menghadap serong ke kanan-belakang menuju jendela lengkung dan kepala tempat tidur. · oblique · Setara ketinggian mata (eye-level) sedikit menatap bidang tempat tidur. · Datar (level), menjaga bingkai jendela dan dinding tetap tegak.
- **Framing:** Medium-tight menampilkan tumpukan bantal tempat tidur, jendela lengkung berbungakan koral, gorden krem, sebagian nakas kanan bervas bunga, dan lampu dinding hitam. → Wide kamar tidur penuh memperlihatkan ranjang kayu utuh hingga footboard, kedua nakas, balok plafon kayu, lampu gantung lentera, sudut duduk berkursi aksen dan tanaman hijau di kiri, serta tepi lemari laci di kiri-bawah.
- **Lighting:** Cahaya siang lembut dari jendela lengkung di belakang tempat tidur dan jendela samping kiri, dipadukan cahaya hangat dari dua lampu dinding hitam, lampu meja keramik, dan lampu gantung lentera.
- **Foreground dan kedalaman:** Selimut rajut krem dan sisi nakas kanan di awal, lalu tepi footboard kayu dan sudut lemari laci kayu di kiri-bawah pada akhir shot. · Berlapis dari lemari depan dan footboard tempat tidur menuju nakas, dinding kepala ranjang, hingga pepohonan hijau di luar jendela.
- **Reveal:** Penarikan mundur membuka keseluruhan ranjang berkayu hangat, balok plafon ekspos, lampu gantung lentera kuningan-kaca, lampu meja keramik dan lukisan relief di kiri, tanaman pot besar, serta kursi aksen di sudut kiri.
- **Kesesuaian gerak:** Sangat cocok memperlihatkan suasana hangat dan proporsi kamar tidur secara bertahap dari detail tekstil tempat tidur.

#### **C. Camera Movement**

Kamera mundur menjauhi area bantal dan jendela lengkung sambil menyapu lembut ke kiri untuk membuka keseluruhan ranjang, kedua nakas, balok plafon, lampu gantung, dan sudut duduk kiri.

**Tempo:** Gerak mundur dan sapuan lembut ke kiri berjalan stabil pada tempo sedang.

**Camera:** Dolly-Out (~1.9×) + Gentle Pan Left (~10°–15°).

---

<a id="shot-05"></a>

### Shot 05 · walk-in-closet

**Time:** 14.57–17.10s · **Duration:** 2.53s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang walk-in closet memanjang dan sempit dengan dinding tampak plester krem hangat serta plafon miring (vaulted ceiling) beraksen balok kaso dan bubungan tampak kayu hangat ekspos. Di ujung sumbu lorong terdapat jendela melengkung (arched) berkusen hitam multi-pane dengan ambang plester tebal. Lantai tampak kayu terang tertutup karpet tenun polos krem di sepanjang koridor, dengan bukaan pintu berkusen gelap di titik masuk.

**Furnitur & dekorasi**

> Unit penyimpanan built-in berwarna krem melapisi kedua dinding memanjang: sisi kiri memuat dua tingkat batang gantungan pakaian (bernuansa bumi seperti terakota, krem, dan hijau zaitun) serta ceruk rak atas berisi keranjang anyaman; sisi kanan menggabungkan gantungan pakaian, rak atas dengan keranjang anyaman, ceruk dekoratif kecil di dekat jendela, dan deretan laci bawah tampak kayu hangat bertarikan hitam. Setiap zona gantung dan rak diterangi lampu strip LED hangat tersembunyi. Di tengah lorong berdiri bangku ottoman persegi panjang berlapis kain krem di atas karpet tenun, sementara ambang jendela dihiasi keranjang anyaman kecil dan pot bunga putih, serta kendi abu-abu berisi rangkaian bunga putih berdiri di lantai kanan jendela.

**Lingkungan**

> Melalui jendela lengkung di ujung lorong terlihat tanaman bunga merah-oranye merambat di bawah cahaya siang cerah serta sebagian dinding stuko dan atap genteng bangunan tetangga.

#### **B. Framing & Lighting**

- **Fokus:** Jendela lengkung berkusen hitam di dinding ujung sebagai titik lenyap sentral.
- **Camera Start:** Berada tepat di ambang pintu masuk walk-in closet pada sumbu tengah lorong. · Menghadap lurus ke depan sepanjang lorong menuju jendela lengkung di dinding ujung. · front-on · Setara ketinggian mata (eye-level). · Datar (level), menjaga simetri lorong dan garis vertikal lemari.
- **Framing:** Wide simetris dari ambang pintu berkusen gelap memperlihatkan plafon miring berbalok kayu, rak dan lemari pakaian di kedua sisi, ottoman krem di tengah, dan jendela lengkung di ujung. → Medium-tight terpusat pada jendela lengkung berambang dalam, vas bunga putih di lantai kanan, sebagian ottoman di kiri-bawah, serta ceruk gantung pakaian di kanan-kiri ujung.
- **Lighting:** Cahaya alami terang masuk dari jendela lengkung ujung, dilengkapi downlight tanam pada plafon miring dan lampu strip LED hangat tersembunyi di setiap rak dan gantung pakaian.
- **Foreground dan kedalaman:** Bingkai pintu gelap dan sedikit daun tanaman pot di kiri bawah pada awal shot, lalu sisi lemari kiri-kanan dan ottoman krem di tengah lorong. · Perspektif satu titik lenyap yang kuat dari ambang pintu melalui lorong lemari kiri-kanan menuju jendela lengkung dan fasad tetangga di luar.
- **Reveal:** Peluncuran lurus ke depan memperjelas detail bingkai jendela lengkung, bunga merah-oranye di taman luar, tekstur keranjang anyaman, tarikan laci kayu, dan rangkaian bunga putih di lantai.
- **Kesesuaian gerak:** Sangat cocok untuk ruang sempit simetris; Dolly-In lurus menonjolkan kedalaman lorong dan kerapian penyimpanan di kedua sisi.

#### **C. Camera Movement**

Kamera meluncur lurus ke depan menyusuri koridor tengah walk-in closet menuju jendela lengkung di ujung ruangan.

**Tempo:** Laju luncuran lurus ke depan berjalan mulus dan konsisten pada tempo sedang.

**Camera:** Straight Dolly-In (~1.9×).

---

<a id="shot-06"></a>

### Shot 06 · bathroom

**Time:** 17.10–19.90s · **Duration:** 2.80s

![Kolase Shot 06](media/shot-06.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi terang berdinding tampak plester krem hangat dengan dua balok tampak kayu ekspos di plafon atas. Di dinding belakang terpasang jendela persegi panjang dua daun berkusen hitam multi-pane dengan rel gorden hitam, berdampingan di kanannya dengan ceruk dinding melengkung (arched niche) yang bagian bawahnya dilapisi ubin persegi kecil berwarna abu-krem berkilau halus. Lantai dilapisi ubin persegi tampak terakota/travertine bernuansa pasir hangat, dengan tepi pintu tampak kayu berkaca terlihat di sisi kiri depan pada frame akhir.

**Furnitur & dekorasi**

> Di bawah jendela ditempatkan bathtub freestanding oval putih dengan keran pengisi dinding hitam matte dan baki kayu melintang berisi botol sabun kuning-amber serta handuk kecil. Di dalam ceruk lengkung berdiri pohon zaitun pot tinggi berbatu putih di permukaan pot, dengan satu rak kayu melayang kecil di atasnya berisi tanaman hijau. Kloset putih berdiri di depan sisi bawah ceruk. Pada dinding kanan terpasang meja rias wastafel tampak kayu hangat bertarikan hitam dengan bak wastafel putih menonjol, keran hitam, ring gantungan handuk hitam berhanduk krem, lampu dinding hitam berkap kaca, dan tepi cermin melengkung berbingkai hitam. Gorden linen krem menjuntai di kedua sisi jendela, pot-pot kecil berjajar di ambang jendela, keranjang anyaman cokelat berisi handuk putih gulung serta tanaman hijau berada di lantai kiri depan, dan keset tenun krem bergaris tampak di lantai depan.

**Lingkungan**

> Melalui jendela belakang terlihat bunga oranye cerah, dedaunan hijau, serta sebagian fasad bangunan putih beratap genteng lengkung di bawah cahaya matahari siang.

#### **B. Framing & Lighting**

- **Fokus:** Bathtub freestanding di bawah jendela dan pohon zaitun dalam ceruk dinding melengkung.
- **Camera Start:** Berada dekat di depan bathtub dan kloset, di tengah-agak-kiri lorong kamar mandi. · Menghadap lurus ke dinding belakang tempat jendela, bathtub, dan ceruk pohon zaitun. · front-on · Setara ketinggian mata (eye-level). · Datar (level), menjaga garis vertikal jendela dan ceruk lengkung tetap tegak.
- **Framing:** Medium-tight menyorot bathtub oval putih, keran dinding hitam, baki kayu sabun, pohon zaitun pot dalam ceruk lengkung berlapis ubin, kloset putih, dan sebagian jendela. → Wide kamar mandi penuh memperlihatkan jendela kotak ganda bergorden krem, dua balok plafon kayu, bathtub, ceruk pohon zaitun, kloset, meja rias wastafel kayu dengan lampu dinding dan cermin di kanan, keranjang anyaman serta tepi pintu kaca kayu di kiri, dan lantai ubin terakota berkeset tenun.
- **Lighting:** Cahaya matahari siang melimpah masuk melalui jendela belakang, dilengkapi cahaya hangat dari lampu dinding kaca di sisi kanan dan downlight plafon.
- **Foreground dan kedalaman:** Tepi kloset putih di kanan bawah awal, lalu meja rias wastafel kayu di kanan dan keranjang rotan berisi handuk gulung serta tanaman hijau di kiri bawah pada akhir shot. · Berlapis dari keranjang kiri dan meja rias wastafel kanan menuju kloset, bathtub, ceruk pohon zaitun, hingga taman dan bangunan tetangga di luar jendela.
- **Reveal:** Penarikan mundur lurus membuka meja rias wastafel tampak kayu berpintu dua, handuk gantung, lampu dinding hitam, tepi cermin hitam di kanan, keranjang handuk dan tepi pintu kayu di kiri, dua balok kayu di plafon atas, serta pola lantai ubin terakota berkeset tenun.
- **Kesesuaian gerak:** Sangat cocok sebagai shot penutup; penarikan mundur lurus yang tenang menuntaskan penyingkapan seluruh elemen kamar mandi.

#### **C. Camera Movement**

Kamera mundur lurus menjauhi bathtub dan ceruk pohon zaitun untuk menyingkap meja rias wastafel di kanan, keranjang handuk di kiri bawah, balok plafon, dan lantai ubin kamar mandi.

**Tempo:** Gerak mundur lurus berlangsung tenang dan konsisten pada tempo sedang hingga akhir video.

**Camera:** Straight Dolly-Out (~1.9×).

**Catatan referensi:** Video menampilkan 6 shot terpisah melalui 5 hard cut dengan pola gerak bergantian IN–OUT–IN–OUT–IN–OUT. Konsistensi gaya Spanish Colonial Revival dan palet material sangat kuat di seluruh ruangan, tetapi konektivitas denah fisik antar-ruang tidak ditunjukkan secara kontinu sehingga tidak disimpulkan. Material fisik aktual dicatat dari tampilan visualnya saja.
