# edh013 — Ivory Spiral Garden Tower

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Ivory Spiral Garden Tower
- **Tipe rumah:** Tower House
- **Gaya utama:** **Organic Architecture**
- **Pengaruh gaya:** Mediterranean Revival
- **Gaya interior:** Romantic Organic Modern
- **Susunan ruang utama:** Ruang tamu tinggi bertangga, dapur melengkung, kamar tidur berplatform dan kamar mandi berundak; hubungan denah antarshot tidak ditunjukkan
- **Ciri khas:** Tangga luar spiral menyelubungi menara; bukaan bundar besar, ceruk melengkung dan tanaman menjuntai
- **Material utama:** Permukaan putih gading halus, kayu cokelat tampak, logam warna emas, tekstil krem dan merah muda
- **Pencahayaan:** Cahaya siang dari bukaan besar, bercampur lampu gantung dan pencahayaan rak hangat
- **Atmosfer:** Romantis, lembut, seperti hunian taman fantasi dengan bentuk mengalir dan bunga melimpah
- **Lingkungan:** Taman bunga merah muda, semak pangkas, pepohonan dan pegunungan di kejauhan

### Palet warna

| Peran | Warna | HEX |
| --- | --- | --- |
| Dominan | Putih gading | `#E4DED1` |
| Pendamping | Krem linen | `#D6C5B4` |
| Pendamping | Dusty pink | `#C7999B` |
| Pendamping | Cokelat kayu | `#93633E` |
| Aksen | Emas hangat | `#B18C52` |
| Aksen | Hijau daun | `#53663B` |

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | rounded tower |
| **Lantai & bentuk atap** | Tiga tingkat fasad tampak · flat rounded parapet |
| **Tapak bangunan** | compact rounded footprint |
| **Proporsi utama** | Massa vertikal membulat, tinggi lebih dominan daripada lebar |
| **Perkiraan luas lantai** | **65–110 m²** |

## 3. Shot Timeline

Durasi 21.33s · 5 shot.

**Camera Pattern:** IN – OUT – IN – OUT – IN.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–4.60 | 4.60s | Exterior | Orbit Right (Ease-Out) + Gentle Pan Left → Accelerating Dolly-In (~1.3×) + Mild Orbit Right. |
| 02 | 4.60–8.07 | 3.47s | Living Room | Straight Dolly-Out (~1.7×, Ease-Out). |
| 03 | 8.07–11.63 | 3.57s | Kitchen | Diagonal Dolly-In (~1.6×) + Moderate Pan Right (~20°–30°, Ease-Out). |
| 04 | 11.63–16.67 | 5.03s | Bedroom | Dolly-Out (~1.5×) + Orbit Left + Moderate Pan Right (Ease-Out). |
| 05 | 16.67–21.33 | 4.67s | Bathroom | Straight Dolly-In (~1.9×). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Exterior · 2.30s**

> Pandangan wide serong dari taman; menara tiga tingkat, tangga spiral, jalur dan hamparan bunga terlihat bersama pegunungan.

**Shot 02 · Living Room · 8.03s**

> Wide dari sisi depan ruang; sofa melengkung, meja bundar, karpet, tangga dan dinding bukaan besar terlihat hingga plafon.

**Shot 03 · Kitchen · 8.07s**

> Wide serong dari sisi meja island; island oval, kabinet melengkung, rak ceruk bercahaya dan beberapa pendant terlihat.

**Shot 04 · Bedroom · 16.63s**

> Wide serong dari kaki ranjang; platform kayu bertangga, ranjang, jendela bundar, rak buku dan bukaan samping berisi tanaman terlihat.

**Shot 05 · Bathroom · 16.67s**

> Wide menghadap arch menuju bak mandi di atas undakan; toilet kiri, vanity kanan, karpet merah muda dan jendela bundar terlihat.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Exterior

**Time:** 0.00–4.60s · **Duration:** 4.60s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Menara putih gading membulat dengan tiga deret bukaan, pintu ganda lengkung di dasar, jendela bulat dan balkon berundak; tangga luar spiral naik mengitari fasad. Puncak tampak datar berparapet.

**Furnitur & dekorasi**

> Pot bunga merah muda dan sulur hijau ditempatkan di balkon, tepian tangga dan dinding.

**Lingkungan**

> Jalur batu berkelok menuju anak tangga, taman bunga merah muda, rumput, semak bulat, pohon dan latar perbukitan.

#### **B. Framing & Lighting**

- **Fokus:** Menara dan spiral.
- **Camera Start:** Di taman di balik batang pohon. · Menghadap menara dan tangga luar. · oblique · Setinggi pandangan taman, perkiraan. · Hampir datar.
- **Framing:** Wide dengan pohon menutupi sebagian fasad. → Menara lebih besar dan terbuka.
- **Lighting:** Cahaya siang dari samping, bayang pohon.
- **Foreground dan kedalaman:** Batang pohon dan bunga. · Pohon dekat, rumah tengah, bukit jauh.
- **Reveal:** Pohon keluar dari kiri lalu fasad mendekat.
- **Kesesuaian gerak:** Paralaks dan skala mendukung gerak badan kamera.

#### **C. Camera Movement**

Batang dekat cepat keluar kiri, bukit bergeser relatif ke menara; sisi fasad membulat berubah sedikit, mendukung orbit kanan. Menara relatif terjaga di tengah meski badan bergeser kanan; pan kiri kompensasi ringan. Pergeseran batang lebih cepat pada 0–30 daripada 60–90; sudut komponen tidak terpisah dengan yakin. Jalur dan bunga menyebar; perubahan sisi menara kecil masih terlihat. Arah pandang tetap dekat menara; perubahan rotasi kecil sulit dipisahkan. Pertambahan skala 95–110 lebih kecil daripada 110–125 dan 125–137; perspektif turut berpengaruh.

**Tempo:** Sapuan awal cukup cepat, bagian tengah lebih tenang, lalu pendekatan menguat di akhir.

**Movement Timeline**

| Time (s) | Area & fokus | Camera Movement | Tempo |
| --- | --- | --- | --- |
| 0.00–3.17 | Exterior · Membuka fasad dari balik pohon | Orbit Right (Ease-Out) + Gentle Pan Left | Sapuan awal cukup cepat, bagian tengah lebih tenang, lalu pendekatan menguat di akhir. |
| 3.17–4.60 | Exterior · Mendekati fasad | Accelerating Dolly-In (~1.3×) + Mild Orbit Right | Sapuan awal cukup cepat, bagian tengah lebih tenang, lalu pendekatan menguat di akhir. |

**Camera:** Orbit Right (Ease-Out) + Gentle Pan Left → Accelerating Dolly-In (~1.3×) + Mild Orbit Right.

---

<a id="shot-02"></a>

### Shot 02 · Living Room

**Time:** 4.60–8.07s · **Duration:** 3.47s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang tinggi dengan dinding membulat putih gading, jendela bundar raksasa berpalang gelap dan bukaan lengkung berbingkai hangat; tangga melengkung naik di kiri dengan balustrade ramping, ceruk tanaman bertingkat, lantai kayu tampak dan undakan depan.

**Furnitur & dekorasi**

> Sofa sectional krem melengkung dengan banyak bantal mengikuti dinding; meja kopi bundar rendah di atas karpet bundar berpola, vas rumput kering dan tanaman hijau.

**Lingkungan**

> Pepohonan dan bunga merah muda terlihat lewat jendela.

#### **B. Framing & Lighting**

- **Fokus:** Sofa, jendela bulat, tangga.
- **Camera Start:** Di depan sofa dekat meja kopi. · Menghadap dinding lengkung dan tangga. · oblique · Setinggi mata, perkiraan. · Sedikit mengarah ke atas.
- **Framing:** Sofa dan jendela dominan, meja terpotong. → Wide ruang duduk beserta lantai dan plafon.
- **Lighting:** Cahaya siang dari jendela kanan; lampu kecil hangat.
- **Foreground dan kedalaman:** Vas dan meja kopi. · Meja dekat, sofa tengah, bukaan dan tangga jauh.
- **Reveal:** Meja, karpet dan undakan terbuka.
- **Kesesuaian gerak:** Mundur membuka lapisan lantai dan plafon.

#### **C. Camera Movement**

Karpet dan undakan depan muncul; lapisan dekat menyusut lebih banyak, tanpa perubahan sisi yang kuat. Jendela dan tangga tetap pada sisi masing-masing; perubahan vertikal tipis tidak cukup untuk tilt. Perubahan per 25 frame relatif lancar, melambat dekat akhir.

**Tempo:** Mundur halus pada laju sedang, agak mereda menjelang akhir.

**Camera:** Straight Dolly-Out (~1.7×, Ease-Out).

---

<a id="shot-03"></a>

### Shot 03 · Kitchen

**Time:** 8.07–11.63s · **Duration:** 3.57s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dapur dengan dinding putih berlekuk dan ceruk rak lengkung bertingkat; backsplash tampak batu berurat, countertop terang, kabinet bawah dusty pink mengikuti kurva; plafon berlekuk dengan lampu kecil.

**Furnitur & dekorasi**

> Island oval beralas bilah vertikal kayu tampak, alat makan di atasnya; kabinet merah muda, oven hitam tanam dan cooktop hitam di tengah, rak terbuka berisi peralatan, vas dan tanaman; pendant emas bertingkat.

**Lingkungan**

> Eksterior tidak terlihat jelas dalam shot dapur; pencahayaan hangat pada rak dominan.

#### **B. Framing & Lighting**

- **Fokus:** Kabinet lengkung dan rak.
- **Camera Start:** Di sisi luar island. · Menghadap serong ke kabinet dan ceruk. · oblique · Setinggi dada hingga mata, perkiraan. · Sedikit menunduk ke meja.
- **Framing:** Wide island dan dinding kerja. → Medium framing oven dan ceruk.
- **Lighting:** Lampu pendant emas, cahaya rak hangat dan permukaan terang.
- **Foreground dan kedalaman:** Island dan alat makan. · Island dekat, kabinet dan ceruk di belakang.
- **Reveal:** Island tersisih, detail oven dan rak membesar.
- **Kesesuaian gerak:** Paralaks island terhadap dinding mendukung maju disertai rotasi.

#### **C. Camera Movement**

Tepi island bergeser relatif terhadap kabinet; mendukung maju diagonal, lintasan orbit tidak jelas. Ceruk dan pendant tersapu ke kiri saat bidang oven menjadi pusat; pan kanan. Sapuan per 25 frame lebih kuat di bagian tengah, kemudian mereda; sudut perkiraan dari pergantian arah pandang.

**Tempo:** Perjalanan sedang, sapuan kanan paling terasa di tengah.

**Camera:** Diagonal Dolly-In (~1.6×) + Moderate Pan Right (~20°–30°, Ease-Out).

---

<a id="shot-04"></a>

### Shot 04 · Bedroom

**Time:** 11.63–16.67s · **Duration:** 5.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding putih membulat dengan jendela bulat berbingkai emas/kayu di atas kepala ranjang; rak buku mengikuti kelengkungan bagian atas dan sisi, bukaan besar lengkung di kanan, platform kayu bertangga.

**Furnitur & dekorasi**

> Ranjang ganda dengan selimut putih gading dan bantal dusty pink, nakas bulat, vas bunga, pendant emas di kiri kanan, tanaman rambat dan tanaman pot besar; dekorasi bunga dekat kaki ranjang.

**Lingkungan**

> Pohon dan daun besar terlihat melalui jendela bundar; tanaman dalam ruang di dekat bukaan kanan.

#### **B. Framing & Lighting**

- **Fokus:** Ranjang dan jendela.
- **Camera Start:** Di depan ranjang dekat kaki. · Menghadap jendela bundar di atas ranjang. · frontal · Setinggi mata, perkiraan. · Hampir datar.
- **Framing:** Ranjang dan jendela bundar mengisi frame. → Wide serong dengan platform, rak dan bukaan kanan.
- **Lighting:** Cahaya siang dari jendela, pendant hangat.
- **Foreground dan kedalaman:** Selimut dan kemudian vas bunga. · Ranjang dekat, jendela dan vegetasi di belakang.
- **Reveal:** Platform dan bukaan samping muncul.
- **Kesesuaian gerak:** Skala menyusut dan sisi ranjang berubah; bukan zoom saja.

#### **C. Camera Movement**

Vas kaki ranjang muncul kiri lalu bergerak relatif ke kanan terhadap jendela; sisi ranjang serta tebal bingkai berubah, mendukung lintasan orbit kiri. Jendela bergerak ke kiri dan bukaan kanan terlihat lebih luas, pan kanan kompensasi. Laju perubahan arah paling jelas 409–469; 469–499 lebih kecil. Sudut orbit dan pan sulit dipisahkan.

**Tempo:** Mundur dan menyapu secara sedang, mereda di akhir.

**Camera:** Dolly-Out (~1.5×) + Orbit Left + Moderate Pan Right (Ease-Out).

---

<a id="shot-05"></a>

### Shot 05 · Bathroom

**Time:** 16.67–21.33s · **Duration:** 4.67s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi putih gading dengan arch lebar menuju platform berundak, plafon miring/melengkung, jendela bulat berbingkai hangat; ceruk rak melengkung, lantai platform berpola dan tepi undakan bercahaya.

**Furnitur & dekorasi**

> Bak mandi oval freestanding putih dengan keran emas di belakang; wastafel mangkuk di atas vanity kanan dengan rak handuk, toilet putih kiri, cermin bulat, karpet merah muda dan tanaman pot/menjuntai.

**Lingkungan**

> Langit biru terlihat dari jendela bulat; vegetasi di sekitar bak memperkuat kesan taman.

#### **B. Framing & Lighting**

- **Fokus:** Bak dan jendela.
- **Camera Start:** Di area depan antara toilet dan vanity. · Menghadap bak mandi melalui arch. · frontal · Setinggi mata, perkiraan. · Hampir datar.
- **Framing:** Wide toilet, vanity dan bak di belakang. → Close wide bak oval dan jendela bulat.
- **Lighting:** Cahaya siang terang melalui jendela dan bagian plafon, aksen emas hangat.
- **Foreground dan kedalaman:** Toilet kiri dan vanity kanan. · Sanitair dekat, arch tengah, bak dan jendela jauh.
- **Reveal:** Melewati pandangan arch menuju bak.
- **Kesesuaian gerak:** Paralaks tepi arch, vanity dan bak mendukung maju.

#### **C. Camera Movement**

Tepi arch dan vanity menyebar keluar layar secara berbeda menurut kedalaman; gerak maju hampir lurus. Jendela relatif stabil di tengah-kanan, tidak terlihat putaran besar; drift kecil tidak cukup untuk tilt. Pertumbuhan skala menguat mendekati bak namun dapat berasal dari perspektif, bukan bukti akselerasi fisik.

**Tempo:** Maju sedang dan lancar, pembesaran perspektif lebih terasa di akhir.

**Camera:** Straight Dolly-In (~1.9×).
