# edh058 — Mediterranean Garden Cottage

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Mediterranean Garden Cottage
- **Tipe rumah:** Cottage
- **Gaya utama:** **Mediterranean Cottage**
- **Pengaruh gaya:** Spanish Colonial Revival
- **Gaya interior:** Rustic Cottage
- **Susunan ruang utama:** Rangkaian visual eksterior, living, kitchen, bedroom, walk-in closet dan bathroom; koneksi denah tidak terbukti karena cut
- **Ciri khas:** Bukaan lengkung berbingkai gelap, balok plafon bernuansa kayu, detail anyaman serta tanaman
- **Material utama:** Permukaan plester krem, genteng warna tanah, kayu natural, tekstil krem, aksen logam gelap dan lantai tampak kayu/batu
- **Pencahayaan:** Cahaya matahari dari taman dan jendela, downlight, pendant serta wall sconce hangat
- **Atmosfer:** Hangat, nyaman, natural dan intim dengan palet netral serta aksen bunga
- **Lingkungan:** Halaman rumput, jalan setapak batu, bedeng bunga dan pohon rindang; vegetasi dan bangunan beratap genteng tampak melalui sebagian bukaan

### Palet warna

| Peran | Warna | HEX |
| --- | --- | --- |
| Dominan | Warm Ivory | `#D6C8AE` |
| Pendamping | Linen Cream | `#E0D8C8` |
| Pendamping | Honey Oak | `#A8784E` |
| Pendamping | Sage Gray | `#8D9385` |
| Aksen | Charcoal | `#34332D` |
| Aksen | Terracotta | `#A56848` |

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Massa rendah dengan entrance menonjol dan sayap kiri |
| **Lantai & bentuk atap** | Satu lantai terlihat · Gable roof berlapis genteng lengkung, overhang pendek dan cerobong |
| **Tapak bangunan** | Massa rendah kompak dengan tonjolan entrance dan sayap kiri |
| **Proporsi utama** | Lebar lebih dominan daripada tinggi, entrance bergable rendah |
| **Perkiraan luas lantai** | **55–90 m²** |

## 3. Shot Timeline

Durasi 19.90s · 6 shot.

**Camera Pattern:** IN – OUT – IN – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–5.30 | 5.30s | Exterior | Dolly-In (~2.0×, Ease-In) + Mild Orbit Left + Subtle Pan Right. |
| 02 | 5.30–8.37 | 3.07s | Living Room | Dolly-Out (~1.4×) + Moderate Pan Left (~20°–25°). |
| 03 | 8.37–11.53 | 3.17s | Kitchen | Dolly-In (~1.6×) + Moderate Pan Right (~20°–25°). |
| 04 | 11.53–14.57 | 3.03s | Bedroom | Dolly-Out (~1.7×) + Gentle Pan Left (~10°–15°). |
| 05 | 14.57–17.10 | 2.53s | Walk-In Closet | Straight Dolly-In (~1.7×) + Subtle Pan Left (~5°). |
| 06 | 17.10–19.90 | 2.80s | Bathroom | Pure Dolly-Out (~1.8×). |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · Exterior · 0.00s**

> Wide dari halaman depan, menghadap serong ke pintu dan sisi kanan massa. Rumput, jalur batu, bedeng bunga, pohon besar dan sayap kiri rumah terlihat bersamaan.

**Shot 02 · Living Room · 8.33s**

> Wide dari sisi belakang sofa mengarah serong ke ceruk televisi dan jendela kiri. Sofa, kursi, coffee table, rug, kabinet media dan plafon terlihat lebih lengkap.

**Shot 03 · Kitchen · 8.37s**

> Wide dari bukaan dapur, serong ke rangkaian kabinet sisi kanan dan jendela lengkung ujung. Meja dengan dua stool, jalur kerja, range dan pendant terlihat.

**Shot 04 · Bedroom · 14.53s**

> Wide serong dari sisi kaki ranjang, menghadap dinding jendela lengkung. Ranjang, dua nakas, kursi kiri, rug, balok plafon dan lampu gantung terlihat.

**Shot 05 · Walk-In Closet · 14.57s**

> Wide dari ambang pintu menghadap lurus ke jendela lengkung pada ujung closet. Rak gantung kiri-kanan, laci, ottoman, karpet dan plafon gable terlihat.

**Shot 06 · Bathroom · 19.87s**

> Wide dari ambang pintu menghadap bathtub di bawah jendela. Toilet, vanity kanan, cermin, ceruk lengkung, tanaman, lantai dan balok plafon tampak dalam satu komposisi.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · Exterior

**Time:** 0.00–5.30s · **Duration:** 5.30s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Massa rendah dengan gable entrance menonjol, genteng lengkung warna tanah, dinding krem halus, cerobong putih dan overhang pendek. Pintu panel kaca bernuansa kayu diapit lentera, jendela berkisi gelap ber-shutter dan planter. Landing kecil satu undakan di ujung jalur batu.

**Furnitur & dekorasi**

> Pot tanah dan planter bermotif dikelompokkan di kiri-kanan pintu; semak konikal dan tanaman berbunga membingkai undakan.

**Lingkungan**

> Rumput hijau, setapak batu bentuk tidak beraturan, bedeng bunga merah-putih dan pohon besar di kanan layar; pagar kayu terlihat di belakang pohon. Matahari terang dengan bayangan pohon di halaman.

#### **B. Framing & Lighting**

- **Fokus:** Pintu masuk dan gable
- **Camera Start:** Dari halaman depan di ujung jalur batu · Menghadap entrance dan sisi kanan fasad · oblique · Setinggi mata, perkiraan · Sedikit menurun untuk memasukkan halaman
- **Framing:** Wide fasad dan taman → Medium wide pintu serta pot
- **Lighting:** Matahari langsung, bayangan tajuk melintang halaman
- **Foreground dan kedalaman:** Rumput, jalan batu dan batang pohon kanan · Jalur, bedeng bunga, fasad dan pohon belakang
- **Reveal:** Pintu dan lampu makin dominan; pohon keluar kanan
- **Kesesuaian gerak:** Mendekat mengikuti jalur; perubahan sisi fasad kecil

#### **C. Camera Movement**

Kamera maju dari halaman menuju pintu dengan awal lebih lembut, sedikit mengitari entrance ke kiri dan mengompensasi arah pandang ke kanan. Jalan, taman dan pohon memberi kedalaman sebelum detail pintu mendominasi.

**Tempo:** Mendekat bertahap selama 5,3 s; perubahan framing meningkat menjelang akhir tanpa memastikan akselerasi fisik konstan.

**Camera:** Dolly-In (~2.0×, Ease-In) + Mild Orbit Left + Subtle Pan Right.

---

<a id="shot-02"></a>

### Shot 02 · Living Room

**Time:** 5.30–8.37s · **Duration:** 3.07s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding krem dengan ceruk TV berarch rendah, sepasang sconce hitam, pilaster tepi dan crown molding. Jendela besar berkisi gelap dengan gorden krem di kiri; balok kayu dan downlight pada plafon, lantai papan hangat.

**Furnitur & dekorasi**

> Sofa krem berlengan bulat menghadap coffee table kayu persegi panjang dengan rak bawah dan kabinet media kayu di ceruk. Kursi dekat jendela, bantal bermotif, rug bermotif klasik, keranjang anyaman dan vas bunga.

**Lingkungan**

> Melalui jendela kiri terlihat taman berbunga, rumput dan sebagian bangunan terang. Cahaya membentuk petak kisi pada rug.

#### **B. Framing & Lighting**

- **Fokus:** Ceruk media dan sofa
- **Camera Start:** Di sisi sofa, dekat bantalan depan kanan · Serong ke ceruk TV di dinding seberang · oblique · Setinggi mata duduk/berdiri rendah, perkiraan · Sedikit menurun
- **Framing:** Medium wide TV dan sofa terpotong → Wide sofa, meja dan jendela
- **Lighting:** Daylight dari kiri dan downlight
- **Foreground dan kedalaman:** Bantal dan lengan sofa di kanan · Sofa dekat, meja, kabinet TV dan jendela
- **Reveal:** Jendela kiri serta area duduk terbuka
- **Kesesuaian gerak:** Mundur dengan sapuan kiri sehingga perabot terungkap

#### **C. Camera Movement**

Mundur dari sisi sofa sambil mengarahkan pandangan ke kiri untuk memperlihatkan jendela, kursi dan keseluruhan kelompok duduk.

**Tempo:** Pelebaran dan sapuan kiri berlangsung selama sekitar tiga detik, tanpa jeda nyata.

**Camera:** Dolly-Out (~1.4×) + Moderate Pan Left (~20°–25°).

---

<a id="shot-03"></a>

### Shot 03 · Kitchen

**Time:** 8.37–11.53s · **Duration:** 3.17s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dapur dengan counter berbelok pada dinding ujung dan kanan, jendela lengkung berkisi gelap, backsplash krem bertekstur, lantai papan cokelat. Bukaan masuk bertepi tekstur batu dan balok; downlight dan pendant silinder.

**Furnitur & dekorasi**

> Kabinet panel recessed krem dengan handle gelap mengapit range dan oven stainless-look; chimney hood metal di atasnya. Rak kayu terbuka di kanan, pot di atas range, mangkuk buah, sink dan faucet gelap, meja berpermukaan terang dengan dua stool kayu. Sambungan meja ke kabinet tidak terlihat jelas.

**Lingkungan**

> Jendela memberi cahaya terang; detail tapak luar tidak terbaca jelas. Bunga merah pada ambang jendela.

#### **B. Framing & Lighting**

- **Fokus:** Range dan hood
- **Camera Start:** Di ambang bukaan dapur, meja di kiri · Serong ke counter kanan dan jendela ujung · oblique · Setinggi mata, perkiraan · Sedikit menurun
- **Framing:** Wide dari bukaan → Medium range, hood dan counter
- **Lighting:** Daylight, pendant, downlight, task light
- **Foreground dan kedalaman:** Meja dan stool kiri, jamb kanan · Meja dekat, range tengah, jendela jauh
- **Reveal:** Jamb dan meja lepas dari frame, range membesar
- **Kesesuaian gerak:** Maju dengan sapuan kanan ke area memasak

#### **C. Camera Movement**

Kamera masuk ke arah counter dan memutar pandangan ke kanan, dari komposisi dapur lebar menuju range, hood dan rak.

**Tempo:** Perubahan dari wide ke medium berlangsung sekitar tiga detik dengan gerak berkesinambungan.

**Camera:** Dolly-In (~1.6×) + Moderate Pan Right (~20°–25°).

---

<a id="shot-04"></a>

### Shot 04 · Bedroom

**Time:** 11.53–14.57s · **Duration:** 3.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding sage gray dengan jendela arch berkisi hitam tepat di atas headboard, gorden krem, jendela samping kiri, plafon terang dengan balok kayu dan pendant rangka lentera. Lantai papan terang, lampu dinding di sekitar ranjang.

**Furnitur & dekorasi**

> Ranjang kayu dengan footboard berpanel, selimut krem bertekstur dan bantal terracotta. Nakas laci kayu di kedua sisi, lampu meja kiri dan vas bunga kanan. Kursi sudut kiri, tanaman tinggi, rug krem serta permukaan kabinet depan kiri.

**Lingkungan**

> Pepohonan hijau tampak melalui jendela, dengan bunga merah di ambang; cahaya alami bercampur lampu hangat.

#### **B. Framing & Lighting**

- **Fokus:** Ranjang dan jendela
- **Camera Start:** Dekat sisi kanan kaki ranjang · Menghadap headboard dan jendela arch · oblique · Setinggi mata, perkiraan · Sedikit menurun
- **Framing:** Medium bed, jendela dan nakas kanan → Wide ranjang, nakas dan sudut kiri
- **Lighting:** Daylight dari jendela, sconce dan lampu meja hangat
- **Foreground dan kedalaman:** Bedding, bantal dan nakas kanan · Ranjang dekat, headboard, jendela dan vegetasi jauh
- **Reveal:** Footboard, pendant, kursi dan rug muncul
- **Kesesuaian gerak:** Mundur dengan pergeseran framing ke kiri

#### **C. Camera Movement**

Mundur dari detail bedding dan jendela sambil sedikit menyapu kiri hingga ranjang, kedua nakas dan sudut duduk terlihat.

**Tempo:** Pelebaran selama tiga detik dengan sapuan ringan, kontinu.

**Camera:** Dolly-Out (~1.7×) + Gentle Pan Left (~10°–15°).

---

<a id="shot-05"></a>

### Shot 05 · Walk-In Closet

**Time:** 14.57–17.10s · **Duration:** 2.53s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang memanjang dengan sirkulasi tengah, plafon vaulted mengikuti gable dengan balok kayu, jendela lengkung berkisi hitam di ujung. Dinding krem, lantai papan terang, lampu recessed dan aksen rak.

**Furnitur & dekorasi**

> Built-in terbuka pada kedua sisi, rel gantung ganda di kiri, pakaian gantung, rak keranjang atas dan laci kayu di kanan. Ottoman persegi berlapis krem di lorong, rug panjang dan bunga putih dekat jendela.

**Lingkungan**

> Jendela memperlihatkan bunga merah-oranye, langit terang dan bagian atap luar.

#### **B. Framing & Lighting**

- **Fokus:** Jendela lengkung
- **Camera Start:** Di ambang pintu closet · Menghadap jendela di ujung lorong · frontal · Setinggi mata, perkiraan · Hampir level
- **Framing:** Wide lorong dan plafon → Medium jendela serta rak belakang
- **Lighting:** Daylight ujung, lampu plafon/rak
- **Foreground dan kedalaman:** Kusen, rak samping dan tanaman kiri · Kusen, ottoman, rak dan jendela
- **Reveal:** Kusen keluar, jendela dan penyimpanan membesar
- **Kesesuaian gerak:** Gerak maju melalui lorong

#### **C. Camera Movement**

Maju hampir lurus di koridor penyimpanan dari ambang pintu ke arah jendela, dengan koreksi pandangan kiri tipis.

**Tempo:** Pendekatan dalam 2,53 detik; aliran kontinu dan cukup aktif.

**Camera:** Straight Dolly-In (~1.7×) + Subtle Pan Left (~5°).

---

<a id="shot-06"></a>

### Shot 06 · Bathroom

**Time:** 17.10–19.90s · **Duration:** 2.80s

![Kolase Shot 06](media/shot-06.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding putih hangat dengan ceruk arch di kanan jendela dan tile kecil di bagian bawahnya. Jendela persegi berkisi gelap dengan gorden krem di atas bathtub, plafon dengan balok kayu dan downlight, lantai tile warna pasir.

**Furnitur & dekorasi**

> Bathtub freestanding oval putih dengan wall-mounted faucet gelap di bawah jendela; toilet di kanan depan bathtub. Vanity kayu berpanel dengan vessel sink putih, faucet hitam dan cermin arch; tanaman tinggi di ceruk serta keranjang anyaman handuk di kiri.

**Lingkungan**

> Bunga merah, pohon dan sebagian atap tampak melalui jendela. Cahaya matahari membentuk petak terang pada lantai.

#### **B. Framing & Lighting**

- **Fokus:** Bathtub dan jendela
- **Camera Start:** Di dalam kamar mandi dekat bathtub dan tanaman · Menghadap dinding jendela dan ceruk kanan · oblique · Setinggi mata, perkiraan · Hampir level
- **Framing:** Medium bathtub dan tanaman, toilet terpotong → Wide dari pintu, bathtub, toilet dan vanity
- **Lighting:** Daylight kuat dari jendela dan sconce hangat
- **Foreground dan kedalaman:** Bibir bathtub dan tutup toilet · Bathtub, tanaman, ceruk dan luar jendela
- **Reveal:** Vanity kanan, lantai, keranjang dan kusen muncul
- **Kesesuaian gerak:** Mundur membuka keseluruhan area

#### **C. Camera Movement**

Kamera mundur dari bathtub hingga ambang pintu dan memperlihatkan toilet, vanity serta lantai. Rotasi kecil tidak terpisahkan dari perubahan perspektif.

**Tempo:** Pelebaran berlangsung 2,8 detik secara berkesinambungan.

**Camera:** Pure Dolly-Out (~1.8×).
