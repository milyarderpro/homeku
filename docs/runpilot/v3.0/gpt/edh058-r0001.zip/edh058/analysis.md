# edh058 — Garden Cottage dengan Fasad Krem dan Interior Kayu Hangat

<a id="profil-dna"></a>

## 1. Profil desain

- **Nama desain:** Garden Cottage dengan Fasad Krem dan Interior Kayu Hangat
- **Gaya utama:** **English Cottage**
- **Pengaruh gaya:** Mediterranean Cottage
- **Gaya interior:** Modern Cottage; Rustic Country
- **Ciri khas:** Ceruk TV melengkung, jendela lengkung hitam, balok kayu, tanaman dan tekstil netral berlapis
- **Warna & material:** Dinding krem halus, unsur tampak kayu hangat, rangka hitam dan bidang meja pucat; material fisik belum diverifikasi; Krem, putih gading, cokelat madu, hitam, hijau tanaman serta aksen bunga merah-oranye
- **Suasana dan lingkungan:** Sinar matahari kuat dari kebun dan jendela; lampu dinding, downlight, pendant dan lampu meja hangat; Kebun rumput, pohon besar, bunga padat dan jalan batu tidak beraturan; hijauan/bunga terlihat dari jendela

## 2. Ukuran & proporsi

| Aspek | Estimasi visual |
| --- | --- |
| **Ukuran rumah** | small |
| **Bentuk bangunan** | Massa rendah dengan volume entrance pelana menjorok dan sayap kiri lebih rendah |
| **Lantai & bentuk atap** | Satu tingkat terlihat dari fasad · Atap pelana landai dengan penutup berprofil genteng cokelat, tepian kayu dan cerobong putih terlihat |
| **Tapak bangunan** | Massa tampak kompak; bentuk denah utuh tidak diketahui |
| **Proporsi utama** | Massa rendah, lebar fasad lebih dominan daripada tinggi; entrance menjorok dengan pelana tersendiri |
| **Perkiraan luas lantai** | **65–100 m²** |

## 3. Shot Timeline

Durasi 19.90s · 6 shot.

**Camera Pattern:** IN – OUT – IN – OUT – IN – OUT.

| Shot | Time (s) | Duration | Area/Scene | Camera Movement |
| --- | --- | --- | --- | --- |
| 01 | 0.00–5.30 | 5.30s | exterior | Dolly-In + Gentle Orbit Left. |
| 02 | 5.30–8.37 | 3.07s | living room | Dolly-Out + Pan Left. |
| 03 | 8.37–11.53 | 3.17s | kitchen | Dolly-In + Pan Right. |
| 04 | 11.53–14.57 | 3.03s | bedroom | Dolly-Out + Gentle Pan Left. |
| 05 | 14.57–17.10 | 2.53s | walk-in closet | Dolly-In. |
| 06 | 17.10–19.90 | 2.80s | bathroom | Dolly-Out. |

## 4. Overview

![Overview wide seluruh area](media/overview.jpg)

**Shot 01 · exterior · 0.00s**

> Wide dari jalan taman menghadap serong ke fasad dan sisi kanannya; rumput, jalan batu, pohon kanan, atap dan entrance terlihat bersama.

**Shot 02 · living room · 8.33s**

> Wide dari sisi sofa menghadap serong ke dinding TV dan jendela kiri; meja kopi, karpet, sofa dan kursi dekat jendela terlihat bersama.

**Shot 03 · kitchen · 8.37s**

> Wide dari ambang dapur menghadap serong ke lorong; island kiri dengan bangku, kabinet L kanan-belakang, range, hood dan jendela lengkung terlihat.

**Shot 04 · bedroom · 14.53s**

> Wide dari sisi kaki ranjang menghadap serong ke headboard; ranjang utuh, dua nakas, jendela lengkung, balok, pendant dan sebagian sudut duduk tampak.

**Shot 05 · walk-in closet · 14.57s**

> Wide hampir frontal dari ambang; kedua sisi lemari, lorong dengan ottoman, plafon pelana dan jendela ujung terlihat utuh.

**Shot 06 · bathroom · 19.87s**

> Wide dari dekat ambang menghadap ujung ruang; bathtub di bawah jendela, toilet, tanaman, ceruk kanan, vanity dan lantai berubin terlihat bersama.

## 5. Storyboard

![Storyboard seluruh shot dengan panel dan camera](media/storyboard.jpg)

## 6. Shot Details

<a id="shot-01"></a>

### Shot 01 · exterior

**Time:** 0.00–5.30s · **Duration:** 5.30s

![Kolase Shot 01](media/shot-01.jpg)

#### **A. Desain area**

**Arsitektur**

> Rumah rendah satu tingkat yang terlihat, dengan volume entrance menjorok berpelana landai di depan sayap kiri. Dinding krem halus, tepian atap kayu dan genteng tampak cokelat; cerobong putih di kiri belakang. Pintu kayu dengan kaca berpetak dan panel bawah berada di tengah entrance, diapit dua lentera dinding dan satu lentera di atas; jendela hitam berpetak dengan shutter gelap di kiri dan jendela sisi kanan. Teras dangkal naik satu undakan dari jalan batu.

**Furnitur & dekorasi**

> Pot terakota dan pot krem bermotif berisi semak tegak dan bunga mengapit pintu. Kotak tanaman di bawah jendela kiri; tidak tampak furnitur duduk di teras. Karangan daun melingkar tergantung pada kaca pintu.

**Lingkungan**

> Jalan batu tidak beraturan membelah rumput hijau menuju entrance, dikelilingi bedeng bunga putih dan merah-oranye. Batang pohon besar membingkai kanan; kanopi hijau dan keemasan di belakang, pagar kayu di sisi kanan. Cahaya matahari menciptakan bayangan daun di rumput.

#### **B. Framing & Lighting**

- **Fokus:** Pintu dan volume entrance
- **Camera Start:** Di jalan taman, jauh dari teras · Menghadap entrance dan sisi kanan fasad · oblique · Sekitar tinggi mata · Hampir mendatar
- **Framing:** Wide fasad, rumput dan pohon → Medium dekat pintu, tepi fasad terpotong
- **Lighting:** Matahari terang, bayangan tajuk
- **Foreground dan kedalaman:** Rumput, jalan batu, batang pohon kanan · Jalan di depan, rumah tengah, pohon belakang
- **Reveal:** Pot, lentera dan detail pintu membesar
- **Kesesuaian gerak:** Dorongan sepanjang akses memperjelas entrance

#### **C. Camera Movement**

Maju menuju pintu sambil sedikit bergeser melingkar ke kiri hingga tampak lebih frontal.

**Tempo:** Awal relatif perlahan, perubahan skala lebih nyata pada paruh akhir; secara keseluruhan sedang.

**Camera:** Dolly-In + Gentle Orbit Left.

---

<a id="shot-02"></a>

### Shot 02 · living room

**Time:** 5.30–8.37s · **Duration:** 3.07s

![Kolase Shot 02](media/shot-02.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding krem dengan ceruk TV berbusur dangkal, diapit lentera hitam; kolom atau pilaster bulat di kanan ceruk. Plafon putih berlis dan downlight, balok kayu terlihat di akhir. Lantai papan cokelat. Bukaan kaca tinggi berpetak hitam dengan tirai krem berada di kiri ceruk.

**Furnitur & dekorasi**

> Sofa krem berlengan gulung di kanan menghadap TV, bantal polos dan bermotif kecil. Meja kopi persegi panjang kayu dengan rak bawah, buku dan vas bunga oranye di atas karpet motif klasik pucat; kabinet TV kayu berpintu samping, rak terbuka tengah dan keranjang. Kursi berkerangka ramping gelap di dekat tanaman tinggi, dudukan krem di tepi kiri jendela dan keranjang anyam di depan sofa.

**Lingkungan**

> Taman hijau dan bunga tampak melalui kaca kiri; sinar dari kiri membentuk pola terang di lantai dan karpet. Tanaman berdaun kecil tinggi di sudut.

#### **B. Framing & Lighting**

- **Fokus:** Ceruk TV lalu kelompok duduk
- **Camera Start:** Dekat sisi sofa kanan · Serong ke ceruk TV · oblique · Sekitar tinggi mata duduk/berdiri rendah · Sedikit mengarah ke bawah
- **Framing:** Medium wide ceruk dan sofa dekat → Wide sofa, meja, jendela dan ceruk
- **Lighting:** Cahaya jendela kiri, downlight
- **Foreground dan kedalaman:** Bantal dan lengan sofa · Sofa dekat, meja tengah, ceruk dan jendela belakang
- **Reveal:** Bukaan kiri, meja, kursi dan keranjang masuk frame
- **Kesesuaian gerak:** Mundur membuka layout kelompok duduk

#### **C. Camera Movement**

Mundur sambil membuka pandangan ke kiri dari ceruk TV menuju keseluruhan kelompok duduk.

**Tempo:** Tempo sedang; perubahan framing berlangsung berkelanjutan selama sekitar tiga detik.

**Camera:** Dolly-Out + Pan Left.

---

<a id="shot-03"></a>

### Shot 03 · kitchen

**Time:** 8.37–11.53s · **Duration:** 3.17s

![Kolase Shot 03](media/shot-03.jpg)

#### **A. Desain area**

**Arsitektur**

> Dapur dengan kabinet perimeter berbentuk L pada dinding belakang dan kanan serta island persegi panjang di kiri depan, membentuk lorong kerja. Jendela lengkung berpetak hitam pada dinding belakang. Kabinet panel bingkai krem hingga dekat plafon, countertop pucat bercorak batu, backsplash krem bertekstur, lantai papan cokelat. Downlight dan pendant silinder di atas island, lampu bawah kabinet dan hood.

**Furnitur & dekorasi**

> Range stainless-look dengan oven dan kisi kompor hitam di sisi kanan, hood cerobong logam di atas. Sink apron-front putih di bawah jendela dengan keran logam; perangkat berpermukaan logam menyerupai dishwasher di bawah counter sebelahnya. Keran lengkung hitam kedua terlihat dekat kompor, tetapi bak keduanya tidak jelas; dua rak kayu terbuka di kanan hood berisi tanaman dan wadah. Dua bangku bundar kayu di ujung island, runner anyam di lorong, talenan, perkakas, panci putih dan mangkuk buah oranye.

**Lingkungan**

> Jendela belakang terang dengan pot bunga merah; pandangan luar rinci tidak jelas. Cahaya alami berpadu dengan lampu tugas hangat.

#### **B. Framing & Lighting**

- **Fokus:** Range, hood dan bidang kerja
- **Camera Start:** Di ambang dapur dekat island · Serong sepanjang lorong menuju counter kanan dan jendela belakang · oblique · Sekitar tinggi mata · Sedikit ke bawah
- **Framing:** Wide dari pintu dengan island dan perimeter → Medium dekat range dan hood
- **Lighting:** Downlight, pendant, cahaya jendela dan lampu kerja
- **Foreground dan kedalaman:** Tepi ambang, island dan bangku · Island dekat, lorong dan kabinet kanan, jendela belakang
- **Reveal:** Detail range, rak dan backsplash membesar
- **Kesesuaian gerak:** Maju menuju zona memasak menjelaskan detail kerja

#### **C. Camera Movement**

Maju masuk sepanjang lorong sambil mengarahkan pandangan ke kanan menuju kompor dan hood.

**Tempo:** Pembesaran dan pergeseran kanan berlangsung kontinu dengan tempo sedang.

**Camera:** Dolly-In + Pan Right.

---

<a id="shot-04"></a>

### Shot 04 · bedroom

**Time:** 11.53–14.57s · **Duration:** 3.03s

![Kolase Shot 04](media/shot-04.jpg)

#### **A. Desain area**

**Arsitektur**

> Dinding hijau abu lembut, jendela lengkung berpetak hitam tepat di atas headboard dengan tirai krem pada batang gelap; bukaan lain tampak di kiri akhir. Plafon putih dengan balok kayu, pendant berbentuk rangka lentera dan sconce hitam di sisi jendela. Lantai tampak kayu terang dan karpet pucat.

**Furnitur & dekorasi**

> Ranjang kayu dengan headboard dan footboard, bedding putih bertekstur dan selimut rajut krem menjuntai, bantal krem serta satu bantal aksen karat. Nakas laci kayu di dua sisi, lampu meja kiri dan vas bunga kanan. Kursi krem dan tanaman tinggi di sudut kiri; sudut furnitur kayu dengan pot terlihat di depan kiri akhir.

**Lingkungan**

> Daun hijau dan bunga merah tampak di jendela, cahaya alami dari belakang ranjang berpadu sconce serta lampu meja hangat.

#### **B. Framing & Lighting**

- **Fokus:** Ranjang dan jendela lengkung
- **Camera Start:** Dekat sisi kanan/kaki ranjang · Serong menuju headboard dan jendela · oblique · Sekitar tinggi mata · Sedikit ke bawah
- **Framing:** Medium ranjang atas, jendela, nakas kanan → Wide ranjang utuh, nakas dan sudut kiri
- **Lighting:** Cahaya jendela, sconce dan lampu meja
- **Foreground dan kedalaman:** Bedding dan nakas kanan · Ranjang dekat, dinding dan jendela belakang
- **Reveal:** Footboard, balok, pendant dan sudut kiri terbuka
- **Kesesuaian gerak:** Mundur memperlihatkan proporsi ranjang dan layout

#### **C. Camera Movement**

Mundur dari ranjang dan sedikit membuka pandangan ke kiri sehingga kaki ranjang dan sudut ruang masuk.

**Tempo:** Tempo sedang; pelebaran berlangsung kontinu selama sekitar tiga detik.

**Camera:** Dolly-Out + Gentle Pan Left.

---

<a id="shot-05"></a>

### Shot 05 · walk-in closet

**Time:** 14.57–17.10s · **Duration:** 2.53s

![Kolase Shot 05](media/shot-05.jpg)

#### **A. Desain area**

**Arsitektur**

> Ruang memanjang dengan lorong tengah di antara penyimpanan terbuka dua sisi, plafon pelana putih dengan balok kayu mengikuti kemiringan. Jendela tinggi lengkung berpetak hitam pada ujung sumbu lorong dengan ceruk putih. Lantai tampak kayu terang dan runner pucat; downlight serta lampu rak hangat.

**Furnitur & dekorasi**

> Sistem lemari terbuka krem dengan rel pakaian dua tingkat, kubi atas berisi keranjang anyam, laci kayu bergagang gelap di kanan. Di ujung kanan terdapat bidang meja pucat, cermin tegak dan vas bunga; bangku ottoman kotak krem sedikit ke kiri lorong. Pot bunga putih di bawah kanan jendela dan properti kecil pada ambang.

**Lingkungan**

> Melalui jendela terlihat bunga merah-oranye, dedaunan dan bagian bangunan beratap di luar. Cahaya alami di ujung lorong.

#### **B. Framing & Lighting**

- **Fokus:** Jendela ujung dan lorong
- **Camera Start:** Di ambang ruang penyimpanan · Sepanjang sumbu lorong ke jendela ujung · frontal · Sekitar tinggi mata · Hampir mendatar
- **Framing:** Wide hampir simetris dari ambang, dua sisi rak → Medium jendela, rel pakaian dan meja kanan
- **Lighting:** Daylight ujung, downlight dan lampu rak
- **Foreground dan kedalaman:** Kusen gelap dan rak kiri-kanan · Kusen dekat, ottoman tengah, jendela belakang
- **Reveal:** Kusen keluar, pakaian dan jendela membesar
- **Kesesuaian gerak:** Maju menegaskan kedalaman lorong

#### **C. Camera Movement**

Maju dari ambang menyusuri lorong tengah menuju jendela, tanpa putaran besar.

**Tempo:** Tempo sedang; perubahan skala cukup nyata dan berkelanjutan sepanjang 2,53 detik.

**Camera:** Dolly-In.

---

<a id="shot-06"></a>

### Shot 06 · bathroom

**Time:** 17.10–19.90s · **Duration:** 2.80s

![Kolase Shot 06](media/shot-06.jpg)

#### **A. Desain area**

**Arsitektur**

> Kamar mandi memanjang dengan bathtub di bawah jendela persegi panjang berpetak hitam di ujung, toilet di depan kanan tub dan vanity pada sisi kanan dekat kamera. Dinding putih krem, ceruk tinggi melengkung di kanan jendela dengan rak, ubin kecil pucat pada bagian bawah; lantai ubin kotak warna tanah. Balok kayu di plafon putih, tirai krem dan sconce hitam.

**Furnitur & dekorasi**

> Bathtub putih oval berdiri bebas, keran hitam dari dinding di belakangnya, tray dengan botol. Toilet putih di kanan, vanity kayu berpintu panel dan laci, vessel sink putih oval, keran hitam, cermin bingkai hitam bagian kanan. Tanaman tinggi berdaun ramping di antara tub dan toilet/ceruk, keranjang anyam dengan handuk kiri, pot kecil di ambang dan vas di vanity.

**Lingkungan**

> Bunga merah-oranye, daun, dan bangunan terang tampak melalui jendela. Sinar kuat dari ujung ruang jatuh pada lantai; lampu dinding hangat di sisi vanity.

#### **B. Framing & Lighting**

- **Fokus:** Tub dan jendela lalu layout kamar mandi
- **Camera Start:** Dekat bathtub dan tanaman, menghadap ujung ruang · Serong ringan ke jendela dan ceruk kanan · oblique · Sekitar tinggi mata · Sedikit ke bawah
- **Framing:** Medium dekat sebagian tub, toilet dan tanaman → Wide dari ambang, tub, toilet, vanity dan lantai
- **Lighting:** Daylight kuat, sconce hangat
- **Foreground dan kedalaman:** Bagian tub, toilet dan tanaman · Vanity dekat akhir, toilet tengah, tub dan jendela jauh
- **Reveal:** Vanity, keranjang, lantai, balok dan ambang terbuka
- **Kesesuaian gerak:** Mundur membuka hubungan perlengkapan kamar mandi

#### **C. Camera Movement**

Mundur dari bathtub menuju ambang, membuka vanity kanan serta keseluruhan ruang.

**Tempo:** Tempo sedang; pelebaran kontinu selama 2,8 detik, tanpa fase berhenti nyata.

**Camera:** Dolly-Out.
