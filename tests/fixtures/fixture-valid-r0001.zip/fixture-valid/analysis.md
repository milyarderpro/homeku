# Synthetic fixture — not a reference

## Identitas

| field | value |
| --- | --- |
| format_version | 1.0 |
| id | fixture-valid |
| revision | 1 |
| title | Synthetic fixture fixture-valid |

## Ringkasan

Contoh sintetis untuk validasi pustaka. Tidak menggambarkan rumah nyata.

## Cakupan

| field | value |
| --- | --- |
| method | synthetic-fixture |
| limitations | Data sintetis untuk tes kontrak; bukan audit rumah atau video referensi. |

## Timeline

| shot | start_s | end_s | areas | transition | continuity |
| --- | --- | --- | --- | --- | --- |
| shot-01 | 0 | 0.6 | bathroom; laundry | cut | unknown |
| shot-02 | 0.6 | 1.2 | kitchen | end | unknown |

![Storyboard](media/storyboard.jpg)

<a id="shot-01"></a>
## Shot shot-01

### Desain dan konfigurasi

Contoh uraian sintetis; fakta untuk katalog berada pada tabel berikut.

### Fakta

| id | domain | subject | attribute | value | state | confidence | evidence |
| --- | --- | --- | --- | --- | --- | --- | --- |
| f-01 | space | bathroom | layout | raised tub platform | observed | medium | [awal](media/shot-01/start.jpg); [akhir](media/shot-01/end.jpg) |
| f-02 | furnishing | bathroom | storage | vanity cabinet | not-visible | low | [awal](media/shot-01/start.jpg); [akhir](media/shot-01/end.jpg) |
| f-03 | material | wall | finish | unknown | unknown | unknown | - |

### Komposisi

| field | value |
| --- | --- |
| overview_timestamp_s | 0 |
| overview_role | start |
| overview_reason | Cakupan area paling jelas dalam fixture. |
| overview_exception | - |
| camera_position | Di dekat sudut masuk area; estimasi visual fixture. |
| camera_direction | Serong menuju subjek. |
| view_angle | oblique |
| camera_height | unknown |
| camera_tilt | unknown |
| foreground | Bukaan di tepi layar. |
| depth | Lapisan dekat dan jauh. |
| reveal | Bagian samping area terlihat. |
| start_composition | Cakupan awal. |
| end_composition | Cakupan akhir. |
| motion_compatibility | Adaptasi posisi serong serta peran awal/akhir sesuai gerakan sumber. |

![Gambaran area](media/shot-01/area-overview.jpg)

### Kamera

```text
Dolly-In (~1.3×) + gentle Pan Right (~15°).
```

| phase | start_s | end_s | components | anchor | tempo | speed_change | basis | evidence | confidence | uncertainty |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| phase-01 | 0.0 | 0.6 | Dolly-In (~1.3×) + gentle Pan Right (~15°) | subjek fixture | moderate | constant | Angka adalah contoh sintaks fixture, bukan pengukuran kamera. | [awal](media/shot-01/start.jpg); [akhir](media/shot-01/end.jpg) | low | Simulasi kontrak, bukan audit gerakan. |

### Ketidakpastian

Seluruh isi merupakan data uji sintetis.

<a id="shot-02"></a>
## Shot shot-02

### Desain dan konfigurasi

Contoh uraian sintetis; fakta untuk katalog berada pada tabel berikut.

### Fakta

| id | domain | subject | attribute | value | state | confidence | evidence |
| --- | --- | --- | --- | --- | --- | --- | --- |
| f-01 | space | kitchen | layout | curved island | observed | medium | [awal](media/shot-02/start.jpg); [akhir](media/shot-02/end.jpg) |
| f-02 | furnishing | kitchen | storage | vanity cabinet | not-visible | low | [awal](media/shot-02/start.jpg); [akhir](media/shot-02/end.jpg) |
| f-03 | material | wall | finish | unknown | unknown | unknown | - |

### Komposisi

| field | value |
| --- | --- |
| overview_timestamp_s | 1.1 |
| overview_role | end |
| overview_reason | Cakupan area paling jelas dalam fixture. |
| overview_exception | - |
| camera_position | Di dekat sudut masuk area; estimasi visual fixture. |
| camera_direction | Serong menuju subjek. |
| view_angle | oblique |
| camera_height | unknown |
| camera_tilt | unknown |
| foreground | Bukaan di tepi layar. |
| depth | Lapisan dekat dan jauh. |
| reveal | Bagian samping area terlihat. |
| start_composition | Cakupan awal. |
| end_composition | Cakupan akhir. |
| motion_compatibility | Adaptasi posisi serong serta peran awal/akhir sesuai gerakan sumber. |

![Gambaran area](media/shot-02/area-overview.jpg)

### Kamera

```text
Dolly-Out (~1.3×).
```

| phase | start_s | end_s | components | anchor | tempo | speed_change | basis | evidence | confidence | uncertainty |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| phase-01 | 0.6 | 1.2 | Dolly-Out (~1.3×) | subjek fixture | moderate | constant | Angka adalah contoh sintaks fixture, bukan pengukuran kamera. | [awal](media/shot-02/start.jpg); [akhir](media/shot-02/end.jpg) | low | Simulasi kontrak, bukan audit gerakan. |

### Ketidakpastian

Seluruh isi merupakan data uji sintetis.

## Hubungan antarshot

| from | to | relation | description | state | confidence | evidence |
| --- | --- | --- | --- | --- | --- | --- |

## Keterbatasan

Data sintetis untuk tes kontrak; bukan audit rumah atau video referensi.
